# --- v59: تشغيل نسخة "التحديث الداخلي" (updates\\current) بدل الكود المضمَّن بالـexe إذا وُجدت وكانت أحدث (lab_overlay.py) ---
try:
    import lab_overlay
    lab_overlay.boot(__file__, globals())
except SystemExit:
    raise
except ImportError:
    pass
from flask import Flask, render_template, request, redirect, url_for, session, g, flash, send_file, jsonify, get_flashed_messages
from datetime import datetime, date, timedelta
from functools import wraps
from werkzeug.utils import secure_filename
from markupsafe import Markup, escape
from io import BytesIO
import os
import json
import re
from html import escape as _html_escape
import subprocess
import webbrowser
import shutil
import sqlite3
from markupsafe import escape as html_escape
import tempfile
import zipfile
import base64
import threading
import time

from database import close_request_connections
from database import text_style_css, sanitize_text_style, TEXT_STYLE_FONTS
from database import write_pending_preset_logo
from database import (get_db, init_db, hash_password, get_setting, set_setting,
                       get_test_price, find_or_create_doctor, find_or_create_referral_center,
                       center_has_price_list, expand_required_tests, sync_test_sections,
                       get_report_template, save_report_template,
                       get_examining_doctors, set_examining_doctors, add_examining_doctor,
                       get_examining_doctors_full, add_examining_doctor_full,
                       update_examining_doctor, delete_examining_doctor, move_examining_doctor,
                       get_letterhead_doctors,
                       get_examining_tests, get_examining_rates_map,
                       set_examining_doctor_rate, compute_examining_doctor_fee,
                       recompute_examining_doctor_fee,
                       find_reference_range,
                       save_saved_report, get_saved_report, search_saved_reports,
                       get_digital_stamps, get_digital_stamp, add_digital_stamp,
                       update_digital_stamp, delete_digital_stamp, find_stamps_for_report,
                       get_stamp_placements, upsert_stamp_placement, remove_stamp_placement,
                       get_report_layout, save_report_layout, reset_report_layout, get_raw_layout,
                       find_last_visit_by_name_age, get_visit_completed_tests,
                       save_visit_previous_merges, get_visit_previous_merges,
                       get_result_layout, effective_labels, save_result_layout, RESULT_STYLES,
                       RESULT_LABEL_DEFAULTS, get_extra_col_values, save_extra_col_values,
                       get_previous_history, get_row_notes, save_row_note,
                       THEME_PRESETS, merged_exclude_keywords, MERGED_EXCLUDE_DEFAULT, resolve_theme_colors,
                       get_visit_prev_pref, set_visit_prev_pref, effective_prev_count,
                       peek_next_sample_no, resolve_visit_sample_no)
from daily_counter import get_patient_number_of_day
import accounts_search as acs
import excel_export

ARABIC_NAME_TRANSLITERATION_MAP = [
    ("عبدال", "Abdul"), ("عبد ال", "Abdul"), ("أبو", "Abu"), ("ابو", "Abu"),
    ("ال", "Al"), ("إ", "I"), ("أ", "A"), ("آ", "Aa"), ("ا", "a"),
    ("ب", "b"), ("ت", "t"), ("ث", "th"), ("ج", "j"), ("ح", "h"), ("خ", "kh"),
    ("د", "d"), ("ذ", "th"), ("ر", "r"), ("ز", "z"), ("س", "s"), ("ش", "sh"),
    ("ص", "s"), ("ض", "d"), ("ط", "t"), ("ظ", "th"), ("ع", "'"), ("غ", "gh"),
    ("ف", "f"), ("ق", "q"), ("ك", "k"), ("ل", "l"), ("م", "m"), ("ن", "n"),
    ("ه", "h"), ("و", "w"), ("ي", "y"), ("ى", "a"), ("ة", "a"), ("ء", "'"),
    (" ", " "),
]


# قاموس أسماء عربية/عراقية شائعة جاهزة بترجمتها الإنكليزية المعتمدة —
# هذا هو الحل العملي الوحيد لمشكلة الحروف المتحركة القصيرة غير المكتوبة
# بالعربي (مثال: "سمر" حروفها فقط س-م-ر، ما فيها أي حرف يدل على الفتحة بين
# الحروف، فالخوارزمية الحرف-بحرف تطلعها "Smr" مهما حاولنا نحسّنها، لأنها
# فعليًا ما "ترى" الحركة القصيرة). لأي اسم موجود هنا، تُستخدم هذي الترجمة
# مباشرة بدل الخوارزمية. القائمة قابلة للتوسيع من الإعدادات (راجع
# get_name_translit_overrides) بدون الحاجة لتعديل الكود لكل اسم جديد.
COMMON_NAME_TRANSLITERATIONS = {
    "سمر": "Samar", "عمر": "Omar", "بشرى": "Bushra", "بشار": "Bashar",
    "زهراء": "Zahraa", "زهرة": "Zahra", "نور": "Noor", "نورا": "Noora",
    "هدى": "Huda", "رنا": "Rana", "رشا": "Rasha", "دينا": "Dina", "هبة": "Hiba",
    "سارة": "Sara", "سارا": "Sara", "مريم": "Mariam", "ليلى": "Layla",
    "فاطمة": "Fatima", "زينب": "Zainab", "خديجة": "Khadija", "عائشة": "Aisha",
    "آية": "Aya", "أمل": "Amal", "امل": "Amal", "أسماء": "Asmaa", "اسماء": "Asmaa",
    "ياسمين": "Yasmin", "شيماء": "Shaimaa", "إيمان": "Eman", "ايمان": "Eman",
    "منى": "Mona", "سلمى": "Salma", "لينا": "Lina", "رغد": "Raghad",
    "تبارك": "Tabarak", "ملك": "Malak", "جنى": "Jana", "غدير": "Ghadeer",
    "بتول": "Batool", "دعاء": "Duaa", "ابتسام": "Ibtisam", "وفاء": "Wafaa",
    "أحمد": "Ahmed", "احمد": "Ahmed", "محمد": "Mohammed", "محمود": "Mahmoud",
    "علي": "Ali", "حسين": "Hussein", "حسن": "Hassan", "كريم": "Karim",
    "يوسف": "Yousif", "إبراهيم": "Ibrahim", "ابراهيم": "Ibrahim",
    "عبدالله": "Abdullah", "عبد الله": "Abdullah", "خالد": "Khalid",
    "سعد": "Saad", "سعيد": "Saeed", "طارق": "Tariq", "زياد": "Ziad",
    "مصطفى": "Mustafa", "مهند": "Mohanad", "منتظر": "Muntadher",
    "حيدر": "Haider", "قاسم": "Qasim", "جعفر": "Jafar", "ثامر": "Thamer",
    "وليد": "Walid", "سامر": "Samer", "زيد": "Zaid", "فراس": "Firas",
    "عدنان": "Adnan", "رياض": "Riyadh", "باسل": "Basil", "نبيل": "Nabil",
    "أنور": "Anwar", "انور": "Anwar", "جاسم": "Jasim", "كاظم": "Kadhim",
    "صادق": "Sadiq", "ناصر": "Nasser", "فؤاد": "Fouad", "غانم": "Ghanim",
    "رعد": "Raad", "سيف": "Saif", "أمير": "Ameer", "امير": "Ameer",
    "دانيال": "Daniel", "آدم": "Adam", "ادم": "Adam", "يحيى": "Yahya",
    "عمار": "Ammar", "فادي": "Fadi", "رافد": "Rafid", "أنس": "Anas", "انس": "Anas",
    "بلال": "Bilal", "سلام": "Salam", "حازم": "Hazim", "ماجد": "Majid",
}


def get_name_translit_overrides(db):
    """تصحيحات ترجمة أسماء يضيفها المختبر بنفسه من الإعدادات (سطر لكل اسم
    بصيغة "عربي=إنكليزي") — تأخذ أولوية حتى فوق القاموس الجاهز أعلاه،
    فتسمح بتصحيح أي اسم يطلع غلط دون الحاجة لتعديل الكود."""
    raw = get_setting(db, "name_translit_overrides", "")
    overrides = {}
    for line in raw.splitlines():
        if "=" not in line:
            continue
        ar, _, en = line.partition("=")
        ar, en = ar.strip(), en.strip()
        if ar and en:
            overrides[ar] = en
    return overrides


def _translit_word_fallback(word):
    """الخوارزمية الاحتياطية حرف-بحرف — تُستخدم فقط للكلمات غير الموجودة
    بالقاموس أعلاه ولا بتصحيحات الإعدادات. تحشر حرف "a" تخمينيًا بين حرفين
    ساكنين متتاليين (زي "سمر" لو ما كانت بالقاموس: s+m+r → Samar) لتقريب
    النطق، لكنها تبقى تخمينًا وليست مضمونة الدقة 100% — العربي المكتوب
    عادة ما يحدد الحركات القصيرة أصلاً، فمافي خوارزمية تقدر "تخمّنها" دايمًا
    صح؛ التغطية المضمونة الوحيدة هي عبر القاموس/تصحيحات الإعدادات أعلاه."""
    if not word:
        return ""
    chunks = []
    i, n = 0, len(word)
    while i < n:
        matched = False
        for ar, en in ARABIC_NAME_TRANSLITERATION_MAP:
            if ar != " " and word[i:i + len(ar)] == ar:
                chunks.append(en)
                i += len(ar)
                matched = True
                break
        if not matched:
            chunks.append(word[i])
            i += 1

    def has_vowel(chunk):
        return any(c in "aeiou" for c in chunk.lower())

    out = []
    for idx, chunk in enumerate(chunks):
        if (
            idx > 0 and chunk and out and out[-1]
            and not has_vowel(chunk) and not has_vowel(out[-1])
            and out[-1][-1].isalpha() and chunk[0].isalpha()
        ):
            out.append("a")
        out.append(chunk)
    return "".join(out)


def transliterate_arabic_name(name, db=None):
    """يرجّع اقتراح إنكليزي لاسم عربي — اقتراح قابل للتعديل يدويًا لاحقًا من
    الواجهة. الأولوية: (1) تصحيحات الإعدادات الخاصة بهذا المختبر، (2) قاموس
    الأسماء الشائعة الجاهز، (3) خوارزمية تقريبية حرف-بحرف لأي اسم غير معروف
    (راجع _translit_word_fallback لسبب كونها تقريبية وليست مضمونة الدقة —
    محدودية بالعربي نفسه، مو بالكود). تُطبَّق كلمة-كلمة حتى تشتغل مع الأسماء
    المركّبة (اسم + اسم أب + اسم جد...الخ)."""
    if not name:
        return ""
    if db is None:
        try:
            db = get_db()
        except Exception:
            db = None
    overrides = get_name_translit_overrides(db) if db is not None else {}
    words_out = []
    for word in name.strip().split(" "):
        if not word:
            continue
        if word in overrides:
            words_out.append(overrides[word])
        elif word in COMMON_NAME_TRANSLITERATIONS:
            words_out.append(COMMON_NAME_TRANSLITERATIONS[word])
        else:
            words_out.append(_translit_word_fallback(word).capitalize())
    return " ".join(words_out)



from translations import t
from barcode_gen import generate_code39, generate_code128, generate_qr
import cloud_sync
import astm_host
import license_manager
import auto_updater
import secrets
import faulthandler

# ------------------------------------------------------------------------
# شبكة أمان لتسجيل كراش أعمق من خطأ بايثون العادي (segfault/stack overflow
# نادر يقفل العملية كاملة بدون أي traceback بالتيرمينال) — faulthandler
# فقط، بدون أي errorhandler عام (كان سبب كسر كل الصفحات بمحاولة سابقة).
# يُكتب بملف crash_log.txt بمجلد البرنامج نفسه — راجعه أول شي لو انغلق
# البرنامج فجأة بدون أي رسالة حمراء بالتيرمينال.
import sys
if getattr(sys, "frozen", False) and (sys.stdout is None or sys.stderr is None):
    # نسخة Setup بدون نافذة سوداء (--noconsole): ما فيه stdout/stderr، فنوجّههم لملف يُصفَّر كل تشغيل
    try:
        _srv_log = open(os.path.join(os.path.dirname(sys.executable), "server_log.txt"), "w", encoding="utf-8", buffering=1)
        if sys.stdout is None:
            sys.stdout = _srv_log
        if sys.stderr is None:
            sys.stderr = _srv_log
    except Exception:
        pass
_CRASH_LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "crash_log.txt")
try:
    _crash_log_file = open(_CRASH_LOG_PATH, "a", encoding="utf-8", buffering=1)
    faulthandler.enable(file=_crash_log_file, all_threads=True)
except Exception:
    _crash_log_file = None

# ------------------------------------------------------------------------
# شبكة أمان ثانية -- لأخطاء بايثون العادية (Exception عادي بصفحة معيّنة،
# مثل خطأ "Create Visit")، وليس الكراشات العميقة اللي يمسكها faulthandler
# فوق. بدل ما نعترض الأخطاء بأنفسنا (errorhandler عام كسر الصفحات بمحاولة
# سابقة)، نضيف بس "وجهة ملف" لنظام التسجيل الداخلي بفلاسك نفسه (logging)
# -- فلاسك أصلاً يسجّل كل خطأ غير متوقع داخليًا بدون ما نلمس أي سلوك أو
# نغيّر شكل صفحة الخطأ المعروضة إطلاقًا؛ هذا فقط يضيف له وجهة ملف إضافية.
# النتيجة: error_log.txt (بجذر البرنامج، جنب crash_log.txt) يحتوي كل
# Traceback كامل لأي صفحة تطيح، بدون أي خطر تغيير سلوك الموقع.
import logging as _logging
_error_log_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "error_log.txt")
_error_file_handler = _logging.FileHandler(_error_log_path, encoding="utf-8")
_error_file_handler.setLevel(_logging.ERROR)
_error_file_handler.setFormatter(_logging.Formatter("%(asctime)s %(levelname)s: %(message)s"))

app = Flask(__name__)
# قوالب التحديث الداخلي تتقدّم على المضمّنة بالـexe (والقالب غير الموجود بالتحديث يؤخذ من المضمّن)
_ov_dir = os.environ.get("LIS_OVERLAY_DIR")
if _ov_dir and os.path.isdir(os.path.join(_ov_dir, "templates")):
    from jinja2 import ChoiceLoader, FileSystemLoader
    app.jinja_loader = ChoiceLoader([FileSystemLoader(os.path.join(_ov_dir, "templates")), app.jinja_loader])
app.logger.addHandler(_error_file_handler)
app.logger.setLevel(_logging.ERROR)
# مفتاح جلسة عشوائي مختلف بكل مرة يُشغَّل فيها السيرفر فعليًا (وليس نفس
# نص ثابت دائمًا) — بهذا الشكل أي كوكي دخول قديم صار غير صالح تلقائيًا بعد
# أي إعادة تشغيل حقيقية للبرنامج (إعادة تشغيل الجهاز، إيقاف ثم تشغيل من
# جديد...)، فيُطلب اسم المستخدم وكلمة المرور من جديد بشكل مضمون، بدل أن
# يبقى المتصفح مسجّل دخول تلقائيًا لأشهر لمجرد أن الكوكي القديم لسا شغّال.
app.secret_key = secrets.token_hex(32)
app.config["PERMANENT_SESSION_LIFETIME"] = 60 * 60 * 24 * 30  # 30 days when "remember me" is checked

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
ALLOWED_LOGO_EXT = {"png", "jpg", "jpeg", "gif", "svg", "webp"}
# صور الأختام/التواقيع — بدون svg (نحتاج نفتحها بمكتبة الصور Pillow لتحويل
# أي خلفية شفافة/ملوّنة إلى خلفية بيضاء صلبة، وsvg متجه وليس بكسلي فلا يدعمه
# نفس المسار).
ALLOWED_STAMP_EXT = {"png", "jpg", "jpeg", "webp"}
STAMPS_UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "static", "uploads", "stamps")
os.makedirs(STAMPS_UPLOAD_DIR, exist_ok=True)
# صور خلفية شاشة الترحيب (dashboard) — صور فوتوغرافية بس، بدون svg/gif
# (svg ما إله فايدة كخلفية ممتدة، وgif المتحرك يشتت الانتباه بشاشة ترحيب).
ALLOWED_DASHBOARD_BG_EXT = {"png", "jpg", "jpeg", "webp"}


def _save_stamp_image_on_white_bg(file_storage, stamp_id, suffix=""):
    """يحفظ صورة الختم أو التوقيع المرفوعة كملف PNG بخلفية بيضاء صلبة دائمًا —
    حتى لو الصورة الأصلية عندها خلفية شفافة (PNG) أو ملوّنة (خلفية زرقاء/
    رمادية من سكنر)، لأن ختم/توقيع بخلفية غير بيضاء يظهر "نشازًا" واضحًا
    فوق التقرير الأبيض. يفتح الصورة بمكتبة Pillow، يدمجها فوق طبقة بيضاء
    (فتُصبح أي شفافية بيضاء تلقائيًا)، ثم يحفظها باسم stamp_<id><suffix>.png
    داخل static/uploads/stamps. suffix فاضي لصورة الختم نفسها، و"_sig" لصورة
    التوقيع المنفصلة (لو الختم من نوع "ختم + توقيع" بصورتين). يرجّع اسم
    الملف النهائي فقط (بدون المسار الكامل) ليُخزَّن بعمود digital_stamps.

    يتطلب: pip install Pillow (لو غير مثبّت أصلاً على جهاز السيرفر)."""
    from PIL import Image

    img = Image.open(file_storage.stream).convert("RGBA")
    white_bg = Image.new("RGBA", img.size, (255, 255, 255, 255))
    white_bg.alpha_composite(img)
    flattened = white_bg.convert("RGB")

    filename = f"stamp_{stamp_id}{suffix}.png"
    flattened.save(os.path.join(STAMPS_UPLOAD_DIR, filename), format="PNG")
    return filename


def _serialize_stamp_placements(placements):
    """يحوّل صفوف report_stamp_placements (sqlite3.Row، غير قابلة للتحويل
    لـJSON مباشرة عبر فلتر tojson بالقالب) لقائمة قواميس عادية بنفس أسماء
    الحقول اللي يتوقعها partials/stamp_picker.html (placement_id، image_url،
    signature_url...). يقبل أيضًا القواميس الجاهزة (من الإلصاق التلقائي
    بـ_print_report_impl) فيمررها كما هي بعد إكمال أي مفتاح ناقص فقط —
    فالدالة idempotent وآمنة الاستدعاء مرتين على نفس القائمة."""
    out = []
    for p in placements:
        keys = p.keys()
        image_filename = p["image_filename"] if "image_filename" in keys else None
        signature_filename = p["signature_filename"] if "signature_filename" in keys else None
        out.append({
            "placement_id": p["id"] if "id" in keys else None,
            "stamp_id": p["stamp_id"],
            "label": p["label"] if "label" in keys else "",
            "pos_x": p["pos_x"], "pos_y": p["pos_y"],
            "width": p["width"] or (p["default_width"] if "default_width" in keys else 140),
            "image_url": url_for("static", filename=f"uploads/stamps/{image_filename}") if image_filename else None,
            "signature_url": url_for("static", filename=f"uploads/stamps/{signature_filename}") if signature_filename else None,
        })
    return out

ROLE_LABELS = {
    "admin": "Administrator",
    "reception": "Reception",
    "technician": "Lab Technician",
    "supervisor": "Lab Supervisor",
    "accountant": "Accountant",
}

# مدد الترخيص الجاهزة المعروضة بلوحة المصمم عند توليد كود لعميل — نقطة
# #12. المفتاح هو قيمة <option value="..."> بفورم designer_generate،
# والقيمة (label, days): days=None تعني ترخيص دائم فعلي (بدون تاريخ
# انتهاء إطلاقاً، يُخزَّن كـ "PERM" داخل الكود نفسه — راجع
# license_manager.generate_activation_code). التعديل هنا فقط ينعكس تلقائياً
# على القائمة المنسدلة بـ designer/panel.html.
LICENSE_DURATION_PRESETS = {
    "trial": ("تجريبي (3 أيام)", license_manager.TRIAL_DAYS),
    "1day": ("يوم واحد", 1),
    "3days": ("3 أيام", 3),
    "1month": ("شهر", 30),
    "3months": ("3 أشهر", 90),
    "6months": ("6 أشهر", 180),
    "1year": ("سنة", 365),
    "permanent": ("دائم (بدون تاريخ انتهاء)", None),
}
app.jinja_env.globals["LICENSE_DURATION_PRESETS"] = LICENSE_DURATION_PRESETS

# دكتور المختبر الفاحص — the examining lab doctor for a visit (separate from
# the external "referring" doctor already tracked via doctor_id/doctors
# table). Editable now from Management → Settings; this constant is only the
# bootstrap default used the first time (see database.get_examining_doctors).
EXAMINING_DOCTORS = ["د.خليل حمود", "د.هدى نصيف", "د.اسراء عبد الاقر"]

# ------------------------------------------------------------- print reports --
# Maps a test_definitions.code to the printable report template that
# reproduces the lab's paper letterhead for that report type.
REPORT_TEMPLATE_MAP = {
    "CBC": "reports/cbc.html",
    "BF": "reports/blood_film.html",
    "BFRETIC": "reports/blood_film.html",
    "RETIC": "reports/retic_only.html",
    "WBCDIFF": "reports/wbc_differential.html",
    "FLUIDEXAM": "reports/fluid_examination.html",
    "COAG": "reports/coagulation.html",
    "GUE": "reports/urine_exam.html",
    "GSE": "reports/stool_exam.html",
    "SFA": "reports/seminal_fluid.html",
    "BMA": "reports/bma.html",
    "BMBIOPSY": "reports/bm_biopsy.html",
    "SICKLE": "reports/special_hematology.html",
    "HBPREP": "reports/special_hematology.html",
}

# نفس القوائم Macroscopic/Microscopic المكتوبة داخل reports/urine_exam.html،
# reports/stool_exam.html، reports/seminal_fluid.html — نسخة مصدرها الوحيد
# هنا بـ Python (بدل التكرار داخل كل قالب) حتى يقدر _build_exam_sections
# يفرز الباراميترات ويرتبها (مع احترام تخصيص المستخدم عبر تصميم/معاينة
# التقرير: تحريك باراميتر لقسم ثاني، إعادة ترتيب) قبل ما توصل للقالب أصلاً.
# أي تعديل مستقبلي على هذي القوائم يكفي هنا فقط — القوالب تلقائيًا تتبعه.
EXAM_SECTION_NAMES = {
    "GUE": {
        "macro": ["Color", "Specific Gravity", "Reaction (pH)", "Glucose", "Protein", "Ketone",
                  "Bile Pigment", "Urobilinogen", "Nitrite"],
        "micro": ["RBCs", "PUS", "Casts", "Epithelial Cells", "Amorphous", "Mucus", "Crystals",
                  "Parasites", "Parasites / Others"],
    },
    "GSE": {
        "macro": ["Color", "Consistency", "Mucus", "Blood", "Worms", "Worms / Helminths"],
        "micro": ["Pus Cells", "RBCs", "Amoeba (E. histolytica)", "Giardia lamblia", "Helminthes Ova",
                  "Undigested Food Particles", "Fungi", "Fungi / Yeast"],
    },
    "SFA": {
        "macro": ["Volume", "Color", "Color / Appearance", "Liquefaction Time", "Viscosity", "pH"],
        "micro": ["Sperm Count", "Total Sperm Count", "Active", "Active (Progressive)", "Sluggish",
                  "Sluggish (Non-progressive)", "Immotile", "Normal Forms", "Abnormal Forms",
                  "Pus Cells", "RBCs", "Agglutination"],
    },
}


def _build_exam_sections(test_code, params, report_layout):
    """يفرز params لقسمين (macro/micro) حسب EXAM_SECTION_NAMES، مع احترام:
    - report_layout['param_section'][اسم الباراميتر]: يفرض قسم مختلف عن
      الافتراضي (نقل باراميتر من Macroscopic لـ Microscopic أو العكس، من
      لوحة تعديل المعاينة). هذا المفتاح الصحيح والوحيد لهذا الغرض.
    - report_layout['section_order'] القديم: كان يُستخدم لنفس الغرض (dict
      بنفس الشكل)، لكن اسمه تعارض مع مفهوم ثانٍ مختلف كليًا (ترتيب عرض
      الأقسام كقائمة نصوص بقوالب أخرى) وانخزنت له قيمة list بالغلط بقاعدة
      بيانات بعض التحاليل، مما كان يسبب AttributeError دائم عند كل طباعة/
      معاينة لذاك التحليل من هذيك اللحظة فصاعدًا. لهذا صار القسم يتجاهل أي
      قيمة بـ section_order إلا إذا كانت dict فعلاً (توافق قديم آمن) —
      وأي نوع بيانات غلط (list أو غيره) يُتجاهل بهدوء بدل ما يكسر الطباعة.
    - report_layout['param_order'][اسم الباراميتر]: رقم ترتيب صريح ضمن
      قسمه — الباراميترات غير المرتّبة يدويًا تحافظ على ترتيبها الأصلي
      نسبةً لبعضها (sort مستقر) وتُذيّل قائمة قسمها. نفس الحماية من نوع
      بيانات غلط مطبّقة هنا كمان.
    الباراميترات غير المذكورة إطلاقًا بـ EXAM_SECTION_NAMES (أُضيفت لاحقًا
    لهذا التحليل من كتالوج التحاليل) تنزل افتراضيًا بقسم Microscopic —
    بنفس سلوك حلقة "الباقي" القديمة بالقوالب.
    """
    names = EXAM_SECTION_NAMES.get(test_code, {"macro": [], "micro": []})
    report_layout = report_layout if isinstance(report_layout, dict) else {}
    section_overrides = report_layout.get("param_section")
    if not isinstance(section_overrides, dict):
        legacy = report_layout.get("section_order")
        section_overrides = legacy if isinstance(legacy, dict) else {}
    param_order = report_layout.get("param_order")
    if not isinstance(param_order, dict):
        param_order = {}

    def default_section(pname):
        if pname in names["macro"]:
            return "macro"
        return "micro"

    macro_list, micro_list = [], []
    for p in params:
        section = section_overrides.get(p["name"], default_section(p["name"]))
        (macro_list if section == "macro" else micro_list).append(p)

    def sort_key(p):
        return param_order.get(p["name"], 10_000)

    macro_list.sort(key=sort_key)
    micro_list.sort(key=sort_key)
    return macro_list, micro_list


# Blood Film and Retic Count are two SEPARATE orderable tests, but when both
# are ordered for the same visit they should print as ONE Blood-Film-shaped
# report (which already has the Reticulocyte/Corrected Retic fields built
# in) instead of two separate pages. If Retic Count is ordered on its own
# (no Blood Film for that visit), it prints its own small standalone report.
BF_RETIC_LINK = {"BF": "RETIC", "RETIC": "BF", "SICKLE": "HBPREP", "HBPREP": "SICKLE"}   # أزواج تُطبع بتقرير واحد

# Test codes whose printed report gets a blank stamp/signature space for the
# examining doctor (Blood Film, Blood Film + Retic, standalone Retic, Fluid
# examination, Hb Preparation, Sickling, BMA, BM Biopsy, WBC Differential) —
# kept in sync with EXAMINING_TEST_DEFS (the tests a doctor is paid to
# personally examine), since every one of those needs a stamp/signature line
# on its printed report. CBC and the other non-examining report types don't
# get this box.
EXAM_SIGNATURE_TEST_CODES = {"BF", "BFRETIC", "RETIC", "FLUIDEXAM", "HBPREP", "SICKLE", "BMA", "BMBIOPSY", "WBCDIFF",
                              "GUE", "GSE", "SFA"}

# CBC results are grouped on the printed report with a blank spacer row
# between each group, matching the reference report layout.
CBC_ROW_GROUPS = [
    ["WBCs", "NE", "Ly", "MO", "BA", "EO", "NE#", "LY#", "MO#", "BA#", "EO#"],
    ["RBC", "HGB", "HCT", "MCV", "MCH", "MCHC", "RDW", "RDW-SD"],
    ["PLT", "MPV"],
]

# الوحدة الثانية لنتيجة التحليل (مثلاً mg/dL بالإضافة لـ mmol/L) — بعض
# التحاليل تُكتب نتيجتها بوحدتين بنفس الوقت (خصوصًا الكيمياء والهرمونات).
# tp.unit2 و tp.unit2_factor يُضبطان مرة وحدة من صفحة إدارة الوحدات لكل
# باراميتر (اختياري تمامًا)، والقيمة الثانية تُحسب تلقائيًا وقت الطباعة:
# value2 = value1 * unit2_factor. لتحويل عكسي (وحدة أساسية أصغر لوحدة ثانية
# أكبر) استخدم معامل أصغر من 1 بدل قسمة منفصلة — النتيجة نفسها رياضيًا.
def format_unit2_value(value, factor):
    """يرجع نص القيمة المحوّلة للوحدة الثانية، أو None إذا ما ينطبق التحويل
    (نتيجة غير رقمية، أو ما فيه معامل محفوظ لهذا الباراميتر)."""
    if factor in (None, "") or value in (None, ""):
        return None
    try:
        converted = float(value) * float(factor)
    except (TypeError, ValueError):
        return None
    if converted == int(converted):
        return str(int(converted))
    return f"{converted:.3f}".rstrip("0").rstrip(".")


# يحوّل حقل range_text (نفس الحقل الحر الموجود أصلاً بجدول reference_ranges)
# إلى قائمة مستويات جاهزة للعرض بشكل "Normal Range" مفصّل بالتقرير، بدل
# كتابته كسطر نص واحد فقط. الصيغة المتوقعة بخانة range_text: كل مستوى
# بسطر مستقل "التسمية: القيمة" — مثال (زي Triglycerides بالنموذج المرجعي):
#   Borderline high: 150 - 199
#   Normal: Less than 150
#   High: 200 - 499
#   Very high: More than 500
# وسطر بدون ":" (أو حقل range_text بسطر وحيد فقط، مثل "166 - 507") يُعرض
# كقيمة بسيطة بلا تسمية — بنفس شكل باقي التحاليل العادية (Cortisol, TSH...).
def parse_range_tiers(text):
    if not text:
        return []
    tiers = []
    for line in text.split("\n"):
        line = line.strip()
        if not line:
            continue
        if ":" in line:
            label, _, value = line.partition(":")
            tiers.append({"label": label.strip(), "value": value.strip()})
        else:
            tiers.append({"label": None, "value": line})
    return tiers


def _fmt_range_num(n):
    """يشيل .0 الزايدة من الأرقام الصحيحة بس يبقي الكسور كما هي (15 مو 15.0،
    بس 4.8 تضل 4.8) — يُستخدم فقط لبناء نص range_text من قيم رقمية."""
    if n is None:
        return ""
    try:
        f = float(n)
    except (TypeError, ValueError):
        return str(n)
    return str(int(f)) if f.is_integer() else str(f)


def _parse_tier_numeric(value):
    """يحاول يفك نص تيير مثل '11 - 33' أو '11-33' لرقمين (low, high).
    يرجّع (None, None) لو النص مو بصيغة رقم-رقم صافية (مثلاً 'Negative') —
    يبقى بهذي الحالة كنص حر (raw) بدل ما ينكسر."""
    if not value:
        return None, None
    m = re.match(r"^\s*([\-+]?[\d.]+)\s*-\s*([\-+]?[\d.]+)\s*$", value.strip())
    if not m:
        return None, None
    try:
        return float(m.group(1)), float(m.group(2))
    except ValueError:
        return None, None


def reference_range_tiers(row):
    """يفكّك صف reference_ranges وحدة لقائمة 'تييرات' موحّدة (المطلوب: صفحة
    Reference Ranges الجديدة — كل حالة/طور فسيولوجي بسطر مستقل قابل للتحرير
    لحاله)، بغض النظر هل الصف مخزّن بـrange_text (أسطر Label: value متعددة،
    نفس فكرة parse_range_tiers) أو بس بعمودي low/high العاديين (حالة الصف
    البسيط بلا تسميات). كل عنصر: {label, low, high, raw} — raw يبقى النص
    الأصلي إذا قيمة التيير مو 'رقم - رقم' صافية (مثلاً 'Negative')."""
    if row["range_text"]:
        out = []
        for tier in parse_range_tiers(row["range_text"]):
            lo, hi = _parse_tier_numeric(tier["value"])
            out.append({"label": tier["label"], "low": lo, "high": hi,
                        "raw": tier["value"] if lo is None else None})
        return out
    if row["low"] is not None or row["high"] is not None:
        return [{"label": None, "low": row["low"], "high": row["high"], "raw": None}]
    return []


def serialize_range_tiers(tiers):
    """عكس reference_range_tiers: يبني (range_text, low, high) الجاهزين
    للحفظ بصف reference_ranges من قائمة تييرات. لو تيير واحد بس بدون تسمية،
    يُخزَّن بعمودي low/high العاديين مباشرة (بدون range_text) — نفس الأسلوب
    القديم البسيط، حتى لا نعقّد الحالة الشائعة (باراميتر بلا أطوار/حالات).
    لو أكثر من تيير أو فيه تسمية، يُبنى range_text (سطر لكل تيير)، وlow/high
    العاديين ياخذوهم من أول تيير بلا تسمية إن وُجد (تُستخدم بحساب الفلاك
    التلقائي High/Low/Critical — التسميات الثانية بس عرض/طباعة، ما تُستخدم
    بتمييز الفلاك تلقائيًا، نفس قيد النظام الحالي)."""
    tiers = [t for t in tiers if t.get("label") or t.get("low") is not None
             or t.get("high") is not None or t.get("raw")]
    if not tiers:
        return None, None, None
    if len(tiers) == 1 and not tiers[0].get("label"):
        t = tiers[0]
        return None, t.get("low"), t.get("high")
    lines = []
    for t in tiers:
        if t.get("raw"):
            value = t["raw"]
        elif t.get("low") is not None and t.get("high") is not None:
            value = f"{_fmt_range_num(t['low'])} - {_fmt_range_num(t['high'])}"
        elif t.get("low") is not None:
            value = f"> {_fmt_range_num(t['low'])}"
        elif t.get("high") is not None:
            value = f"< {_fmt_range_num(t['high'])}"
        else:
            value = ""
        lines.append(f"{t['label']}: {value}" if t.get("label") else value)
    base = next((t for t in tiers if not t.get("label")), None)
    return "\n".join(lines), (base["low"] if base else None), (base["high"] if base else None)


def get_known_analyzers(db):
    """قائمة أجهزة التحليل المحفوظة بالإعدادات (سطر لكل جهاز) — تُستخدم
    كمقترحات (datalist) بحقل الجهاز وقت إدخال النتيجة وبصفحة النسب الطبيعية."""
    raw = get_setting(db, "known_analyzers", "")
    return [ln.strip() for ln in raw.splitlines() if ln.strip()]


def get_known_units(db):
    """قائمة كل الوحدات المستخدمة فعليًا حاليًا بأي باراميتر بالبرنامج
    (مقترحات datalist بصفحة النسب الطبيعية — المطلوب 6: تعديل/اختيار وحدة
    القياس لكل باراميتر مباشرة من نفس بطاقته، بدل الاضطرار للذهاب لصفحة
    "تعديل الوحدات" المنفصلة كل مرة)."""
    rows = db.execute(
        "SELECT DISTINCT unit FROM test_parameters WHERE unit IS NOT NULL AND TRIM(unit) != '' ORDER BY unit"
    ).fetchall()
    return [r["unit"] for r in rows]


AGE_UNIT_FULL_WORD = {"Hours": "Hour", "Days": "Day", "Weeks": "Week", "Months": "Month", "Years": "Year"}


def format_age_display(age, age_unit):
    """يبني نص عمر المريض المطبوع بالتقرير — كلمة كاملة ("Year") مو حرف
    مختصر ("Y") بناءً على طلب المستخدم، مع مسافة بينه وبين الرقم."""
    if age in (None, ""):
        return ""
    word = AGE_UNIT_FULL_WORD.get(age_unit or "Years", "Year")
    return f"{age} {word}"


# متاح مباشرة كدالة Jinja (parse_range_tiers(text)) حتى تقدر القوالب اللي
# تبني عرض المدى الطبيعي بنفسها (exam_row بـ exam_report_shared.html) تفكّ
# range_text متعدد الأسطر بدون الحاجة لتمرير النسخة المفكوكة يدويًا من
# Python لكل صف — نفس الدالة المستخدمة بجانب custom_rows/combined_panel.
app.jinja_env.globals["parse_range_tiers"] = parse_range_tiers

# عرض المدى الطبيعي بتقارير الفحص (GUE/GSE/SFA) مثل المعاينة المعتمدة:
# أرقام موحّدة (1.005 - 1.030 / 5.0 - 8.0 / 15 - 30) + إلحاق وحدة /HPF وmL وmin
# بالمدى الرقمي فقط. القيم تبقى من قاعدة البيانات (Reference Range) كما هي.
_RANGE_UNIT_SUFFIX = {"/HPF", "mL", "min"}


def _fmt_num_pair(*vals):
    def decs(v):
        s = repr(float(v))
        frac = s.split(".")[1].rstrip("0") if "." in s else ""
        return len(frac)
    nums = [float(v) for v in vals]
    d = max(decs(v) for v in nums)
    if d == 0 and max(abs(v) for v in nums) >= 10:
        return [str(int(v)) for v in nums]
    d = max(d, 1)
    return [f"{v:.{d}f}" for v in nums]


def exam_range_display(range_row, unit=None):
    if not range_row:
        return ""
    txt = (range_row["range_text"] or "").strip() if "range_text" in range_row.keys() else ""
    low, high = range_row["low"], range_row["high"]
    if txt:
        out = txt
    elif low is not None and high is not None:
        a, b = _fmt_num_pair(low, high)
        out = f"{a} - {b}"
    elif low is not None:
        out = "> " + _fmt_num_pair(low)[0]
    elif high is not None:
        out = "< " + _fmt_num_pair(high)[0]
    else:
        return ""
    if unit and unit.strip() in _RANGE_UNIT_SUFFIX and "\n" not in out and re.fullmatch(r"[\d.\s\-–<>≥≤]+", out):
        out = f"{out} {unit.strip()}"
    return out


app.jinja_env.globals["exam_range_display"] = exam_range_display

# ------------------------------------------------------------------------
# تلوين النتيجة غير الطبيعية بالأحمر بتقارير الفحص (GUE/GSE/SFA). خيار قابل للتشغيل/الإيقاف من
# الإدارة ← مصمم التقارير (الإعداد exam_abnormal_red، الافتراضي مفعّل). يقارن النتيجة بالمدى الطبيعي:
#   - مدى رقمي (0-2 أو 1.005 - 1.030): خارج المدى = غير طبيعي.
#   - مدى نصي (Negative / Nil / Yellow ...): أي قيمة مختلفة عنه = غير طبيعي، و"Negative/Nil/Absent/None"
#     تُعدّ مترادفات. اللون اليدوي المضبوط لصف معيّن يبقى له الأسبقية دائمًا.
# ------------------------------------------------------------------------
_EXAM_NEG_WORDS = {"negative", "neg", "nil", "absent", "none", "not seen", "not detected", "nad", "-", "--", "normal"}
_EXAM_ABN_RED = "#C0392B"


def _exam_num(x):
    try:
        return float(str(x).strip().replace(",", ""))
    except (TypeError, ValueError):
        return None


def exam_abnormal_color(result_value, range_row):
    try:
        if result_value in (None, "") or not range_row:
            return ""
        db = get_db()
        if get_setting(db, "exam_abnormal_red", "1") != "1":
            return ""
        val = str(result_value).strip()
        if not val:
            return ""
        vnorm = re.sub(r"\s+", " ", val.lower())
        vnum = _exam_num(val)
        low = range_row["low"] if "low" in range_row.keys() else None
        high = range_row["high"] if "high" in range_row.keys() else None
        rtext = ((range_row["range_text"] if "range_text" in range_row.keys() else "") or "").strip()
        if vnum is not None and (low is not None or high is not None) and not rtext:
            return _EXAM_ABN_RED if ((low is not None and vnum < low) or (high is not None and vnum > high)) else ""
        if not rtext:
            if vnum is not None and (low is not None or high is not None):
                return _EXAM_ABN_RED if ((low is not None and vnum < low) or (high is not None and vnum > high)) else ""
            return ""
        lines = [ln.strip() for ln in re.split(r"[\n;]+", rtext) if ln.strip()]
        # لو المدى متعدد الأسطر (مستويات): نترك التلوين للمستخدم (لا نعرف أي مستوى ينطبق)
        if len(lines) > 1:
            return ""
        rt = lines[0]
        m = re.match(r"^\s*(-?\d+(?:\.\d+)?)\s*(?:-|–|to)\s*(-?\d+(?:\.\d+)?)\s*[A-Za-z/%µ]*\s*$", rt)
        if m:
            a, b = float(m.group(1)), float(m.group(2))
            if vnum is not None:
                return _EXAM_ABN_RED if (vnum < min(a, b) or vnum > max(a, b)) else ""
            return _EXAM_ABN_RED if "+" in val or vnorm in ("positive", "present") else ""
        m = re.match(r"^\s*([<>]=?)\s*(-?\d+(?:\.\d+)?)", rt)
        if m and vnum is not None:
            lim = float(m.group(2))
            ok = {"<": vnum < lim, "<=": vnum <= lim, ">": vnum > lim, ">=": vnum >= lim}[m.group(1)]
            return "" if ok else _EXAM_ABN_RED
        normals = {re.sub(r"\s+", " ", t.strip().lower()) for t in re.split(r"\s*(?:/|,|\bor\b|،)\s*", rt) if t.strip()}
        if normals & _EXAM_NEG_WORDS:
            normals |= _EXAM_NEG_WORDS
        if vnorm in normals:
            return ""
        return _EXAM_ABN_RED
    except Exception:
        return ""


app.jinja_env.globals["exam_abnormal_color"] = exam_abnormal_color
app.jinja_env.globals["exam_abnormal_red_enabled"] = lambda: get_setting(get_db(), "exam_abnormal_red", "1") == "1"




# ألوان تلوين رقم النتيجة تلقائيًا حسب flag (المطلوب 2) — المستخدم صراحة
# رفض أي قاعدة ألوان ثابتة بالكود وطلب يختار هو اللونين بنفسه من الإعدادات
# (راجع flag_color_high/flag_color_low بصفحة settings.html)، فـ"تلوين
# ثابت" مو صحيح هنا. أبقينا فقط فكرة "هل التلوين مفعّل أصلاً"
# (auto_flag_color_enabled) من الشغل الجديد لأنها إضافة مفيدة ومستقلة.
# Normal ما تدخل هذا القاموس عمدًا — يعني بدون تلوين، كالسابق.
def build_flag_color_map(db):
    high = get_setting(db, "flag_color_high", "#D40000")
    low = get_setting(db, "flag_color_low", "#B58900")
    return {"High": high, "Critical": high, "Low": low}


def get_report_flag_settings(db):
    """(auto_flag_color_enabled, show_result_flag, flag_color_map) لطباعة أي
    تقرير — راجع شرح كامل عند مفتاحي هذا الإعداد بصفحة settings.html (بطاقة
    "تلوين رقم النتيجة" و"إظهار كلمة High/Low/Critical"). auto_flag_color_enabled
    افتراضيًا معطّل (0) — اختياري بالكامل، المدير لازم يفعّله يدويًا من
    الإعدادات إذا يريده. show_result_flag افتراضيًا معطّل (0) بنفس الشكل.
    flag_color_map يُبنى من لونين يختارهما المدير بنفسه (settings)، لا قاعدة
    ثابتة بالكود.
    """
    return (
        get_setting(db, "auto_flag_color_enabled", "0") == "1",
        get_setting(db, "show_result_flag", "0") == "1",
        build_flag_color_map(db),
    )



ROW_SPACING_PRESETS = {"tight": 4, "normal": 8, "loose": 14}


# تحاليل الكيمياء/الفيتامينات/الفايروسات/الدلائل الورمية تطبع بتصميم جدول
# مختلف (Test Name / Conventional Units / SI Units، مع Normal Range تحت كل
# تحليل) بناءً على طلب المستخدم — يُكتشف تلقائيًا من اسم "Department" لهذا
# التحليل بكتالوج التحاليل، فما يحتاج أي إعداد يدوي إضافي لكل تحليل. لو
# تحليل معيّن ما انطبق عليه رغم إنه فعلاً كيمياء/فيتامينات/فايروسات/دلائل
# ورمية، عدّل حقل "Department" له بكتالوج التحاليل ليتضمن إحدى الكلمات
# بالقائمة تحت (عربي أو إنكليزي)، أو أضف كلمة جديدة للقائمة.
ORDER_STYLE_DEPT_KEYWORDS = [
    "chem", "كيمياء", "بايوكيمستري", "biochem",
    "vitamin", "فيتامين",
    "virus", "virolog", "فايروس", "فيروس", "serolog",
    "tumor", "marker", "ورمي", "دلائل",
]


def uses_order_style_report(department, report_style=None):
    """True لو هذا التحليل يطبع بالتصميم الجديد (جدول Conventional/SI Units
    المُصلَّح -- custom_v2.html). التصميم القديم (custom.html) فيه خلل تراكب
    بصري بالمدى الطبيعي (نقطة 7/8) فصار custom_v2 هو الافتراضي لكل التحاليل
    الآن -- مو بس تحاليل الكيمياء/الفيتامينات كما كان سابقًا. report_style
    يقدر يلغيه يدويًا فقط: 'classic' يرجّع تحليل معيّن للتصميم القديم لو
    احتجته لسبب ما."""
    if report_style == "classic":
        return False
    return True


def row_spacing_px(raw_value):
    """يحوّل test_definitions.row_spacing (المطلوب 8) لبكسل فعلي — يقبل
    درجة جاهزة (tight/normal/loose) أو رقم بكسل حر مكتوب كنص. يرجع None
    لو فاضي/NULL/غير صالح، وهذا مقصود: القوالب تستخدم None لتترك التباعد
    الافتراضي القديم لكل قالب كما هو تمامًا (بدون أي inline style إضافي)،
    حتى ما يتغير شكل أي تقرير قديم لم يُضبط له شي بعد."""
    if not raw_value:
        return None
    raw_value = str(raw_value).strip()
    if raw_value in ROW_SPACING_PRESETS:
        return ROW_SPACING_PRESETS[raw_value]
    try:
        px = int(float(raw_value))
        return max(0, min(60, px))
    except (TypeError, ValueError):
        return None


def resolve_label(param_row, override_label=None):
    """اسم العرض النهائي لباراميتر (المطلوب 9ب) — الأولوية: تسمية مخصصة
    لهذا الصف بالذات إن وُجدت (override_label — مثلاً rows_json.label
    بـcustom.html، أو param_overrides.label بexam rows) ← display_label
    المحفوظة على test_parameters نفسها (تنطبق بكل مكان يُطبع فيه هذا
    الباراميتر) ← الاسم الأصلي name كالسابق تمامًا لو ما فيه أي تخصيص."""
    if override_label:
        return override_label
    if param_row is not None:
        try:
            dl = param_row["display_label"]
        except (KeyError, IndexError, TypeError):
            dl = None
        if dl:
            return dl
        return param_row["name"]
    return ""


VALUE_ALIGN_CSS = {"near_name": "left", "center": "center", "near_unit": "right"}


def resolve_value_align(param_row):
    """محاذاة CSS لرقم النتيجة (المطلوب 11) حسب test_parameters.value_align
    — NULL/فاضي/قيمة غير معروفة = None (يعني اترك السلوك الافتراضي القديم
    لهذا القالب كما هو بدون أي inline style إضافي، حتى ما يتغير أي تقرير
    قديم لم يُضبط له شي بعد)."""
    if param_row is None:
        return None
    try:
        va = param_row["value_align"]
    except (KeyError, IndexError, TypeError):
        va = None
    return VALUE_ALIGN_CSS.get(va)


app.jinja_env.globals["resolve_label"] = resolve_label
app.jinja_env.globals["uses_order_style_report"] = uses_order_style_report


def report_design(family):
    """رقم التصميم (1..4) لعائلة تقارير: 'coag' (التخثر) أو 'exam' (GUE/GSE/SFA).
    الأولوية لـ?design=N بالرابط (معاينة مؤقتة بدون حفظ)، ثم الإعداد المحفوظ
    (الإدارة ← تصاميم التقارير)، وغيره 1 = التصميم الكلاسيكي الحالي."""
    try:
        q = request.args.get("design")
        if q in ("1", "2", "3", "4"):
            return q
    except RuntimeError:
        pass
    try:
        _db = get_db()
        v = get_setting(_db, f"report_design_{family}", "1")
        _db.close()
    except Exception:
        v = "1"
    return v if v in ("1", "2", "3", "4") else "1"


app.jinja_env.globals["report_design"] = report_design
app.jinja_env.globals["RESULT_STYLE_CHOICES"] = [
    ("a1", "Style A — Labels Set 1"), ("a2", "Style A — Labels Set 2"),
    ("b_grid", "Style B — Matching Image 1"), ("b_compact", "Style B — Compact"),
    ("r1", "Style R1 — شريط ملوّن + المدى تحت الاسم"), ("r2", "Style R2 — أعمدة كلاسيكية"),
    ("r3", "Style R3 — مدمج بشرائط أقسام"),
]
app.jinja_env.globals["RESULT_THEME_CHOICES"] = [
    ("default", "الألوان الافتراضية"), ("green", "Custom colors (أخضر/بنفسجي/برتقالي)"), ("custom", "ألواني اليدوية"),
]
app.jinja_env.globals["resolve_value_align"] = resolve_value_align
app.jinja_env.globals["VALUE_ALIGN_CSS"] = VALUE_ALIGN_CSS


ALLOWED_DOCX_EXT = {"docx"}

# نص الكليشة الجاهز لزر "Normal" بحقول وصف RBC/WBC/Platelets بتقرير الـ Blood
# film (شاشة إدخال النتائج المفردة والمجمّعة). عدّل النص هنا فقط وينعكس
# تلقائيًا بكل شاشات الإدخال دون أي تعديل إضافي بالقوالب. الزر يعبّي الحقل
# بهذا النص، ويبقى قابلاً للتعديل الكامل بعدها (نفس أي حقل نصي عادي).
NORMAL_CLICHE_TEXT = {
    "RBC_desc": "Normochromic normocytic",
    "WBC_desc": "Normal count and morphology",
    "Platelets_desc": "Within normal limits",
}
app.jinja_env.globals["NORMAL_CLICHE_TEXT"] = NORMAL_CLICHE_TEXT

# أسماء الأشهر بالتسمية العراقية/الشامية المتداولة (بدل كانون الثاني/يناير
# الرسمية أو January/February الإنكليزية) — نقطة #11. تُستخدم كـ Jinja
# filter بأي قالب: {{ "2026-08"|iraqi_month }} أو {{ 8|iraqi_month }} تعطي
# "آب"، و IRAQI_MONTHS متاح كـ global لبناء قوائم اختيار الأشهر (dropdown)
# بنفس التسمية مباشرة من القالب.
IRAQI_MONTHS = {
    1: "كانون الثاني", 2: "شباط", 3: "آذار", 4: "نيسان",
    5: "أيار", 6: "حزيران", 7: "تموز", 8: "آب",
    9: "أيلول", 10: "تشرين الأول", 11: "تشرين الثاني", 12: "كانون الأول",
}
app.jinja_env.globals["IRAQI_MONTHS"] = IRAQI_MONTHS


@app.template_filter("ddmmyyyy")
def _ddmmyyyy_filter(value):
    """'2026-09-12' -> '12/09/2026' — لعرض تواريخ ميزة البحث/التصدير
    بصيغة DD/MM/YYYY كما طُلب."""
    return acs.ddmmyyyy(value)


@app.template_filter("iraqi_month")
def iraqi_month_filter(value):
    """يحوّل شهرًا لاسمه العراقي. يقبل: رقم شهر مباشر (1-12)، أو نص تاريخ
    يبدأ بصيغة 'YYYY-MM' (مثل قيمة ?month المستخدمة بالتقارير الشهرية)،
    أو أي نص تاريخ/ISO يبدأ بنفس الصيغة. أي قيمة غير مفهومة تُرجع فاضية
    بدل ما تكسر الصفحة."""
    if value in (None, ""):
        return ""
    if isinstance(value, int):
        return IRAQI_MONTHS.get(value, "")
    s = str(value)
    try:
        if len(s) >= 7 and s[4] == "-":
            return IRAQI_MONTHS.get(int(s[5:7]), "")
        return IRAQI_MONTHS.get(int(s), "")
    except (ValueError, IndexError):
        return ""

# رموز التمييز الملوّنة بحقل الـ Conclusion (نجمة وأسهم وعلامتي استفهام/تعجب)
# — يضيفها المستخدم بنفسه من زر التنسيق فوق حقل الاستنتاج بشاشات إدخال
# النتائج (المفردة والمجمّعة). "key" هو المعرّف المستخدم بجدول settings
# و"label" هو الاسم العربي اللي يظهر بشاشة Management → Settings.
# CONCLUSION_MARKER_DEFAULT_COLORS تحت هو اللون الافتراضي فقط — المدير يكدر
# يغيّر أي لون من شاشة الإعدادات، والقيمة المحفوظة هناك (settings key:
# "conclusion_marker_colors", JSON) هي اللي تُستخدم فعليًا وقت الطباعة/العرض
# عبر get_conclusion_marker_colors(db). الأزرار تُدرج الرمز في موضع المؤشر
# بالضبط (بدون فرض سطر جديد)، فالرمز ممكن يطلع بأي مكان بالسطر — لهيك
# التلوين يفحص كل رمز بالسطر أينما وجد، مو بس إذا كان ببداية السطر.
CONCLUSION_MARKERS = [
    {"key": "star", "char": "★", "label": "نجمة حمراء", "default_color": "#D40000"},
    {"key": "arrow", "char": "→", "label": "سهم مفرد", "default_color": "#1F3B7A"},
    {"key": "arrow_left", "char": "◄", "label": "سهم يسار (اختياري)", "default_color": "#1F3B7A"},
    {"key": "arrow_double", "char": "⇒", "label": "سهم مزدوج", "default_color": "#1F3B7A"},
    {"key": "triangle", "char": "▶", "label": "سهم مثلث", "default_color": "#1F3B7A"},
    {"key": "question", "char": "?", "label": "علامة استفهام", "default_color": "#E67E22"},
    {"key": "exclaim", "char": "!", "label": "علامة تعجب", "default_color": "#8E44AD"},
]
CONCLUSION_MARKER_DEFAULT_COLORS = {m["char"]: m["default_color"] for m in CONCLUSION_MARKERS}
_CONCLUSION_MARKER_PATTERN = re.compile(
    "|".join(re.escape(m) for m in CONCLUSION_MARKER_DEFAULT_COLORS)
)
_HEX_COLOR_RE = re.compile(r"^#[0-9a-fA-F]{6}$")
DASH_INTERFACES = ("reception", "lab", "both")
DASH_INTERFACE_LABELS = {"reception": "الاستقبال", "lab": "المختبر", "both": "الاثنين معًا"}
DASH_LOOK_KEYS = ("dashboard_bg_path", "dashboard_bg_overlay_opacity", "dashboard_bg_blur",
                  "dashboard_bg_position", "dashboard_bg_size_mode", "dashboard_bg_size_percent",
                  "theme_primary_color", "theme_page_bg_color",
                  "dashboard_overlay_color", "dashboard_bg_brightness", "dashboard_hero_text_color")
DASH_LOOK_DEFAULTS = {"dashboard_overlay_color": "#0a101c", "dashboard_bg_brightness": "100",
                      "dashboard_hero_text_color": "#f8fafc"}


def _hex_to_rgb_str(h, fallback="10,16,28"):
    try:
        h = h.lstrip("#")
        return f"{int(h[0:2], 16)},{int(h[2:4], 16)},{int(h[4:6], 16)}"
    except Exception:
        return fallback


def get_conclusion_marker_colors(db):
    """يرجع dict {رمز: لون hex} بعد دمج الألوان الافتراضية مع أي تعديل
    حفظه المدير من شاشة Management → Settings (مخزّن كـ JSON بجدول
    settings تحت المفتاح conclusion_marker_colors: {key: hex})."""
    colors = dict(CONCLUSION_MARKER_DEFAULT_COLORS)
    raw = get_setting(db, "conclusion_marker_colors", "")
    if raw:
        try:
            saved = json.loads(raw)
        except (ValueError, TypeError):
            saved = {}
        for m in CONCLUSION_MARKERS:
            val = saved.get(m["key"])
            if val and _HEX_COLOR_RE.match(val):
                colors[m["char"]] = val
    return colors


@app.template_filter("render_conclusion")
def render_conclusion_filter(text):
    """يحوّل نص حقل الـ Conclusion (بأسطره كما كتبها المستخدم بالضبط) إلى
    HTML آمن للطباعة: كل رمز نجمة/سهم بأي موضع بالسطر يُلوَّن الرمز نفسه
    فقط بلونه (المحفوظ من شاشة الإعدادات أو الافتراضي)، وباقي السطر يبقى
    بلونه الطبيعي، والأسطر تُفصل بـ <br> حتى يطبع كل سطر لحاله بدل ما
    ينضغط كلها بسطر وحد متل الـ HTML العادي. كل النص غير الرمز يُهرَّب
    (escape) بشكل طبيعي — ما في أي HTML يُنفَّذ من داخل النص المكتوب نفسه."""
    if not text:
        return ""
    colors = get_conclusion_marker_colors(get_db())
    lines = str(text).split("\n")
    rendered = []
    for line in lines:
        pos = 0
        parts = []
        for m in _CONCLUSION_MARKER_PATTERN.finditer(line):
            if m.start() > pos:
                parts.append(str(escape(line[pos:m.start()])))
            color = colors[m.group()]
            parts.append(
                '<span class="conclusion-marker" style="color:'
                + color + ';">' + str(escape(m.group())) + "</span>"
            )
            pos = m.end()
        if pos < len(line):
            parts.append(str(escape(line[pos:])))
        rendered.append("".join(parts))
    return Markup("<br>".join(rendered))

# The department names that get the extra "previous result per parameter"
# column on the printed report (in addition to the previous-visit date that
# every report shows), AND that get the printed report's repeating letterhead
# when a result overflows onto a second page (see repeat_header_on_print in
# print_report). Covers Chemistry, Hormones, Vitamins, Tumor Markers,
# Virology and Coagulation — the quantifiable/serology departments the lab
# wants tracked over time / laid out as multi-line result cards. Hematology
# (CBC, Blood Film, WBC Differential, Fluid examination, and the other big
# dedicated-template reports) never goes through either feature — they don't
# call find_previous_reference and print_report never sets
# repeat_header_on_print for them — so they're unaffected either way. Matches
# loosely (Arabic or English, any casing) so it keeps working no matter how
# an admin later spells a new department.
PREVIOUS_VALUE_DEPARTMENT_KEYWORDS = (
    "chem", "كيمياء",
    "coagul", "تخثر",
    "hormone", "هرمون",
    "vitamin", "فيتامين",
    "virology", "viral", "فايروس", "فيروس",
    "tumor", "tumour", "marker", "دلائل", "ورمي",
)


def department_shows_previous_values(department):
    d = (department or "").lower()
    return any(k in d for k in PREVIOUS_VALUE_DEPARTMENT_KEYWORDS)


# الترتيب الافتراضي لتحاليل شاشة "إدخال النتائج" حسب القسم — يُستخدم فقط
# لأي تحليل غير مذكور صراحةً بإعداد "ترتيب التحاليل بشاشة إدخال النتائج"
# اليدوي (results_entry_test_order)؛ لو ذاك الإعداد فاضي بالكامل، يصير هذا
# الترتيب هو الافتراضي الوحيد. مطابقة كلمات مفتاحية (عربي/انكليزي، أي حالة
# أحرف) نفس أسلوب PREVIOUS_VALUE_DEPARTMENT_KEYWORDS فوق — تشتغل بغض النظر
# شلون كتب الأدمن اسم القسم بالضبط بكتالوج التحاليل. أي قسم ما يطابق ولا
# مجموعة (مثلاً قسم نادر أو Other) يظهر بالأخير.
# الترتيب المطلوب: كيمياء ← فايروسات ← هرمونات ← فيتامينات ← تخثر ← أمراض الدم.
DEPARTMENT_PRIORITY_KEYWORDS = [
    ("chem", "كيمياء"),                              # 1) Chemistry
    ("virology", "viral", "فايروس", "فيروس"),        # 2) Virology
    ("hormone", "هرمون"),                             # 3) Hormones
    ("vitamin", "فيتامين"),                           # 4) Vitamins
    ("coagul", "تخثر"),                               # 5) Coagulation
    ("hemat", "دم"),                                  # 6) Hematology / blood diseases
]


def _dept_group(department):
    """يصنّف قسم التحليل لمجموعة قسم الجهاز: chem (كيمياء/هرمونات/فيتامينات/فايروسات) | hema (أمراض الدم/التخثر)
    | micro (أحياء مجهرية/سيرولوجي/طفيليات/Others: GUE وGSE وSFA وغيرها). يُستخدم لفلتر \"قسم هذا الجهاز\"."""
    d = (department or "").lower()
    if any(k in d for k in ("chem", "كيمياء", "hormone", "هرمون", "vitamin", "فيتامين", "viral", "virolog", "فايروس", "فيروس",
                            "tumor", "marker", "lipid", "diabet")):
        return "chem"
    if any(k in d for k in ("hemat", "coagul", "blood", "دم", "تخثر")):
        return "hema"
    return "micro"


app.jinja_env.globals["dept_group"] = _dept_group


def department_priority_rank(department):
    d = (department or "").lower()
    for i, keywords in enumerate(DEPARTMENT_PRIORITY_KEYWORDS):
        if any(k in d for k in keywords):
            return i
    return len(DEPARTMENT_PRIORITY_KEYWORDS)  # قسم غير معروف/غير مذكور أعلاه — يظهر بالأخير


def _check_completed_result_gate(db, form):
    """المطلوب 2: تعديل نتيجة مكتملة (order_tests.status == 'Completed')
    محمي بكلمة مرور خاصة (نفس مبدأ ميزة "تحليل مجاني" -- إعداد منفصل
    fee_waiver_gate_password_hash من صفحة الإعدادات). الواجهة الأمامية
    (result_entry.html) أصلاً تسأل عنها وترسلها بحقل gate_password، لكن
    السيرفر ما كان يتحقق منها فعليًا قبل هذا التعديل -- أي شخص يقدر يتجاوز
    الفحص بس بتعطيل الجافاسكربت أو بإرسال الطلب مباشرة. يرجع (ok, error).
    """
    # نمط جديد (مفضّل): يوزر وباسورد حساب حقيقي بجدول users دوره admin أو
    # supervisor -- كل شخص يفتح التعديل بحسابه الشخصي، فيُعرف بالضبط مين
    # فتحه بدون الاعتماد على حقل اسم حر غير موثّق. لو الفورم بعث
    # gate_username نمشي بهذا المسار حصرًا؛ غير هيك نرجع للنمط القديم
    # (كلمة مرور مشتركة fee_waiver_gate_password_hash) حتى ما تنكسر أي
    # شاشة قديمة لسا تستخدم الحقل القديم فقط (مثل تعديل معلومات المريض/
    # الزيارة اللي ما تغيّرت هون).
    entered_username = (form.get("gate_username") or "").strip()
    entered_password = form.get("gate_password", "")
    if entered_username:
        user = db.execute(
            "SELECT * FROM users WHERE username=? AND is_active=1", (entered_username,)
        ).fetchone()
        if not user or user["password_hash"] != hash_password(entered_password):
            return False, "اسم المستخدم أو كلمة المرور غير صحيحة."
        if user["role"] not in ("admin", "supervisor"):
            return False, "هذا الحساب لا يملك صلاحية مسؤول/مشرف المختبر -- التعديل مرفوض."
        return True, None
    stored_hash = get_setting(db, "fee_waiver_gate_password_hash", "")
    if not stored_hash:
        return False, "لم تُضبط كلمة مرور حماية تعديل النتائج المكتملة بعد -- اضبطها من صفحة الإعدادات أولاً."
    if hash_password(entered_password) != stored_hash:
        return False, "كلمة مرور الحماية غير صحيحة -- التعديل مرفوض."
    return True, None


def _ot_has_result_changes(db, ot, parameters, form, field_prefix=""):
    """يرجّع True فقط لو القيم المُرسَلة بالفورم تختلف فعلاً عن المحفوظ بقاعدة
    البيانات (قيمة جديدة أو مختلفة أو تغيير جهاز). يُستخدم حتى لا تُطلب كلمة
    مرور المسؤول لمجرد الطباعة: طباعة نتيجة مكتملة بدون أي تعديل = مسموحة
    لأي موظف، وكلمة المرور تُطلب فقط لو فيه تعديل حقيقي على نتيجة مكتملة."""
    analyzer_field = f"{field_prefix}analyzer"
    if analyzer_field in form:
        new_an = (form.get(analyzer_field, "") or "").strip() or None
        old_an = (ot["analyzer"] if "analyzer" in ot.keys() else None) or None
        if new_an != old_an:
            return True
    for param in parameters:
        value = (form.get(f"{field_prefix}param_{param['id']}", "") or "").strip()
        if value == "":
            continue
        existing = db.execute(
            "SELECT value_numeric, value_text FROM results WHERE order_test_id=? AND test_parameter_id=?",
            (ot["id"], param["id"]),
        ).fetchone()
        if not existing:
            return True
        new_num, new_txt = None, value
        if param["result_type"] == "Numeric":
            try:
                new_num, new_txt = float(value), None
            except ValueError:
                pass
        if existing["value_numeric"] != new_num or existing["value_text"] != new_txt:
            return True
    return False


def get_visit_hct(db, visit_id):
    """يجيب آخر قيمة HCT مُدخلة ضمن تحليل CBC لنفس الزيارة (إن وجدت)، تُستخدم
    لحساب Corrected Retic count تلقائيًا من Reticulocyte count. يرجع None إذا
    ما كان فيه CBC بعد أو ما دخلت قيمة HCT."""
    row = db.execute(
        "SELECT r.value_numeric FROM results r "
        "JOIN test_parameters tp ON tp.id = r.test_parameter_id "
        "JOIN order_tests ot ON ot.id = r.order_test_id "
        "JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id "
        "WHERE o.visit_id = ? AND td.code = 'CBC' AND tp.name = 'HCT' "
        "AND r.value_numeric IS NOT NULL "
        "ORDER BY r.id DESC LIMIT 1",
        (visit_id,),
    ).fetchone()
    return row["value_numeric"] if row else None

def get_normal_hct(db, gender, age, age_unit):
    """يجيب متوسط المدى الطبيعي لـ HCT (من جدول القيم المرجعية reference_ranges)
    حسب عمر وجنس المريض — يُستخدم أساسًا لحساب Corrected Retic count بدل رقم
    ثابت واحد لكل الأعمار. يرجع None إذا ما كان فيه مدى مرجعي مطابق."""
    param = db.execute(
        "SELECT tp.id FROM test_parameters tp "
        "JOIN test_definitions td ON td.id = tp.test_definition_id "
        "WHERE td.code = 'CBC' AND tp.name = 'HCT' LIMIT 1"
    ).fetchone()
    if not param:
        return None
    rng = find_reference_range(db, param["id"], gender, age, age_unit)
    if not rng or rng["low"] is None or rng["high"] is None:
        return None
    return (rng["low"] + rng["high"]) / 2.0


def find_previous_reference(db, full_name, age, gender, test_definition_id, department,
                             exclude_visit_id, before_created_at):
    """Find this patient's most recent EARLIER visit that has a completed
    result for the same test — matched strictly on full name + age + gender
    (not just patients.id, since reception may have re-registered a
    returning patient as a new row) and dated before the current visit.

    Returns (previous_visit_date_str_or_None, {param_name: previous_value}).
    The values dict is only populated for Chemistry/Coagulation-type
    departments; every other department gets the date only.
    """
    row = db.execute(
        "SELECT ot.id as order_test_id, v.created_at as visit_created_at "
        "FROM order_tests ot "
        "JOIN orders o ON o.id = ot.order_id "
        "JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id "
        "WHERE ot.test_definition_id = ? "
        "AND LOWER(TRIM(p.full_name)) = LOWER(TRIM(?)) "
        "AND p.age = ? AND p.gender = ? "
        "AND v.id != ? AND v.created_at < ? "
        "AND ot.status IN ('Completed', 'Verified') "
        "ORDER BY v.created_at DESC LIMIT 1",
        (test_definition_id, full_name or "", age, gender, exclude_visit_id, before_created_at or ""),
    ).fetchone()
    if not row:
        return None, {}

    try:
        dt = datetime.fromisoformat(row["visit_created_at"])
        prev_date = f"{dt.day}/{dt.month}/{dt.year}"
    except (TypeError, ValueError):
        prev_date = row["visit_created_at"] or ""

    prev_values = {}
    if department_shows_previous_values(department):
        prev_results = db.execute(
            "SELECT r.*, tp.name as param_name FROM results r "
            "JOIN test_parameters tp ON tp.id = r.test_parameter_id WHERE r.order_test_id=?",
            (row["order_test_id"],),
        ).fetchall()
        for r in prev_results:
            val = r["value_text"] if r["value_text"] not in (None, "") else r["value_numeric"]
            prev_values[r["param_name"]] = "" if val is None else val
    return prev_date, prev_values


# ---------------------------------------------------------------- helpers --
def current_lang():
    return session.get("lang", "en")


_SKY_TH_CSS = (
    b"<style id=\"lis-sky-th\">"
    b"table thead th, table th, html.ui3d table thead th, html.ui3d table th, html.ui3d .rb-box table th {"
    b"background: linear-gradient(180deg, #C8F0FF 0%, #6FD0FF 55%, #4CC2FA 100%) !important;"
    b"color: #000 !important; font-weight: 800 !important;"
    b"text-shadow: 0 1px 0 rgba(255,255,255,.75), 0 0 1px rgba(0,0,0,.25);"
    b"border-bottom: 2px solid #1FA9EC !important; box-shadow: inset 0 1px 0 rgba(255,255,255,.85);}"
    b"</style>"
)


@app.after_request
def _inject_sky_table_headers(resp):
    """عناوين كل الجداول بصفحات البرنامج (اللي ترث base.html): سمائي فاتح زاهي + نص أسود.
    يُحقن بنهاية <head> فيغلب أي لون قديم بدون تعديل كل قالب. صفحات الطباعة/التقارير لا تتأثر
    (ما ترث base.html فلا يوجد فيها مفتاح lis-sidebar-hidden)."""
    try:
        if resp.status_code != 200 or resp.mimetype != "text/html" or resp.direct_passthrough:
            return resp
        data = resp.get_data()
        if b"lis-sidebar-hidden" not in data or b'id="lis-sky-th"' in data or b"</head>" not in data:
            return resp
        resp.set_data(data.replace(b"</head>", _SKY_TH_CSS + b"</head>", 1))
    except Exception:
        pass
    return resp




# --- v64: زر الإغلاق بصفحات الطباعة ما يبقى ميّت لو المتصفح رفض window.close() ---
_LIS_CLOSE_SHIM = (b'<script id="lis-close-shim">(function(){var c=window.close.bind(window);'
                   b'window.close=function(){try{c();}catch(e){}'
                   b'setTimeout(function(){if(window.closed)return;'
                   b'var r=document.referrer;window.location.href=(r&&r.indexOf(window.location.origin)===0)?r:"/";},400);};})();</script>')


@app.after_request
def _inject_close_shim(resp):
    try:
        if resp.status_code != 200 or resp.mimetype != "text/html" or resp.direct_passthrough:
            return resp
        data = resp.get_data()
        if b"window.close()" not in data or b'id="lis-close-shim"' in data or b"</body>" not in data:
            return resp
        head, _, tail = data.rpartition(b"</body>")
        resp.set_data(head + _LIS_CLOSE_SHIM + b"</body>" + tail)
    except Exception:
        pass
    return resp


@app.context_processor
def inject_globals():
    db = get_db()
    lang = current_lang()
    brand_name = get_setting(db, "app_name_ar" if lang == "ar" else "app_name", t(lang, "app_name"))
    logo_path = get_setting(db, "logo_path", "")
    logo_url = url_for("static", filename=logo_path) if logo_path else None
    # خلفية شاشة الترحيب (dashboard) — اختيارية، تُرفع من Management → الإعدادات
    # (بطاقة "خلفية شاشة الترحيب")، نفس أسلوب الشعار logo_path أعلاه بالضبط.
    # محقونة هنا عالمياً حتى تتوفر بـ dashboard.html دون تمريرها يدويًا من route.
    dashboard_bg_path = get_setting(db, "dashboard_bg_path", "")
    dashboard_bg_url = url_for("static", filename=dashboard_bg_path) if dashboard_bg_path else None
    # تعتيم/ضبابية طبقة الخلفية فوق الصورة أو التدرّج بشاشة الترحيب —
    # قابلة للتحكم من الإعدادات (بطاقة خلفية شاشة الترحيب)، القيم
    # الافتراضية (62%، 2px) هي بالضبط القيم اللي كانت ثابتة بالكود سابقاً.
    dashboard_bg_overlay_opacity = get_setting(db, "dashboard_bg_overlay_opacity", "62")
    dashboard_bg_blur = get_setting(db, "dashboard_bg_blur", "2")
    # موضع الصورة (أي جزء منها يبقى بمنتصف الشاشة عند القص) -- إضافة سابقة
    # لم تُحذف، بس مو موجودة بآخر نسخة رفعها المستخدم؛ أعدتها هنا لحد ما
    # يتأكد إذا يريدها يبقى أو يشيلها نهائيًا (سألته صراحة قبل الحذف).
    dashboard_bg_position = get_setting(db, "dashboard_bg_position", "center")
    # حجم صورة خلفية شاشة الترحيب: cover (الافتراضي = السلوك القديم بالضبط،
    # تملأ الشاشة وتُقصّ)، contain (تظهر كاملة بدون قص)، أو custom (نسبة
    # مئوية من عرض الشاشة، الارتفاع تلقائي بنفس النسبة). يُترجم لقيمة CSS
    # جاهزة هنا حتى يستخدمها dashboard.html مباشرة داخل background.
    _bg_size_mode = get_setting(db, "dashboard_bg_size_mode", "cover")
    _bg_size_pct = get_setting(db, "dashboard_bg_size_percent", "100")
    if _bg_size_mode == "contain":
        dashboard_bg_size_css = "contain"
    elif _bg_size_mode == "custom":
        try:
            dashboard_bg_size_css = f"{max(5, min(400, int(_bg_size_pct)))}% auto"
        except ValueError:
            dashboard_bg_size_css = "cover"
    else:
        dashboard_bg_size_css = "cover"
    # عنوان وهاتف المختبر — اختياريان، يُضبطان مرة وحدة من الإعدادات (بطاقة
    # العلامة التجارية) ويظهران تلقائيًا بأي قالب يحتاجهم (خصوصًا فاتورة
    # A5 — نقطة #10) بدون تمريرهما يدويًا من كل route.
    lab_address = get_setting(db, "lab_address", "")
    lab_phone = get_setting(db, "lab_phone", "")
    # ارتفاع/عرض خلايا جدول نتائج التقرير (Test/Result/Control/Unit...) — يتحكم
    # بيها الأدمن من Management → Settings، تنطبق تلقائيًا على كل التقارير
    # لأنها محقونة هنا بدل تمريرها يدويًا بكل route.
    report_row_pad = get_setting(db, "report_row_pad", "5")
    report_col_pad = get_setting(db, "report_col_pad", "12")
    # المسافة بين ترويسة الدكاترة وصندوق معلومات المريض (patient-info-v2)،
    # وعرض عمود تسمية الحقل بنفس الصندوق (يتحكم بمدى قرب القيمة من تسميتها
    # زي "Patient Name:") — محقونان هنا بنفس أسلوب report_row_pad أعلاه
    # فينطبقان على كل التقارير المطبوعة دفعة وحدة.
    patient_info_top_gap = get_setting(db, "patient_info_top_gap", "4")
    patient_info_label_width = get_setting(db, "patient_info_label_width", "108")
    # المسافة العمودية بين كل سطر وسطر بصندوق معلومات المريض نفسه (بين
    # "Patient Name" و"Age" مثلاً) — منفصلة عن المسافة فوق الصندوق كله.
    patient_info_row_gap = get_setting(db, "patient_info_row_gap", "3")
    # المسافة الأفقية بين عمود بيانات المريض الأيمن والأيسر (Patient
    # Name/Age/Sex... مقابل Sample No./Patient No....) — كانت ثابتة 36px
    # بالكود، صارت الحين قابلة للتحكم بنفس أسلوب بقية إعدادات التباعد.
    patient_info_col_gap = get_setting(db, "patient_info_col_gap", "36")
    # نمط الخط تحت عناوين التقارير (.report-heading/.report-title) —
    # المستخدم يعاني تكرارًا من مشاكل عرض بصرية بهذا الخط تختلف باختلاف
    # المتصفح/الطابعة، فبدل ملاحقة كل شكوى شكل جديدة، صار قابل للتحكم
    # الكامل من الإعدادات: solid (افتراضي، متصل)، dashed (متقطع بنمط
    # واضح ومقصود)، أو none (بدون خط إطلاقًا).
    report_underline_style = get_setting(db, "report_underline_style", "solid")
    # دكاترة الفحص المُفعَّل لهم "إظهار بترويسة التقرير" — تُحقن هنا تلقائيًا
    # حتى تنعرض بترويسة أي تقرير مطبوع (reports/*.html) بدون تمريرها يدويًا
    # من كل route. راجع Management → الإعدادات → إدارة قائمة الدكاترة.
    letterhead_doctors = get_letterhead_doctors(db)
    letterhead_font_size = get_setting(db, "letterhead_font_size", "14")
    letterhead_font_family = get_setting(db, "letterhead_font_family", "Segoe UI, Tahoma, Arial, sans-serif")
    # حجم خط اسم التحليل وحجم خط النتيجة بكل التقارير المطبوعة — نفس أسلوب
    # letterhead_font_size أعلاه: محقونة هنا مرة وحدة فتنطبق تلقائيًا على كل
    # قوالب reports/* (وbase_report.html) دون تمريرها يدويًا من كل route.
    test_name_font_size = get_setting(db, "test_name_font_size", "16")
    result_value_font_size = get_setting(db, "result_value_font_size", "16")
    # موضع/حجم الشعار بترويسة كل تقرير مطبوع — إعدادان عامان محقونان هنا
    # مرة وحدة، بنفس أسلوب باقي إعدادات التقرير.
    logo_position = get_setting(db, "logo_position", "right")
    report_header_style = get_setting(db, "report_header_style", "default")
    report_header_accent = get_setting(db, "report_header_accent", "") or "#4FB6E8"
    report_header_subtitle = get_setting(db, "report_header_subtitle", "")
    lab_name_ar = get_setting(db, "app_name_ar", "") or get_setting(db, "app_name", "")
    logo_width = get_setting(db, "logo_width", "100")
    # حالة "التحديث التلقائي" الحالية — تُحقن هنا حتى يظهر زر التبديل بشريط
    # الأعلى (base.html، بجانب اسم المستخدم) بأي صفحة بدون تمريرها يدويًا.
    auto_update_enabled = get_setting(db, "auto_update_enabled", "1") == "1"
    # لون/خلفية الواجهة العامة (المطلوب: تغيير ألوان الخلفية بكل صفحات
    # البرنامج -- الشريط الجانبي، صفحة زيارة جديدة، وبقية الصفحات -- مو
    # بس شاشة الترحيب). محقونة هنا بنفس أسلوب باقي إعدادات التخصيص، وتُحقن
    # كمتغيرات CSS بـ:root من base.html فتنطبق تلقائيًا على أي عنصر
    # بالصفحات يستخدم أصلاً var(--primary) أو var(--page-bg) بملف
    # static/css/style.css. أي لون hex ثابت مكتوب مباشرة داخل قالب معيّن
    # (بدل ما يستخدم متغير CSS) ما يتأثر تلقائيًا -- يحتاج تحويله لمتغير
    # لحاله أول.
    theme_primary_color = get_setting(db, "theme_primary_color", "#205072")
    theme_page_bg_color = get_setting(db, "theme_page_bg_color", "#F3F6F8")
    # مظهر 3D للواجهة (اختياري): الإعداد العام للجميع؛ المعاينة تتم محليًا بالمتصفح قبل التطبيق
    ui_3d = get_setting(db, "ui_3d", "1") == "1"
    # إعدادات مظهر شاشة الترحيب/الألوان الخاصة بكل واجهة (استقبال/مختبر/الاثنين):
    # لو الواجهة الحالية لها قيمة محفوظة بمفتاح "<المفتاح>__<الواجهة>" تُستخدم بدل
    # العامة، وغير هيك تبقى القيمة العامة كما هي (فما ينكسر شي عند من ما ضبط شي).
    dashboard_overlay_color = get_setting(db, "dashboard_overlay_color", DASH_LOOK_DEFAULTS["dashboard_overlay_color"])
    dashboard_bg_brightness = get_setting(db, "dashboard_bg_brightness", DASH_LOOK_DEFAULTS["dashboard_bg_brightness"])
    dashboard_hero_text_color = get_setting(db, "dashboard_hero_text_color", DASH_LOOK_DEFAULTS["dashboard_hero_text_color"])
    _iface = session.get("interface")
    if _iface in DASH_INTERFACES:
        def _ov(key):
            v = get_setting(db, f"{key}__{_iface}", "")
            return v if v != "" else None
        _v = _ov("dashboard_bg_path")
        if _v is not None:
            dashboard_bg_url = None if _v == "-" else url_for("static", filename=_v)
        _v = _ov("dashboard_bg_overlay_opacity")
        if _v is not None:
            dashboard_bg_overlay_opacity = _v
        _v = _ov("dashboard_bg_blur")
        if _v is not None:
            dashboard_bg_blur = _v
        _v = _ov("dashboard_bg_position")
        if _v in ("top", "center", "bottom"):
            dashboard_bg_position = _v
        _mode = _ov("dashboard_bg_size_mode")
        if _mode in ("cover", "contain", "custom"):
            if _mode == "custom":
                try:
                    dashboard_bg_size_css = f"{max(5, min(400, int(_ov('dashboard_bg_size_percent') or 100)))}% auto"
                except ValueError:
                    dashboard_bg_size_css = "cover"
            else:
                dashboard_bg_size_css = _mode
        _v = _ov("dashboard_overlay_color")
        if _v and _HEX_COLOR_RE.match(_v):
            dashboard_overlay_color = _v
        _v = _ov("dashboard_hero_text_color")
        if _v and _HEX_COLOR_RE.match(_v):
            dashboard_hero_text_color = _v
        _v = _ov("dashboard_bg_brightness")
        if _v is not None:
            dashboard_bg_brightness = _v
        _v = _ov("theme_primary_color")
        if _v and _HEX_COLOR_RE.match(_v):
            theme_primary_color = _v
        _v = _ov("theme_page_bg_color")
        if _v and _HEX_COLOR_RE.match(_v):
            theme_page_bg_color = _v
    license_banner = None
    if "user_id" in session:
        # كان check_license() ينادى هنا بكل عرض صفحة (وهو يكتب بالقاعدة) فيتصادم مع باقي الطلبات
        # ويسبب "صفنات" البرنامج. نستخدم نتيجة enforce_license المحفوظة بالذاكرة (تتجدد كل 5 دقائق).
        _lc = _license_check_cache
        lic = _lc[1] if _lc else {"status": "unknown"}
        # الشريط التحذيري "متبقي كم يوم" يظهر فقط للترخيص التجريبي، وليس
        # لأي ترخيص عادي (حتى لو كان له تاريخ انتهاء بعد سنة مثلاً).
        if lic["status"] == "active" and lic.get("is_trial") and lic.get("days_left") is not None:
            license_banner = f"متبقي {lic['days_left']} يوم على انتهاء الفترة التجريبية"
    db.close()
    return dict(t=lambda key: t(lang, key), lang=lang, ui_3d=ui_3d,
                current_user=session.get("full_name") or ("المصمم" if session.get("designer_id") else None),
                current_role=session.get("role") or ("designer" if session.get("designer_id") else None),
                brand_name=brand_name, logo_url=logo_url,
                dashboard_bg_url=dashboard_bg_url,
                dashboard_bg_overlay_opacity=dashboard_bg_overlay_opacity,
                dashboard_bg_blur=dashboard_bg_blur,
                dashboard_bg_position=dashboard_bg_position,
                dashboard_bg_size_css=dashboard_bg_size_css,
                dashboard_overlay_rgb=_hex_to_rgb_str(dashboard_overlay_color),
                dashboard_bg_brightness=dashboard_bg_brightness,
                dashboard_hero_text_color=dashboard_hero_text_color,
                lab_address=lab_address, lab_phone=lab_phone,
                report_row_pad=report_row_pad, report_col_pad=report_col_pad,
                patient_info_top_gap=patient_info_top_gap,
                patient_info_label_width=patient_info_label_width,
                patient_info_row_gap=patient_info_row_gap,
                patient_info_col_gap=patient_info_col_gap,
                report_underline_style=report_underline_style,
                letterhead_doctors=letterhead_doctors,
                letterhead_font_size=letterhead_font_size,
                letterhead_font_family=letterhead_font_family,
                test_name_font_size=test_name_font_size,
                result_value_font_size=result_value_font_size,
                logo_position=logo_position,
                report_header_style=report_header_style, report_header_accent=report_header_accent,
                report_header_subtitle=report_header_subtitle, lab_name_ar=lab_name_ar,
                logo_width=logo_width,
                auto_update_enabled=auto_update_enabled,
                theme_primary_color=theme_primary_color,
                theme_page_bg_color=theme_page_bg_color,
                license_banner=license_banner,
                # أيقونة المصمم العائمة: تظهر فقط لمن سجّل دخوله فعلاً من
                # /designer/login بنفس المتصفح (session['designer_id']).
                # المستخدمين العاديين (admin, reception...) ما عندهم هذا
                # المفتاح بالسيشن أبداً، فالأيقونة ما تظهر عندهم إطلاقاً.
                is_designer=bool(session.get("designer_id")))


def login_required(view):
    """بعد استبدال نظام تسجيل الدخول الشخصي (نقطة 3 الموسّعة): "تسجيل
    الدخول" صار يعني ببساطة "دخل من إحدى بطاقات الشاشة الرئيسية" --
    session["interface"] هو المرجع الحقيقي الآن، مو session["user_id"]
    (اللي يبقى موجود لأغراض ثانية فقط -- حساب الواجهة "الظل"، راجع
    ensure_interface_accounts بـdatabase.py).

    استثناء مهم: جلسة "المصمم" (session["designer_id"]) منفصلة كليًا عن
    نظام الواجهات هذا ولا تحدد session["interface"] إطلاقًا -- بدونه كان
    المصمم ما يقدر يوصل حتى لصفحة الإعدادات العادية أو الداشبورد نفسها
    (بالضبط سبب عدم القدرة على تغيير ألوان الشاشة الرئيسية من لوحة
    المصمم). المصمم مخوّل دائماً يشوف أي صفحة بالبرنامج بغض النظر عن
    اختيار واجهة."""
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("designer_id"):
            return view(*args, **kwargs)
        if "interface" not in session:
            return redirect(url_for("landing"))
        return view(*args, **kwargs)
    return wrapped


def roles_required(*roles):
    """كل الصفحات اللي كانت محمية بأدوار admin/supervisor/accountant
    القديمة صارت -- بقرار صريح من العميل -- مسموحة لواجهتي "مختبر"
    و"الاثنين معًا" بس (بدون تمييز فني/مسؤول حاليًا)، وممنوعة عن
    "استقبال". الأسماء الممرَّرة (roles) ما عادت تُستخدم فعليًا، أبقيتها
    بالتوقيع فقط حتى ما نضطر نلمس الـ85 مكان اللي يستخدمون هذا الديكوريتر
    بكل أنحاء الملف -- التغيير صار بمكان واحد هنا بس.

    نفس استثناء login_required: جلسة "المصمم" تتخطى فحص الواجهة بالكامل
    (بدونه ما يقدر يوصل حتى لصفحة الإعدادات لتغيير ألوان/صور الشاشة
    الرئيسية أو أي إعداد ثاني)."""
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if session.get("designer_id"):
                return view(*args, **kwargs)
            if "interface" not in session:
                return redirect(url_for("landing"))
            if session.get("interface") not in ("lab", "both"):
                flash("هذي الصفحة متاحة فقط لواجهة المختبر أو الاثنين معًا.")
                return redirect(url_for("dashboard"))
            return view(*args, **kwargs)
        return wrapped
    return decorator


def designer_required(view):
    """يحمي لوحة المصمم فقط — منفصلة تماماً عن نظام المستخدمين/الأدوار
    العادي في البرنامج (users/session['role']). لا أحد غير من يعرف اسم
    المستخدم وكلمة المرور الخاصين بالمصمم (المُنشَأين مرة واحدة عبر
    /designer/setup) يقدر يدخل هذه اللوحة."""
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("designer_id"):
            return redirect(url_for("designer_login"))
        return view(*args, **kwargs)
    return wrapped


_license_check_cache = None
_license_check_lock = threading.Lock()


@app.teardown_request
def _release_db_connections(exc=None):
    """نهاية كل طلب (نجح أو فشل): ألغِ أي كتابة معلّقة وسكّر كل اتصالات القاعدة المفتوحة به،
    حتى ما يقدر طلب فاشل يقفل القاعدة على الجميع (شوف الشرح بـ database.close_request_connections)."""
    close_request_connections()


# ---------------------------------------------------------------------------
# مراقب "الصفنات": يسجّل بملف hang_log.txt (بمجلد البرنامج) أي طلب علق أكثر من 6 ثواني
# مع مكان توقفه بالكود (stack)، وأي طلب انتهى ببطء (> 2 ثانية). لو البرنامج صفن أرسل الملف.
# ---------------------------------------------------------------------------
_inflight = {}
_inflight_lock = threading.Lock()
_inflight_seq = [0]
_HANG_LOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "hang_log.txt")


def _hang_log(text):
    try:
        if os.path.exists(_HANG_LOG) and os.path.getsize(_HANG_LOG) > 2_000_000:
            os.replace(_HANG_LOG, _HANG_LOG + ".old")
        with open(_HANG_LOG, "a", encoding="utf-8") as f:
            f.write(text + "\n")
    except Exception:
        pass


@app.before_request
def _track_request_start():
    with _inflight_lock:
        _inflight_seq[0] += 1
        rid = _inflight_seq[0]
        _inflight[rid] = {"t": time.time(), "ep": request.endpoint, "path": request.full_path,
                          "thread": threading.get_ident(), "reported": False}
    request.environ["lis.rid"] = rid


@app.teardown_request
def _track_request_end(exc=None):
    rid = request.environ.get("lis.rid")
    with _inflight_lock:
        info = _inflight.pop(rid, None)
    if info and (time.time() - info["t"]) > 2.0 and request.endpoint != "static":
        _hang_log(f"[{datetime.now().isoformat(timespec='seconds')}] SLOW {time.time() - info['t']:.1f}s "
                  f"{request.method} {info['path']} ({info['ep']})")


def _hang_watchdog():
    import sys as _sys, traceback as _tb
    while True:
        time.sleep(3)
        try:
            now = time.time()
            with _inflight_lock:
                stuck = [(rid, dict(i)) for rid, i in _inflight.items()
                         if now - i["t"] > 6 and not i["reported"]]
                for rid, _i in stuck:
                    _inflight[rid]["reported"] = True
            for rid, i in stuck:
                fr = _sys._current_frames().get(i["thread"])
                stack = "".join(_tb.format_stack(fr)) if fr else "(no frame)"
                _hang_log(f"[{datetime.now().isoformat(timespec='seconds')}] HANG {now - i['t']:.0f}s+ "
                          f"{i['path']} ({i['ep']})\n{stack}")
        except Exception:
            pass


@app.before_request
def enforce_license():
    # المسارات المستثناة من فحص الترخيص: الملفات الثابتة، ولوحة المصمم نفسها
    # (المصمم لازم يقدر يدخلها حتى لو الترخيص منتهي عشان يولّد كود جديد)،
    # وشاشة القفل/التفعيل نفسها (وإلا صار حلقة تحويل لا نهائية).
    endpoint = request.endpoint or ""

    # لو صار تحديث تلقائي بالخلفية وأعاد تشغيل البرنامج، هذا يعرض رسالة
    # نجاح لأول مستخدم يفتح أي صفحة بعدها (بدون ما يحتاج يدخل لوحة
    # المصمم إطلاقاً)، ثم يمسح العلامة فوراً حتى ما تتكرر بكل صفحة.
    if endpoint != "static":
        _db = get_db()
        _pending = get_setting(_db, "auto_update_pending_banner", "")
        if _pending:
            set_setting(_db, "auto_update_pending_banner", "")
            _db.commit()
            flash(f"✅ تم تحديث البرنامج تلقائياً إلى الإصدار {_pending} بنجاح.")
        _db.close()

    if (endpoint == "static"
            or endpoint.startswith("designer_")
            or endpoint in ("license_locked", "license_activate", "set_lang")):
        return
    # تعديل: check_license() كانت تُنادى وتكتب بقاعدة البيانات (UPDATE
    # license_info SET last_ip=..., last_checked=...) على *كل* طلب -- بما
    # فيها /front-desk/notifications/check اللي يتكرر كل ثواني قليلة تلقائيًا
    # من كل شاشة مفتوحة. هذا كان يسبب تصادم كتابة كثيف على SQLite ورسائل
    # "database is locked" / انقطاع اتصال عشوائي (مثلاً عند "Create Visit")
    # لأن كل طلب ثاني بنفس اللحظة يصادف قفل الكتابة. صار الفحص نفسه (وأهم
    # شي كتابة last_ip/last_checked) يصير مرة وحدة كل 5 دقائق بحد أقصى --
    # النتيجة (مفعّل/منتهي/إلخ) تبقى محفوظة بالذاكرة بينهم، فحساسية اكتشاف
    # ترخيص منتهي ما تتأثر عمليًا (5 دقائق تأخير كحد أقصى، بدل تأخير صفر).
    global _license_check_cache
    now_ts = time.time()
    with _license_check_lock:
        cached = _license_check_cache
        if cached is None or (now_ts - cached[0]) > 300:
            try:
                db = get_db()
                lic = license_manager.check_license(db)
                db.close()
                _license_check_cache = (now_ts, lic)
            except sqlite3.OperationalError:
                # القاعدة مشغولة لحظيًا: لا نطيّح الصفحة بخطأ 500 — نستخدم آخر نتيجة معروفة (أو نسمح)
                # ونعيد الفحص بعد دقيقة تقريبًا.
                lic = cached[1] if cached else {"status": "active"}
                _license_check_cache = (now_ts - 240, lic)
        else:
            lic = cached[1]
    if lic["status"] in ("expired", "hardware_mismatch", "pending", "revoked"):
        session.pop("user_id", None)
        session.pop("interface", None)
        return redirect(url_for("license_locked"))


@app.before_request
def enforce_interface_scope():
    """فصل واجهة "استقبال" عن واجهة "مختبر" (بدون لمس أي من الـ69 صفحة
    المحمية بـ@login_required فقط) -- استخدام بادئة الرابط بدل تعديل كل
    صفحة براسها: /front-desk/* خاص بالاستقبال، /workbench/* خاص
    بالمختبر. "الاثنين معًا" والمصمم ما عندهم أي قيد. مسجّل بعد
    enforce_license فوق حتى فحص الترخيص يشتغل أول شي دائمًا."""
    interface = session.get("interface")
    if not interface or interface == "both":
        return
    path = request.path
    # صفحات مشتركة: سجل المريض + تقرير الطباعة مفتوحة لكل الواجهات (استقبال/
    # مختبر/الاثنين) حتى موظف المختبر يقدر يطبع ويتابع نتائج المريض.
    if request.endpoint in ("patient_history", "print_visit_full_report", "visit_results_entry", "print_combined_panel",
                            "quick_entry", "api_quick_entry_search", "labels_center", "labels_outside_print",
                            "print_sample_barcodes", "print_request_label", "visit_request_qr", "visit_barcode_code128",
                            "print_visit_barcode", "completed_results", "report_pdf_test", "report_pdf_visit",
                            "api_order_test_hide_params"):
        return   # أي جهاز (حتى واجهة المختبر) يقدر يدخل النتائج من شاشة الزيارة/الإدخال السريع
    if interface == "reception" and path.startswith("/workbench"):
        flash("هذي الصفحة خاصة بواجهة المختبر فقط.")
        return redirect(url_for("dashboard"))
    if interface == "lab" and path.startswith("/front-desk"):
        flash("هذي الصفحة خاصة بواجهة الاستقبال فقط.")
        return redirect(url_for("dashboard"))


def log_action(action, entity, entity_id, details=""):
    db = get_db()
    db.execute(
        "INSERT INTO audit_logs (user_id, action, entity, entity_id, details, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (session.get("user_id"), action, entity, entity_id, details, datetime.now().isoformat(timespec="seconds")),
    )
    db.commit()


def next_registration_number(db):
    row = db.execute("SELECT MAX(registration_number) AS m FROM visits").fetchone()
    return (row["m"] or 18999) + 1


def build_test_picker_context(db, tests, referral_labs):
    """شجرة الأقسام + معلومات كل تحليل (رمز/أسماء بديلة/شرط ارتباط) + أسعار المختبرات المُرسِلة (لواجهة الزيارة الجديدة)."""
    secs = db.execute("SELECT * FROM sections ORDER BY sort_order, id").fetchall()
    nodes = {s_["id"]: {"id": s_["id"], "name": s_["name"], "parent_id": s_["parent_id"], "tests": [], "children": []} for s_ in secs}
    orphan = {"id": 0, "name": "بدون قسم", "parent_id": None, "tests": [], "children": []}
    code_to_id = {str(t["code"]).upper(): t["id"] for t in tests}
    test_meta = {}
    for t in tests:
        sid = t["section_id"] if "section_id" in t.keys() else None
        node = nodes.get(sid) or orphan
        node["tests"].append(t)
        req = []
        for c in [x.strip().upper() for x in (t["requires_codes"] or "").split(",") if x.strip()] if "requires_codes" in t.keys() else []:
            if c in code_to_id:
                req.append(code_to_id[c])
        test_meta[str(t["id"])] = {
            "code": t["code"], "name": t["name"], "name_ar": (t["name_ar"] or ""),
            "section": (node["name"] if node is not orphan else ""),
            "aliases": [x.strip() for x in ((t["aliases"] or "") if "aliases" in t.keys() else "").split(",") if x.strip()],
            "requires": [str(x) for x in req],
        }
    roots = []
    for n in nodes.values():
        par = nodes.get(n["parent_id"])
        (par["children"] if par else roots).append(n)

    def _count(n):
        n["count"] = len(n["tests"]) + sum(_count(c) for c in n["children"])
        return n["count"]
    for r in roots:
        _count(r)
    roots = [r for r in roots if r["count"] > 0]
    if orphan["tests"]:
        orphan["count"] = len(orphan["tests"])
        roots.append(orphan)
    lab_prices = {}
    for r in db.execute("SELECT center_id, test_definition_id, price FROM center_test_prices").fetchall():
        lab_prices.setdefault(str(r["center_id"]), {})[str(r["test_definition_id"])] = r["price"]
    lab_name_to_id = {(l["name"] or "").strip().lower(): l["id"] for l in referral_labs}
    return {"section_tree": roots, "test_meta": test_meta, "lab_prices": lab_prices, "lab_name_to_id": lab_name_to_id}


def doctor_pricing_context(db):
    """Everything the new-visit / edit-visit pages need to auto-fill the
    referring doctor field and switch prices live in the browser:
    - doctors: list of {id, full_name} for the autocomplete list
    - doctor_prices: {doctor_id: {test_id: price}} overrides per doctor
    - doctor_name_to_id: {lowercased full_name: id} so the page can match
      what reception typed to an existing doctor without another request
    """
    doctors = db.execute("SELECT id, full_name FROM doctors ORDER BY full_name").fetchall()
    doctors = [{"id": d["id"], "full_name": d["full_name"]} for d in doctors]

    overrides = db.execute("SELECT doctor_id, test_definition_id, price FROM doctor_test_prices").fetchall()
    doctor_prices = {}
    for row in overrides:
        doctor_prices.setdefault(str(row["doctor_id"]), {})[str(row["test_definition_id"])] = row["price"]

    doctor_name_to_id = {d["full_name"].strip().lower(): d["id"] for d in doctors}

    return doctors, doctor_prices, doctor_name_to_id


# --------------------------------------------------------------- auth ------
def _scan_like(q):
    """باركود أنبوب مطبوع بصيغة <رقم التسجيل>T<رقم> (مثل 19004T1): أي أنبوب يُمسح يفتح كل زيارة المريض، لذلك
    نحوّله إلى رقم التسجيل نفسه (مطابقة تامة بدون %). أي نص آخر يبقى بحث جزئي عادي."""
    m = re.fullmatch(r"(\d+)[Tt]\d+", (q or "").strip())
    return m.group(1) if m else f"%{q}%"



@app.route("/set-lang/<lang>")
def set_lang(lang):
    if lang in ("en", "ar"):
        session["lang"] = lang
    return redirect(request.referrer or url_for("dashboard"))


@app.route("/")
def landing():
    """الشاشة الرئيسية (المطلوب: شاشة تفتح بعد تشغيل البرنامج، فيها ثلاث
    خيارات كبطاقات مصوّرة -- استقبال/مختبر/الاثنين معًا -- بدل ما يوصل
    المستخدم لصفحة تسجيل الدخول العادية مباشرة). عامة بدون تسجيل دخول
    (نفس مبدأ /login) -- لو المستخدم مسجّل دخول أصلاً بجلسة سابقة (تذكرني)
    نوديه للوحة التحكم فورًا بدون ما نعرض له هذي الشاشة من جديد.
    """
    if "interface" in session:
        return redirect(url_for("dashboard"))
    db = get_db()
    ctx = {
        "landing_title": get_setting(db, "landing_title", "نظام الإدارة المتكامل"),
        # عنوان فرعي انكليزي اختياري تحت العنوان العربي -- فاضي افتراضيًا
        # فيبقى شكل الشاشة تمامًا زي ما كان قبل هذي الإضافة.
        "landing_title_en": get_setting(db, "landing_title_en", ""),
        "landing_gradient_color1": get_setting(db, "landing_gradient_color1", "#0f172a"),
        "landing_gradient_color2": get_setting(db, "landing_gradient_color2", "#205072"),
        "reception_needs_password": bool(get_setting(db, "interface_reception_password_hash", "")),
        "lab_needs_password": bool(get_setting(db, "interface_lab_password_hash", "")),
        "landing_image_shape": get_setting(db, "landing_image_shape", "square"),
        "landing_image_position": get_setting(db, "landing_image_position", "top"),
        "landing_image_opacity": get_setting(db, "landing_image_opacity", "100"),
        "landing_bg_overlay_opacity": get_setting(db, "landing_bg_overlay_opacity", "55"),
    }
    for key in ("reception", "lab", "together"):
        img_path = get_setting(db, f"landing_{key}_image_path", "")
        ctx[f"landing_{key}_image"] = url_for("static", filename=img_path) if img_path else None
    # صورة خلفية كاملة للشاشة الرئيسية (اختيارية) -- لو ما انرفعت، تبقى
    # الخلفية تدرّج الألوان القديم بالضبط زي ما كانت (landing.html يتحقق
    # من None ويتجاهل كل كود الصورة إذا ما فيه صورة مرفوعة).
    bg_img_path = get_setting(db, "landing_bg_image_path", "")
    ctx["landing_bg_image"] = url_for("static", filename=bg_img_path) if bg_img_path else None
    ctx["landing_bg_position"] = get_setting(db, "landing_bg_position", "background")
    ctx["landing_bg_shape"] = get_setting(db, "landing_bg_shape", "rectangle")
    ctx["landing_bg_banner_size"] = get_setting(db, "landing_bg_banner_size", "160")
    logo_img_path = get_setting(db, "landing_bglogo_image_path", "")
    ctx["landing_bg_logo_image"] = url_for("static", filename=logo_img_path) if logo_img_path else None
    ctx["landing_bg_logo_size"] = get_setting(db, "landing_bg_logo_size", "90")
    return render_template("landing.html", **ctx)


@app.route("/enter/<interface>", methods=["POST"])
def landing_enter(interface):
    """الضغط على إحدى بطاقات الشاشة الرئيسية -- بعد استبدال نظام تسجيل
    الدخول الشخصي بالكامل (نقطة 3 الموسّعة): كلمة مرور الواجهة (لو
    مضبوطة بالإعدادات) هي التحقق الوحيد الآن، وتدخل الواجهة مباشرة --
    بدون أي شاشة تسجيل دخول شخصي بعدها. الاسم الحر (operator_name)
    اختياري، يُحفظ بالجلسة فقط لغرض "مين سوى شنو" بسجلات التدقيق (يُدمج
    مع حساب الواجهة "الظل" -- راجع ensure_interface_accounts)."""
    if interface not in ("reception", "lab", "both"):
        return redirect(url_for("landing"))
    db = get_db()
    if interface != "both":
        stored_hash = get_setting(db, f"interface_{interface}_password_hash", "")
        if stored_hash:
            entered = request.form.get("password", "")
            if hash_password(entered) != stored_hash:
                flash("كلمة مرور هذي الواجهة غير صحيحة.")
                return redirect(url_for("landing"))
    shadow_username = f"__interface_{interface}__"
    shadow_user = db.execute("SELECT * FROM users WHERE username=?", (shadow_username,)).fetchone()
    if not shadow_user:
        # طبقة أمان إضافية -- ensure_interface_accounts أصلاً تسوي هذا
        # أول إقلاع، لكن لو لأي سبب ما انسوّت (قاعدة بيانات قديمة جدًا
        # قبل هذا التحديث)، ننشئها هسه بدل ما نطيح بخطأ.
        db.execute(
            "INSERT INTO users (username, password_hash, full_name, role, is_active, created_at) "
            "VALUES (?, ?, ?, 'admin', 1, ?)",
            (shadow_username, hash_password(os.urandom(16).hex()),
             {"reception": "حساب واجهة الاستقبال", "lab": "حساب واجهة المختبر",
              "both": "حساب واجهة الاستقبال والمختبر معًا"}[interface],
             datetime.now().isoformat(timespec="seconds")),
        )
        db.commit()
        shadow_user = db.execute("SELECT * FROM users WHERE username=?", (shadow_username,)).fetchone()

    operator_name = (request.form.get("operator_name") or "").strip()
    session["user_id"] = shadow_user["id"]
    session["role"] = "admin"
    session["branch_id"] = shadow_user["branch_id"]
    session["interface"] = interface
    session["full_name"] = operator_name or shadow_user["full_name"]
    session["operator_name"] = operator_name
    session.permanent = True
    log_action("EnterInterface", "user", shadow_user["id"], f"interface={interface} operator={operator_name}")
    return redirect(url_for("dashboard"))


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username = ? AND is_active = 1", (username,)).fetchone()
        if user and user["password_hash"] == hash_password(password):
            session["user_id"] = user["id"]
            session["full_name"] = user["full_name"]
            session["role"] = user["role"]
            session["branch_id"] = user["branch_id"]
            session.permanent = bool(request.form.get("remember"))
            log_action("Login", "user", user["id"])
            # لو المستخدم اختار واحد من بطاقات الشاشة الرئيسية (استقبال/
            # مختبر/الاثنين معًا) قبل لا يوصل لصفحة الدخول هذي، نطبّق
            # اختياره فورًا ونروح مباشرة للوحة التحكم بدون ما نسأله مرة
            # ثانية بصفحة interface_choose. الدخول المباشر بـ/login (بدون
            # المرور بالشاشة الرئيسية أول) يبقى يشتغل متل ما كان -- يودّيه
            # لصفحة الاختيار بعد الدخول كالمعتاد.
            pending_interface = session.pop("pending_interface", None)
            if pending_interface in ("reception", "lab", "both"):
                session["interface"] = pending_interface
                return redirect(url_for("dashboard"))
            return redirect(url_for("interface_choose"))
        error = t(current_lang(), "invalid_login")
    return render_template("login.html", error=error)


@app.route("/interface/choose")
@login_required
def interface_choose():
    """شاشة اختيار صفة الدخول (المطلوب 3): استقبال/مختبر/الاثنين معًا.
    فلترة عرض فقط لأقسام القائمة الجانبية -- ما تغيّر صلاحيات اليوزر
    الفعلية (role) إطلاقًا. تبديل الواجهة لاحقًا (من نفس هذي الصفحة عبر
    زر "تبديل الواجهة" بأسفل القائمة) يحتاج كلمة مرور خاصة بتلك الواجهة
    (تُضبط من صفحة الإعدادات) -- اختيار "الاثنين معًا" ما يحتاج كلمة مرور
    لأنه أوسع خيار (كل الأقسام)، فمافيه شي يُقيَّد عنه."""
    db = get_db()
    reception_configured = bool(get_setting(db, "interface_reception_password_hash", ""))
    lab_configured = bool(get_setting(db, "interface_lab_password_hash", ""))
    try:
        return render_template("interface_choose.html", current_interface=session.get("interface"),
                                reception_configured=reception_configured, lab_configured=lab_configured,
                                both_configured=False)
    except Exception:
        # لو قالب interface_choose.html نفسه فيه خطأ، نطبع السبب الحقيقي
        # (traceback) بنافذة السيرفر بدل صفحة 500 صماء، ونعرض صفحة اختيار
        # بسيطة تشتغل فعلاً حتى يبقى تبديل الواجهة ممكن.
        app.logger.exception("interface_choose.html failed to render")
        return _interface_choose_fallback(reception_configured, lab_configured)


def _interface_choose_fallback(reception_configured, lab_configured):
    from markupsafe import escape
    current = session.get("interface") or ""
    def card(key, title, needs_pw):
        pw = ('<input type="password" name="password" placeholder="كلمة مرور الواجهة" '
              'style="padding:8px;margin:8px 0;width:90%;">') if needs_pw else ""
        mark = " ✅" if current == key else ""
        return (f'<form method="POST" action="{url_for("interface_set")}" '
                f'style="background:#fff;border:1px solid #E2E8F0;border-radius:12px;padding:18px;'
                f'min-width:200px;text-align:center;">'
                f'<input type="hidden" name="interface" value="{key}">'
                f'<h3 style="margin:0 0 8px;">{escape(title)}{mark}</h3>{pw}'
                f'<button type="submit" style="padding:8px 18px;border:0;border-radius:8px;'
                f'background:#205072;color:#fff;cursor:pointer;">دخول</button></form>')
    flashes = "".join(f'<p style="color:#b91c1c;">{escape(m)}</p>' for m in get_flashed_messages())
    html = (
        '<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8">'
        '<title>تبديل الواجهة</title></head>'
        '<body style="font-family:Tahoma,Arial,sans-serif;background:#F3F6F8;padding:30px;">'
        '<h2>🔀 تبديل الواجهة</h2>' + flashes +
        '<div style="display:flex;gap:16px;flex-wrap:wrap;">'
        + card("reception", "استقبال", reception_configured)
        + card("lab", "مختبر", lab_configured)
        + card("both", "الاثنين معًا", False) +
        '</div><p><a href="' + url_for("dashboard") + '">↩ رجوع للرئيسية</a></p></body></html>'
    )
    return html


@app.route("/interface/set", methods=["POST"])
@login_required
def interface_set():
    choice = request.form.get("interface")
    if choice not in ("reception", "lab", "both"):
        flash("اختيار غير صحيح.")
        return redirect(url_for("interface_choose"))
    db = get_db()
    if choice != "both":
        setting_key = f"interface_{choice}_password_hash"
        stored_hash = get_setting(db, setting_key, "")
        if stored_hash:
            entered = request.form.get("password", "")
            if hash_password(entered) != stored_hash:
                flash("كلمة مرور هذي الواجهة غير صحيحة.")
                return redirect(url_for("interface_choose"))
        # لو ما فيه كلمة مرور مضبوطة لهذي الواجهة بعد، تُقبل بدون كلمة مرور
        # (بدل ما تصير الميزة كلها معطّلة لين الأدمن يضبطها من الإعدادات).
    # تبديل حساب الجلسة "الظل" لنفس واجهة الاختيار الجديد -- حتى entered_by
    # وaudit_logs يبقون متوافقين مع الواجهة الفعلية بعد التبديل (نفس مبدأ
    # landing_enter بالضبط).
    shadow_username = f"__interface_{choice}__"
    shadow_user = db.execute("SELECT * FROM users WHERE username=?", (shadow_username,)).fetchone()
    if shadow_user:
        session["user_id"] = shadow_user["id"]
        session["full_name"] = session.get("operator_name") or shadow_user["full_name"]
    session["interface"] = choice
    log_action("SetInterface", "user", session.get("user_id"), choice)
    return redirect(url_for("dashboard"))


@app.route("/logout")
def logout():
    if "user_id" in session:
        log_action("Logout", "user", session.get("user_id"))
    session.clear()
    return redirect(url_for("landing"))


# ---------------------------------------------------- license (client side) --
@app.route("/license/locked")
def license_locked():
    db = get_db()
    lic = license_manager.check_license(db)
    db.close()
    return render_template("license_locked.html", lic=lic)


@app.route("/license/activate", methods=["POST"])
def license_activate():
    username = request.form.get("username", "")
    code = request.form.get("code", "")
    db = get_db()
    ok, err = license_manager.apply_activation(db, username, code)
    db.close()
    if ok:
        flash("تم تفعيل الترخيص بنجاح")
        return redirect(url_for("landing"))
    flash(err or "فشل التفعيل")
    return redirect(url_for("license_locked"))


# --------------------------------------------------------- designer panel --
@app.route("/designer/setup", methods=["GET", "POST"])
def designer_setup():
    db = get_db()
    if license_manager.designer_exists(db):
        db.close()
        return redirect(url_for("designer_login"))
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")
        if not username or len(password) < 6:
            error = "أدخل اسم مستخدم وكلمة مرور لا تقل عن 6 أحرف"
        elif password != confirm:
            error = "كلمتا المرور غير متطابقتين"
        else:
            license_manager.create_designer_account(db, username, password)
            db.close()
            flash("تم إنشاء حساب المصمم — سجّل الدخول الآن")
            return redirect(url_for("designer_login"))
    db.close()
    return render_template("designer/setup.html", error=error)


@app.route("/designer/login", methods=["GET", "POST"])
def designer_login():
    db = get_db()
    if not license_manager.designer_exists(db):
        db.close()
        return redirect(url_for("designer_setup"))
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if license_manager.verify_designer(db, username, password):
            session["designer_id"] = 1
            session["designer_username"] = username
            db.close()
            return redirect(url_for("designer_panel"))
        error = "بيانات الدخول غير صحيحة"
    db.close()
    return render_template("designer/login.html", error=error)


@app.route("/designer/logout")
def designer_logout():
    session.pop("designer_id", None)
    session.pop("designer_username", None)
    return redirect(url_for("designer_login"))



# ---- قائمة الإلغاء: كاش + تحديث بالخلفية (كانت تُجلب من GitHub بكل فتحة للوحة المصمم بمهلة 20 ثانية
# فتصفن الصفحة لما الإنترنت/الـDNS بطيء). الحين الصفحة ما تنتظر الشبكة أكثر من ثانية ونصف. ----
_REVOKE_CACHE = {"data": {}, "error": None, "ts": 0.0, "busy": False}
_REVOKE_LOCK = threading.Lock()


def _revocation_refresh_worker():
    try:
        data = auto_updater.fetch_revocation_list()
        err = None
    except Exception as e:
        data, err = None, str(e)
    with _REVOKE_LOCK:
        if data is not None:
            _REVOKE_CACHE["data"] = data
        _REVOKE_CACHE["error"] = err
        _REVOKE_CACHE["ts"] = time.time()
        _REVOKE_CACHE["busy"] = False


def _revocation_invalidate():
    with _REVOKE_LOCK:
        _REVOKE_CACHE["ts"] = 0.0


def _revocation_cached(ttl=120, wait=1.5):
    now = time.time()
    with _REVOKE_LOCK:
        fresh = (now - _REVOKE_CACHE["ts"]) < ttl
        start = (not fresh) and (not _REVOKE_CACHE["busy"])
        if start:
            _REVOKE_CACHE["busy"] = True
    if start:
        t = threading.Thread(target=_revocation_refresh_worker, daemon=True)
        t.start()
        if _REVOKE_CACHE["ts"] == 0.0:
            t.join(wait)          # أول مرة فقط ننتظر شوي
    with _REVOKE_LOCK:
        err = _REVOKE_CACHE["error"]
        if _REVOKE_CACHE["ts"] == 0.0 and not err:
            err = "جارِ جلب قائمة الإلغاء من GitHub بالخلفية… حدّث الصفحة بعد لحظات."
        return dict(_REVOKE_CACHE["data"]), err


@app.route("/designer")
@designer_required
def designer_panel():
    db = get_db()
    lic = license_manager.check_license(db)
    issue_log = db.execute("SELECT * FROM license_issue_log ORDER BY id DESC LIMIT 50").fetchall()
    update_info = {
        "local_version": auto_updater.get_local_version(),
        "configured": auto_updater.is_configured(),
        "enabled": get_setting(db, "auto_update_enabled", "1") == "1",
        "last_check": get_setting(db, "auto_update_last_check", ""),
        "last_status": get_setting(db, "auto_update_last_status", ""),
        "branch": auto_updater.get_update_branch(db),
        "default_branch": auto_updater.GITHUB_BRANCH,
        "custom_channel": get_setting(db, "update_channel", ""),
    }
    github_write_token = get_setting(db, "github_write_token", "")
    github_read_token = get_setting(db, "github_read_token", "")
    revoked_licenses = {}
    revocation_error = None
    if github_write_token and auto_updater.is_configured():
        revoked_licenses, revocation_error = _revocation_cached()
    branding = {
        "app_name": get_setting(db, "app_name", ""),
        "app_name_ar": get_setting(db, "app_name_ar", ""),
        "logo_path": get_setting(db, "logo_path", ""),
    }
    db.close()
    return render_template(
        "designer/panel.html", lic=lic, issue_log=issue_log,
        this_hw=license_manager.get_hardware_id(), this_ip=license_manager.get_local_ip(),
        update_info=update_info, github_write_token=github_write_token,
        github_read_token=github_read_token,
        revoked_licenses=revoked_licenses, revocation_error=revocation_error,
        branding=branding,
    )


# ============== تفريغ بيانات البرنامج (المصمم فقط) قبل تسليمه لعميل ==============
# كل مجموعة = جداول تُفرَّغ. الاعتماديات: اختيار "الزيارات" يفرض "النتائج" معه، واختيار "المرضى" يفرض "الزيارات".
_WIPE_GROUPS = [
    ("results", "النتائج السابقة (نتائج التحاليل + سجل التعديلات + ملاحظات التقارير + دمج/تفضيلات النتائج السابقة)",
     ["visit_previous_merges", "visit_prev_prefs", "result_history", "results", "report_row_notes", "saved_reports",
      "report_stamp_placements"], ["report_layout_overrides|scope='order_test'"]),
    ("visits", "الزيارات (الزيارات + الطلبات + التحاليل المطلوبة + الفواتير + الدفعات + المتابعات + ترقيم العينات + بوابة QR)",
     ["removed_order_tests", "patient_followups", "payments", "invoices", "order_tests", "orders", "visits",
      "sample_counters", "portal_state"], []),
    ("patients", "المرضى (بطاقات المرضى)", ["patients"], []),
    ("whatsapp", "طابور وسجل الواتساب", ["whatsapp_sends"], []),
    ("audit", "سجل العمليات (Audit log) وسجل ربط الأجهزة", ["audit_logs", "host_interface_log"], []),
]
_WIPE_DIRS = {"visits": ("static/whatsapp_pdfs", "static/pdf_archive", "static/reports_pdf", "static/portal_pdf_cache"),
              "whatsapp": ("static/whatsapp_pdfs",)}


def _wipe_counts(db):
    existing = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    out = []
    for key, label, tables, extra in _WIPE_GROUPS:
        n = 0
        for t_ in tables:
            if t_ in existing:
                n += db.execute(f"SELECT COUNT(*) FROM {t_}").fetchone()[0]
        out.append({"key": key, "label": label, "count": n})
    return out


@app.route("/designer/wipe", methods=["GET", "POST"])
@designer_required
def designer_wipe():
    """يفرّغ بيانات التشغيل (نتائج/زيارات/مرضى/واتساب/سجلات) ويبقي الإعدادات والتحاليل والنسب والتصاميم والمستخدمين والأطباء.
    يأخذ نسخة احتياطية كاملة من القاعدة قبل التفريغ ويطلب كتابة كلمة تأكيد."""
    db = get_db()
    if request.method == "POST":
        picked = set(request.form.getlist("groups"))
        if "patients" in picked:
            picked |= {"visits"}
        if "visits" in picked:
            picked |= {"results"}
        if request.form.get("confirm", "").strip() != "تفريغ":
            flash("لم يتم التفريغ: اكتب كلمة  تفريغ  بخانة التأكيد.")
            return redirect(url_for("designer_wipe"))
        if not picked:
            flash("اختر مجموعة واحدة على الأقل.")
            return redirect(url_for("designer_wipe"))
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"lis_before_wipe_{stamp}.db"
        backup_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), backup_name)
        try:
            bk = sqlite3.connect(backup_path)
            db.backup(bk)
            bk.close()
        except Exception as e:  # noqa: BLE001
            flash(f"تعذّر أخذ النسخة الاحتياطية ({type(e).__name__}) — لم يُفرَّغ شي.")
            return redirect(url_for("designer_wipe"))
        existing = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        # الترتيب: النتائج → الزيارات → المرضى (الأبناء قبل الآباء)
        db.execute("PRAGMA foreign_keys = OFF")
        removed = 0
        for key, label, tables, extra in _WIPE_GROUPS:
            if key not in picked:
                continue
            for t_ in tables:
                if t_ in existing:
                    removed += db.execute(f"DELETE FROM {t_}").rowcount
            for spec in extra:
                tname, cond = spec.split("|", 1)
                if tname in existing:
                    removed += db.execute(f"DELETE FROM {tname} WHERE {cond}").rowcount
            if "sqlite_sequence" in existing:
                for t_ in tables:
                    db.execute("DELETE FROM sqlite_sequence WHERE name=?", (t_,))
            for d in _WIPE_DIRS.get(key, ()):
                full = os.path.join(os.path.dirname(os.path.abspath(__file__)), d)
                if os.path.isdir(full):
                    for fn in os.listdir(full):
                        fp = os.path.join(full, fn)
                        if os.path.isfile(fp):
                            try:
                                os.remove(fp)
                            except OSError:
                                pass
        if "visits" in picked:
            try:  # بوابة QR المحلية: تفريغ الصفحات المنشورة أيضًا
                import portal_local
                _pc = portal_local._db()
                _pc.execute("DELETE FROM reports")
                _pc.commit()
                _pc.close()
            except Exception:
                pass
        db.commit()
        db.execute("PRAGMA foreign_keys = ON")
        try:
            db.execute("VACUUM")
        except Exception:
            pass
        log_action("DesignerWipe", "system", 0, ",".join(sorted(picked)))
        flash(f"تم التفريغ ({removed} سجل). نسخة احتياطية كاملة قبل التفريغ: {backup_name} (بمجلد البرنامج).")
        return redirect(url_for("designer_wipe"))
    groups = _wipe_counts(db)
    db.close()
    return render_template("designer/wipe.html", groups=groups)


@app.route("/designer/github-token", methods=["POST"])
@designer_required
def designer_save_github_token():
    """يحفظ توكن GitHub بصلاحية كتابة محلياً بجدول settings بجهاز المصمم
    فقط — منفصل تماماً عن توكن القراءة (settings.github_read_token، راجع
    /designer/github-read-token تحت) المشحون مع نسخة كل عميل. هذا التوكن
    لا يُشحن أبداً مع أي نسخة تُسلَّم لعميل، فيبقى فقط بقاعدة بيانات جهاز
    المصمم نفسه."""
    db = get_db()
    token = request.form.get("github_write_token", "").strip()
    set_setting(db, "github_write_token", token)
    db.commit()
    db.close()
    flash("تم حفظ توكن الكتابة." if token else "تم مسح توكن الكتابة.")
    return redirect(url_for("designer_panel"))


@app.route("/designer/github-read-token", methods=["POST"])
@designer_required
def designer_save_github_read_token():
    """يحفظ توكن القراءة (اللي يستخدمه هذا الجهاز بالذات لفحص/تنزيل
    التحديثات من GitHub) بجدول settings المحلي فقط — أبداً لا يُكتب بأي
    ملف كود يدخل بـ git push، حتى لا يكتشفه GitHub تلقائياً كسر مسرّب
    ويُلغيه (هذا بالضبط سبب انقطاع التحديث المتكرر قبل هذا التعديل).
    يُطبَّق فوراً بذاكرة هذا التشغيل عبر configure_token() بدون أي حاجة
    لإعادة تشغيل البرنامج."""
    db = get_db()
    token = request.form.get("github_read_token", "").strip()
    set_setting(db, "github_read_token", token)
    db.commit()
    db.close()
    auto_updater.configure_token(token)
    flash("تم حفظ توكن القراءة وتفعيله فوراً." if token else "تم مسح توكن القراءة.")
    return redirect(url_for("designer_panel"))


# تعديل سريع لاسم المختبر (عربي/إنكليزي) والشعار مباشرة من لوحة المصمم —
# بعد رفع تحديث لعميل معيّن، يضبط المصمم هويته الصحيحة بنفس الصفحة اللي
# رفع منها التحديث، بدون ما يحتاج يفتح "الإدارة ← الإعدادات" كخطوة منفصلة.
# يستخدم بالضبط نفس مفاتيح settings (app_name, app_name_ar, logo_path)
# ونفس منطق حفظ الشعار المستخدم بصفحة الإعدادات العادية (app_settings)،
# فالقيمتين مصدرهما واحد بغض النظر من وين تُعدَّل.
@app.route("/designer/branding", methods=["POST"])
@designer_required
def designer_save_branding():
    db = get_db()
    name_en = request.form.get("app_name", "").strip()
    name_ar = request.form.get("app_name_ar", "").strip()
    if name_en:
        set_setting(db, "app_name", name_en)
    if name_ar:
        set_setting(db, "app_name_ar", name_ar)

    file = request.files.get("logo")
    if file and file.filename:
        ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
        if ext in ALLOWED_LOGO_EXT:
            filename = secure_filename(f"logo.{ext}")
            for old_ext in ALLOWED_LOGO_EXT:
                old_path = os.path.join(UPLOAD_DIR, f"logo.{old_ext}")
                if os.path.exists(old_path):
                    os.remove(old_path)
            file.save(os.path.join(UPLOAD_DIR, filename))
            set_setting(db, "logo_path", f"uploads/{filename}")
        else:
            flash("امتداد الشعار غير مدعوم. استخدم PNG, JPG, GIF, SVG أو WEBP.")

    db.commit()
    db.close()
    flash("تم حفظ اسم المختبر/الشعار.")
    return redirect(url_for("designer_panel"))


@app.route("/designer/revoke", methods=["POST"])
@designer_required
def designer_revoke_license():
    db = get_db()
    write_token = get_setting(db, "github_write_token", "")
    hardware_id = request.form.get("hardware_id", "").strip()
    reason = request.form.get("reason", "").strip()
    if not hardware_id:
        flash("أدخل معرّف جهاز العميل المطلوب إلغاء ترخيصه")
    else:
        try:
            auto_updater.push_revocation(write_token, hardware_id, reason, revoke=True)
            _revocation_invalidate()
            flash(f"تم إرسال إلغاء الترخيص لجهاز {hardware_id} — راح يوصله أول ما يتصل بالنت (لازم يكون \"مربوط بالإنترنت\" مفعّل عنده).")
        except Exception as e:
            flash(f"⚠️ تعذر إلغاء الترخيص عن بُعد: {e}")
    db.close()
    return redirect(url_for("designer_panel"))


@app.route("/designer/revoke/<path:hardware_id>/restore", methods=["POST"])
@designer_required
def designer_restore_license(hardware_id):
    db = get_db()
    write_token = get_setting(db, "github_write_token", "")
    try:
        auto_updater.push_revocation(write_token, hardware_id, None, revoke=False)
        _revocation_invalidate()
        flash(f"تم رفع الإلغاء عن جهاز {hardware_id} — يقدر يفعّل ببرنامجه بكود جديد أول ما يتصل بالنت.")
    except Exception as e:
        flash(f"⚠️ تعذر رفع الإلغاء: {e}")
    db.close()
    return redirect(url_for("designer_panel"))


@app.route("/designer/update/push", methods=["POST"])
@designer_required
def designer_push_update():
    """يرسل أمر تحديث فوري لجهاز عميل واحد بالذات (مستقل عن بقية العملاء)
    — لا ينتظر دورة الفحص التلقائي (كل CHECK_INTERVAL_HOURS)، بل يُطبَّق أول
    ما يتصل ذلك الجهاز بالنت (أو فوراً لو ضغط عنده زر 'تحقق من تحديث
    الآن'). يعتمد فعلياً على أن يكون ذلك الجهاز 'مربوط بالإنترنت' من لوحة
    المصمم عنده، ويستخدم نفس توكن الكتابة المستخدَم لإلغاء التراخيص عن بُعد."""
    db = get_db()
    write_token = get_setting(db, "github_write_token", "")
    hardware_id = request.form.get("hardware_id", "").strip()
    if not hardware_id:
        flash("أدخل معرّف جهاز العميل المطلوب إرسال التحديث له")
    else:
        try:
            auto_updater.push_update_signal(write_token, hardware_id)
            flash(f"تم إرسال أمر تحديث فوري لجهاز {hardware_id} — راح يُطبَّق أول ما يتصل بالنت "
                  f"(لازم يكون \"مربوط بالإنترنت\" مفعّل عنده، أو يضغط هو زر \"تحقق من تحديث الآن\").")
        except Exception as e:
            flash(f"⚠️ تعذر إرسال أمر التحديث: {e}")
    db.close()
    return redirect(url_for("designer_panel"))


@app.route("/designer/update/channel", methods=["POST"])
@designer_required
def designer_update_channel():
    """يضبط 'قناة التحديث' (اسم الفرع بمستودع GitHub) لهذا الجهاز بالذات.
    اتركه فاضي حتى يرجع يتابع الفرع العام (GITHUB_BRANCH، افتراضياً main)
    زي باقي العملاء. عبّي اسم فرع خاص (مثلاً client-alkut) حتى يستلم هذا
    الجهاز فقط تحديثات ذلك الفرع دون بقية العملاء."""
    db = get_db()
    channel = request.form.get("update_channel", "").strip()
    set_setting(db, "update_channel", channel)
    db.commit()
    db.close()
    if channel:
        flash(f"تم ضبط هذا الجهاز على قناة تحديث خاصة: {channel} — لن يتأثر بتحديثات main العامة إلا هذا الفرع.")
    else:
        flash("تم إرجاع هذا الجهاز لمتابعة قناة التحديث العامة (main) مثل بقية العملاء.")
    return redirect(url_for("designer_panel"))


@app.route("/designer/update/toggle", methods=["POST"])
@designer_required
def designer_update_toggle():
    """يشغّل/يوقف "ربط هذا الجهاز بالإنترنت" — أي تفعيل الفحص الدوري
    التلقائي للتحديثات من GitHub. هذا الأمر خاص بلوحة المصمم فقط ولا
    يظهر أبداً للمستخدمين العاديين (admin/reception)."""
    db = get_db()
    currently_on = get_setting(db, "auto_update_enabled", "0") == "1"
    set_setting(db, "auto_update_enabled", "0" if currently_on else "1")
    db.commit()
    db.close()
    flash("تم فصل البرنامج عن التحديث التلقائي" if currently_on else "تم ربط البرنامج بالإنترنت — سيتحقق تلقائياً من التحديثات دورياً")
    return redirect(url_for("designer_panel"))


@app.route("/designer/update/check-now", methods=["POST"])
@designer_required
def designer_update_check_now():
    """فحص فوري يدوي (زر احتياطي) — يشتغل بغض النظر عن حالة الربط
    التلقائي، مفيد لتجربة الاتصال أو لتنزيل تحديث فوراً بدون انتظار.
    يفحص أيضاً قائمة الإلغاء البعيدة لهذا الجهاز نفسه بنفس الفحص (مفيد
    لو المصمم يجرّب الميزة على جهازه هو قبل ما يعتمد عليها مع عميل)."""
    db = get_db()
    if not auto_updater.is_configured():
        flash("⚠️ لم يتم إعداد بيانات GitHub بعد داخل auto_updater.py")
    else:
        result = auto_updater.check_and_apply(db, force_apply=True)
        auto_updater.check_revocation(db)
        auto_updater.check_update_signal(db)
        try:
            _cm = auto_updater.check_config_pack(db)
            if _cm:
                flash(_cm)
        except Exception:
            pass
        flash(result["message"])
    db.close()
    return redirect(url_for("designer_panel"))


@app.route("/designer/generate", methods=["POST"])
@designer_required
def designer_generate():
    hardware_id = request.form.get("hardware_id", "").strip().upper()
    username = request.form.get("username", "").strip()
    expiry_mode = request.form.get("expiry_mode")

    if not hardware_id or not username:
        flash("أدخل معرّف الجهاز واسم المستخدم")
        return redirect(url_for("designer_panel"))

    preset = LICENSE_DURATION_PRESETS.get(expiry_mode)
    if not preset:
        flash("مدة ترخيص غير صالحة — اختر مدة من القائمة")
        return redirect(url_for("designer_panel"))

    _label, days = preset
    is_trial = expiry_mode == "trial"
    # days=None يعني ترخيص دائم فعلي (بدون تاريخ انتهاء) — license_manager
    # يخزّنه كـ "PERM" داخل الكود نفسه ويتحقق منه محلياً دون أي اعتماد على
    # تاريخ. الإلغاء عن بُعد (designer_revoke_license) يبقى شغّال بنفس
    # الطريقة حتى مع ترخيص دائم، فهو ليس "بلا رجعة".
    expiry_date = None if days is None else (date.today() + timedelta(days=days)).isoformat()

    code = license_manager.generate_activation_code(hardware_id, expiry_date, is_trial=is_trial)
    db = get_db()
    license_manager.log_issued_code(db, hardware_id, username, expiry_date, code)
    db.close()
    return render_template(
        "designer/generated.html", username=username, code=code,
        hardware_id=hardware_id, expiry_date=expiry_date,
    )


@app.route("/designer/issue-log/<int:log_id>/delete", methods=["POST"])
@designer_required
def designer_delete_issue_log(log_id):
    """حذف سطر واحد من سجل أكواد التفعيل المولَّدة — لا يلغي الترخيص نفسه
    عند العميل (الكود المفعّل عنده يبقى شغّال)، فقط ينظّف السجل المعروض
    بلوحة المصمم."""
    db = get_db()
    db.execute("DELETE FROM license_issue_log WHERE id=?", (log_id,))
    db.commit()
    db.close()
    flash("تم حذف السطر من السجل.")
    return redirect(url_for("designer_panel"))


@app.route("/designer/client/delete", methods=["POST"])
@designer_required
def designer_delete_client():
    """حذف عميل كامل من سجل لوحة المصمم (كل أسطر أكواد التفعيل لنفس معرّف الجهاز).
    لا يحتاج أي توكن ولا يلغي الترخيص عند العميل — فقط ينظّف السجل المعروض.
    لإلغاء ترخيصه فعليًا عن بُعد استخدم زر \"إلغاء التفعيل\" (يحتاج توكن الكتابة)."""
    hardware_id = request.form.get("hardware_id", "").strip()
    if not hardware_id:
        flash("معرّف جهاز العميل مفقود.")
        return redirect(url_for("designer_panel"))
    db = get_db()
    n = db.execute("DELETE FROM license_issue_log WHERE hardware_id=?", (hardware_id,)).rowcount
    db.commit()
    db.close()
    flash(f"تم حذف العميل من السجل ({n} سطر).")
    return redirect(url_for("designer_panel"))


def _parse_extension_text(raw):
    """نص حر لمدة التمديد: "1 يوم" / "2 يوم" / "اسبوع" / "1 شهر" / "3 شهر" / "6 اشهر" / "1 سنة" /
    "سنتين" / "دائمي". يرجّع ("perm", None) أو ("delta", (سنوات, أشهر, أيام)) أو None لو ما فهم."""
    t = str(raw or "").strip().lower()
    t = t.translate({ord(c): str(i) for i, c in enumerate("٠١٢٣٤٥٦٧٨٩")})
    t = t.translate({ord(c): str(i) for i, c in enumerate("۰۱۲۳۴۵۶۷۸۹")})
    t = (t.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا").replace("ة", "ه").replace("ى", "ي"))
    t = re.sub(r"\s+", " ", t).strip()
    if not t:
        return None
    if re.search(r"دائم|دايم|مدي? ?الحياه|permanent|perm|forever|lifetime|unlimited", t):
        return ("perm", None)
    if re.fullmatch(r"\d+", t):                      # رقم لحاله = أيام (السلوك القديم)
        return ("delta", (0, 0, int(t)))
    y = m = d = 0
    found = False
    units = [
        (r"(\d+)?\s*(?:سنتين|سنتان)", "y2"), (r"(\d+)?\s*(?:سنوات|سنه|سنين|سنة|years?|yrs?|y)(?![a-z\u0621-\u064a])", "y"),
        (r"(\d+)?\s*(?:شهرين|شهران)", "m2"), (r"(\d+)?\s*(?:اشهر|شهور|شهر|months?|mos?)(?![a-z\u0621-\u064a])", "m"),
        (r"(\d+)?\s*(?:اسبوعين|اسبوعان)", "w2"), (r"(\d+)?\s*(?:اسابيع|اسبوع|weeks?|w)(?![a-z\u0621-\u064a])", "w"),
        (r"(\d+)?\s*(?:يومين|يومان)", "d2"), (r"(\d+)?\s*(?:ايام|يوم|days?|d)(?![a-z\u0621-\u064a])", "d"),
    ]
    rest = t
    for pat, kind in units:
        for mt in list(re.finditer(pat, rest)):
            n = int(mt.group(1)) if mt.group(1) else 1
            if kind.endswith("2"):
                n = 2
            if kind[0] == "y": y += n
            elif kind[0] == "m": m += n
            elif kind[0] == "w": d += 7 * n
            else: d += n
            found = True
        rest = re.sub(pat, " ", rest)
    left = re.sub(r"[\s,و+]|and", "", rest)
    if not found or left:
        return None
    return ("delta", (y, m, d))


def _add_ymd(base, y, m, d):
    """يضيف سنوات/أشهر تقويمية (مع ضبط آخر الشهر) ثم أيام."""
    import calendar
    total = base.year * 12 + (base.month - 1) + y * 12 + m
    ny, nm = divmod(total, 12)
    nm += 1
    nd = min(base.day, calendar.monthrange(ny, nm)[1])
    return date(ny, nm, nd) + timedelta(days=d)


@app.route("/designer/client/extend", methods=["POST"])
@designer_required
def designer_extend_client():
    """تمديد فترة عميل بنص حر (1 يوم، 2 يوم، 1 شهر، 3 شهر، 6 شهر، 1 سنة، دائمي ...):
    يولّد كود تفعيل جديد لنفس الجهاز. التمديد يُحسب من تاريخ انتهائه الحالي لو لسا
    ما انتهى، وإلا من اليوم. "دائمي" = ترخيص بلا تاريخ انتهاء. محلي — بدون توكن ولا إنترنت."""
    hardware_id = request.form.get("hardware_id", "").strip().upper()
    username = request.form.get("username", "").strip()
    raw = request.form.get("extension", request.form.get("extra_days", ""))
    parsed = _parse_extension_text(raw)
    if not hardware_id or parsed is None:
        flash("ما فهمت مدة التمديد — اكتب مثلاً: 1 يوم، 2 يوم، 1 شهر، 3 شهر، 6 شهر، 1 سنة، دائمي.")
        return redirect(url_for("designer_panel"))
    db = get_db()
    row = db.execute(
        "SELECT expiry, username FROM license_issue_log WHERE upper(hardware_id)=? ORDER BY id DESC LIMIT 1",
        (hardware_id,),
    ).fetchone()
    username = username or (row["username"] if row and row["username"] else "client")
    if parsed[0] == "perm":
        expiry_date = None
    else:
        base = date.today()
        if row and row["expiry"] and row["expiry"] not in ("PERM", "None", "دائم"):
            try:
                cur = date.fromisoformat(str(row["expiry"])[:10])
                if cur > base:
                    base = cur
            except ValueError:
                pass
        expiry_date = _add_ymd(base, *parsed[1]).isoformat()
    code = license_manager.generate_activation_code(hardware_id, expiry_date, is_trial=False)
    license_manager.log_issued_code(db, hardware_id, username, expiry_date, code)
    db.close()
    return render_template("designer/generated.html", username=username, code=code,
                           hardware_id=hardware_id, expiry_date=expiry_date)


@app.route("/designer/change-password", methods=["POST"])
@designer_required
def designer_change_password():
    new_password = request.form.get("new_password", "")
    confirm = request.form.get("confirm", "")
    if len(new_password) < 6 or new_password != confirm:
        flash("تحقق من كلمة المرور الجديدة (6 أحرف على الأقل ومتطابقة)")
        return redirect(url_for("designer_panel"))
    db = get_db()
    license_manager.change_designer_password(db, new_password)
    db.close()
    flash("تم تغيير كلمة مرور المصمم")
    return redirect(url_for("designer_panel"))


# ---------------------------------------------------------- dashboard ------
@app.route("/dashboard")
@login_required
def dashboard():
    db = get_db()
    today = date.today().isoformat()
    visits_today = db.execute(
        "SELECT COUNT(*) c FROM visits WHERE substr(created_at,1,10)=?", (today,)
    ).fetchone()["c"]
    revenue_today = db.execute(
        "SELECT COALESCE(SUM(amount),0) s FROM payments WHERE substr(paid_at,1,10)=?", (today,)
    ).fetchone()["s"]
    pending_results = db.execute(
        "SELECT COUNT(*) c FROM order_tests WHERE status IN ('Accepted','In-progress')"
    ).fetchone()["c"]
    critical_count = db.execute(
        "SELECT COUNT(*) c FROM results WHERE flag='Critical' AND verified_at IS NULL"
    ).fetchone()["c"]
    # "آخر الزيارات" انتقلت لصفحتها الخاصة (راجع recent_visits_page أدناه)
    # وصارت وحدة من قوائم Front Desk المنسدلة، بدل ما تظهر مباشرة أسفل
    # لوحة التحكم -- فما نجيب هذا الاستعلام هنا بعد الآن.
    return render_template("dashboard.html", visits_today=visits_today, revenue_today=revenue_today,
                            pending_results=pending_results, critical_count=critical_count)


@app.route("/front-desk/recent-visits")
@login_required
def recent_visits_page():
    """صفحة "آخر الزيارات" المستقلة -- كانت جدول ثابت أسفل لوحة التحكم،
    صارت صفحة خاصة بيها ضمن قائمة Front Desk المنسدلة (بطلب المستخدم)."""
    db = get_db()
    recent_visits = db.execute(
        "SELECT v.id, v.registration_number, p.id as patient_id, p.full_name, v.status, v.created_at "
        "FROM visits v JOIN patients p ON p.id=v.patient_id "
        "ORDER BY v.id DESC LIMIT 100"
    ).fetchall()
    return render_template("front_desk/recent_visits.html", recent_visits=recent_visits)


@app.route("/front-desk/visits/<int:visit_id>/print/full-report")
@login_required
def print_visit_full_report(visit_id):
    """يعرض نفس التقرير الكامل الحقيقي (نفس التصميم بالضبط المستخدم أصلاً
    للأرشفة الآلية، لإرسال واتساب، وللنسخة الاحتياطية القابلة للبحث بدون
    تنصيب) لكل التحاليل المكتملة/الموثّقة بزيارة وحدة -- بصفحة متصفح
    عادية جاهزة للطباعة مباشرة (Ctrl+P أو زر الطباعة بالمتصفح). يُستخدم
    من صفحة سجل زيارات المريض (front_desk/patient_history.html)."""
    html_content = _build_combined_designed_reports_html(visit_id)
    if not html_content:
        return (
            "<div dir='rtl' style='padding:40px;text-align:center;"
            "font-family:Tahoma,Arial,sans-serif;color:#64748B;'>"
            "لا توجد نتائج مكتملة بهذي الزيارة بعد لعرضها أو طباعتها.</div>"
        )
    # autoprint=1: طباعة تلقائية مرة وحدة للصفحة المدمجة كلها. نستخدم اسم وسيط مختلف
    # عن auto حتى لا تنفّذ تقارير التحاليل المضمّنة طباعتها الذاتية كل وحدة لحالها
    # (طلبات طباعة متعددة متزامنة = نافذة طباعة تتجمّد).
    if request.args.get("autoprint") == "1":
        _ap = ("<script>window.addEventListener('load',function(){setTimeout(function(){"
               "if(window.__lisPrinted)return;window.__lisPrinted=true;window.print();},700);});</script>")
        if "</body>" in html_content:
            html_content = html_content.replace("</body>", _ap + "</body>", 1)
        else:
            html_content += _ap
    return html_content


# --------------------------------------------------------------- front desk
@app.route("/front-desk/new-visit", methods=["GET", "POST"])
@login_required
def new_visit():
    db = get_db()
    if request.method == "POST":
        # زر "✅ تم سحب العينة" إلزامي بهذي الصفحة (نقطة #9) — يمثّل تأكيد
        # الاستقبال إنه سحب العينة فعليًا وقت تسجيل الزيارة (حالة شائعة
        # بالمختبرات الصغيرة حيث الاستقبال هو نفسه يسحب العينة). لو ما
        # انضغط، نرفض الحفظ من السيرفر (مو بس تحقق JS بالواجهة) قبل أي
        # INSERT بقاعدة البيانات. تأثيره: order_tests تُنشأ مباشرة بحالة
        # 'Collected' (بدل 'Accepted' الافتراضية) فتتخطى طابور "سحب
        # العينة" وتظهر مباشرة بطابور "استلام العينة" — راجع
        # samples_collection/samples_accession لنفس منطق الحالتين.
        sample_collected = request.form.get("sample_collected") == "1"
        if not sample_collected:
            error_msg = "لازم تأكيد \"تم سحب العينة\" قبل حفظ الزيارة."
            if request.headers.get("X-LIS-Ajax") == "1":
                return jsonify({"ok": False, "error": error_msg}), 400
            flash(error_msg)
            return redirect(url_for("new_visit"))

        name = request.form.get("patient_name", "").strip()
        title = request.form.get("title", "Mr.")
        gender = request.form.get("gender", "")
        age = request.form.get("age") or None
        age_unit = request.form.get("age_unit") or "Years"
        phone = request.form.get("phone", "")
        email = request.form.get("email", "").strip()
        address = request.form.get("address", "")
        national_id = request.form.get("national_id", "").strip()
        passport_number = request.form.get("passport_number", "").strip()
        travel_certificate_number = request.form.get("travel_certificate_number", "").strip()
        lab_card_number = request.form.get("lab_card_number", "").strip()
        birth_date = (request.form.get("birth_date") or "").strip()[:10] or None
        expected_ready_at = (request.form.get("expected_ready_at") or "").strip()[:16] or None
        expected_ready_text = (request.form.get("expected_ready_text") or "").strip()[:60] or None
        if expected_ready_text and not expected_ready_at:
            _edt = parse_expected_text(expected_ready_text)
            if _edt:
                expected_ready_at = _edt.strftime("%Y-%m-%dT%H:%M")
        fasting = request.form.get("fasting", "Undefined")
        notes = request.form.get("notes", "")
        # المعلومات الصحية (Health Information) — خاصة بهذي الزيارة تحديداً.
        weight = request.form.get("weight") or None
        height = request.form.get("height") or None
        symptoms = request.form.get("symptoms", "")
        disease = request.form.get("disease", "")
        therapy = request.form.get("therapy", "")
        # الزيارة المنزلية (Home Visit)
        is_home_visit = 1 if request.form.get("is_home_visit") == "1" else 0
        home_visit_address = request.form.get("home_visit_address", "") if is_home_visit else ""
        try:
            home_visit_fee = float(request.form.get("home_visit_fee") or 0) if is_home_visit else 0.0
        except ValueError:
            home_visit_fee = 0.0
        examining_doctor = request.form.get("examining_doctor", "")
        expenses = request.form.get("expenses") or 0
        # حقل "الدكتور الفاحص" (attending_doctor) صار نفس "دكتور المختبر
        # الفاحص" (examining_doctor) — كانا حقلين منفصلين بالشاشة سابقًا
        # وصار واحد بس بناءً على طلب المستخدم، وهذا العمود يُملأ تلقائيًا
        # بنفس القيمة حتى يبقى عمود "الزيارات" شغّالاً بدون أي تغيير.
        attending_doctor = examining_doctor
        contact_method = request.form.get("contact_method", "None")
        test_ids = request.form.getlist("tests")
        test_ids = expand_required_tests(db, test_ids)   # BF يحتاج CBC (CBC لا يحتاج BF)
        now = datetime.now().isoformat(timespec="seconds")

        # الطبيب المُحيل (خارجي) — إذا هذا أول مرة يذكر اسمه، ينحفظ تلقائيًا
        # بجدول الأطباء حتى يظهر بالاقتراحات بالمرات الجاية.
        referring_doctor_id = find_or_create_doctor(db, request.form.get("doctor_name", ""))

        # المختبر المُرسِل لهذه العينة (لو النموذج وارد من مختبر ثاني مو من
        # مراجع مباشر) — تُستخدم فقط للمحاسبة الداخلية بين المختبرين؛ اسم
        # هذا المختبر ما ينطبع بأي تقرير أبدًا (راجع print_report/from_other_lab).
        # يُكتب كاسم حر (نفس أسلوب حقل الدكتور المُحيل) بدل قائمة منسدلة
        # ثابتة، فيُنشأ المختبر تلقائيًا بأول مرة يُذكر اسمه — ما تحتاج
        # الاستقبال تضيفه مسبقًا من صفحة إدارة المختبرات المُحيلة.
        referral_center_id = find_or_create_referral_center(db, request.form.get("referral_lab_name", ""))

        # إذا اختار موظف الاستقبال مريضًا سبق أن زار المختبر (من نتائج البحث
        # الفوري)، تُستخدم بطاقته الحالية بدل إنشاء بطاقة مريض مكررة جديدة.
        existing_patient_id = request.form.get("existing_patient_id") or None
        patient_id = None
        if existing_patient_id:
            existing = db.execute(
                "SELECT id FROM patients WHERE id=?", (existing_patient_id,)
            ).fetchone()
            if existing:
                patient_id = existing["id"]

        if patient_id is None:
            name_en = (request.form.get("patient_name_en") or "").strip() or transliterate_arabic_name(name)
            cur = db.execute(
                "INSERT INTO patients (full_name, full_name_en, gender, age, age_unit, phone, address, contact_method, "
                "title, email, national_id, passport_number, travel_certificate_number, lab_card_number, "
                "branch_id, created_at, birth_date) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (name, name_en, gender, age, age_unit, phone, address, contact_method,
                 title, email, national_id, passport_number, travel_certificate_number, lab_card_number,
                 session.get("branch_id"), now, birth_date),
            )
            patient_id = cur.lastrowid

        examining_doctor_fee = compute_examining_doctor_fee(db, examining_doctor, test_ids)

        reg_number = next_registration_number(db)
        visit_type = "home-visit" if is_home_visit else "walk-in"
        cur = db.execute(
            "INSERT INTO visits (registration_number, patient_id, doctor_id, referral_center_id, visit_type, fasting, notes, "
            "examining_doctor, expenses, examining_doctor_fee, attending_doctor, weight, height, symptoms, disease, therapy, "
            "is_home_visit, home_visit_address, home_visit_fee, status, branch_id, created_by, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Open', ?, ?, ?)",
            (reg_number, patient_id, referring_doctor_id, referral_center_id, visit_type, fasting, notes, examining_doctor, expenses,
             examining_doctor_fee, attending_doctor, weight, height, symptoms, disease, therapy,
             is_home_visit, home_visit_address, home_visit_fee, session.get("branch_id"), session.get("user_id"), now),
        )
        visit_id = cur.lastrowid
        # رقم العينة: من حقل "Sample No." بصفحة زيارة جديدة (يتسلسل من جديد حسب إعداد التصفير)
        db.execute("UPDATE visits SET sample_no=?, expected_ready_at=?, expected_ready_text=? WHERE id=?",
                   (resolve_visit_sample_no(db, request.form.get("sample_no")), expected_ready_at,
                    expected_ready_text, visit_id))
        # (بوابة النتائج: توليد الرمز + إيقاظ العامل صار بعد db.commit() النهائي تحت —
        #  قبل كان يوقظ العامل الخلفي والزيارة لسا ما اكتملت فيتنافس معها على قفل القاعدة)

        order_cur = db.execute("INSERT INTO orders (visit_id, status, created_at) VALUES (?, 'Open', ?)",
                                (visit_id, now))
        order_id = order_cur.lastrowid

        total = 0.0
        for tid in test_ids:
            test = db.execute("SELECT * FROM test_definitions WHERE id=?", (tid,)).fetchone()
            if not test:
                continue
            # طلب بارامترات معيّنة بس من هذا التحليل (سهم ▾ بالواجهة) بدل
            # التحليل كامل — selected_params_<tid> يوصل "id,id,id" لو
            # استُخدم، وإلا فاضي (السلوك الافتراضي القديم: التحليل كامل).
            # السعر يُحسب من قاعدة البيانات دائماً (مجموع أسعار البارامترات
            # المختارة فعلاً)، ما نثق بأي مجموع جاي من الواجهة.
            selected_params_raw = (request.form.get(f"selected_params_{tid}") or "").strip()
            selected_param_ids = None
            if selected_params_raw:
                try:
                    pid_list = [int(x) for x in selected_params_raw.split(",") if x.strip()]
                except ValueError:
                    pid_list = []
                if pid_list:
                    placeholders = ",".join("?" * len(pid_list))
                    prows = db.execute(
                        f"SELECT id, price FROM test_parameters WHERE id IN ({placeholders}) AND test_definition_id=?",
                        (*pid_list, tid),
                    ).fetchall()
                    if prows:
                        price = sum((r["price"] or 0) for r in prows)
                        selected_param_ids = ",".join(str(r["id"]) for r in prows)
                    else:
                        price = get_test_price(db, tid, referring_doctor_id, referral_center_id)
                else:
                    price = get_test_price(db, tid, referring_doctor_id, referral_center_id)
            else:
                price = get_test_price(db, tid, referring_doctor_id, referral_center_id)
            barcode = f"{reg_number}{tid.zfill(3)}"
            # الحالة تبدأ 'Collected' مباشرة (مو 'Accepted') لأن زر "تم سحب
            # العينة" الإلزامي فوق تأكد إنها انسحبت فعليًا هذي اللحظة —
            # فتتخطى طابور "سحب العينة" وتظهر مباشرة بطابور "استلام العينة".
            db.execute(
                "INSERT INTO order_tests (order_id, test_definition_id, status, barcode, price, doctor_id, "
                "collected_at, created_at, selected_param_ids, price_missing) VALUES (?, ?, 'Collected', ?, ?, ?, ?, ?, ?, ?)",
                (order_id, tid, barcode, (price if price is not None else 0), referring_doctor_id, now, now, selected_param_ids,
                 1 if price is None else 0),
            )
            total += price or 0

        _apply_partner_forward(db, order_id, request.form.get("forward_lab_id"))

        # أجرة الزيارة المنزلية الإضافية (إن فُعِّلت) تُضاف لمجموع الفحوصات
        # قبل حساب الفاتورة، بنفس أسلوب أي بند إضافي بالمجموع.
        total += home_visit_fee

        # "المبلغ الكلي" بصفحة الزيارة الجديدة يبدأ محسوبًا تلقائيًا من
        # مجموع أسعار التحاليل المختارة، بس موظف الاستقبال يقدر يعدّله يدويًا
        # (مثلاً لخصم أو تسوية) — الفرق بين المجموع الفعلي والمبلغ المُعدَّل
        # يُسجَّل بعمودي discount_amount/extra_charges حتى يبقى مجموع أسعار
        # التحاليل الأصلي محفوظًا للمراجعة.
        computed_total = total
        total_override_raw = request.form.get("total_amount_input")
        try:
            total_override = float(total_override_raw) if total_override_raw not in (None, "") else None
        except ValueError:
            total_override = None
        invoice_total = total_override if (total_override is not None and total_override >= 0) else computed_total
        discount_amount = max(0.0, computed_total - invoice_total)
        extra_charges = max(0.0, invoice_total - computed_total)

        # "الواصل" — أي مبلغ استلمه الاستقبال نقدًا وقت تسجيل الزيارة نفسها.
        # يُسجَّل كدفعة فعلية بجدول payments (نفس آلية /billing/pay) حتى يظهر
        # بسجلات المحاسبة والتقارير، و"الباقي" يُحسب تلقائيًا من الفرق.
        try:
            paid_amount = float(request.form.get("paid_amount") or 0)
        except ValueError:
            paid_amount = 0.0
        paid_amount = max(0.0, paid_amount)
        if invoice_total > 0:
            paid_amount = min(paid_amount, invoice_total)
            invoice_status = "Paid" if paid_amount >= invoice_total else ("Partial" if paid_amount > 0 else "Unpaid")
        else:
            invoice_status = "Paid" if paid_amount <= 0 else "Partial"

        inv_cur = db.execute(
            "INSERT INTO invoices (visit_id, total_amount, discount_amount, extra_charges, paid_amount, status, "
            "created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (visit_id, invoice_total, discount_amount, extra_charges, paid_amount, invoice_status,
             session.get("user_id"), now),
        )
        invoice_id = inv_cur.lastrowid

        _payment_log_details = None
        if paid_amount > 0:
            db.execute(
                "INSERT INTO payments (invoice_id, amount, method, user_id, paid_at) VALUES (?, ?, 'Cash', ?, ?)",
                (invoice_id, paid_amount, session.get("user_id"), now),
            )
            # مهم: log_action() تفتح اتصال قاعدة بيانات ثاني مستقل. استدعاؤها هنا (قبل db.commit)
            # كان يخلي الاتصال الثاني ينتظر قفل الكتابة المحجوز من اتصال هذي الزيارة لين 5 ثواني
            # ثم يفشل بـ"database is locked" (الزيارة تتأخر 5 ثواني وتطلع خطأ ويضيع الحفظ).
            # لذلك نؤجل تسجيلها لما بعد الـcommit.
            _payment_log_details = f"amount={paid_amount} (at registration)"


        if contact_method != "None":
            db.execute(
                "INSERT INTO patient_followups (patient_id, visit_id, status, followup_date, created_at) "
                "VALUES (?, ?, 'Pending', ?, ?)",
                (patient_id, visit_id, now[:10], now),
            )

        db.commit()
        if _payment_log_details:
            log_action("Payment", "invoice", invoice_id, _payment_log_details)
        log_action("Create", "visit", visit_id, f"reg#{reg_number}")
        log_action("Collect", "visit", visit_id, f"sample_collected_at_registration reg#{reg_number}")
        # بوابة النتائج: رمز QR للمريض + دفع حالة "قيد التحضير" للسحابة (بالخلفية) — بعد اكتمال الحفظ
        try:
            if cloud_sync.get_cfg(db)["enabled"]:
                cloud_sync.ensure_token(db, visit_id)
                cloud_sync.trigger()
        except Exception:
            pass  # فشل البوابة ما لازم يفشّل حفظ الزيارة نفسها
        flash(f"Visit #{reg_number} created successfully.")

        # موافقة الموظف على دمج نتائج تحاليل قديمة (من آخر زيارة سابقة
        # لنفس المريض) بتقرير هذي الزيارة الجديدة — تُسجَّل هنا بس عند
        # التأكيد الصريح من بنك تنبيه الزيارة السابقة بشاشة "زيارة جديدة"،
        # راجع visit_previous_merges لتفاصيل الآلية.
        # عدد الزيارات السابقة اللي تظهر نتائجها (0 = إلغاء) — يختاره الموظف بصفحة "زيارة جديدة".
        _pvc = (request.form.get("prev_visits_count") or "").strip()
        if _pvc.lstrip("-").isdigit():
            set_visit_prev_pref(db, visit_id, int(_pvc))
        merge_ids_raw = request.form.get("merge_previous_order_test_ids", "").strip()
        if merge_ids_raw:
            merge_ids = [x for x in merge_ids_raw.split(",") if x.strip().isdigit()]
            if merge_ids:
                save_visit_previous_merges(db, visit_id, merge_ids)

        # إذا اختار موظف الاستقبال تضمين زيارة/زيارات سابقة مع هذي الزيارة
        # الجديدة بجدول موحّد، يروح مباشرة لصفحة الجدول الموحّد بدل قائمة الزيارات.
        include_visit_ids = request.form.get("include_visit_ids", "").strip()
        if include_visit_ids:
            all_ids = [visit_id_str for visit_id_str in include_visit_ids.split(",") if visit_id_str.strip().isdigit()]
            all_ids.append(str(visit_id))
            redirect_url = url_for("combined_visits_report", visit_ids=",".join(all_ids))
        else:
            redirect_url = url_for("visits_list")

        # صفحة "زيارة جديدة" تُرسل الفورم بـ AJAX حتى تقدر تعرض زر "طباعة
        # الباركود" وتطبع من نفس الصفحة (بدون فتح تبويب/متصفح جديد) قبل ما
        # تنتقل لقائمة الزيارات. لو الطلب اجى بالطريقة العادية (بدون JS)،
        # نكمل بنفس سلوك التحويل المباشر كما كان سابقًا.
        if request.headers.get("X-LIS-Ajax") == "1":
            return jsonify({
                "ok": True,
                "visit_id": visit_id,
                "registration_number": reg_number,
                "patient_name": name,
                "redirect_url": redirect_url,
            })

        return redirect(redirect_url)

    sync_test_sections(db)
    tests = db.execute("SELECT * FROM test_definitions WHERE is_active=1 ORDER BY department, name").fetchall()
    quick_items = db.execute(
        "SELECT td.id, td.name FROM quick_add_items q JOIN test_definitions td ON td.id = q.test_definition_id "
        "WHERE q.is_active=1 ORDER BY q.display_order"
    ).fetchall()
    doctors, doctor_prices, doctor_name_to_id = doctor_pricing_context(db)
    test_default_prices = {str(tst["id"]): tst["price"] for tst in tests}
    examining_test_ids = [row["id"] for row in get_examining_tests(db)]
    referral_labs = db.execute(
        "SELECT * FROM referral_centers WHERE name != 'Walk-in' ORDER BY name"
    ).fetchall()
    picker = build_test_picker_context(db, tests, referral_labs)
    partner_labs, partner_prices = _partner_context(db)
    return render_template("front_desk/new_visit.html", partner_labs=partner_labs, partner_prices=partner_prices, tests=tests, quick_items=quick_items,
                            section_tree=picker["section_tree"], test_meta=picker["test_meta"],
                            lab_prices=picker["lab_prices"], lab_name_to_id=picker["lab_name_to_id"],
                            examining_doctors=get_examining_doctors(db), doctors=doctors,
                            doctor_prices=doctor_prices, doctor_name_to_id=doctor_name_to_id,
                            test_default_prices=test_default_prices,
                            examining_test_ids=examining_test_ids,
                            examining_rates=get_examining_rates_map(db),
                            referral_labs=referral_labs)


# ============================================================ v54: الأقسام + أسعار المختبرات ==
@app.route("/master/sections", methods=["GET", "POST"])
@roles_required("supervisor")
def sections_manage():
    """شجرة الأقسام (قسم رئيسي ← أقسام فرعية)، نقل التحاليل بينها، والرموز البديلة/شرط الارتباط لكل تحليل."""
    db = get_db()
    sync_test_sections(db)
    if request.method == "POST":
        act = request.form.get("action", "")
        if act == "add":
            name = (request.form.get("name") or "").strip()
            if not name:
                flash("اسم القسم إلزامي.")
                return redirect(url_for("sections_manage"))
            if db.execute("SELECT 1 FROM sections WHERE LOWER(name)=LOWER(?)", (name,)).fetchone():
                flash("هذا القسم موجود أصلاً.")
                return redirect(url_for("sections_manage"))
            parent_id = request.form.get("parent_id", type=int) or None
            dept = (request.form.get("dept_name") or "").strip() or name
            nxt = db.execute("SELECT COALESCE(MAX(sort_order),0)+1 AS n FROM sections").fetchone()["n"]
            db.execute("INSERT INTO sections (name, parent_id, dept_name, sort_order) VALUES (?, ?, ?, ?)",
                       (name, parent_id, dept, nxt))
            db.commit()
            log_action("Create", "section", None, name)
            flash("تمت إضافة القسم. انقل إليه تحاليل من الأسفل ليظهر بتنسيق عناوين الأقسام بمصمم التقارير.")
        elif act == "update":
            sid = request.form.get("id", type=int)
            name = (request.form.get("name") or "").strip()
            parent_id = request.form.get("parent_id", type=int) or None
            # منع الحلقات: القسم لا يصير تحت نفسه أو تحت أحد فروعه
            cur = parent_id
            while cur:
                if cur == sid:
                    parent_id = None
                    flash("لا يمكن جعل القسم تحت نفسه أو تحت أحد فروعه.")
                    break
                r = db.execute("SELECT parent_id FROM sections WHERE id=?", (cur,)).fetchone()
                cur = r["parent_id"] if r else None
            if sid and name:
                db.execute("UPDATE sections SET name=?, parent_id=?, dept_name=?, sort_order=? WHERE id=?",
                           (name, parent_id, (request.form.get("dept_name") or "").strip() or None,
                            request.form.get("sort_order", type=int) or 0, sid))
                db.commit()
                flash("تم حفظ القسم.")
        elif act == "delete":
            sid = request.form.get("id", type=int)
            used = db.execute("SELECT COUNT(*) AS c FROM test_definitions WHERE section_id=?", (sid,)).fetchone()["c"]
            kids = db.execute("SELECT COUNT(*) AS c FROM sections WHERE parent_id=?", (sid,)).fetchone()["c"]
            if used or kids:
                flash("لا يمكن حذف قسم فيه تحاليل أو أقسام فرعية. انقلها أولاً.")
            else:
                db.execute("DELETE FROM sections WHERE id=?", (sid,))
                db.commit()
                flash("تم حذف القسم.")
        elif act == "move_tests":
            sid = request.form.get("section_id", type=int)
            ids = [int(x) for x in request.form.getlist("test_ids") if x.isdigit()]
            sec = db.execute("SELECT * FROM sections WHERE id=?", (sid,)).fetchone()
            if not sec or not ids:
                flash("اختر القسم الهدف وتحليلاً واحدًا على الأقل.")
            else:
                for tid in ids:
                    db.execute("UPDATE test_definitions SET section_id=? WHERE id=?", (sid, tid))
                    if (sec["dept_name"] or "").strip():   # department يتبع القسم → يظهر بمصمم التقارير واللوحة المجمّعة
                        db.execute("UPDATE test_definitions SET department=? WHERE id=?", (sec["dept_name"].strip(), tid))
                db.commit()
                log_action("MoveTests", "section", sid, f"{len(ids)} tests")
                flash(f"تم نقل {len(ids)} تحليل إلى «{sec['name']}».")
        elif act == "save_tests_meta":
            n = 0
            for key, val in request.form.items():
                if key.startswith("aliases_"):
                    tid = key[8:]
                    if tid.isdigit():
                        req = (request.form.get("requires_" + tid) or "").strip()
                        db.execute("UPDATE test_definitions SET aliases=?, requires_codes=? WHERE id=?",
                                   (val.strip(), req, int(tid)))
                        n += 1
            db.commit()
            flash("تم حفظ الرموز البديلة وشروط الارتباط.")
        return redirect(url_for("sections_manage"))

    secs = db.execute("SELECT * FROM sections ORDER BY sort_order, id").fetchall()
    counts = {r["section_id"]: r["c"] for r in db.execute(
        "SELECT section_id, COUNT(*) AS c FROM test_definitions GROUP BY section_id").fetchall()}
    tests = db.execute(
        "SELECT td.*, s.name AS section_name FROM test_definitions td LEFT JOIN sections s ON s.id=td.section_id "
        "WHERE td.is_active=1 ORDER BY COALESCE(s.name,''), td.name").fetchall()
    return render_template("master/sections.html", secs=secs, counts=counts, tests=tests)


# ============================================================ v55: أقسام + زيارات من صفحة "زيارة جديدة" ==
def _req_text(name):
    data = request.get_json(silent=True) or {}
    return str(data.get(name) or request.form.get(name) or "").strip()


@app.route("/api/sections/<int:sid>/rename", methods=["POST"])
@login_required
def api_section_rename(sid):
    """تعديل اسم قسم من صفحة زيارة جديدة. يبقى ربط التحاليل بالقسم كما هو: إذا القسم بلا dept_name
    نثبّت dept_name على اسمه القديم حتى تستمر التحاليل المضافة بنفس الـdepartment بالانربط به
    (sync_test_sections يطابق dept_name أولاً ثم الاسم)."""
    db = get_db()
    sec = db.execute("SELECT * FROM sections WHERE id=?", (sid,)).fetchone()
    if not sec:
        return jsonify({"ok": False, "error": "القسم غير موجود"}), 404
    name = _req_text("name")
    if not name:
        return jsonify({"ok": False, "error": "اسم القسم إلزامي"}), 400
    if db.execute("SELECT 1 FROM sections WHERE LOWER(name)=LOWER(?) AND id<>?", (name, sid)).fetchone():
        return jsonify({"ok": False, "error": "يوجد قسم بهذا الاسم"}), 409
    dept = (sec["dept_name"] or "").strip() or sec["name"]
    db.execute("UPDATE sections SET name=?, dept_name=? WHERE id=?", (name, dept, sid))
    db.commit()
    log_action("RenameSection", "section", sid, f"{sec['name']} -> {name}")
    return jsonify({"ok": True, "id": sid, "name": name})


@app.route("/api/sections/<int:sid>/add-test", methods=["POST"])
@login_required
def api_section_add_test(sid):
    """إضافة تحليل جديد داخل قسم مباشرة (يُربط بالقسم فورًا، بسعر 0 مؤقتًا — السعر من صفحة الأسعار)."""
    db = get_db()
    sec = db.execute("SELECT * FROM sections WHERE id=?", (sid,)).fetchone()
    if not sec:
        return jsonify({"ok": False, "error": "القسم غير موجود"}), 404
    name = _req_text("name")
    if not name:
        return jsonify({"ok": False, "error": "اسم التحليل مطلوب"}), 400
    if db.execute("SELECT 1 FROM test_definitions WHERE LOWER(TRIM(name))=LOWER(TRIM(?)) AND is_active=1", (name,)).fetchone():
        return jsonify({"ok": False, "error": "يوجد تحليل بنفس الاسم"}), 409
    dept = (sec["dept_name"] or "").strip() or sec["name"]
    code = unique_test_code(db, name)
    cur = db.execute(
        "INSERT INTO test_definitions (code, name, department, sample_type, price, is_active, is_examining_test, section_id) "
        "VALUES (?, ?, ?, '', 0, 1, 0, ?)",
        (code, name, dept, sid),
    )
    db.commit()
    log_action("QuickAddTest", "test_definition", cur.lastrowid, f"{name} (section {sid})")
    return jsonify({"ok": True, "id": cur.lastrowid, "name": name, "code": code, "section_id": sid})


@app.route("/api/sections/<int:sid>/hide", methods=["POST"])
@login_required
def api_section_hide(sid):
    """\"مسح\" قسم من قائمة الطلبات: إخفاء كل تحاليله (والأقسام الفرعية) دفعة واحدة. لا يُحذف أي تحليل ولا نتيجة
    ولا زيارة سابقة (تقارير الزيارات القديمة تحتاج بيانات التحليل)؛ ويمكن إظهارها لاحقًا من كتالوج التحاليل."""
    db = get_db()
    if not db.execute("SELECT 1 FROM sections WHERE id=?", (sid,)).fetchone():
        return jsonify({"ok": False, "error": "القسم غير موجود"}), 404
    ids, frontier = {sid}, [sid]
    while frontier:
        ph = ",".join("?" * len(frontier))
        kids = [r["id"] for r in db.execute(f"SELECT id FROM sections WHERE parent_id IN ({ph})", frontier).fetchall()]
        frontier = [k for k in kids if k not in ids]
        ids.update(frontier)
    ph = ",".join("?" * len(ids))
    tids = [r["id"] for r in db.execute(
        f"SELECT id FROM test_definitions WHERE is_active=1 AND section_id IN ({ph})", list(ids)).fetchall()]
    if tids:
        ph2 = ",".join("?" * len(tids))
        db.execute(f"UPDATE test_definitions SET is_active=0 WHERE id IN ({ph2})", tids)
        db.commit()
        log_action("HideSection", "section", sid, f"{len(tids)} tests hidden")
    return jsonify({"ok": True, "hidden": tids})


def _is_privileged_interface():
    return bool(session.get("designer_id")) or session.get("interface") in ("lab", "both")


@app.route("/api/visits/<int:visit_id>/cancel", methods=["POST"])
@login_required
def api_visit_cancel(visit_id):
    """إلغاء زيارة (مراجع انسحب): يحذف الزيارة وتحاليلها وفاتورتها وأي مبالغ مستلمة منها.
    واجهة المختبر/الاثنين: أي زيارة. الاستقبال: فقط زيارة اليوم قبل بدء أي نتيجة وإذا الفاتورة غير مقفلة."""
    db = get_db()
    visit = db.execute("SELECT * FROM visits WHERE id=?", (visit_id,)).fetchone()
    if not visit:
        return jsonify({"ok": False, "error": "الزيارة غير موجودة"}), 404
    if not _is_privileged_interface():
        if (visit["created_at"] or "")[:10] != datetime.now().date().isoformat():
            return jsonify({"ok": False, "error": "الاستقبال يقدر يلغي زيارات اليوم فقط. استخدم واجهة المختبر لحذف زيارة قديمة."}), 403
        inv = db.execute("SELECT is_locked FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()
        if inv and inv["is_locked"]:
            return jsonify({"ok": False, "error": "الفاتورة مقفلة — لا يمكن إلغاء الزيارة من الاستقبال."}), 403
        started = db.execute(
            "SELECT COUNT(*) AS c FROM order_tests ot JOIN orders o ON o.id=ot.order_id "
            "WHERE o.visit_id=? AND (ot.status IN ('Completed','Verified') "
            "OR EXISTS (SELECT 1 FROM results r WHERE r.order_test_id=ot.id))", (visit_id,)
        ).fetchone()["c"]
        if started:
            return jsonify({"ok": False, "error": "بدأ إدخال نتائج هذه الزيارة — لا يمكن إلغاؤها من الاستقبال."}), 403
    _delete_visit_cascade(db, visit)
    return jsonify({"ok": True})


@app.route("/api/visits/<int:visit_id>/add-tests", methods=["POST"])
@login_required
def api_visit_add_tests(visit_id):
    """إضافة تحاليل لزيارة سابقة لنفس المريض بنفس اليوم (بدل إنشاء زيارة جديدة): تُسعَّر حسب دكتور/مختبر الزيارة،
    يرتفع إجمالي الفاتورة، ويُسجَّل أي مبلغ \"الواصل\" الجديد كدفعة."""
    db = get_db()
    visit = db.execute("SELECT * FROM visits WHERE id=?", (visit_id,)).fetchone()
    if not visit:
        return jsonify({"ok": False, "error": "الزيارة غير موجودة"}), 404
    if (visit["created_at"] or "")[:10] != datetime.now().date().isoformat():
        return jsonify({"ok": False, "error": "إضافة التحاليل من هنا لزيارات اليوم فقط. للزيارات القديمة استخدم «تعديل الزيارة»."}), 400
    order = db.execute("SELECT * FROM orders WHERE visit_id=?", (visit_id,)).fetchone()
    if not order:
        return jsonify({"ok": False, "error": "لا يوجد طلب لهذي الزيارة"}), 404
    invoice = db.execute("SELECT * FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()
    if invoice and invoice["is_locked"]:
        return jsonify({"ok": False, "error": "الفاتورة مقفلة — افتحها أولًا من صفحة الفواتير."}), 403
    req_ids = [x for x in request.form.getlist("tests") if str(x).isdigit()]
    if not req_ids:
        return jsonify({"ok": False, "error": "حدّد تحليلًا واحدًا على الأقل."}), 400

    have = {str(r["test_definition_id"]) for r in db.execute(
        "SELECT test_definition_id FROM order_tests WHERE order_id=?", (order["id"],)).fetchall()}
    new_ids = []
    for tid in expand_required_tests(db, req_ids):      # BF يحتاج CBC
        if tid not in have and tid not in new_ids:
            new_ids.append(tid)
    if not new_ids:
        return jsonify({"ok": False, "error": "كل التحاليل المحددة موجودة أصلاً بهذه الزيارة."}), 400

    doctor_id, center_id = visit["doctor_id"], visit["referral_center_id"]
    reg = visit["registration_number"]
    collected = request.form.get("sample_collected") == "1"
    now = datetime.now().isoformat(timespec="seconds")
    added, added_total = [], 0.0
    for tid in new_ids:
        test = db.execute("SELECT id, name FROM test_definitions WHERE id=? AND is_active=1", (tid,)).fetchone()
        if not test:
            continue
        price, selected_param_ids = None, None
        raw = (request.form.get(f"selected_params_{tid}") or "").strip()
        if raw:
            try:
                pid_list = [int(x) for x in raw.split(",") if x.strip()]
            except ValueError:
                pid_list = []
            if pid_list:
                ph = ",".join("?" * len(pid_list))
                prows = db.execute(
                    f"SELECT id, price FROM test_parameters WHERE id IN ({ph}) AND test_definition_id=?",
                    (*pid_list, tid)).fetchall()
                if prows:
                    price = sum((r["price"] or 0) for r in prows)
                    selected_param_ids = ",".join(str(r["id"]) for r in prows)
        if price is None and selected_param_ids is None:
            price = get_test_price(db, tid, doctor_id, center_id)
        db.execute(
            "INSERT INTO order_tests (order_id, test_definition_id, status, barcode, price, doctor_id, "
            "collected_at, created_at, selected_param_ids, price_missing) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (order["id"], tid, "Collected" if collected else "Accepted", f"{reg}{str(tid).zfill(3)}",
             (price if price is not None else 0), doctor_id, now if collected else None, now, selected_param_ids,
             1 if price is None else 0))
        added.append({"id": int(tid), "name": test["name"], "price": price if price is not None else 0,
                      "price_missing": price is None})
        added_total += price or 0
    if not added:
        return jsonify({"ok": False, "error": "تعذّر إضافة التحاليل المحددة."}), 400

    recompute_examining_doctor_fee(db, visit_id)

    try:
        paid_now = max(0.0, float((request.form.get("paid_amount") or "0").replace(",", "").strip() or 0))
    except ValueError:
        paid_now = 0.0
    payment_note = None
    if invoice:
        new_total = float(invoice["total_amount"] or 0) + added_total
        old_paid = float(invoice["paid_amount"] or 0)
        paid_now = min(paid_now, max(0.0, new_total - old_paid))
        new_paid = old_paid + paid_now
        status = "Paid" if new_paid >= new_total else ("Partial" if new_paid > 0 else "Unpaid")
        db.execute("UPDATE invoices SET total_amount=?, paid_amount=?, status=? WHERE id=?",
                   (new_total, new_paid, status, invoice["id"]))
        inv_id = invoice["id"]
    else:
        new_total = added_total + float(visit["home_visit_fee"] or 0)
        paid_now = min(paid_now, new_total)
        new_paid = paid_now
        status = "Paid" if new_paid >= new_total else ("Partial" if new_paid > 0 else "Unpaid")
        inv_id = db.execute(
            "INSERT INTO invoices (visit_id, total_amount, discount_amount, extra_charges, paid_amount, status, "
            "created_by, created_at) VALUES (?, ?, 0, 0, ?, ?, ?, ?)",
            (visit_id, new_total, new_paid, status, session.get("user_id"), now)).lastrowid
    if paid_now > 0:
        db.execute("INSERT INTO payments (invoice_id, amount, method, user_id, paid_at) VALUES (?, ?, 'Cash', ?, ?)",
                   (inv_id, paid_now, session.get("user_id"), now))
        payment_note = f"amount={paid_now} (added tests to visit)"
    db.commit()
    if payment_note:
        log_action("Payment", "invoice", inv_id, payment_note)
    log_action("AddTestsToVisit", "visit", visit_id, ", ".join(a["name"] for a in added))
    return jsonify({"ok": True, "registration_number": reg, "added": added, "added_total": added_total,
                    "total": new_total, "paid": new_paid, "remaining": max(0.0, new_total - new_paid)})



# ============== التحاليل المرسلة لمختبرات أخرى (v65) ==============
def _ensure_partner_labs(db):
    db.execute("CREATE TABLE IF NOT EXISTS partner_labs (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, "
               "is_active INTEGER DEFAULT 1)")
    db.execute("CREATE TABLE IF NOT EXISTS partner_lab_prices (id INTEGER PRIMARY KEY AUTOINCREMENT, lab_id INTEGER NOT NULL, "
               "test_definition_id INTEGER NOT NULL, cost REAL NOT NULL DEFAULT 0, UNIQUE(lab_id, test_definition_id))")


def _partner_context(db):
    """(المختبرات الفعّالة, {labId: {testId: كلفة}}) لشاشة زيارة جديدة."""
    _ensure_partner_labs(db)
    labs = db.execute("SELECT id, name FROM partner_labs WHERE is_active=1 ORDER BY name").fetchall()
    prices = {}
    for r in db.execute("SELECT lab_id, test_definition_id, cost FROM partner_lab_prices").fetchall():
        prices.setdefault(str(r["lab_id"]), {})[str(r["test_definition_id"])] = r["cost"]
    return labs, prices


def _apply_partner_forward(db, order_id, lab_id_raw):
    """بعد إنشاء تحاليل الزيارة: التحاليل اللي لها كلفة عند المختبر المختار تُعلَّم «مرسلة» (forwarded_lab_name/cost)
    فتنخصم تلقائيًا بالتقارير. الباقي يبقى بمختبرك."""
    lab_id_raw = (lab_id_raw or "").strip()
    if not lab_id_raw.isdigit():
        return 0
    _ensure_partner_labs(db)
    lab = db.execute("SELECT id, name FROM partner_labs WHERE id=?", (int(lab_id_raw),)).fetchone()
    if not lab:
        return 0
    rows = db.execute(
        "SELECT ot.id AS ot_id, pp.cost FROM order_tests ot JOIN partner_lab_prices pp "
        "ON pp.test_definition_id = ot.test_definition_id AND pp.lab_id = ? WHERE ot.order_id = ?",
        (lab["id"], order_id)).fetchall()
    for r in rows:
        db.execute("UPDATE order_tests SET forwarded_lab_name=?, forwarded_cost=? WHERE id=?",
                   (lab["name"], r["cost"] or 0, r["ot_id"]))
    return len(rows)


@app.route("/management/partner-labs", methods=["GET", "POST"])
@roles_required("supervisor")
def partner_labs_page():
    """إعدادات «التحاليل المرسلة لمختبرات أخرى»: المختبرات الشريكة + التحاليل اللي ممكن ترسلها لكل مختبر + كلفة كل تحليل عندهم."""
    db = get_db()
    _ensure_partner_labs(db)
    if request.method == "POST":
        act = request.form.get("act")
        if act == "add_lab":
            nm = (request.form.get("name") or "").strip()
            if nm:
                try:
                    db.execute("INSERT INTO partner_labs (name) VALUES (?)", (nm,))
                    db.commit()
                    flash("تمت إضافة المختبر.")
                except Exception:
                    flash("هذا المختبر موجود مسبقًا.")
        elif act == "delete_lab":
            lid = request.form.get("lab_id")
            db.execute("DELETE FROM partner_lab_prices WHERE lab_id=?", (lid,))
            db.execute("DELETE FROM partner_labs WHERE id=?", (lid,))
            db.commit()
            flash("تم حذف المختبر (التحاليل المرسلة سابقًا تبقى مسجّلة بزياراتها).")
        elif act == "save_price":
            q = (request.form.get("test") or "").strip().lower()
            try:
                cost = float((request.form.get("cost") or "0").replace(",", ""))
            except ValueError:
                cost = 0
            td = db.execute("SELECT id FROM test_definitions WHERE LOWER(code)=? OR LOWER(name)=? OR LOWER(COALESCE(short_name,''))=? LIMIT 1",
                            (q, q, q)).fetchone()
            if not td:
                flash("ما لقيت هذا التحليل — اكتب رمزه أو اسمه كما بالكتالوج.")
            else:
                db.execute("INSERT INTO partner_lab_prices (lab_id, test_definition_id, cost) VALUES (?,?,?) "
                           "ON CONFLICT(lab_id, test_definition_id) DO UPDATE SET cost=excluded.cost",
                           (request.form.get("lab_id"), td["id"], cost))
                db.commit()
                flash("تم حفظ الكلفة.")
        elif act == "delete_price":
            db.execute("DELETE FROM partner_lab_prices WHERE id=?", (request.form.get("id"),))
            db.commit()
        return redirect(url_for("partner_labs_page"))
    labs = db.execute("SELECT id, name FROM partner_labs ORDER BY name").fetchall()
    prices = {}
    for r in db.execute("SELECT pp.id, pp.lab_id, pp.cost, td.name AS tname, td.code AS tcode FROM partner_lab_prices pp "
                        "JOIN test_definitions td ON td.id = pp.test_definition_id ORDER BY td.name").fetchall():
        prices.setdefault(r["lab_id"], []).append(r)
    tests = db.execute("SELECT code, name FROM test_definitions WHERE is_active=1 ORDER BY name").fetchall()
    from flask import render_template_string
    return render_template_string(
        "{% extends 'base.html' %}{% block page_title %}التحاليل المرسلة لمختبرات أخرى{% endblock %}{% block content %}"
        "<style>.pl-t{width:100%;border-collapse:collapse}.pl-t th,.pl-t td{border:1px solid #E2E8F0;padding:6px 9px;font-size:13px;text-align:right}"
        ".pl-t th{background:#205072;color:#fff}.pl-lab{border:1px solid #CBD5E1;border-radius:10px;padding:12px;margin:12px 0;background:#fff}</style>"
        "<div class='card'><h3 style='margin:0 0 6px'>📤 التحاليل المرسلة لمختبرات أخرى</h3>"
        "<p style='color:#475569;font-size:13px'>سجّل المختبرات اللي ترسل لها تحاليل مو متوفرة عندك، وكلفة كل تحليل عند كل مختبر. "
        "بشاشة «زيارة جديدة» تختار المختبر فتُعلَّم تلقائيًا التحاليل المسجّلة هنا، وتُخصم كلفتها من حسابات اليوم والتقارير "
        "(عمود «الفحوصات المرسلة لمختبرات أخرى»). سعر المريض يبقى حسب قائمة أسعارك العادية.</p>"
        "<form method='post' style='display:flex;gap:8px;margin-bottom:8px'><input type='hidden' name='act' value='add_lab'>"
        "<input type='text' name='name' placeholder='اسم المختبر (مثال: مختبر القمة)' required style='padding:8px 10px;min-width:260px'>"
        "<button class='btn'>➕ إضافة مختبر</button></form>"
        "<datalist id='plTests'>{% for t in tests %}<option value='{{ t.code }}'>{{ t.name }}</option>{% endfor %}</datalist>"
        "{% for lab in labs %}<div class='pl-lab'><div style='display:flex;justify-content:space-between;align-items:center'>"
        "<b style='font-size:15px'>🧪 {{ lab.name }}</b>"
        "<form method='post' onsubmit=\"return confirm('حذف هذا المختبر وأسعاره؟')\"><input type='hidden' name='act' value='delete_lab'>"
        "<input type='hidden' name='lab_id' value='{{ lab.id }}'><button class='btn small secondary'>🗑 حذف المختبر</button></form></div>"
        "<table class='pl-t' style='margin-top:8px'><thead><tr><th>التحليل</th><th>الرمز</th><th>الكلفة عندهم</th><th></th></tr></thead><tbody>"
        "{% for p in prices.get(lab.id, []) %}<tr><td>{{ p.tname }}</td><td>{{ p.tcode }}</td><td>{{ '%.0f'|format(p.cost) }}</td>"
        "<td><form method='post'><input type='hidden' name='act' value='delete_price'><input type='hidden' name='id' value='{{ p.id }}'>"
        "<button class='btn small secondary'>🗑</button></form></td></tr>"
        "{% else %}<tr><td colspan='4' style='color:#64748B;text-align:center'>ما أُضيف أي تحليل لهذا المختبر بعد.</td></tr>{% endfor %}</tbody></table>"
        "<form method='post' style='display:flex;gap:8px;margin-top:8px;flex-wrap:wrap'><input type='hidden' name='act' value='save_price'>"
        "<input type='hidden' name='lab_id' value='{{ lab.id }}'>"
        "<input type='text' name='test' list='plTests' placeholder='رمز أو اسم التحليل' required style='padding:7px 9px;min-width:200px'>"
        "<input type='number' name='cost' min='0' step='any' placeholder='الكلفة' required style='padding:7px 9px;width:130px'>"
        "<button class='btn small'>حفظ / تحديث الكلفة</button></form></div>"
        "{% else %}<p class='muted'>لا يوجد مختبرات بعد.</p>{% endfor %}</div>{% endblock %}",
        labs=labs, prices=prices, tests=tests)


@app.route("/master/lab-prices", methods=["GET", "POST"])
@roles_required("supervisor")
def lab_prices():
    """قائمة أسعار لكل مختبر مُرسِل. خانة فارغة = بدون سعر (تنبيه بالزيارة). مختبر بدون أي سعر = يبقى بالسعر الافتراضي القديم."""
    db = get_db()
    sync_test_sections(db)
    labs = db.execute("SELECT * FROM referral_centers WHERE name != 'Walk-in' ORDER BY name").fetchall()
    center_id = request.values.get("center_id", type=int)
    if request.method == "POST" and center_id:
        act = request.form.get("action", "save")
        if act == "save":
            db.execute("DELETE FROM center_test_prices WHERE center_id=?", (center_id,))
            n = 0
            for key, val in request.form.items():
                if key.startswith("price_") and key[6:].isdigit() and val.strip() != "":
                    try:
                        pr = float(val.replace(",", ""))
                    except ValueError:
                        continue
                    if pr < 0:
                        continue
                    db.execute("INSERT INTO center_test_prices (center_id, test_definition_id, price) VALUES (?, ?, ?)",
                               (center_id, int(key[6:]), pr))
                    n += 1
            db.commit()
            log_action("LabPrices", "referral_center", center_id, f"{n} prices")
            flash(f"تم حفظ أسعار المختبر ({n} تحليل).")
        elif act == "copy_default":
            db.execute("INSERT OR IGNORE INTO center_test_prices (center_id, test_definition_id, price) "
                       "SELECT ?, id, price FROM test_definitions WHERE is_active=1 AND COALESCE(price,0)>0", (center_id,))
            db.commit()
            flash("نُسخت الأسعار الافتراضية للتحاليل الناقصة. عدّلها ثم احفظ.")
        elif act == "copy_from":
            src = request.form.get("src_center_id", type=int)
            if src and src != center_id:
                db.execute("INSERT OR IGNORE INTO center_test_prices (center_id, test_definition_id, price) "
                           "SELECT ?, test_definition_id, price FROM center_test_prices WHERE center_id=?", (center_id, src))
                db.commit()
                flash("نُسخت أسعار المختبر المختار للتحاليل الناقصة.")
        return redirect(url_for("lab_prices", center_id=center_id))
    prices, tests = {}, []
    if center_id:
        prices = {r["test_definition_id"]: r["price"] for r in db.execute(
            "SELECT test_definition_id, price FROM center_test_prices WHERE center_id=?", (center_id,)).fetchall()}
        tests = db.execute(
            "SELECT td.*, COALESCE(s.name, td.department, '') AS sec FROM test_definitions td "
            "LEFT JOIN sections s ON s.id=td.section_id WHERE td.is_active=1 ORDER BY sec, td.name").fetchall()
    return render_template("master/lab_prices.html", labs=labs, center_id=center_id, prices=prices, tests=tests)



@app.route("/front-desk/patients")
@login_required
def patients_list():
    db = get_db()
    q = request.args.get("q", "").strip()
    query = "SELECT * FROM patients "
    params = []
    if q:
        query += "WHERE full_name LIKE ? OR phone LIKE ? OR national_id LIKE ? "
        params = [f"%{q}%", f"%{q}%", f"%{q}%"]
    query += "ORDER BY id DESC LIMIT 200"
    patients = db.execute(query, params).fetchall()
    return render_template("front_desk/patients.html", patients=patients, q=q)


@app.route("/front-desk/patients/new", methods=["GET", "POST"])
@login_required
def patient_new():
    db = get_db()
    if request.method == "POST":
        now = datetime.now().isoformat(timespec="seconds")
        _pn_name = request.form.get("full_name", "").strip()
        _pn_name_en = (request.form.get("full_name_en") or "").strip() or transliterate_arabic_name(_pn_name)
        db.execute(
            "INSERT INTO patients (full_name, full_name_en, gender, age, age_unit, phone, email, address, national_id, "
            "passport_number, lab_card_number, contact_method, title, travel_certificate_number, "
            "branch_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (_pn_name, _pn_name_en, request.form.get("gender"),
             request.form.get("age") or None, request.form.get("age_unit") or "Years",
             request.form.get("phone"), request.form.get("email"),
             request.form.get("address"), request.form.get("national_id"),
             request.form.get("passport_number"), request.form.get("lab_card_number"),
             request.form.get("contact_method", "None"), request.form.get("title", "Mr."),
             request.form.get("travel_certificate_number"), session.get("branch_id"), now),
        )
        db.commit()
        flash("Patient added.")
        return redirect(url_for("patients_list"))
    return render_template("front_desk/patient_form.html", patient=None, requires_gate=False)


@app.route("/front-desk/patients/<int:patient_id>/edit", methods=["GET", "POST"])
@login_required
def patient_edit(patient_id):
    db = get_db()
    patient = db.execute("SELECT * FROM patients WHERE id=?", (patient_id,)).fetchone()
    if not patient:
        return "Not found", 404
    # المطلوب 2: تعديل بيانات مريض كل نتائجه مكتملة (ومطبوعة) محمي بنفس
    # كلمة مرور حماية النتائج المكتملة أعلاه -- إذا هذا المريض عنده تحليل
    # واحد ع الأقل وكلها Completed/Verified، لازم كلمة المرور. مريض جديد
    # أو عنده تحليل لسا Pending يبقى تعديله حر بدون أي قيد زيادة عن
    # المعتاد. نحسبها هنا مرة وحدة، تُستخدم بالـGET (لتظهر حقل الباسورد
    # بالفورم أصلاً) وبالـPOST (للتحقق الفعلي).
    all_tests = db.execute(
        "SELECT ot.status FROM order_tests ot JOIN orders o ON o.id=ot.order_id "
        "JOIN visits v ON v.id=o.visit_id WHERE v.patient_id=?",
        (patient_id,),
    ).fetchall()
    requires_gate = bool(all_tests) and all(t["status"] in ("Completed", "Verified") for t in all_tests)
    if request.method == "POST":
        if requires_gate:
            ok, err = _check_completed_result_gate(db, request.form)
            if not ok:
                flash(err)
                return redirect(url_for("patient_edit", patient_id=patient_id))
        _pe_name = request.form.get("full_name", "").strip()
        _pe_name_en = (request.form.get("full_name_en") or "").strip() or transliterate_arabic_name(_pe_name)
        db.execute(
            "UPDATE patients SET full_name=?, full_name_en=?, gender=?, age=?, age_unit=?, phone=?, email=?, address=?, "
            "national_id=?, passport_number=?, lab_card_number=?, contact_method=?, title=?, "
            "travel_certificate_number=? WHERE id=?",
            (_pe_name, _pe_name_en, request.form.get("gender"),
             request.form.get("age") or None, request.form.get("age_unit") or "Years",
             request.form.get("phone"), request.form.get("email"),
             request.form.get("address"), request.form.get("national_id"),
             request.form.get("passport_number"), request.form.get("lab_card_number"),
             request.form.get("contact_method", "None"), request.form.get("title", "Mr."),
             request.form.get("travel_certificate_number"), patient_id),
        )
        db.commit()
        log_action("Update", "patient", patient_id)
        flash("Patient updated.")
        return redirect(url_for("patients_list"))
    return render_template("front_desk/patient_form.html", patient=patient, requires_gate=requires_gate)


def _check_delete_password(db, password):
    """كلمة مرور الحذف (من الإعدادات): أي موظف (استقبال/مختبر/مسؤول) يحذف مريض/زيارة بشرط إدخالها."""
    stored = get_setting(db, "delete_password_hash", "")
    if not stored:
        return False, "لم تُضبط كلمة مرور الحذف بعد — اضبطها من الإعدادات (بطاقة «كلمة مرور الحذف»)."
    if hash_password(password or "") != stored:
        return False, "كلمة مرور الحذف غير صحيحة."
    return True, None


@app.route("/api/delete/visit/<int:visit_id>", methods=["POST"])
@login_required
def api_delete_visit(visit_id):
    db = get_db()
    d = request.get_json(silent=True) or {}
    ok, err = _check_delete_password(db, d.get("password"))
    if not ok:
        return jsonify(ok=False, error=err), 403
    visit = db.execute("SELECT * FROM visits WHERE id=?", (visit_id,)).fetchone()
    if not visit:
        return jsonify(ok=False, error="الزيارة غير موجودة"), 404
    _delete_visit_cascade(db, visit)
    return jsonify(ok=True)


@app.route("/api/delete/patient/<int:patient_id>", methods=["POST"])
@login_required
def api_delete_patient(patient_id):
    """حذف المريض مع كل زياراته ونتائجه وفواتيره (بعد كلمة مرور الحذف)."""
    db = get_db()
    d = request.get_json(silent=True) or {}
    ok, err = _check_delete_password(db, d.get("password"))
    if not ok:
        return jsonify(ok=False, error=err), 403
    patient = db.execute("SELECT * FROM patients WHERE id=?", (patient_id,)).fetchone()
    if not patient:
        return jsonify(ok=False, error="المريض غير موجود"), 404
    for v in db.execute("SELECT * FROM visits WHERE patient_id=?", (patient_id,)).fetchall():
        _delete_visit_cascade(db, v)
    if db.execute("SELECT 1 FROM patients WHERE id=?", (patient_id,)).fetchone():
        db.execute("DELETE FROM patient_followups WHERE patient_id=?", (patient_id,))
        db.execute("DELETE FROM patients WHERE id=?", (patient_id,))
        db.commit()
        log_action("Delete", "patient", patient_id, patient["full_name"])
    return jsonify(ok=True)


@app.route("/front-desk/patients/<int:patient_id>/delete", methods=["POST"])
@roles_required("admin")
def delete_patient(patient_id):
    db = get_db()
    patient = db.execute("SELECT * FROM patients WHERE id=?", (patient_id,)).fetchone()
    if not patient:
        return "Not found", 404
    # لا نحذف المريض إذا عنده زيارات مسجّلة (بيها نتائج/فواتير مرتبطة)، حتى
    # لا تبقى سجلات يتيمة. نمنع الحذف بهذي الحالة ونعرض عدد الزيارات.
    linked_visits = db.execute("SELECT COUNT(*) c FROM visits WHERE patient_id=?", (patient_id,)).fetchone()["c"]
    if linked_visits:
        flash(f"لا يمكن حذف هذا المريض لأنه مرتبط بـ {linked_visits} زيارة. "
              f"احذف تلك الزيارات أولاً إذا تريد حذفه فعلاً.")
        return redirect(url_for("patients_list"))
    db.execute("DELETE FROM patients WHERE id=?", (patient_id,))
    db.commit()
    log_action("Delete", "patient", patient_id, patient["full_name"])
    flash("تم حذف المريض.")
    return redirect(url_for("patients_list"))


# بحث سريع عن مريض سبق أن زار المختبر: يعرض كل زياراته السابقة والفحوصات
# التي أجراها، ويسمح للأدمن حصراً باختيار نتائج قديمة (تحليل واحد أو أكثر،
# من أي زيارة سابقة) ونسخها إلى أحدث زيارة للمريض — وليس الزيارة كاملة.
@app.route("/front-desk/patients/<int:patient_id>/history", methods=["GET", "POST"])
@login_required
def patient_history(patient_id):
    db = get_db()
    patient = db.execute("SELECT * FROM patients WHERE id=?", (patient_id,)).fetchone()
    if not patient:
        return "Not found", 404

    if request.method == "POST":
        if session.get("role") != "admin":
            flash("نسخ نتائج قديمة إلى الزيارة الحالية صلاحية خاصة بالأدمن فقط.")
            return redirect(url_for("patient_history", patient_id=patient_id))

        selected_result_ids = request.form.getlist("copy_result")
        if not selected_result_ids:
            flash("لم تحدد أي نتيجة لنسخها.")
            return redirect(url_for("patient_history", patient_id=patient_id))

        latest_visit = db.execute(
            "SELECT v.*, o.id as order_id FROM visits v JOIN orders o ON o.visit_id = v.id "
            "WHERE v.patient_id=? ORDER BY v.id DESC LIMIT 1",
            (patient_id,),
        ).fetchone()
        if not latest_visit:
            flash("لا توجد زيارة حالية لهذا المريض لنسخ النتائج إليها.")
            return redirect(url_for("patient_history", patient_id=patient_id))

        now = datetime.now().isoformat(timespec="seconds")
        copied = 0
        for result_id in selected_result_ids:
            old_result = db.execute(
                "SELECT r.*, ot.test_definition_id, ot.barcode FROM results r "
                "JOIN order_tests ot ON ot.id = r.order_test_id WHERE r.id=?",
                (result_id,),
            ).fetchone()
            if not old_result:
                continue
            reg = latest_visit["registration_number"]
            tid = old_result["test_definition_id"]
            new_barcode = f"{reg}{str(tid).zfill(3)}-old"

            # نفس هذا التحليل قد يكون انتسخ مسبقًا (نفس المريض، نفس الزيارة
            # الحالية) -- إما بضغطة سابقة لنفس الزر، أو لأن التحليل نفسه فيه
            # أكثر من parameter وكل واحد يُنسخ بضغطة منفصلة. بدون هذا الفحص،
            # كل ضغطة كانت تنشئ صف order_tests جديد بنفس الـbarcode، فيطلع
            # نفس التحليل مكرر بعدة جداول منفصلة بصفحة سجل الزيارات (الخلل
            # المُبلَّغ عنه). نعيد استخدام صف order_tests الموجود أصلاً لهذا
            # الـbarcode بهذي الزيارة إذا كان موجود، بدل إنشاء صف جديد كل مرة.
            existing_ot = db.execute(
                "SELECT id FROM order_tests WHERE order_id=? AND barcode=?",
                (latest_visit["order_id"], new_barcode),
            ).fetchone()
            if existing_ot:
                new_order_test_id = existing_ot["id"]
            else:
                cur = db.execute(
                    "INSERT INTO order_tests (order_id, test_definition_id, status, barcode, notes, created_at) "
                    "VALUES (?, ?, 'Completed', ?, ?, ?)",
                    (latest_visit["order_id"], tid, new_barcode, "نتيجة منسوخة من زيارة سابقة", now),
                )
                new_order_test_id = cur.lastrowid

            # وبنفس المنطق -- نفس الـparameter لنفس صف order_tests هذا قد
            # يكون انتسخ مسبقًا هو نفسه؛ نحدّثه بدل تكراره كصف results جديد.
            existing_result = db.execute(
                "SELECT id FROM results WHERE order_test_id=? AND test_parameter_id=?",
                (new_order_test_id, old_result["test_parameter_id"]),
            ).fetchone()
            if existing_result:
                db.execute(
                    "UPDATE results SET value_numeric=?, value_text=?, flag=?, entered_by=?, entered_at=? "
                    "WHERE id=?",
                    (old_result["value_numeric"], old_result["value_text"], old_result["flag"],
                     session.get("user_id"), now, existing_result["id"]),
                )
            else:
                db.execute(
                    "INSERT INTO results (order_test_id, test_parameter_id, value_numeric, value_text, flag, "
                    "entered_by, entered_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (new_order_test_id, old_result["test_parameter_id"], old_result["value_numeric"],
                     old_result["value_text"], old_result["flag"], session.get("user_id"), now),
                )
            copied += 1
        db.commit()
        log_action("CopyOldResults", "visit", latest_visit["id"], f"{copied} نتيجة من زيارات سابقة")
        flash(f"تم نسخ {copied} نتيجة إلى الزيارة الحالية #{latest_visit['registration_number']}.")
        return redirect(url_for("visit_edit", visit_id=latest_visit["id"]))

    visits = db.execute(
        "SELECT v.*, d.full_name as referring_doctor FROM visits v "
        "LEFT JOIN doctors d ON d.id = v.doctor_id WHERE v.patient_id=? ORDER BY v.id DESC", (patient_id,),
    ).fetchall()
    visit_data = []
    for v in visits:
        order_tests = db.execute(
            "SELECT ot.id, ot.barcode, ot.status, td.name as test_name, td.id as test_definition_id "
            "FROM order_tests ot JOIN orders o ON o.id = ot.order_id "
            "JOIN test_definitions td ON td.id = ot.test_definition_id WHERE o.visit_id=?",
            (v["id"],),
        ).fetchall()
        tests_with_results = []
        for ot in order_tests:
            results = db.execute(
                "SELECT r.*, tp.name as param_name, tp.unit FROM results r "
                "JOIN test_parameters tp ON tp.id = r.test_parameter_id WHERE r.order_test_id=?",
                (ot["id"],),
            ).fetchall()
            tests_with_results.append({"order_test": ot, "results": results})
        visit_data.append({"visit": v, "tests": tests_with_results})

    # التعديل على النتائج: لواجهة المختبر أو الاثنين معًا (أو المصمم) فقط؛ الطباعة
    # والعرض مفتوحة للجميع.
    can_edit_results = bool(session.get("designer_id")) or session.get("interface") in ("lab", "both")
    return render_template("front_desk/patient_history.html", patient=patient,
                           visit_data=visit_data, can_edit_results=can_edit_results)


# بحث موحّد بالصفحة الرئيسية: يبحث بثلاث فئات مرة وحدة — اسم مريض (يظهر
# تفاصيله عبر رابط سجله)، اسم طبيب مُحيل، واسم مختبر مُرسِل (الأخيرين
# يوديان لقائمة زياراتهما مرتبة بالأحدث تاريخًا ووقتًا عبر فلتر
# doctor_id/referral_center_id بصفحة "الزيارات" — راجع visits_list أعلاه).
@app.route("/api/dashboard/search")
@login_required
def api_dashboard_search():
    q = (request.args.get("q") or "").strip()
    if len(q) < 2:
        return jsonify({"patients": [], "doctors": [], "referral_labs": []})
    db = get_db()
    patients = db.execute(
        "SELECT p.id, p.full_name, p.gender, p.age, p.age_unit, p.phone, "
        "(SELECT MAX(v.created_at) FROM visits v WHERE v.patient_id = p.id) as last_visit_at, "
        "(SELECT substr(MAX(v.created_at), 1, 10) FROM visits v WHERE v.patient_id = p.id) as last_visit_date, "
        "(SELECT d.full_name FROM visits v LEFT JOIN doctors d ON d.id = v.doctor_id "
        " WHERE v.patient_id = p.id ORDER BY v.id DESC LIMIT 1) as referring_doctor, "
        "(SELECT COUNT(*) FROM order_tests ot JOIN orders o ON o.id = ot.order_id "
        " JOIN visits v ON v.id = o.visit_id WHERE v.patient_id = p.id "
        " AND ot.status NOT IN ('Completed', 'Verified')) as pending_count "
        "FROM patients p WHERE p.full_name LIKE ? ORDER BY p.full_name LIMIT 10",
        (f"%{q}%",),
    ).fetchall()
    doctors = db.execute(
        "SELECT d.id, d.full_name, d.phone, "
        "(SELECT MAX(v.created_at) FROM visits v WHERE v.doctor_id = d.id) as last_visit_at "
        "FROM doctors d WHERE d.full_name LIKE ? "
        "ORDER BY last_visit_at IS NULL, last_visit_at DESC LIMIT 6",
        (f"%{q}%",),
    ).fetchall()
    referral_labs = db.execute(
        "SELECT rc.id, rc.name, rc.phone, "
        "(SELECT MAX(v.created_at) FROM visits v WHERE v.referral_center_id = rc.id) as last_visit_at "
        "FROM referral_centers rc WHERE rc.name LIKE ? AND rc.name != 'Walk-in' "
        "ORDER BY last_visit_at IS NULL, last_visit_at DESC LIMIT 6",
        (f"%{q}%",),
    ).fetchall()
    return jsonify({
        "patients": [dict(r) for r in patients],
        "doctors": [dict(r) for r in doctors],
        "referral_labs": [dict(r) for r in referral_labs],
    })


# بحث سريع موحّد عن أي نتيجة تحليل (بالاسم/رقم التسجيل/الباركود) --
# يظهر بمربع البحث العلوي المشترك بشريط كل صفحات البرنامج (topbar
# بـbase.html)، فيكون متاحًا بنفس المكان وبنفس السرعة بالشاشات الثلاث
# (استقبال/مختبر/الاثنين معًا) بدل المرور بصفحة Orders أو النتائج أول.
# الرابط المُرجَع لكل نتيجة يتغيّر حسب واجهة المستخدم الحالية (session
# interface) حتى ما يوصّل لصفحة محجوبة عنه (enforce_interface_scope).
@app.route("/api/results/quick-search")
@login_required
def api_results_quick_search():
    """v65: سطر واحد لكل زيارة (قبل: سطر لكل تحليل فيتكرر اسم المريض). لو نفس الاسم لأكثر من مريض/زيارة
    يظهر مع كل واحد (العمر · تاريخ الزيارة) حتى يتفرقون."""
    q = (request.args.get("q") or "").strip()
    if len(q) < 2:
        return jsonify({"items": []})
    db = get_db()
    _seq_q = _visit_seq_clause(q)
    rows = db.execute(
        "SELECT v.id AS visit_id, v.registration_number, v.created_at, p.full_name AS patient_name, p.age, p.age_unit, "
        "MIN(ot.id) AS order_test_id, MAX(ot.barcode) AS barcode, COUNT(ot.id) AS n_tests, "
        "SUM(CASE WHEN ot.status IN ('Completed','Verified') THEN 1 ELSE 0 END) AS n_done, "
        "GROUP_CONCAT(COALESCE(NULLIF(td.short_name,''), td.name), ', ') AS tests "
        "FROM order_tests ot "
        "JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id "
        "JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id "
        "WHERE p.full_name LIKE ? OR CAST(v.registration_number AS TEXT) LIKE ? OR ot.barcode LIKE ? "
        + (" OR " + _seq_q[0] if _seq_q else "") +
        " GROUP BY v.id ORDER BY v.id DESC LIMIT 15",
        (f"%{q}%", _scan_like(q), f"%{q}%") + tuple(_seq_q[1] if _seq_q else ()),
    ).fetchall()
    use_front_desk = session.get("interface") in (None, "reception", "both")
    name_count = {}
    for r in rows:
        name_count[r["patient_name"]] = name_count.get(r["patient_name"], 0) + 1
    items = []
    for r in rows:
        link = (url_for("visit_results_entry", visit_id=r["visit_id"]) if use_front_desk
                else url_for("result_entry", order_test_id=r["order_test_id"]))
        # v71: نتائج مكتملة + PDF مؤرشف موجود => يفتح الـPDF مباشرة بدل لوحة إدخال النتائج
        try:
            if r["n_done"] == r["n_tests"]:
                link = url_for("pdf_archive_open", visit_id=r["visit_id"])
        except Exception:
            pass
        label = f"{r['n_tests']} تحاليل"
        if name_count.get(r["patient_name"], 0) > 1:
            # تشابه أسماء: نضيف العمر وتاريخ الزيارة للتفريق
            label = f"{r['age'] or '?'} {r['age_unit'] or ''} · {(r['created_at'] or '')[:16].replace('T', ' ')} — " + label
        items.append({
            "test_name": label, "patient_name": r["patient_name"],
            "registration_number": r["registration_number"],
            "status": "Completed" if r["n_done"] == r["n_tests"] else f"{r['n_done']}/{r['n_tests']}",
            "barcode": r["barcode"], "link": link, "tests": r["tests"],
            "age": r["age"], "created_at": r["created_at"], "same_name": name_count.get(r["patient_name"], 0) > 1,
        })
    return jsonify({"items": items})


# بحث فوري (Live search) يُستخدم من شاشة "زيارة جديدة": بمجرد كتابة اسم
# المريض يبحث عن أي مطابقة سابقة بجدول المرضى، حتى لا تنفتح بطاقة مريض
# مكررة لشخص سبق أن راجع المختبر.
@app.route("/api/patients/search")
@login_required
def api_patients_search():
    q = (request.args.get("q") or "").strip()
    if len(q) < 2:
        return jsonify([])
    db = get_db()
    rows = db.execute(
        "SELECT p.id, p.full_name, p.gender, p.age, p.age_unit, p.phone, p.address, "
        "(SELECT MAX(v.created_at) FROM visits v WHERE v.patient_id = p.id) as last_visit_at, "
        "(SELECT v2.id FROM visits v2 WHERE v2.patient_id = p.id ORDER BY v2.created_at DESC LIMIT 1) as last_visit_id "
        "FROM patients p WHERE p.full_name LIKE ? ORDER BY p.full_name LIMIT 8",
        (f"%{q}%",),
    ).fetchall()
    # لكل مريض مطابق بالاسم، نجيب أسماء تحاليل آخر زيارة له (مو كل الزيارات
    # — بس آخر وحدة، تكفي كتمييز سريع) حتى يقدر موظف الاستقبال يفرّق فورًا
    # بين شخصين بنفس الاسم بالضبط عن طريق نوع التحليل أو تاريخ آخر زيارة،
    # دون فتح كل سجل على حدة. هذا لا يغيّر أو يحذف أي بيانات — قراءة فقط.
    out = []
    for r in rows:
        d = dict(r)
        last_tests = []
        if d.get("last_visit_id"):
            last_tests = [t["name"] for t in db.execute(
                "SELECT DISTINCT td.name FROM order_tests ot "
                "JOIN orders o ON o.id = ot.order_id "
                "JOIN test_definitions td ON td.id = ot.test_definition_id "
                "WHERE o.visit_id=? LIMIT 6",
                (d["last_visit_id"],),
            ).fetchall()]
        d["last_visit_tests"] = last_tests
        d.pop("last_visit_id", None)
        out.append(d)
    return jsonify(out)


# ملخص زيارات مريض سبق أن راجع (تُستدعى من شاشة "زيارة جديدة" بعد اختيار
# مطابقة من البحث الفوري) — تاريخ كل زيارة والتحاليل التي أُجريت بها، حتى
# تظهر أزرار مشاهدة / طباعة / تضمين لكل زيارة قديمة.

# كشف زيارة سابقة لنفس المريض (بمطابقة الاسم الثلاثي + العمر بالضبط) لحظة
# كتابة الاسم والعمر بشاشة "زيارة جديدة" — تُرجع بس آخر زيارة (الأحدث، لا
# كل التاريخ)، وتحاليلها المكتملة مقسّمة لمجموعتين حسب سياسة الدمج:
# "mergeable" (Biochemistry/Hormones/Vitamins/Virology/Tumor Marker/
# Coagulation — نفس PREVIOUS_VALUE_DEPARTMENT_KEYWORDS) يعرضها الموظف
# كخيارات دمج اختيارية، و"info_only" (Blood Film/Retic/Fluid Exam/BMA/
# BMB — نفس REPORT_TEMPLATE_MAP) تُعرض كرسالة إعلامية بس بدون أي خيار
# دمج. أي تحليل من قسم غير مذكور بأي من القائمتين يُهمَل بصمت (لا داعي
# له بهذا التنبيه أصلاً).
@app.route("/api/sample-no/next")
@login_required
def api_next_sample_no():
    return jsonify({"sample_no": peek_next_sample_no(get_db())})


def _visit_balance(db, visit_id):
    """الإجمالي/الواصل/الباقي لزيارة — نفس منطق عمودي \"الواصل\" و\"الباقي\" بقائمة الزيارات:
    الباقي = إجمالي الفاتورة - الواصل (ما فيه فاتورة = لا باقي)."""
    inv = db.execute("SELECT id, total_amount, paid_amount FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()
    if not inv:
        return {"has_invoice": False, "total": 0.0, "paid": 0.0, "remaining": 0.0}
    total = float(inv["total_amount"] or 0)
    paid = float(inv["paid_amount"] or 0)
    return {"has_invoice": True, "total": total, "paid": paid, "remaining": max(0.0, total - paid)}


@app.route("/api/visits/<int:visit_id>/balance")
@login_required
def api_visit_balance(visit_id):
    """يُستدعى من شاشة إدخال النتائج قبل الطباعة: هل المريض مسدّد كامل أجور التحاليل؟"""
    db = get_db()
    row = db.execute(
        "SELECT p.full_name FROM visits v JOIN patients p ON p.id=v.patient_id WHERE v.id=?", (visit_id,)
    ).fetchone()
    if not row:
        return jsonify({"ok": False, "error": "الزيارة غير موجودة"}), 404
    out = _visit_balance(db, visit_id)
    out.update({"ok": True, "patient_name": row["full_name"],
                "can_override": session.get("role") in ("admin", "supervisor")})
    return jsonify(out)


@app.route("/api/visits/<int:visit_id>/pay", methods=["POST"])
@login_required
def api_visit_pay(visit_id):
    """تسجيل دفعة إضافية للمريض من نفس شاشة النتائج/الطباعة (بدون الذهاب لصفحة الفواتير)."""
    db = get_db()
    inv = db.execute("SELECT * FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()
    if not inv:
        return jsonify({"ok": False, "error": "ما توجد فاتورة لهذي الزيارة"}), 404
    if inv["is_locked"]:
        return jsonify({"ok": False, "error": "الفاتورة مقفلة — افتحها أولًا من صفحة الفواتير"}), 403
    try:
        amount = float((request.form.get("amount") or "0").replace(",", "").strip())
    except ValueError:
        return jsonify({"ok": False, "error": "المبلغ غير صالح"}), 400
    if amount <= 0:
        return jsonify({"ok": False, "error": "أدخل مبلغًا أكبر من صفر"}), 400
    now = datetime.now().isoformat(timespec="seconds")
    new_paid = float(inv["paid_amount"] or 0) + amount
    status = "Paid" if new_paid >= float(inv["total_amount"] or 0) else "Partial"
    db.execute("INSERT INTO payments (invoice_id, amount, method, user_id, paid_at) VALUES (?, ?, 'Cash', ?, ?)",
               (inv["id"], amount, session.get("user_id"), now))
    db.execute("UPDATE invoices SET paid_amount=?, status=? WHERE id=?", (new_paid, status, inv["id"]))
    db.commit()
    log_action("Payment", "invoice", inv["id"], f"amount={amount} (from results/print screen)")
    out = _visit_balance(db, visit_id)
    out["ok"] = True
    return jsonify(out)


@app.route("/api/visits/<int:visit_id>/prev-count", methods=["POST"])
@login_required
def api_set_visit_prev_count(visit_id):
    """يحدد/يغيّر عدد الزيارات السابقة اللي تظهر نتائجها بتقارير هذي الزيارة (0 = إلغاء)."""
    db = get_db()
    if not db.execute("SELECT id FROM visits WHERE id=?", (visit_id,)).fetchone():
        return {"ok": False, "error": "الزيارة غير موجودة"}, 404
    raw = (request.form.get("count") or (request.get_json(silent=True) or {}).get("count") or "").__str__().strip()
    if not raw.lstrip("-").isdigit():
        return {"ok": False, "error": "عدد غير صالح"}, 400
    n = set_visit_prev_pref(db, visit_id, int(raw))
    log_action("SetVisitPrevCount", "visit", visit_id, str(n))
    return {"ok": True, "count": n}


@app.route("/api/patients/previous-visit-count-options")
@login_required
def api_prev_visit_count_options():
    """خيارات عدد الزيارات السابقة لصفحة \"زيارة جديدة\": الافتراضي من الإعدادات والحد الأقصى."""
    cfg = get_result_layout(get_db())
    return jsonify({"default": cfg["prev_count"], "max": 20, "order": cfg["prev_order"]})


@app.route("/api/patients/previous-visit-check")
@login_required
def api_previous_visit_check():
    full_name = (request.args.get("full_name") or "").strip()
    age_raw = (request.args.get("age") or "").strip()
    if not full_name or not age_raw:
        return jsonify({"found": False})
    try:
        age = float(age_raw)
    except ValueError:
        return jsonify({"found": False})

    db = get_db()
    match = find_last_visit_by_name_age(db, full_name, age)
    if not match:
        return jsonify({"found": False})

    try:
        dt = datetime.fromisoformat(match["created_at"])
        date_display = f"{dt.day}/{dt.month}/{dt.year}"
    except (TypeError, ValueError):
        date_display = match["created_at"] or ""

    tests = get_visit_completed_tests(db, match["visit_id"])
    mergeable, info_only = [], []
    for tst in tests:
        if department_shows_previous_values(tst["department"]):
            results = db.execute(
                "SELECT r.*, tp.name as param_name FROM results r "
                "JOIN test_parameters tp ON tp.id = r.test_parameter_id WHERE r.order_test_id=? LIMIT 1",
                (tst["order_test_id"],),
            ).fetchone()
            summary = ""
            if results:
                val = results["value_text"] if results["value_text"] not in (None, "") else results["value_numeric"]
                summary = f"{results['param_name']}: {val}" if val not in (None, "") else ""
            # كم مرة سُحب نفس هذا التحليل لهذا المريض بزيارات سابقة + تواريخها (مدموج من v10)
            prior_rows = db.execute(
                "SELECT v.created_at FROM order_tests ot2 "
                "JOIN orders o2 ON o2.id = ot2.order_id "
                "JOIN visits v ON v.id = o2.visit_id "
                "WHERE v.patient_id=? AND ot2.test_definition_id=? AND ot2.status IN ('Completed', 'Verified') "
                "ORDER BY v.created_at DESC",
                (match["patient_id"], tst["test_definition_id"]),
            ).fetchall()
            prior_dates = []
            for pr in prior_rows:
                try:
                    pdt = datetime.fromisoformat(pr["created_at"])
                    prior_dates.append(f"{pdt.day}/{pdt.month}/{pdt.year}")
                except (TypeError, ValueError):
                    if pr["created_at"]:
                        prior_dates.append(pr["created_at"])
            mergeable.append({
                "order_test_id": tst["order_test_id"], "name": tst["test_name"], "summary": summary,
                "prior_count": len(prior_dates), "prior_dates": prior_dates,
            })
        elif tst["test_code"] in REPORT_TEMPLATE_MAP:
            info_only.append({"order_test_id": tst["order_test_id"], "name": tst["test_name"]})

    # كل التحاليل اللي انعملت لنفس المريض بأي زيارة سابقة (مو بس آخر زيارة) مع عدد زياراتها
    # وآخر تاريخ — حتى لما يختار الموظف تحليل (مثل FBS) يطلع له إن المريض سبق وسحب له.
    _cur = db.execute("SELECT full_name, age FROM patients WHERE id=?", (match["patient_id"],)).fetchone()
    _rows = db.execute(
        "SELECT td.id AS tdid, td.name AS name, td.department AS department, td.code AS code, "
        "COUNT(DISTINCT v.id) AS visits, MAX(v.created_at) AS last_at "
        "FROM order_tests ot JOIN orders o ON o.id = ot.order_id JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id JOIN test_definitions td ON td.id = ot.test_definition_id "
        "WHERE ot.status IN ('Completed','Verified') "
        "AND (v.patient_id=? OR (LOWER(TRIM(p.full_name))=LOWER(TRIM(?)) AND p.age=?)) "
        "GROUP BY td.id ORDER BY td.name",
        (match["patient_id"], (_cur["full_name"] if _cur else full_name) or "", age),
    ).fetchall()
    history_tests = []
    for r in _rows:
        if r["code"] in REPORT_TEMPLATE_MAP and r["code"] != "COAG":
            continue
        try:
            _d = datetime.fromisoformat(r["last_at"]); _dd = f"{_d.day:02d}/{_d.month:02d}/{_d.year}"
        except (TypeError, ValueError):
            _dd = r["last_at"] or ""
        history_tests.append({"test_definition_id": r["tdid"], "name": r["name"], "department": r["department"] or "",
                              "visits": r["visits"], "last_date": _dd})

    return jsonify({
        "found": True,
        "patient_id": match["patient_id"],
        "date_display": date_display,
        "mergeable": mergeable,
        "info_only": info_only,
        "history_tests": history_tests,
        "default_count": get_result_layout(db)["prev_count"],
    })


@app.route("/api/patients/<int:patient_id>/visits-summary")
@login_required
def api_patient_visits_summary(patient_id):
    db = get_db()
    patient = db.execute("SELECT * FROM patients WHERE id=?", (patient_id,)).fetchone()
    if not patient:
        return jsonify({"error": "not found"}), 404
    visits = db.execute(
        "SELECT v.id, v.registration_number, v.created_at FROM visits v "
        "WHERE v.patient_id=? ORDER BY v.id DESC LIMIT 10",
        (patient_id,),
    ).fetchall()
    visits_out = []
    for v in visits:
        tests = db.execute(
            "SELECT td.name FROM order_tests ot JOIN orders o ON o.id = ot.order_id "
            "JOIN test_definitions td ON td.id = ot.test_definition_id WHERE o.visit_id=? ORDER BY td.name",
            (v["id"],),
        ).fetchall()
        has_results = db.execute(
            "SELECT COUNT(*) c FROM results r JOIN order_tests ot ON ot.id = r.order_test_id "
            "JOIN orders o ON o.id = ot.order_id WHERE o.visit_id=?",
            (v["id"],),
        ).fetchone()["c"] > 0
        visits_out.append({
            "id": v["id"],
            "registration_number": v["registration_number"],
            "created_at": v["created_at"],
            "tests": [t["name"] for t in tests],
            "has_results": has_results,
        })
    return jsonify({
        "patient": {
            "id": patient["id"], "full_name": patient["full_name"], "gender": patient["gender"],
            "age": patient["age"], "age_unit": patient["age_unit"], "phone": patient["phone"],
            "address": patient["address"],
        },
        "visits": visits_out,
    })


@app.route("/front-desk/results")
@login_required
def results_list():
    db = get_db()
    # فلترة اختيارية قادمة من بطاقات الرئيسية:
    # - "pending": زيارات فيها تحليل واحد على الأقل لسا حالته Accepted أو
    #   In-progress — نفس المعيار بالضبط المستخدم بعدّاد "نتائج قيد الإنجاز"
    #   بالرئيسية (dashboard()), حتى يطابق العدد المعروض هناك عدد الصفوف هنا.
    # - "critical": زيارات فيها نتيجة واحدة على الأقل flag='Critical' ولسا
    #   verified_at فاضي — نفس معيار عدّاد "تنبيهات حرجة" بالرئيسية بالضبط.
    filter_type = request.args.get("filter", "")
    # q: بحث حر باسم المريض / رقم التسجيل / الباركود -- يشتغل على كل
    # الزيارات بدون استثناء (المُرسَلة للاستقبال وغيرها)، لأن أي موظف
    # بأي شاشة لازم يقدر يوصل لأي نتيجة قديمة أو جديدة من هنا.
    q = request.args.get("q", "").strip()
    query = (
        "SELECT v.id as visit_id, v.registration_number, v.created_at, p.full_name as patient_name, "
        "COUNT(ot.id) as tests_count, "
        "SUM(CASE WHEN ot.status IN ('Completed', 'Verified') THEN 1 ELSE 0 END) as done_count, "
        "SUM(CASE WHEN ot.status = 'Verified' THEN 1 ELSE 0 END) as verified_count, "
        "SUM(CASE WHEN ot.sent_to_reception = 1 THEN 1 ELSE 0 END) as sent_count, "
        "SUM(CASE WHEN ot.sent_to_reception = 1 AND ot.reception_seen = 0 THEN 1 ELSE 0 END) as unseen_count, "
        "GROUP_CONCAT(ot.id || ':' || td.name, '||') as tests_list "
        "FROM order_tests ot "
        "JOIN orders o ON o.id = ot.order_id "
        "JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id "
        "JOIN test_definitions td ON td.id = ot.test_definition_id "
    )
    filter_label = None
    if q:
        query += (
            "WHERE (p.full_name LIKE ? OR CAST(v.registration_number AS TEXT) LIKE ? OR v.id IN ("
            "  SELECT o2.visit_id FROM order_tests ot2 JOIN orders o2 ON o2.id = ot2.order_id "
            "  WHERE ot2.barcode LIKE ?"
            ")) "
        )
    elif filter_type == "pending":
        query += (
            "WHERE v.id IN ("
            "  SELECT o2.visit_id FROM order_tests ot2 "
            "  JOIN orders o2 ON o2.id = ot2.order_id "
            "  WHERE ot2.status IN ('Accepted','In-progress')"
            ") "
        )
        filter_label = "زيارات فيها نتائج قيد الإنجاز"
    elif filter_type == "critical":
        query += (
            "WHERE v.id IN ("
            "  SELECT o2.visit_id FROM order_tests ot2 "
            "  JOIN orders o2 ON o2.id = ot2.order_id "
            "  JOIN results r2 ON r2.order_test_id = ot2.id "
            "  WHERE r2.flag='Critical' AND r2.verified_at IS NULL"
            ") "
        )
        filter_label = "زيارات فيها تنبيهات حرجة غير مُصادَق عليها"
    query += "GROUP BY v.id "
    if not q and not filter_type:
        # صفحة "إدخال النتائج": المريض المكتملة كل نتائجه ينتقل لصفحة "النتائج المكتملة".
        # البحث (q) يبقى يشوف كل شي. ?all=1 يعرض الكل.
        if request.args.get("all") != "1":
            query += "HAVING SUM(CASE WHEN ot.status NOT IN ('Completed', 'Verified') THEN 1 ELSE 0 END) > 0 "
    query += "ORDER BY v.id DESC LIMIT 200"
    q_params = [f"%{q}%", _scan_like(q), f"%{q}%"] if q else []
    rows = db.execute(query, q_params).fetchall()
    return render_template("front_desk/results.html", rows=rows, filter_type=filter_type,
                            filter_label=filter_label, q=q)



# ------------------------------------------------------------------------
# صفحة "النتائج المكتملة": مرضى عندهم نتائج مكتملة (اليوم افتراضيًا، أو بحث بالاسم/الرقم/الباركود على كل الأيام).
# اسم المريض -> PDF مجمّع لكل تحاليله المكتملة، اسم التحليل -> PDF لهذا التحليل. المسار بلا بادئة (يفتح من كل الواجهات).
# ------------------------------------------------------------------------
@app.route("/completed-results")
@login_required
def completed_results():
    db = get_db()
    q = request.args.get("q", "").strip()
    day = request.args.get("date", "").strip()
    all_days = request.args.get("all") == "1"
    if not day:
        day = datetime.now().strftime("%Y-%m-%d")
    where = ["ot.status IN ('Completed', 'Verified')"]
    params = []
    if q:
        where.append("(p.full_name LIKE ? OR CAST(v.registration_number AS TEXT) LIKE ? OR v.id IN ("
                     "SELECT o2.visit_id FROM order_tests ot2 JOIN orders o2 ON o2.id = ot2.order_id WHERE ot2.barcode LIKE ?))")
        params += [f"%{q}%", _scan_like(q), f"%{q}%"]
    elif not all_days:
        where.append("substr(v.created_at,1,10) = ?")
        params.append(day)
    rows = db.execute(
        "SELECT v.id as visit_id, v.registration_number, v.created_at, p.full_name as patient_name, p.phone as phone, "
        "MIN(COALESCE(ot.collected_at, v.created_at)) as drawn_at, "
        "GROUP_CONCAT(ot.id || '\u0001' || COALESCE(NULLIF(td.short_name, ''), td.name) || '\u0001' || td.name, '\u0002') as tests_list, "
        "(SELECT COUNT(*) FROM order_tests ot3 JOIN orders o3 ON o3.id = ot3.order_id WHERE o3.visit_id = v.id) as total_tests "
        "FROM order_tests ot JOIN orders o ON o.id = ot.order_id JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id JOIN test_definitions td ON td.id = ot.test_definition_id "
        "WHERE " + " AND ".join(where) + " GROUP BY v.id ORDER BY v.id DESC LIMIT 200", params).fetchall()
    visits = []
    for r in rows:
        tests = []
        for part in (r["tests_list"] or "").split("\u0002"):
            bits = part.split("\u0001")
            if len(bits) == 3:
                tid = int(bits[0])
                code_, name_ = bits[1], bits[2]
                # تحليل التخثر (COAG) تعريف واحد يضم PT/INR/PTT...: نعرض أسماء البارامترات اللي لها نتيجة
                # (PT, INR) بدل اسم القسم/التعريف العام.
                if (code_ or "").upper() in ("COAG",) or "coagulation" in (name_ or "").lower():
                    try:
                        prs = db.execute(
                            "SELECT tp.name FROM results rs JOIN test_parameters tp ON tp.id = rs.test_parameter_id "
                            "WHERE rs.order_test_id=? AND (COALESCE(rs.value_text,'')<>'' OR rs.value_numeric IS NOT NULL) "
                            "ORDER BY tp.id", (tid,)).fetchall()
                        pn = [p["name"] for p in prs if p["name"] and not p["name"].strip().lower().endswith("control")]
                        if pn:
                            code_ = name_ = ", ".join(pn)
                    except Exception:
                        pass
                tests.append({"id": tid, "code": code_, "name": name_})
        visits.append({"visit_id": r["visit_id"], "reg": r["registration_number"], "name": r["patient_name"],
                       "phone": r["phone"], "drawn": (r["drawn_at"] or "")[:16].replace("T", " "),
                       "tests": tests, "total": r["total_tests"]})
    return render_template("front_desk/completed_results.html", visits=visits, q=q, day=day, all_days=all_days)


def _restore_printed_at(db, snapshot):
    """عرض PDF ما يُعتبر طباعة: نرجّع printed_at لقيمته السابقة (print_report يثبّتها أول فتحة)."""
    try:
        for ot_id, prev in snapshot.items():
            db.execute("UPDATE order_tests SET printed_at=? WHERE id=?", (prev, ot_id))
        db.commit()
    except Exception:
        pass


def _v74_log_exc(msg):
    """يكتب سبب الفشل + traceback بـ error_log.txt (بدل ما نبلعه بصمت)."""
    try:
        import traceback as _tb
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "error_log.txt"), "a", encoding="utf-8") as _f:
            _f.write("\n[%s] %s\n%s\n" % (datetime.now().isoformat(timespec="seconds"), msg, _tb.format_exc()))
    except Exception:
        pass


def _v74_printable_html(html_content):
    """لما يتعذّر توليد PDF: نعرض التقرير نفسه مع شريط (لا يُطبع) فيه زر طباعة / حفظ كـPDF."""
    if not isinstance(html_content, str) or "</body>" not in html_content:
        return html_content
    bar = ('<style>@media print{#lisV74Bar{display:none!important}}</style>'
           '<div id="lisV74Bar" style="position:fixed;top:8px;left:8px;z-index:99999;background:#fff;border:1px solid #94A3B8;'
           'border-radius:10px;padding:6px 12px;font:13px Tahoma,Arial,sans-serif;direction:rtl;box-shadow:0 3px 12px rgba(0,0,0,.25);">'
           '<button onclick="window.print()" style="background:#205072;color:#fff;border:0;border-radius:7px;padding:6px 14px;'
           'font:700 13px Tahoma;cursor:pointer;">🖨 طباعة / حفظ كـ PDF</button>'
           '<span style="color:#64748B;margin-inline-start:8px;">(بنافذة الطباعة اختر الوجهة: Save as PDF)</span></div>')
    return html_content.replace("</body>", bar + "</body>", 1)


def _serve_pdf_or_html(html_content, prefix):
    """يحوّل HTML لـPDF ويعرضه بالمتصفح (inline). لو محرك الـPDF فشل نعرض التقرير نفسه (جاهز للطباعة) بدل خطأ."""
    try:
        import pdf_export
        pdf_path = pdf_export.make_temp_pdf_path(_safe_pdf_name_part(prefix))
        pdf_export.html_to_pdf(html_content, request.url_root, pdf_path)
        if os.path.exists(pdf_path):
            return send_file(pdf_path, mimetype="application/pdf", as_attachment=False,
                             download_name=os.path.basename(pdf_path))
    except Exception:
        _v74_log_exc("pdf_export failed (_serve_pdf_or_html)")
    return _v74_printable_html(html_content)


@app.route("/reports/pdf/test/<int:order_test_id>")
@login_required
def report_pdf_test(order_test_id):
    db = get_db()
    row = db.execute(
        "SELECT ot.printed_at, p.full_name, td.name as test_name FROM order_tests ot "
        "JOIN test_definitions td ON td.id = ot.test_definition_id JOIN orders o ON o.id = ot.order_id "
        "JOIN visits v ON v.id = o.visit_id JOIN patients p ON p.id = v.patient_id WHERE ot.id=?", (order_test_id,)).fetchone()
    if not row:
        return "Not found", 404
    html_content = print_report(order_test_id)
    _restore_printed_at(db, {order_test_id: row["printed_at"]})
    if not isinstance(html_content, str):
        return html_content
    return _serve_pdf_or_html(html_content, f"{row['full_name']} - {row['test_name']}")


@app.route("/reports/pdf/visit/<int:visit_id>")
@login_required
def report_pdf_visit(visit_id):
    db = get_db()
    vrow = db.execute("SELECT p.full_name FROM visits v JOIN patients p ON p.id = v.patient_id WHERE v.id=?", (visit_id,)).fetchone()
    if not vrow:
        return "Not found", 404
    snap = {r["id"]: r["printed_at"] for r in db.execute(
        "SELECT ot.id, ot.printed_at FROM order_tests ot JOIN orders o ON o.id = ot.order_id WHERE o.visit_id=?", (visit_id,))}
    html_content = None
    try:   # نفس "اللوحة المجمّعة" المصممة اللي تنطبع (مثل الأرشفة v72)، وإلا المولّد القديم
        session.setdefault("interface", "both")
        _h74 = print_combined_panel(visit_id)
        html_content = _h74 if isinstance(_h74, str) and len(_h74) > 500 else None
    except Exception:
        _v74_log_exc("print_combined_panel failed (report_pdf_visit)")
    if not html_content:
        html_content = _build_combined_designed_reports_html(visit_id)
    _restore_printed_at(db, snap)
    if not html_content:
        return ("<div dir='rtl' style='padding:40px;text-align:center;font-family:Tahoma,Arial,sans-serif;color:#64748B;'>"
                "لا توجد نتائج مكتملة لهذا المريض بعد.</div>")
    return _serve_pdf_or_html(html_content, f"{vrow['full_name']} - كل النتائج")


@app.route("/search")
@login_required
def global_result_search():
    """بحث سريع وشامل عن أي نتيجة (باسم المريض / رقم التسجيل / الباركود)
    -- متاح بكل الصفحات وكل الواجهات الثلاث (استقبال/مختبر/الاثنين معًا)
    عبر مربع البحث بأعلى شريط base.html، بما فيها أعلى صفحة \"زيارة
    جديدة\" مباشرة. لا يتقيّد بأي فلتر (يشمل حتى التحاليل المُرسَلة
    لشاشة الاستقبال والمختفية من القائمة الافتراضية بصفحة Orders).
    يعرض لكل نتيجة رابط متابعة يناسب الواجهة الحالية للمستخدم فقط، حتى
    لا يوصل لصفحة ممنوعة عنه (enforce_interface_scope)."""
    q = (request.args.get("q") or "").strip()
    rows = []
    if len(q) >= 2:
        db = get_db()
        rows = db.execute(
            "SELECT ot.id, ot.status, ot.sent_to_reception, ot.printed_at, "
            "td.name as test_name, td.department, "
            "p.full_name as patient_name, v.id as visit_id, v.registration_number, v.created_at "
            "FROM order_tests ot "
            "JOIN test_definitions td ON td.id = ot.test_definition_id "
            "JOIN orders o ON o.id = ot.order_id "
            "JOIN visits v ON v.id = o.visit_id "
            "JOIN patients p ON p.id = v.patient_id "
            "WHERE p.full_name LIKE ? OR CAST(v.registration_number AS TEXT) LIKE ? OR ot.barcode LIKE ? "
            "ORDER BY ot.id DESC LIMIT 100",
            (f"%{q}%", _scan_like(q), f"%{q}%"),
        ).fetchall()
    return render_template("search_results.html", q=q, rows=rows)



@app.route("/front-desk/barcodes")
@login_required
def barcodes_search():
    """v65: ابحث عن أي مريض/زيارة (اسم، رقم تسجيل، هاتف، باركود) واطبع باركوداته بأي وقت —
    حتى لو النتيجة غير مكتملة: باركود الأنابيب، باركود الزيارة، QR البوابة، ملصق الطلب."""
    db = get_db()
    q = (request.args.get("q") or "").strip()
    if q:
        like = f"%{q}%"
        rows = db.execute(
            "SELECT DISTINCT v.id AS visit_id, v.registration_number AS reg, v.created_at, p.full_name, p.phone, "
            "(SELECT COUNT(*) FROM order_tests ot2 JOIN orders o2 ON o2.id=ot2.order_id WHERE o2.visit_id=v.id) AS n_tests, "
            "(SELECT COUNT(*) FROM order_tests ot3 JOIN orders o3 ON o3.id=ot3.order_id WHERE o3.visit_id=v.id "
            " AND ot3.status IN ('Completed','Verified')) AS n_done "
            "FROM visits v JOIN patients p ON p.id=v.patient_id "
            "LEFT JOIN orders o ON o.visit_id=v.id LEFT JOIN order_tests ot ON ot.order_id=o.id "
            "WHERE p.full_name LIKE ? OR CAST(v.registration_number AS TEXT) LIKE ? OR p.phone LIKE ? OR ot.barcode LIKE ? "
            "ORDER BY v.id DESC LIMIT 60", (like, _scan_like(q), like, like)).fetchall()
    else:
        rows = db.execute(
            "SELECT v.id AS visit_id, v.registration_number AS reg, v.created_at, p.full_name, p.phone, "
            "(SELECT COUNT(*) FROM order_tests ot2 JOIN orders o2 ON o2.id=ot2.order_id WHERE o2.visit_id=v.id) AS n_tests, "
            "(SELECT COUNT(*) FROM order_tests ot3 JOIN orders o3 ON o3.id=ot3.order_id WHERE o3.visit_id=v.id "
            " AND ot3.status IN ('Completed','Verified')) AS n_done "
            "FROM visits v JOIN patients p ON p.id=v.patient_id ORDER BY v.id DESC LIMIT 30").fetchall()
    from flask import render_template_string
    return render_template_string(
        "{% extends 'base.html' %}{% block page_title %}باركودات المرضى{% endblock %}{% block content %}"
        "<style>.bc-t{width:100%;border-collapse:collapse}.bc-t th,.bc-t td{border:1px solid #E2E8F0;padding:7px 9px;font-size:13px;text-align:right}"
        ".bc-t th{background:#205072;color:#fff}.bc-b{display:inline-block;margin:2px;padding:5px 9px;border:1px solid #205072;border-radius:7px;"
        "text-decoration:none;color:#205072;font-size:12px;background:#fff}.bc-b:hover{background:#205072;color:#fff}</style>"
        "<div class='card'><h3 style='margin:0 0 8px'>🏷 بحث وطباعة باركودات (حتى لو النتيجة غير مكتملة)</h3>"
        "<form method='get' style='display:flex;gap:8px;margin-bottom:10px'>"
        "<input type='text' name='q' value='{{ q }}' placeholder='اسم المريض / رقم التسجيل / الهاتف / الباركود' style='flex:1;padding:9px 12px;font-size:15px' autofocus>"
        "<button class='btn' type='submit'>بحث</button></form>"
        "<table class='bc-t'><thead><tr><th>المريض</th><th>رقم التسجيل</th><th>التاريخ</th><th>التحاليل</th><th>طباعة باركود</th></tr></thead><tbody>"
        "{% for r in rows %}<tr><td><a href='/front-desk/visits/{{ r.visit_id }}/results'><b>{{ r.full_name }}</b></a></td>"
        "<td>{{ r.reg }}</td><td>{{ (r.created_at or '')[:16] }}</td><td>{{ r.n_done }} / {{ r.n_tests }} مكتمل</td><td>"
        "<a class='bc-b' target='_blank' href='{{ url_for(\"print_sample_barcodes\", visit_id=r.visit_id) }}'>🧪 أنابيب</a>"
        "<a class='bc-b' target='_blank' href='{{ url_for(\"print_visit_portal_qr\", visit_id=r.visit_id) }}'>📱 باركود البوابة (QR)</a>"
        "<a class='bc-b' target='_blank' href='{{ url_for(\"print_visit_barcode\", visit_id=r.visit_id) }}'>🏷 باركود الزيارة</a>"
        "<a class='bc-b' target='_blank' href='{{ url_for(\"print_request_label\", visit_id=r.visit_id) }}'>📄 ريكويست</a>"
        "<a class='bc-b' target='_blank' href='{{ url_for(\"labels_center\", visit_id=r.visit_id) }}'>⚙ كل الملصقات</a>"
        "</td></tr>{% else %}<tr><td colspan='5' style='text-align:center;padding:24px;color:#64748B'>لا توجد نتائج.</td></tr>{% endfor %}"
        "</tbody></table></div>{% endblock %}", rows=rows, q=q)


@app.route("/front-desk/followups")
@login_required
def followups_list():
    db = get_db()
    status_filter = request.args.get("status", "")
    query = (
        "SELECT f.id, f.status, f.notes, f.followup_date, p.full_name, p.phone, "
        "v.registration_number "
        "FROM patient_followups f JOIN patients p ON p.id = f.patient_id "
        "LEFT JOIN visits v ON v.id = f.visit_id "
    )
    params = []
    if status_filter:
        query += "WHERE f.status = ? "
        params.append(status_filter)
    query += "ORDER BY f.id DESC LIMIT 200"
    rows = db.execute(query, params).fetchall()
    return render_template("front_desk/followups.html", rows=rows, status_filter=status_filter)


@app.route("/front-desk/followups/<int:followup_id>/update", methods=["POST"])
@login_required
def followup_update(followup_id):
    db = get_db()
    status = request.form.get("status", "Pending")
    notes = request.form.get("notes", "")
    db.execute("UPDATE patient_followups SET status=?, notes=? WHERE id=?", (status, notes, followup_id))
    db.commit()
    log_action("UpdateFollowup", "patient_followup", followup_id, status)
    flash("Followup updated.")
    return redirect(url_for("followups_list"))



@app.route("/management/doctors", methods=["GET", "POST"])
@roles_required("admin")
def doctors_list():
    db = get_db()
    if request.method == "POST":
        db.execute(
            "INSERT INTO doctors (full_name, specialty, phone, email, commission_percent) "
            "VALUES (?, ?, ?, ?, ?)",
            (request.form.get("full_name", "").strip(), request.form.get("specialty"),
             request.form.get("phone"), request.form.get("email"),
             float(request.form.get("commission_percent") or 0)),
        )
        db.commit()
        flash("Doctor added.")
        return redirect(url_for("doctors_list"))
    doctors = db.execute("SELECT * FROM doctors ORDER BY full_name").fetchall()
    return render_template("management/doctors.html", doctors=doctors)


@app.route("/management/doctors/<int:doctor_id>/delete", methods=["POST"])
@roles_required("admin")
def delete_doctor(doctor_id):
    db = get_db()
    doctor = db.execute("SELECT * FROM doctors WHERE id=?", (doctor_id,)).fetchone()
    if not doctor:
        return "Not found", 404
    # لا نحذف الطبيب إذا مرتبط بزيارات أو طلبات موجودة فعلاً، حتى لا تبقى
    # سجلات يتيمة (orphaned) بالزيارات القديمة. بهذي الحالة نمنع الحذف
    # ونعرض للمستخدم عدد السجلات المرتبطة.
    linked_visits = db.execute("SELECT COUNT(*) c FROM visits WHERE doctor_id=?", (doctor_id,)).fetchone()["c"]
    linked_orders = db.execute("SELECT COUNT(*) c FROM order_tests WHERE doctor_id=?", (doctor_id,)).fetchone()["c"]
    if linked_visits or linked_orders:
        flash(f"لا يمكن حذف هذا الطبيب لأنه مرتبط بـ {linked_visits} زيارة و {linked_orders} طلب تحليل. "
              f"احذف/عدّل تلك السجلات أولاً إذا تريد حذفه فعلاً.")
        return redirect(url_for("doctors_list"))
    db.execute("DELETE FROM doctor_test_prices WHERE doctor_id=?", (doctor_id,))
    db.execute("DELETE FROM doctors WHERE id=?", (doctor_id,))
    db.commit()
    log_action("Delete", "doctor", doctor_id, doctor["full_name"])
    flash("تم حذف الطبيب.")
    return redirect(url_for("doctors_list"))


@app.route("/management/doctors/<int:doctor_id>/rates", methods=["GET", "POST"])
@roles_required("admin", "accountant")
def doctor_rates(doctor_id):
    db = get_db()
    doctor = db.execute("SELECT * FROM doctors WHERE id=?", (doctor_id,)).fetchone()
    if not doctor:
        return "Not found", 404
    if request.method == "POST":
        test_id = request.form.get("test_id")
        price = request.form.get("price", "").strip()
        if price == "":
            # حقل فارغ = رجّع هذا التحليل لسعر المختبر الافتراضي لهذا الطبيب
            db.execute("DELETE FROM doctor_test_prices WHERE doctor_id=? AND test_definition_id=?",
                       (doctor_id, test_id))
            flash("Price reset to the default lab rate for this test.")
        else:
            db.execute(
                "INSERT INTO doctor_test_prices (doctor_id, test_definition_id, price) VALUES (?, ?, ?) "
                "ON CONFLICT(doctor_id, test_definition_id) DO UPDATE SET price=excluded.price",
                (doctor_id, test_id, float(price)),
            )
            flash("Doctor's price updated.")
        db.commit()
        return redirect(url_for("doctor_rates", doctor_id=doctor_id))

    tests = db.execute("SELECT * FROM test_definitions WHERE is_active=1 ORDER BY department, name").fetchall()
    overrides = {
        row["test_definition_id"]: row["price"]
        for row in db.execute(
            "SELECT test_definition_id, price FROM doctor_test_prices WHERE doctor_id=?", (doctor_id,)
        ).fetchall()
    }
    return render_template("management/doctor_rates.html", doctor=doctor, tests=tests, overrides=overrides)


@app.route("/management/doctors/<int:doctor_id>/statement")
@roles_required("admin")
def doctor_statement(doctor_id):
    db = get_db()
    doctor = db.execute("SELECT * FROM doctors WHERE id=?", (doctor_id,)).fetchone()
    month = request.args.get("month", datetime.now().strftime("%Y-%m"))
    rows = db.execute(
        "SELECT ot.id, td.name as test_name, COALESCE(ot.price, td.price) as price, "
        "p.full_name as patient_name, ot.created_at "
        "FROM order_tests ot JOIN test_definitions td ON td.id=ot.test_definition_id "
        "JOIN orders o ON o.id=ot.order_id JOIN visits v ON v.id=o.visit_id "
        "JOIN patients p ON p.id=v.patient_id "
        "WHERE ot.doctor_id=? AND substr(ot.created_at,1,7)=? ORDER BY ot.created_at",
        (doctor_id, month),
    ).fetchall()
    total = sum((r["price"] or 0) for r in rows)
    commission_due = total * ((doctor["commission_percent"] or 0) / 100)
    return render_template("management/doctor_statement.html", doctor=doctor, rows=rows, month=month,
                            total=total, commission_due=commission_due)



@app.route("/management/examining-doctor-rates")
@roles_required("admin", "accountant")
def examining_doctor_rates_list():
    db = get_db()
    names = get_examining_doctors(db)
    rates_map = get_examining_rates_map(db)
    eligible_count = len(get_examining_tests(db))
    doctors_summary = [
        {"name": n, "configured_count": len(rates_map.get(n, {}))} for n in names
    ]
    return render_template("management/examining_doctor_rates_list.html",
                            doctors_summary=doctors_summary, eligible_count=eligible_count)


@app.route("/management/examining-doctor-rates/<doctor_name>", methods=["GET", "POST"])
@roles_required("admin", "accountant")
def examining_doctor_rates(doctor_name):
    db = get_db()
    if doctor_name not in get_examining_doctors(db):
        return "Not found", 404
    if request.method == "POST":
        test_id = request.form.get("test_id")
        rate = request.form.get("rate", "").strip()
        set_examining_doctor_rate(db, doctor_name, int(test_id), float(rate or 0))
        flash("تم تحديث أجر الدكتور الفاحص لهذا الفحص.")
        return redirect(url_for("examining_doctor_rates", doctor_name=doctor_name))

    tests = get_examining_tests(db)
    rates = get_examining_rates_map(db).get(doctor_name, {})
    return render_template("management/examining_doctor_rates.html", doctor_name=doctor_name,
                            tests=tests, rates=rates)


@app.route("/management/examining-doctor-rates/<doctor_name>/statement")
@roles_required("admin", "accountant")
def examining_doctor_statement(doctor_name):
    db = get_db()
    month = request.args.get("month", datetime.now().strftime("%Y-%m"))
    rows = db.execute(
        "SELECT v.registration_number, v.examining_doctor_fee, v.created_at, p.full_name "
        "FROM visits v JOIN patients p ON p.id = v.patient_id "
        "WHERE v.examining_doctor=? AND substr(v.created_at,1,7)=? AND v.examining_doctor_fee > 0 "
        "ORDER BY v.created_at",
        (doctor_name, month),
    ).fetchall()
    total = sum((r["examining_doctor_fee"] or 0) for r in rows)
    return render_template("management/examining_doctor_statement.html", doctor_name=doctor_name,
                            rows=rows, month=month, total=total)


@app.route("/management/referral-labs", methods=["GET", "POST"])
@roles_required("admin")
def referral_labs_list():
    db = get_db()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        phone = request.form.get("phone", "").strip()
        if not name:
            flash("اسم المختبر إلزامي.")
            return redirect(url_for("referral_labs_list"))
        exists = db.execute(
            "SELECT id FROM referral_centers WHERE LOWER(TRIM(name))=LOWER(?)", (name,)
        ).fetchone()
        if exists:
            flash("هذا المختبر مضاف أصلاً.")
        else:
            db.execute("INSERT INTO referral_centers (name, type, phone) VALUES (?, 'Lab', ?)",
                       (name, phone or None))
            db.commit()
            flash("تمت إضافة المختبر.")
        return redirect(url_for("referral_labs_list"))

    labs = db.execute(
        "SELECT * FROM referral_centers WHERE name != 'Walk-in' ORDER BY name"
    ).fetchall()
    return render_template("management/referral_labs.html", labs=labs)


@app.route("/management/referral-labs/<int:center_id>/phone", methods=["POST"])
@roles_required("admin")
def referral_lab_update_phone(center_id):
    db = get_db()
    phone = request.form.get("phone", "").strip()
    db.execute("UPDATE referral_centers SET phone=? WHERE id=?", (phone or None, center_id))
    db.commit()
    flash("تم تحديث رقم واتساب المختبر.")
    return redirect(url_for("referral_labs_list"))


def _referral_lab_statement_data(db, center_id, month):
    """يرجّع (lab, rows, by_day, by_test, total) لكشف حساب مختبر مُرسِل معيّن
    عن شهر معيّن — كل تحليل بكل نموذج وارد منه بهذا الشهر، مجمّع يوميًا
    (لمتابعة الحساب أول بأول) ومجمّع حسب نوع التحليل (لملخص نهاية الشهر)."""
    lab = db.execute("SELECT * FROM referral_centers WHERE id=?", (center_id,)).fetchone()
    if not lab:
        return None, [], [], [], 0.0

    rows = db.execute(
        "SELECT ot.id, td.name as test_name, COALESCE(ot.price, td.price) as price, COALESCE(ot.price_missing, 0) as price_missing, "
        "p.full_name as patient_name, v.registration_number, v.created_at "
        "FROM order_tests ot "
        "JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id "
        "JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id "
        "WHERE v.referral_center_id=? AND substr(v.created_at,1,7)=? "
        "ORDER BY v.created_at",
        (center_id, month),
    ).fetchall()

    day_map = {}
    test_map = {}
    total = 0.0
    rows = [dict(r) for r in rows]   # price_missing = تحليل بدون سعر عند هذا المختبر (يُحسب 0 ويُنبَّه عليه)
    for r in rows:
        price = r["price"] or 0
        total += price
        day_key = (r["created_at"] or "")[:10]
        d = day_map.setdefault(day_key, {"date": day_key, "count": 0, "subtotal": 0.0})
        d["count"] += 1
        d["subtotal"] += price
        tname = r["test_name"]
        tm = test_map.setdefault(tname, {"test_name": tname, "count": 0, "subtotal": 0.0, "missing": 0})
        tm["missing"] += 1 if r["price_missing"] else 0
        tm["count"] += 1
        tm["subtotal"] += price

    by_day = sorted(day_map.values(), key=lambda x: x["date"])
    by_test = sorted(test_map.values(), key=lambda x: -x["subtotal"])
    return lab, rows, by_day, by_test, total


@app.route("/management/referral-labs/<int:center_id>/statement")
@roles_required("admin", "accountant")
def referral_lab_statement(center_id):
    db = get_db()
    month = request.args.get("month", datetime.now().strftime("%Y-%m"))
    lab, rows, by_day, by_test, total = _referral_lab_statement_data(db, center_id, month)
    if not lab:
        return "Not found", 404
    return render_template("management/referral_lab_statement.html", lab=lab, rows=rows,
                            by_day=by_day, by_test=by_test, total=total, month=month)


@app.route("/management/referral-labs/<int:center_id>/statement/pdf")
@roles_required("admin", "accountant")
def referral_lab_statement_pdf(center_id):
    import pdf_export

    db = get_db()
    month = request.args.get("month", datetime.now().strftime("%Y-%m"))
    lab, rows, by_day, by_test, total = _referral_lab_statement_data(db, center_id, month)
    if not lab:
        return "Not found", 404
    html_content = render_template("management/print_referral_lab_statement.html", lab=lab,
                                    by_day=by_day, by_test=by_test, total=total, month=month)
    pdf_path = pdf_export.make_temp_pdf_path(f"reflab{center_id}_{month}")
    try:
        pdf_export.html_to_pdf(html_content, request.url_root, pdf_path)
    except Exception as exc:
        flash(f"❌ تعذّر توليد ملف PDF لكشف الحساب: {exc}")
        return redirect(url_for("referral_lab_statement", center_id=center_id, month=month))
    log_action("PDF", "referral_center", center_id, f"statement {month}")
    safe_name = re.sub(r"[^\w\-]+", "_", lab["name"])
    return send_file(pdf_path, as_attachment=True, download_name=f"{safe_name}_{month}.pdf")


@app.route("/management/referral-labs/<int:center_id>/statement/whatsapp", methods=["POST"])
@roles_required("admin", "accountant")
def referral_lab_statement_whatsapp(center_id):
    import pdf_export

    db = get_db()
    month = request.args.get("month", datetime.now().strftime("%Y-%m"))
    lab, rows, by_day, by_test, total = _referral_lab_statement_data(db, center_id, month)
    if not lab:
        return "Not found", 404
    if not lab["phone"]:
        flash("لا يوجد رقم واتساب مسجّل لهذا المختبر — أضِفه أولًا من نفس هذي الصفحة.")
        return redirect(url_for("referral_labs_list"))

    html_content = render_template("management/print_referral_lab_statement.html", lab=lab,
                                    by_day=by_day, by_test=by_test, total=total, month=month)
    pdf_path = pdf_export.make_temp_pdf_path(f"reflab{center_id}_{month}")
    try:
        pdf_export.html_to_pdf(html_content, request.url_root, pdf_path)
    except Exception as exc:
        flash(f"❌ تعذّر توليد ملف PDF لإرساله: {exc}")
        return redirect(url_for("referral_lab_statement", center_id=center_id, month=month))

    opened_wa, _ = _open_whatsapp_with_pdf(
        lab["phone"], pdf_path, get_setting(db, "whatsapp_country_code", "964")
    )
    if opened_wa:
        flash(f"📎 جهّزنا كشف حساب {month} وفتحنا واتساب على رقم {lab['name']} — اسحب الملف من نافذة المجلد وأرسله يدويًا.")
        log_action("WhatsAppSend", "referral_center", center_id, f"statement {month} opened")
    else:
        flash("❌ تعذّر فتح تطبيق واتساب — تأكد إنه مثبّت على هذا الجهاز.")
        log_action("WhatsAppSend", "referral_center", center_id, f"statement {month} failed")
    return redirect(url_for("referral_lab_statement", center_id=center_id, month=month))


@app.route("/front-desk/visits")
@login_required
def visits_list():
    db = get_db()
    q = request.args.get("q", "").strip()
    show_all = request.args.get("all") == "1"
    # فلترة اختيارية بطبيب مُحيل أو مختبر مُرسِل — تُستخدم من نتائج بحث
    # الرئيسية (بحث باسم طبيب/مختبر) لعرض كل زياراته مرتبة بالأحدث تاريخًا
    # ووقتًا، بغض النظر عن يوم الزيارة (بعكس الوضع الافتراضي المقتصر على
    # اليوم الحالي فقط).
    doctor_id = request.args.get("doctor_id", type=int)
    referral_center_id = request.args.get("referral_center_id", type=int)
    filter_label = None
    if doctor_id:
        row = db.execute("SELECT full_name FROM doctors WHERE id=?", (doctor_id,)).fetchone()
        if row:
            filter_label = f"زيارات الدكتور المُحيل: {row['full_name']}"
    elif referral_center_id:
        row = db.execute("SELECT name FROM referral_centers WHERE id=?", (referral_center_id,)).fetchone()
        if row:
            filter_label = f"زيارات المختبر المُرسِل: {row['name']}"

    query = (
        "SELECT v.id, v.registration_number, p.full_name, p.gender, p.age, p.phone, "
        "v.status, v.created_at, v.attending_doctor, "
        "(SELECT COALESCE(SUM(ot.price),0) FROM order_tests ot "
        " JOIN orders o ON o.id=ot.order_id WHERE o.visit_id=v.id) as total, "
        # الواصل (المبلغ المدفوع فعليًا) والإجمالي الفعلي بالفاتورة (بعد أي
        # خصم/رسوم إضافية) — يُستخدمان بالقالب لعرض "الواصل" و"الباقي" بدل
        # حقل "المدفوع" القديم. LEFT JOIN لأن بعض الزيارات القديمة قد لا
        # تملك صف فاتورة.
        "COALESCE(i.paid_amount, 0) as paid_amount, i.total_amount as invoice_total "
        "FROM visits v JOIN patients p ON p.id = v.patient_id "
        "LEFT JOIN invoices i ON i.visit_id = v.id "
    )
    params = []
    conditions = []
    if doctor_id:
        conditions.append("v.doctor_id=?")
        params.append(doctor_id)
    elif referral_center_id:
        conditions.append("v.referral_center_id=?")
        params.append(referral_center_id)
    elif q:
        conditions.append("(p.full_name LIKE ? OR p.phone LIKE ? OR v.registration_number LIKE ?)")
        params += [f"%{q}%", f"%{q}%", _scan_like(q)]   # (الاسم، الهاتف، رقم التسجيل)
    elif not show_all:
        # الصفحة تعرض زيارات اليوم الحالي فقط افتراضيًا — تُصفَّر تلقائيًا كل
        # يوم جديد. السجل الكامل لكل الأيام السابقة يبقى متوفرًا دائمًا عبر
        # صفحة "السجلات" (التقرير اليومي)، أو بالبحث بالاسم/الرقم هنا.
        today = date.today().isoformat()
        conditions.append("substr(v.created_at,1,10)=?")
        params.append(today)
    if conditions:
        query += "WHERE " + " AND ".join(conditions) + " "
    query += "ORDER BY v.created_at DESC, v.id DESC LIMIT 100"
    visits = db.execute(query, params).fetchall()
    # عمود "التحاليل": كل تحاليل الزيارة بسعر كل تحليل (بنفس سطر المريض)
    visit_tests = {}
    _vids = [v["id"] for v in visits]
    if _vids:
        _ph = ",".join("?" * len(_vids))
        for r in db.execute(
            "SELECT o.visit_id AS visit_id, td.name AS tname, ot.price AS price FROM order_tests ot "
            "JOIN orders o ON o.id = ot.order_id "
            "JOIN test_definitions td ON td.id = ot.test_definition_id "
            f"WHERE o.visit_id IN ({_ph}) ORDER BY ot.id", _vids,
        ).fetchall():
            visit_tests.setdefault(r["visit_id"], []).append({"name": r["tname"], "price": r["price"] or 0})
    return render_template("front_desk/visits.html", visits=visits, q=q, show_all=show_all,
                            filter_label=filter_label, visit_tests=visit_tests)

def _delete_visit_cascade(db, visit):
    """يحذف الزيارة بالكامل مع كل ما يتبعها (طلبات، نتائج، فواتير، مدفوعات، متابعات،
    واتساب)، ثم المريض والدكتور المُحيل إذا صاروا بلا أي زيارة/طلب آخر.
    مشتركة بين حذف الزيارة من قائمة الزيارات (delete_visit) وإلغاء الزيارة من صفحة
    \"زيارة جديدة\" (api_visit_cancel)."""
    visit_id = visit["id"]
    patient_id = visit["patient_id"]
    doctor_id = visit["doctor_id"]

    order_ids = [r["id"] for r in db.execute("SELECT id FROM orders WHERE visit_id=?", (visit_id,)).fetchall()]
    if order_ids:
        placeholders = ",".join("?" * len(order_ids))
        order_test_ids = [r["id"] for r in db.execute(
            f"SELECT id FROM order_tests WHERE order_id IN ({placeholders})", order_ids
        ).fetchall()]
        if order_test_ids:
            ot_placeholders = ",".join("?" * len(order_test_ids))
            db.execute(f"DELETE FROM result_history WHERE order_test_id IN ({ot_placeholders})", order_test_ids)
            db.execute(f"DELETE FROM results WHERE order_test_id IN ({ot_placeholders})", order_test_ids)
        db.execute(f"DELETE FROM order_tests WHERE order_id IN ({placeholders})", order_ids)
    db.execute("DELETE FROM orders WHERE visit_id=?", (visit_id,))
    db.execute(
        "DELETE FROM payments WHERE invoice_id IN (SELECT id FROM invoices WHERE visit_id=?)",
        (visit_id,),
    )
    db.execute("DELETE FROM invoices WHERE visit_id=?", (visit_id,))
    db.execute("DELETE FROM removed_order_tests WHERE visit_id=?", (visit_id,))
    db.execute("DELETE FROM patient_followups WHERE visit_id=?", (visit_id,))
    db.execute("DELETE FROM whatsapp_sends WHERE visit_id=?", (visit_id,))
    db.execute("DELETE FROM visits WHERE id=?", (visit_id,))
    db.commit()
    log_action("Delete", "visit", visit_id, visit["registration_number"])

    # المريض: يُحذف فقط إذا ما عنده أي زيارة أخرى، حتى ما نحذف مريض له سجل
    # فعلي بزيارات ثانية.
    remaining_visits = db.execute(
        "SELECT COUNT(*) c FROM visits WHERE patient_id=?", (patient_id,)
    ).fetchone()["c"]
    if remaining_visits == 0:
        patient = db.execute("SELECT * FROM patients WHERE id=?", (patient_id,)).fetchone()
        if patient:
            db.execute("DELETE FROM patient_followups WHERE patient_id=?", (patient_id,))
            db.execute("DELETE FROM patients WHERE id=?", (patient_id,))
            db.commit()
            log_action("Delete", "patient", patient_id, patient["full_name"])

    # الدكتور المرسل: يُحذف فقط إذا ما بقى مرتبط بأي زيارة أو طلب تحليل آخر.
    if doctor_id:
        linked_visits = db.execute(
            "SELECT COUNT(*) c FROM visits WHERE doctor_id=?", (doctor_id,)
        ).fetchone()["c"]
        linked_orders = db.execute(
            "SELECT COUNT(*) c FROM order_tests WHERE doctor_id=?", (doctor_id,)
        ).fetchone()["c"]
        if not linked_visits and not linked_orders:
            doctor = db.execute("SELECT * FROM doctors WHERE id=?", (doctor_id,)).fetchone()
            if doctor:
                db.execute("DELETE FROM doctor_test_prices WHERE doctor_id=?", (doctor_id,))
                db.execute("DELETE FROM doctors WHERE id=?", (doctor_id,))
                db.commit()
                log_action("Delete", "doctor", doctor_id, doctor["full_name"])


@app.route("/front-desk/visits/<int:visit_id>/delete", methods=["POST"])
@login_required
def delete_visit(visit_id):
    """حذف زيارة بالكامل مع كل ما يتبعها (طلبات، نتائج، فواتير، مدفوعات،
    متابعات، إرسالات واتساب)، ثم — إذا صار المريض بلا أي زيارة أخرى — يُحذف
    المريض نفسه فينحذف من صفحة/أيقونة المرضى، وكذلك إذا صار الدكتور المرسل
    (doctor_id) غير مرتبط بأي زيارة أو طلب تحليل آخر يُحذف هو الآخر تلقائيًا."""
    db = get_db()
    _ok, _err = _check_delete_password(db, request.form.get("delete_password"))
    if not _ok:
        flash(_err)
        return redirect(url_for("visits_list"))
    visit = db.execute("SELECT * FROM visits WHERE id=?", (visit_id,)).fetchone()
    if not visit:
        return "Not found", 404

    _delete_visit_cascade(db, visit)
    flash("تم حذف الزيارة، والمريض والدكتور المرسل أيضًا إذا صاروا بلا أي زيارات أخرى مرتبطة.")
    return redirect(url_for("visits_list"))


@app.route("/front-desk/visits/<int:visit_id>/edit", methods=["GET", "POST"])
@login_required
def visit_edit(visit_id):
    db = get_db()
    visit = db.execute(
        "SELECT v.*, p.full_name, p.gender, p.age, p.age_unit, p.phone, p.title, p.email, "
        "p.national_id, p.passport_number, p.travel_certificate_number, p.lab_card_number "
        "FROM visits v JOIN patients p ON p.id = v.patient_id WHERE v.id=?", (visit_id,),
    ).fetchone()
    if not visit:
        return "Not found", 404
    order = db.execute("SELECT * FROM orders WHERE visit_id=?", (visit_id,)).fetchone()
    invoice = db.execute("SELECT * FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()

    if request.method == "POST":
        if invoice and invoice["is_locked"]:
            flash("This invoice is locked and cannot be edited.")
            return redirect(url_for("visits_list"))

        _ve_name = request.form.get("patient_name", "").strip()
        _ve_name_en = (request.form.get("patient_name_en") or "").strip() or transliterate_arabic_name(_ve_name)
        db.execute(
            "UPDATE patients SET full_name=?, full_name_en=?, gender=?, age=?, age_unit=?, phone=?, title=?, email=?, "
            "national_id=?, passport_number=?, travel_certificate_number=?, lab_card_number=? WHERE id=?",
            (_ve_name, _ve_name_en, request.form.get("gender"),
             request.form.get("age") or None, request.form.get("age_unit") or "Years",
             request.form.get("phone"), request.form.get("title", "Mr."), request.form.get("email", "").strip(),
             request.form.get("national_id", "").strip(), request.form.get("passport_number", "").strip(),
             request.form.get("travel_certificate_number", "").strip(), request.form.get("lab_card_number", "").strip(),
             visit["patient_id"]),
        )
        referring_doctor_id = find_or_create_doctor(db, request.form.get("doctor_name", ""))
        doctor_changed = referring_doctor_id != visit["doctor_id"]
        center_changed = False   # يُحدَّد بعد معرفة المختبر المُرسِل أدناه

        examining_doctor = request.form.get("examining_doctor", "")
        # نفس منطق شاشة "زيارة جديدة" — attending_doctor يتبع examining_doctor
        # تلقائيًا الآن بعد ما صار حقلاً واحدًا بالشاشة.
        attending_doctor = examining_doctor
        referral_center_id = find_or_create_referral_center(db, request.form.get("referral_lab_name", ""))
        center_changed = (referral_center_id or None) != (visit["referral_center_id"] or None)
        # المعلومات الصحية + الزيارة المنزلية — نفس حقول شاشة "زيارة جديدة".
        weight = request.form.get("weight") or None
        height = request.form.get("height") or None
        symptoms = request.form.get("symptoms", "")
        disease = request.form.get("disease", "")
        therapy = request.form.get("therapy", "")
        is_home_visit = 1 if request.form.get("is_home_visit") == "1" else 0
        home_visit_address = request.form.get("home_visit_address", "") if is_home_visit else ""
        try:
            home_visit_fee = float(request.form.get("home_visit_fee") or 0) if is_home_visit else 0.0
        except ValueError:
            home_visit_fee = 0.0
        db.execute(
            "UPDATE visits SET doctor_id=?, referral_center_id=?, fasting=?, notes=?, examining_doctor=?, "
            "expenses=?, attending_doctor=?, weight=?, height=?, symptoms=?, disease=?, therapy=?, "
            "is_home_visit=?, home_visit_address=?, home_visit_fee=? WHERE id=?",
            (referring_doctor_id, referral_center_id, request.form.get("fasting", "Undefined"), request.form.get("notes", ""),
             examining_doctor, request.form.get("expenses") or 0, attending_doctor,
             weight, height, symptoms, disease, therapy,
             is_home_visit, home_visit_address, home_visit_fee, visit_id))

        new_test_id = request.form.get("add_test")
        if new_test_id:
            test = db.execute("SELECT * FROM test_definitions WHERE id=?", (new_test_id,)).fetchone()
            if test:
                reg = visit["registration_number"]
                barcode = f"{reg}{new_test_id.zfill(3)}"
                price = get_test_price(db, new_test_id, referring_doctor_id, referral_center_id)
                db.execute(
                    "INSERT INTO order_tests (order_id, test_definition_id, status, barcode, price, doctor_id, created_at, price_missing) "
                    "VALUES (?, ?, 'Accepted', ?, ?, ?, ?, ?)",
                    (order["id"], new_test_id, barcode, (price if price is not None else 0), referring_doctor_id,
                     datetime.now().isoformat(timespec="seconds"), 1 if price is None else 0),
                )
                # شرط الارتباط (BF -> CBC): أضف التحليل المطلوب إن لم يكن موجودًا بالزيارة
                _have = {str(r["test_definition_id"]) for r in db.execute(
                    "SELECT test_definition_id FROM order_tests WHERE order_id=?", (order["id"],)).fetchall()}
                for _rid in expand_required_tests(db, [new_test_id])[1:]:
                    if _rid not in _have:
                        _rp = get_test_price(db, _rid, referring_doctor_id, referral_center_id)
                        db.execute(
                            "INSERT INTO order_tests (order_id, test_definition_id, status, barcode, price, doctor_id, created_at, price_missing) "
                            "VALUES (?, ?, 'Accepted', ?, ?, ?, ?, ?)",
                            (order["id"], _rid, f"{reg}{_rid.zfill(3)}", (_rp if _rp is not None else 0), referring_doctor_id,
                             datetime.now().isoformat(timespec="seconds"), 1 if _rp is None else 0),
                        )

        # نعيد حساب أجر دكتور المختبر الفاحص حسب كل الفحوصات الحالية بالزيارة
        # (بعد أي حذف/إضافة) واسم الدكتور الفاحص المختار حاليًا.
        # (تحاليل "مجانية" fee_waived=1 تُستثنى تلقائيًا من هذا الحساب --
        # راجع recompute_examining_doctor_fee بـdatabase.py.)
        recompute_examining_doctor_fee(db, visit_id)

        # إذا انتغيّر الطبيب المُحيل، نعيد تسعير كل التحاليل الموجودة أصلاً
        # بالزيارة حسب جدول أسعار الطبيب الجديد (أو السعر الافتراضي إذا ماكو
        # طبيب / ماكو سعر خاص إله).
        if doctor_changed or center_changed:
            existing = db.execute(
                "SELECT id, test_definition_id, selected_param_ids FROM order_tests WHERE order_id=?", (order["id"],)
            ).fetchall()
            for row in existing:
                new_price = None
                # تحليل مطلوب جزئيًا (بارامترات مختارة فقط): سعره مجموع أسعار بارامتراته المختارة،
                # مو سعر التحليل كامل (كان إعادة التسعير تسعّره كاملاً فيزيد الإجمالي ويظهر باقي).
                _raw = (row["selected_param_ids"] or "").strip()
                if _raw:
                    try:
                        _pids = [int(x) for x in _raw.split(",") if x.strip()]
                    except ValueError:
                        _pids = []
                    if _pids:
                        _ph = ",".join("?" * len(_pids))
                        _pr = db.execute(
                            f"SELECT price FROM test_parameters WHERE id IN ({_ph}) AND test_definition_id=?",
                            (*_pids, row["test_definition_id"]),
                        ).fetchall()
                        if _pr:
                            new_price = sum((x["price"] or 0) for x in _pr)
                if new_price is None:
                    new_price = get_test_price(db, row["test_definition_id"], referring_doctor_id, referral_center_id)
                db.execute("UPDATE order_tests SET price=?, doctor_id=?, price_missing=? WHERE id=?",
                           ((new_price if new_price is not None else 0), referring_doctor_id,
                            1 if new_price is None else 0, row["id"]))

        extra_charges = float(request.form.get("extra_charges") or 0)
        discount_amount = float(request.form.get("discount_amount") or 0)
        new_total = db.execute(
            "SELECT COALESCE(SUM(ot.price),0) as total FROM order_tests ot WHERE ot.order_id=?",
            (order["id"],),
        ).fetchone()["total"]
        # أجرة الزيارة المنزلية (إن فُعِّلت) تُضاف لمجموع الفحوصات، نفس أسلوب
        # شاشة "زيارة جديدة" — منفصلة عن حقل "Extra Charges" اليدوي.
        new_total += home_visit_fee
        if invoice:
            db.execute(
                "UPDATE invoices SET total_amount=?, extra_charges=?, discount_amount=? WHERE id=?",
                (new_total + extra_charges, extra_charges, discount_amount, invoice["id"]),
            )
        db.commit()
        log_action("Update", "visit", visit_id)
        flash("Visit updated.")
        return redirect(url_for("visits_list"))

    order_tests = db.execute(
        "SELECT ot.id, ot.status, ot.test_definition_id, ot.fee_waived, ot.hidden_from_log, td.name, td.is_examining_test, "
        "COALESCE(ot.price, td.price) as price "
        "FROM order_tests ot JOIN test_definitions td ON td.id = ot.test_definition_id WHERE ot.order_id=?",
        (order["id"] if order else 0,),
    ).fetchall()
    all_tests = db.execute("SELECT * FROM test_definitions WHERE is_active=1 ORDER BY department, name").fetchall()
    current_doctor_name = ""
    if visit["doctor_id"]:
        d = db.execute("SELECT full_name FROM doctors WHERE id=?", (visit["doctor_id"],)).fetchone()
        current_doctor_name = d["full_name"] if d else ""
    current_referral_lab_name = ""
    if visit["referral_center_id"]:
        rl = db.execute("SELECT name FROM referral_centers WHERE id=?", (visit["referral_center_id"],)).fetchone()
        current_referral_lab_name = rl["name"] if rl else ""
    doctors, doctor_prices, doctor_name_to_id = doctor_pricing_context(db)
    test_default_prices = {str(tst["id"]): tst["price"] for tst in all_tests}
    last_removed_row = db.execute(
        "SELECT rot.*, td.name as test_name FROM removed_order_tests rot "
        "JOIN test_definitions td ON td.id = rot.test_definition_id "
        "WHERE rot.visit_id=? AND rot.restored=0 ORDER BY rot.id DESC LIMIT 1",
        (visit_id,),
    ).fetchone()
    last_removed = dict(last_removed_row) if last_removed_row else None

    examining_test_ids = [row["id"] for row in get_examining_tests(db)]
    referral_labs = db.execute(
        "SELECT * FROM referral_centers WHERE name != 'Walk-in' ORDER BY name"
    ).fetchall()
    return render_template("front_desk/visit_edit.html", visit=visit, order_tests=order_tests,
                            all_tests=all_tests, invoice=invoice, examining_doctors=get_examining_doctors(db),
                            doctors=doctors, doctor_prices=doctor_prices, doctor_name_to_id=doctor_name_to_id,
                            current_doctor_name=current_doctor_name,
                            current_referral_lab_name=current_referral_lab_name,
                            test_default_prices=test_default_prices,
                            last_removed=last_removed, examining_test_ids=examining_test_ids,
                            examining_rates=get_examining_rates_map(db), referral_labs=referral_labs,
                            fee_waiver_configured=bool(get_setting(db, "fee_waiver_password_hash", "")))


@app.route("/front-desk/visits/<int:visit_id>/order-tests/<int:order_test_id>/price", methods=["POST"])
@login_required
def visit_update_test_price(visit_id, order_test_id):
    db = get_db()
    invoice = db.execute("SELECT * FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()
    if invoice and invoice["is_locked"]:
        flash("This invoice is locked and cannot be edited.")
        return redirect(url_for("visit_edit", visit_id=visit_id))
    try:
        new_price = float(request.form.get(f"price_{order_test_id}"))
    except (TypeError, ValueError):
        flash("Invalid price.")
        return redirect(url_for("visit_edit", visit_id=visit_id))
    order_test = db.execute("SELECT * FROM order_tests WHERE id=?", (order_test_id,)).fetchone()
    if not order_test:
        return "Not found", 404
    db.execute("UPDATE order_tests SET price=? WHERE id=?", (new_price, order_test_id))
    if invoice:
        order = db.execute("SELECT * FROM orders WHERE visit_id=?", (visit_id,)).fetchone()
        new_total = db.execute(
            "SELECT COALESCE(SUM(ot.price),0) as total FROM order_tests ot WHERE ot.order_id=?",
            (order["id"],),
        ).fetchone()["total"]
        db.execute(
            "UPDATE invoices SET total_amount=? WHERE id=?",
            (new_total + (invoice["extra_charges"] or 0), invoice["id"]),
        )
    db.commit()
    log_action("Update", "order_test_price", order_test_id)
    flash("Price updated.")
    return redirect(url_for("visit_edit", visit_id=visit_id))


@app.route("/front-desk/visits/<int:visit_id>/remove-test/<int:order_test_id>", methods=["POST"])
@login_required
def visit_remove_test(visit_id, order_test_id):
    db = get_db()
    invoice = db.execute("SELECT * FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()
    if invoice and invoice["is_locked"]:
        flash("This invoice is locked.")
        return redirect(url_for("visit_edit", visit_id=visit_id))

    ot_row = db.execute("SELECT * FROM order_tests WHERE id=?", (order_test_id,)).fetchone()
    if not ot_row:
        return redirect(url_for("visit_edit", visit_id=visit_id))
    # المطلوب 2: حذف تحليل مكتمل (نتيجته جاهزة ومحفوظة) محمي بنفس كلمة
    # مرور حماية النتائج المكتملة أعلاه.
    if ot_row["status"] in ("Completed", "Verified"):
        ok, err = _check_completed_result_gate(db, request.form)
        if not ok:
            flash(err)
            return redirect(url_for("visit_edit", visit_id=visit_id))
    result_rows = db.execute("SELECT * FROM results WHERE order_test_id=?", (order_test_id,)).fetchall()
    snapshot = {
        "order_test": dict(ot_row),
        "results": [dict(r) for r in result_rows],
    }
    now = datetime.now().isoformat(timespec="seconds")
    db.execute(
        "INSERT INTO removed_order_tests (visit_id, order_id, test_definition_id, snapshot, removed_by, removed_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (visit_id, ot_row["order_id"], ot_row["test_definition_id"], json.dumps(snapshot), session.get("user_id"), now),
    )

    db.execute("DELETE FROM results WHERE order_test_id=?", (order_test_id,))
    db.execute("DELETE FROM order_tests WHERE id=?", (order_test_id,))
    order = db.execute("SELECT * FROM orders WHERE visit_id=?", (visit_id,)).fetchone()
    new_total = db.execute(
        "SELECT COALESCE(SUM(ot.price),0) as total FROM order_tests ot WHERE ot.order_id=?",
        (order["id"],),
    ).fetchone()["total"]
    if invoice:
        db.execute("UPDATE invoices SET total_amount=? WHERE id=?",
                   (new_total + (invoice["extra_charges"] or 0), invoice["id"]))
    db.commit()
    log_action("RemoveTest", "order_test", order_test_id)
    flash("Test removed from visit. You can undo this from the visit edit page.")
    return redirect(url_for("visit_edit", visit_id=visit_id))


@app.route("/front-desk/visits/<int:visit_id>/undo-remove-test", methods=["POST"])
@login_required
def visit_undo_remove_test(visit_id):
    db = get_db()
    invoice = db.execute("SELECT * FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()
    if invoice and invoice["is_locked"]:
        flash("This invoice is locked.")
        return redirect(url_for("visit_edit", visit_id=visit_id))

    last_removed = db.execute(
        "SELECT * FROM removed_order_tests WHERE visit_id=? AND restored=0 ORDER BY id DESC LIMIT 1",
        (visit_id,),
    ).fetchone()
    if not last_removed:
        flash("Nothing to undo.")
        return redirect(url_for("visit_edit", visit_id=visit_id))

    snapshot = json.loads(last_removed["snapshot"])
    ot = snapshot["order_test"]
    cur = db.execute(
        "INSERT INTO order_tests (order_id, test_definition_id, status, barcode, notes, doctor_id, "
        "collected_at, accessioned_at, price, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (ot["order_id"], ot["test_definition_id"], ot["status"], ot["barcode"], ot["notes"],
         ot["doctor_id"], ot["collected_at"], ot["accessioned_at"], ot.get("price"), ot["created_at"]),
    )
    new_order_test_id = cur.lastrowid
    for r in snapshot["results"]:
        db.execute(
            "INSERT INTO results (order_test_id, test_parameter_id, value_numeric, value_text, flag, "
            "entered_by, entered_at, verified_by, verified_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (new_order_test_id, r["test_parameter_id"], r["value_numeric"], r["value_text"], r["flag"],
             r["entered_by"], r["entered_at"], r["verified_by"], r["verified_at"]),
        )
    db.execute("UPDATE removed_order_tests SET restored=1 WHERE id=?", (last_removed["id"],))

    order = db.execute("SELECT * FROM orders WHERE visit_id=?", (visit_id,)).fetchone()
    new_total = db.execute(
        "SELECT COALESCE(SUM(ot.price),0) as total FROM order_tests ot WHERE ot.order_id=?",
        (order["id"],),
    ).fetchone()["total"]
    if invoice:
        db.execute("UPDATE invoices SET total_amount=? WHERE id=?",
                   (new_total + (invoice["extra_charges"] or 0), invoice["id"]))
    db.commit()
    log_action("UndoRemoveTest", "order_test", new_order_test_id)
    flash("Test restored.")
    return redirect(url_for("visit_edit", visit_id=visit_id))



@app.route("/barcode/<code>.png")
def barcode_image(code):
    img = generate_code39(code)
    buf = BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")


def _visit_barcode_context(db, visit_id):
    """Visit + its ordered tests, used to build the visit barcode label
    (both the print page and the Code128/QR image endpoints)."""
    visit = db.execute(
        "SELECT v.*, p.full_name, p.age, p.age_unit, p.gender FROM visits v "
        "JOIN patients p ON p.id = v.patient_id WHERE v.id=?",
        (visit_id,),
    ).fetchone()
    if not visit:
        return None, None, None
    tests = db.execute(
        "SELECT td.name, td.name_ar, td.code, td.short_name FROM order_tests ot "
        "JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id WHERE o.visit_id=? "
        "AND COALESCE(ot.status,'') NOT IN ('Cancelled','Canceled','Rejected') ORDER BY ot.id",
        (visit_id,),
    ).fetchall()
    # ساعة السحب: أوّل collected_at مسجّل بين تحاليل الزيارة، وإن ما كانت
    # العيّنة مسحوبة بعد نرجع لوقت إنشاء الزيارة كبديل.
    draw_row = db.execute(
        "SELECT MIN(ot.collected_at) as draw_time FROM order_tests ot "
        "JOIN orders o ON o.id = ot.order_id WHERE o.visit_id=? AND ot.collected_at IS NOT NULL",
        (visit_id,),
    ).fetchone()
    draw_time = (draw_row["draw_time"] if draw_row else None) or visit["created_at"]
    return visit, tests, draw_time


@app.route("/front-desk/visits/<int:visit_id>/barcode/code128.png")
@login_required
def visit_barcode_code128(visit_id):
    # Code128 (English/Latin only) carries the registration number plus the
    # English test codes -- this is what lab scanners/instruments read.
    db = get_db()
    visit, tests, draw_time = _visit_barcode_context(db, visit_id)
    if not visit:
        return "Not found", 404
    test_codes = [row["code"] for row in tests if row["code"]]
    reg = visit["registration_number"]
    payload = f"{reg}|{','.join(test_codes)}" if test_codes else str(reg)
    img = generate_code128(payload, caption=str(reg))
    buf = BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")


@app.route("/front-desk/visits/<int:visit_id>/barcode/qr.png")
@login_required
def visit_barcode_qr(visit_id):
    # QR carries the Arabic content (Code128 cannot represent it): the
    # patient's full (triple) name plus the Arabic names of their tests.
    db = get_db()
    visit, tests, draw_time = _visit_barcode_context(db, visit_id)
    if not visit:
        return "Not found", 404
    test_names_ar = [(row["name_ar"] or row["name"]) for row in tests]
    lines = [visit["full_name"]]
    if test_names_ar:
        lines.append("، ".join(test_names_ar))
    img = generate_qr("\n".join(lines))
    buf = BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")



# ستايلات ملصقات الباركود + إظهار/إخفاء اسم المختبر (اختياري). كلها تُحفظ بالإعدادات
# وتتغير من شريط الإعدادات أعلى صفحتي الباركود عبر /api/settings/barcode-print-prefs.
# اسم المختبر نفسه يُقرأ دائمًا من إعدادات البرنامج (app_name_ar، وإلا app_name) —
# فأي تغيير له من الإعدادات ينعكس مباشرة على الملصق عند تفعيل خيار الإظهار.
BARCODE_STYLES = ("classic", "compact", "bold", "banner", "minimal")


def _barcode_show_lab_name(db):
    return get_setting(db, "barcode_show_lab_name", "1") != "0"


def _barcode_style(db, key):
    v = get_setting(db, key, "classic")
    return v if v in BARCODE_STYLES else "classic"



# ====================== مصمّم الملصقات (أسطر قابلة للتحكم) ======================
# كل ملصق (tube = ملصق الأنابيب، request = ملصق ورقة طلب المريض) له تصميم محفوظ
# بالإعدادات كـJSON: القياس (مم)، الأسطر بالترتيب (كل سطر: الحقل + حجم الخط + غامق +
# محاذاة + هل يُسمح بلفّ السطر)، وإعدادات الباركود وعدد النسخ. الصفحة تنبّه لو أي سطر
# تجاوز عرض الملصق أو المحتوى تجاوز ارتفاعه.
LABEL_FIELD_TITLES = {
    "lab_name": "اسم المختبر", "patient_name": "اسم المريض", "age_gender": "العمر والجنس",
    "datetime": "التاريخ والوقت", "date": "التاريخ فقط", "time": "الوقت فقط",
    "reg_no": "رقم التسجيل", "sample_no": "رقم العينة (Sample No.)", "visit_id": "رقم الزيارة الداخلي",
    "sample_type": "نوع العينة / القسم", "tests": "أسماء التحاليل",
    "tests_codes": "أكواد التحاليل", "custom": "نص ثابت (تكتبه أنت)",
    "order_no": "رقم الطلب (التسجيل بدون #)", "dept_age_gender": "القسم/الجهاز + الجنس-العمر (Abbot - Female-18Y)",
    "ready_by": "وقت الجاهزية (Ready by)", "paid": "الواصل (Paid)", "balance": "الباقي (Balance)",
    "month_no": "التسلسل الشهري للعينة", "day_month_no": "رقم عينة اليوم + التسلسل الشهري (002 / M17)",
}
LABEL_SCAN_TITLES = {
    "reg_no": "رقم التسجيل", "sample_no": "رقم العينة", "patient_name": "اسم المريض",
    "age_gender": "العمر والجنس", "datetime": "التاريخ والوقت", "lab_name": "اسم المختبر",
    "tests": "أسماء التحاليل", "tests_codes": "أكواد التحاليل",
}
LABEL_FIELDS_BY_KIND = {
    "tube": ("lab_name", "patient_name", "age_gender", "datetime", "date", "time", "reg_no",
             "sample_no", "sample_type", "tests", "tests_codes", "custom", "order_no", "dept_age_gender",
             "month_no", "day_month_no"),
    "request": ("lab_name", "patient_name", "age_gender", "datetime", "date", "time", "reg_no",
                "sample_no", "visit_id", "tests", "tests_codes", "custom", "order_no", "ready_by", "paid", "balance",
                "month_no", "day_month_no"),
}
_DEFAULT_LABEL_LAYOUTS = {
    "tube": {
        "w": 0, "h": 0, "roll": False, "tmode": "full", "d": 0,
        "lines": [{"f": "lab_name"}, {"f": "patient_name"}, {"f": "datetime"},
                  {"f": "sample_type"}, {"f": "tests", "w": 1}],
    },
    "request": {
        "w": 60, "h": 40, "roll": True, "copies": 1, "tmode": "full",
        # الافتراضي (حسب طلب المختبر): اسم المريض + تاريخ ووقت سحب العينة فقط.
        # أي سطر إضافي (نص حر أو حقل ثاني) يُضاف من مصمم الملصق أعلى صفحة الطباعة.
        "lines": [{"f": "patient_name", "s": 11, "b": 1, "a": "center"}, {"f": "datetime", "s": 8, "a": "center"}],
        "bc": {"type": "code128", "pos": "bottom", "h": 16},
        "scan": ["reg_no", "patient_name", "datetime"],
    },
}



# قوالب جاهزة لملصق الأنبوب (T1) وملصق الطلب (R1) — تُختار من مصمم الملصق (⚙) وتبقى قابلة للتعديل بالكامل.
LABEL_PRESETS = {
    "tube": {
        "T1": {"title": "T1 — اسم + جهاز/جنس/عمر + وقت (سطر فاصل) + التحاليل + باركود + رقم/نوع العينة",
               "w": 50, "h": 25, "roll": True, "tmode": "short",
               "lines": [{"f": "patient_name", "s": 9, "b": 1, "a": "center"},
                         {"f": "dept_age_gender", "f2": "datetime", "s": 6.5, "r": 1},
                         {"f": "tests", "s": 6.5, "a": "center", "w": 1},
                         {"f": "day_month_no", "f2": "sample_type", "s": 7, "p": "after"}]},
        "T2": {"title": "T2 — أنبوب 16 مم: اسم + وقت + التحاليل + باركود + رقم اليوم/الشهري ونوع العينة",
               "w": 44, "h": 30, "d": 16, "roll": True, "tmode": "short",
               "lines": [{"f": "patient_name", "s": 9, "b": 1, "a": "center"},
                         {"f": "datetime", "s": 6.5, "a": "center"},
                         {"f": "tests", "s": 6.5, "a": "center", "w": 1},
                         {"f": "day_month_no", "f2": "sample_type", "s": 7.5, "b": 1, "p": "after"}]},
    },
    "request": {
        "R1": {"title": "R1 — اسم + Ready by/التاريخ + Paid/Balance + رقم الطلب + باركود",
               "w": 60, "h": 30, "roll": True, "tmode": "full", "copies": 1,
               "lines": [{"f": "patient_name", "s": 10, "b": 1, "a": "center"},
                         {"f": "ready_by", "f2": "datetime", "s": 8},
                         {"f": "paid", "f2": "balance", "s": 8},
                         {"f": "order_no", "s": 9, "a": "center"}],
               "bc": {"type": "code128", "pos": "bottom", "h": 10}},
    },
}
app.jinja_env.globals["LABEL_PRESETS_JSON"] = json.dumps(LABEL_PRESETS, ensure_ascii=False).replace("</", "<\\/")

def _lnum(v, lo, hi, default=None):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return default
    return max(lo, min(hi, x))


def _sanitize_label_layout(kind, raw):
    import copy as _copy
    d = _copy.deepcopy(_DEFAULT_LABEL_LAYOUTS[kind])
    if not isinstance(raw, dict):
        return d
    d["w"] = _lnum(raw.get("w"), 0, 300, d["w"])
    d["h"] = _lnum(raw.get("h"), 0, 300, d["h"])
    if kind == "request":
        d["w"] = d["w"] or 60
        d["h"] = d["h"] or 40
    if kind == "tube":
        # قطر الأنبوب (مم): عرض الملصق ≤ المحيط − 6 مم حتى ما تتقابل حافتا الملصق حول الأنبوب.
        # 13 مم → 34 مم | 16 مم → 44 مم. العرض يُقصّ تلقائيًا هنا حتى لو الواجهة تجاوزته.
        d["d"] = _lnum(raw.get("d"), 0, 40, 0) or 0
        if d["d"]:
            import math as _math
            _maxw = round(_math.pi * d["d"] - 6, 1)
            if not d["w"] or d["w"] > _maxw:
                d["w"] = _maxw
    d["roll"] = bool(raw.get("roll", d["roll"]))
    d["tmode"] = raw.get("tmode") if raw.get("tmode") in ("full", "short", "none") else d["tmode"]
    allowed = LABEL_FIELDS_BY_KIND[kind]
    lines = []
    for ln in (raw.get("lines") or [])[:10]:
        if not isinstance(ln, dict) or ln.get("f") not in allowed:
            continue
        item = {"f": ln["f"]}
        sz = _lnum(ln.get("s"), 3, 40)
        if sz:
            item["s"] = sz
        if ln.get("b") in (0, 1, True, False):
            item["b"] = 1 if ln.get("b") else 0
        if ln.get("a") in ("left", "center", "right"):
            item["a"] = ln["a"]
        if ln.get("w"):
            item["w"] = 1
        if ln["f"] == "custom":
            item["t"] = str(ln.get("t") or "")[:80]
        # v61: سطر بحقلين (يسار + يمين بنفس السطر)، خط فاصل تحت السطر، وسطر يُطبع بعد الباركود (ملصق الأنبوب)
        if ln.get("f2") in allowed:
            item["f2"] = ln["f2"]
            if ln["f2"] == "custom":
                item["t2"] = str(ln.get("t2") or "")[:80]
        if ln.get("r") in (1, True):
            item["r"] = 1
        if kind == "tube" and ln.get("p") == "after":
            item["p"] = "after"
        lines.append(item)
    if lines:
        d["lines"] = lines
    elif isinstance(raw.get("lines"), list):
        d["lines"] = []  # المستخدم حذف كل الأسطر عمدًا
    if kind == "request":
        bc = raw.get("bc") or {}
        d["bc"] = {
            "type": bc.get("type") if bc.get("type") in ("qr", "code128") else "qr",
            "pos": bc.get("pos") if bc.get("pos") in ("bottom", "side") else "side",
            "h": _lnum(bc.get("h"), 6, 60, 18),
        }
        d["copies"] = int(_lnum(raw.get("copies"), 1, 50, 1))
        if isinstance(raw.get("scan"), list):
            d["scan"] = [k for k in raw["scan"] if k in LABEL_SCAN_TITLES]
    return d


def _get_label_layout(db, kind):
    try:
        raw = json.loads(get_setting(db, f"label_layout_{kind}", "") or "null")
    except ValueError:
        raw = None
    return _sanitize_label_layout(kind, raw)


@app.route("/management/ui-style")
@roles_required("admin")
def ui_style_page():
    return render_template("management/ui_style.html")


@app.route("/api/settings/ui-3d", methods=["POST"])
@roles_required("admin")
def api_set_ui_3d():
    """تطبيق/إلغاء مظهر 3D لكل المستخدمين (المعاينة المحلية لا تحتاج هذا الطلب)."""
    on = request.form.get("on") == "1"
    db = get_db()
    set_setting(db, "ui_3d", "1" if on else "0")
    db.commit()
    return jsonify({"ok": True, "on": on})


@app.route("/api/settings/label-layout/<kind>", methods=["POST"])
@login_required
def api_set_label_layout(kind):
    if kind not in _DEFAULT_LABEL_LAYOUTS:
        return jsonify({"ok": False, "error": "نوع ملصق غير معروف"}), 404
    raw = request.get_json(silent=True)
    if not isinstance(raw, dict):
        return jsonify({"ok": False, "error": "بيانات غير صالحة"}), 400
    layout = _sanitize_label_layout(kind, raw)
    db = get_db()
    set_setting(db, f"label_layout_{kind}", json.dumps(layout, ensure_ascii=False))
    db.commit()
    return jsonify({"ok": True, "layout": layout})


@app.route("/api/settings/label-layout/<kind>/reset", methods=["POST"])
@login_required
def api_reset_label_layout(kind):
    if kind not in _DEFAULT_LABEL_LAYOUTS:
        return jsonify({"ok": False, "error": "نوع ملصق غير معروف"}), 404
    db = get_db()
    set_setting(db, f"label_layout_{kind}", "")
    db.commit()
    return jsonify({"ok": True, "layout": _sanitize_label_layout(kind, None)})


def _fmt_dt(v):
    v = str(v or "").replace("T", " ")
    return v[:16]


def _label_money(db, visit):
    """حقول الجاهزية/الواصل/الباقي لملصق الطلب (نص جاهز بعنوانه): Ready by / Paid / Balance."""
    out = {"ready_by": "Ready by :", "paid": "Paid : 0.000", "balance": "Balance : 0.000"}
    try:
        vid = visit["id"]
        bal = _visit_balance(db, vid)
        out["paid"] = "Paid : %.3f" % bal["paid"]
        out["balance"] = "Balance : %.3f" % bal["remaining"]
        row = db.execute("SELECT expected_ready_at, expected_ready_text FROM visits WHERE id=?", (vid,)).fetchone()
        if row:
            txt = (row["expected_ready_text"] or "").strip() or _fmt_dt(row["expected_ready_at"] or "")
            if txt:
                out["ready_by"] = "Ready by : " + txt
    except Exception:
        pass
    return out


def _visit_month_no(visit_id, created_at):
    """التسلسل الشهري للزيارة = ترتيبها بين زيارات نفس الشهر (حسب تاريخ الإنشاء). يُحسب ولا يُخزَّن."""
    try:
        ym = (created_at or "")[:7]
        if not ym:
            return ""
        row = get_db().execute(
            "SELECT COUNT(*) AS c FROM visits WHERE substr(created_at,1,7)=? AND id<=?", (ym, visit_id)).fetchone()
        return str(row["c"]) if row and row["c"] else ""
    except Exception:  # noqa: BLE001
        return ""


# بحث بالتسلسل: m17 / M17 / ش17 = التسلسل الشهري 17 لهذا الشهر؛ رقم قصير (1-3 خانات) أو d2 / ي2 = رقم عينة اليوم.
# يُستخدم كشرط إضافي (OR) بجانب البحث بالاسم/رقم التسجيل/الباركود، لا يغيّر شي منها.
def _visit_seq_clause(q, vcol="v"):
    q = (q or "").strip()
    m = re.fullmatch(r"(?:m|M|ش|شهري)\s*[-:]?\s*(\d{1,5})", q)
    if m:
        return (f"((SELECT COUNT(*) FROM visits vq WHERE substr(vq.created_at,1,7)=substr({vcol}.created_at,1,7) "
                f"AND vq.id<={vcol}.id)=? AND substr({vcol}.created_at,1,7)=?)",
                [int(m.group(1)), datetime.now().strftime("%Y-%m")])
    m = re.fullmatch(r"(?:d|D|ي|يومي)\s*[-:]?\s*(\d{1,3})|(\d{1,3})", q)
    if m:
        n = int(m.group(1) or m.group(2))
        return (f"(CAST({vcol}.sample_no AS INTEGER)=? AND substr({vcol}.created_at,1,10)=?)",
                [n, datetime.now().strftime("%Y-%m-%d")])
    return None


def _label_visit_fields(visit, lab_name, tests=None, draw_time=None, money=None):
    """الحقول المشتركة لأي ملصق (قيم نصية جاهزة)."""
    keys = visit.keys()
    age = visit["age"] if "age" in keys and visit["age"] else ""
    unit = (visit["age_unit"] if "age_unit" in keys else "") or ""
    gender = (visit["gender"] if "gender" in keys else "") or ""
    age_gender = (f"{age} {unit}".strip() if age else "")
    if gender:
        age_gender = (age_gender + " · " if age_gender else "") + gender
    dt = _fmt_dt(draw_time or visit["created_at"])
    out = {
        "lab_name": lab_name or "",
        "patient_name": visit["full_name"] if "full_name" in keys else "",
        "age_gender": age_gender,
        "datetime": dt, "date": dt[:10], "time": dt[11:16],
        "reg_no": f"#{visit['registration_number']}",
        "sample_no": (str(visit["sample_no"]) if "sample_no" in keys and visit["sample_no"] else ""),
        "visit_id": str(visit["id"]),
        "order_no": str(visit["registration_number"]) if "registration_number" in keys else "",
    }
    out["month_no"] = _visit_month_no(visit["id"], visit["created_at"] if "created_at" in keys else "")
    out["day_month_no"] = " / ".join(x for x in [out["sample_no"], f"M{out['month_no']}" if out["month_no"] else ""] if x)
    _ab = {"years": "Y", "year": "Y", "months": "M", "month": "M", "days": "D", "day": "D", "weeks": "W"}.get(unit.strip().lower(), unit[:1].upper())
    out["ga_short"] = "-".join(x for x in [gender, f"{age}{_ab}" if age else ""] if x)
    out["dept_age_gender"] = out["ga_short"]
    out.update(money or {})
    if tests is not None:
        out["tests_full"] = [t["name"] for t in tests]
        out["tests_short"] = [(t["short_name"] or t["name"]) for t in tests]
        out["tests_codes"] = ", ".join(t["code"] for t in tests if t["code"])
    return out


def _request_scan_payload(visit, tests, draw_time, lab_name, scan, tmode):
    """النص الذي يطلعه القارئ عند مسح QR ملصق الطلب (سطر لكل حقل مختار)."""
    f = _label_visit_fields(visit, lab_name, tests, draw_time)
    names = {"full": f["tests_full"], "short": f["tests_short"]}.get(
        tmode, [t["code"] or t["name"] for t in tests])
    lines = []
    for k in scan:
        if k == "reg_no":
            lines.append(f"Reg: {visit['registration_number']}")
        elif k == "sample_no" and f["sample_no"]:
            lines.append(f"Sample: {f['sample_no']}")
        elif k == "patient_name":
            lines.append(f"Name: {f['patient_name']}")
        elif k == "age_gender" and f["age_gender"]:
            lines.append(f"Age: {f['age_gender']}")
        elif k == "datetime":
            lines.append(f"Date: {f['datetime']}")
        elif k == "lab_name" and f["lab_name"]:
            lines.append(f"Lab: {f['lab_name']}")
        elif k == "tests":
            lines.append("Tests: " + ", ".join(names))
        elif k == "tests_codes" and f["tests_codes"]:
            lines.append("Codes: " + f["tests_codes"])
    return "\n".join(lines)


@app.route("/front-desk/visits/<int:visit_id>/barcode/request.png")
@login_required
def visit_request_qr(visit_id):
    db = get_db()
    visit, tests, draw_time = _visit_barcode_context(db, visit_id)
    if not visit:
        return "Not found", 404
    scan = [k for k in (request.args.get("scan") or "").split(",") if k in LABEL_SCAN_TITLES]
    tmode = request.args.get("tm") if request.args.get("tm") in ("full", "short", "codes") else "full"
    lab_name = get_setting(db, "app_name_ar", "") or get_setting(db, "app_name", "")
    payload = _request_scan_payload(visit, tests, draw_time, lab_name, scan or ["reg_no"], tmode)
    img = generate_qr(payload)
    buf = BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")


# أنماط جاهزة لملصق باركود ورقة الطلب (اسم المريض بالمنتصف ← التاريخ والوقت بالمنتصف تحته ← الباركود). تُختار من "مركز الباركودات"
# أو ?style=key بطباعة الملصق (للطباعة الحالية فقط)، وتُحفظ كافتراضي من نفس الصفحة. كل نمط يبقى قابلًا للتعديل بمصمم الملصق.
_REQUEST_LABEL_STYLES = {
    "R1": {"title": "R1 — مع Ready by / Paid / Balance", "w": 60, "h": 30,
           "lines": [{"f": "patient_name", "s": 10, "b": 1, "a": "center"}, {"f": "ready_by", "f2": "datetime", "s": 8},
                     {"f": "paid", "f2": "balance", "s": 8}, {"f": "order_no", "s": 9, "a": "center"}],
           "bc": {"type": "code128", "pos": "bottom", "h": 10}},
    "centered": {"title": "مركزي (الأساسي): الاسم + التاريخ والوقت + باركود", "w": 60, "h": 40,
                 "lines": [{"f": "patient_name", "s": 11, "b": 1, "a": "center"}, {"f": "datetime", "s": 8, "a": "center"}],
                 "bc": {"type": "code128", "pos": "bottom", "h": 16}},
    "centered_qr": {"title": "مركزي مع QR", "w": 50, "h": 50,
                    "lines": [{"f": "patient_name", "s": 11, "b": 1, "a": "center"}, {"f": "datetime", "s": 8, "a": "center"}],
                    "bc": {"type": "qr", "pos": "bottom", "h": 22}},
    "big_name": {"title": "اسم كبير", "w": 70, "h": 40,
                 "lines": [{"f": "patient_name", "s": 15, "b": 1, "a": "center"}, {"f": "datetime", "s": 9, "a": "center"}],
                 "bc": {"type": "code128", "pos": "bottom", "h": 14}},
    "compact": {"title": "صغير مضغوط", "w": 50, "h": 25,
                "lines": [{"f": "patient_name", "s": 9, "b": 1, "a": "center"}, {"f": "datetime", "s": 7, "a": "center"}],
                "bc": {"type": "code128", "pos": "bottom", "h": 9}},
    "with_tests": {"title": "مع أكواد التحاليل", "w": 60, "h": 50,
                   "lines": [{"f": "patient_name", "s": 11, "b": 1, "a": "center"}, {"f": "datetime", "s": 8, "a": "center"},
                             {"f": "tests_codes", "s": 7, "a": "center"}],
                   "bc": {"type": "code128", "pos": "bottom", "h": 14}},
    "with_lab": {"title": "مع اسم المختبر بالأعلى", "w": 60, "h": 45,
                 "lines": [{"f": "lab_name", "s": 7, "a": "center"}, {"f": "patient_name", "s": 11, "b": 1, "a": "center"},
                           {"f": "datetime", "s": 8, "a": "center"}],
                 "bc": {"type": "code128", "pos": "bottom", "h": 14}},
}


def other_lab_extra(visit_id):
    """سطر إضافي (اختياري) يُطبع تحت عبارة "The sample received from another Lab." لزيارة معيّنة فقط."""
    try:
        if not visit_id:
            return ""
        r = get_db().execute("SELECT other_lab_note FROM visits WHERE id=?", (int(visit_id),)).fetchone()
        return (r["other_lab_note"] or "").strip() if r else ""
    except Exception:
        return ""


app.jinja_env.globals["other_lab_extra"] = other_lab_extra


@app.route("/api/visit/<int:visit_id>/other-lab-note", methods=["POST"])
@login_required
def api_visit_other_lab_note(visit_id):
    """يحفظ/يمسح الإضافة على عبارة المختبر المحيل لمريض (زيارة) واحد فقط. الفاضي = بدون إضافة (العبارة الأصلية تبقى للكل)."""
    db = get_db()
    if not db.execute("SELECT 1 FROM visits WHERE id=?", (visit_id,)).fetchone():
        return {"ok": False, "error": "الزيارة غير موجودة"}, 404
    body = request.get_json(silent=True) or {}
    text = str(body.get("text") or "").strip()[:300]
    db.execute("UPDATE visits SET other_lab_note=? WHERE id=?", (text or None, visit_id))
    db.commit()
    log_action("SetOtherLabNote", "visit", visit_id, text[:80])
    return {"ok": True, "text": text}


@app.route("/management/label-designer")
@roles_required("admin")
def label_designer_page():
    """صفحة تصميم الباركودات: تفتح ملصق الأنبوب/الطلب لآخر زيارة مع لوحة التصميم مفتوحة (قالب جاهز T1/R1 + القياس)."""
    db = get_db()
    row = db.execute("SELECT id FROM visits ORDER BY id DESC LIMIT 1").fetchone()
    vid = row["id"] if row else None
    from flask import render_template_string
    return render_template_string(
        """<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>تصميم الباركودات</title>
<style>body{font-family:Tahoma,Arial,sans-serif;background:#F1F5F9;margin:0;padding:24px;color:#0F172A}
.w{max-width:760px;margin:0 auto}.c{background:#fff;border:1px solid #E2E8F0;border-radius:12px;padding:18px;margin-bottom:14px}
a.b{display:inline-block;background:#26529C;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:700;margin-top:8px}
.m{color:#64748B;font-size:13px;line-height:1.8}</style></head><body><div class="w">
<h2>🏷️ تصميم الباركودات</h2>
{% if vid %}
<div class="c"><h3>ملصق الأنبوب</h3><div class="m">اسم + جهاز/جنس/عمر + وقت + التحاليل + باركود. بلوحة التصميم اختر «قالب جاهز: T1» وعدّل القياس بالمليمتر.</div>
<a class="b" href="{{ url_for('print_sample_barcodes', visit_id=vid) }}?design=1">تصميم ملصق الأنبوب</a></div>
<div class="c"><h3>ملصق الطلب</h3><div class="m">اسم + Ready by + Paid/Balance + رقم الطلب + باركود. اختر «قالب جاهز: R1».</div>
<a class="b" href="{{ url_for('print_request_label', visit_id=vid) }}?design=1">تصميم ملصق الطلب</a></div>
<p class="m">يُفتح بآخر زيارة مسجلة للمعاينة. كل تعديل يُحفظ تلقائيًا ويطبَّق على كل الزيارات.</p>
{% else %}<div class="c m">سجّل زيارة واحدة على الأقل أولًا حتى تظهر معاينة الملصق.</div>{% endif %}
</div></body></html>""", vid=vid)


@app.route("/front-desk/visits/<int:visit_id>/print/request-label")
@login_required
def print_request_label(visit_id):
    """ملصق خاص بورقة طلب المريض (request): تصميم/محتوى/عدد مستقل عن ملصقات الأنابيب."""
    db = get_db()
    visit, tests, draw_time = _visit_barcode_context(db, visit_id)
    if not visit:
        return "Not found", 404
    lab_name = get_setting(db, "app_name_ar", "") or get_setting(db, "app_name", "")
    label_layout = dict(_get_label_layout(db, "request"))
    _st = request.args.get("style")
    if _st in _REQUEST_LABEL_STYLES:   # نمط جاهز للطباعة الحالية فقط (بدون حفظ)
        _pre = dict(_REQUEST_LABEL_STYLES[_st]); _pre.pop("title", None)
        _pre["roll"] = True; _pre["copies"] = label_layout.get("copies", 1)
        label_layout = _sanitize_label_layout("request", _pre)
    # ?copies=N (من شاشة زيارة جديدة) يتجاوز العدد المحفوظ لهذه الطباعة فقط
    _cp = request.args.get("copies", type=int)
    if _cp and 1 <= _cp <= 50:
        label_layout["copies"] = _cp
    return render_template(
        "front_desk/print_request_label.html", visit=visit,
        autoprint=request.args.get("autoprint") == "1",
        label_data=_label_visit_fields(visit, lab_name, tests, draw_time, money=_label_money(db, visit)),
        label_layout=label_layout,
        field_titles=[(k, LABEL_FIELD_TITLES[k]) for k in LABEL_FIELDS_BY_KIND["request"]],
        scan_titles=list(LABEL_SCAN_TITLES.items()),
    )


# ------------------------------------------------------------------------
# "مركز الباركودات": المريض اللي عنده تحاليل بالمختبر وتم البحث عنه تقدر من أي جهاز/واجهة تطبع له باركودات إضافية:
# أنابيب (الكل / قسم محدد / تحاليل محددة)، باركود ورقة الطلب (أكثر من نمط)، وملصق للتحاليل الخارجية (غير الموجودة
# بالمختبر): اسم المريض ← أسماء التحاليل ← تاريخ ووقت السحب ← اسم المختبر، وكلها قابلة للتعديل قبل الطباعة.
# ------------------------------------------------------------------------
@app.route("/labels/visit/<int:visit_id>")
@login_required
def labels_center(visit_id):
    db = get_db()
    visit, tests, draw_time = _visit_barcode_context(db, visit_id)
    if not visit:
        return "Not found", 404
    rows = db.execute(
        "SELECT ot.id, ot.status, td.name, td.short_name, td.code, COALESCE(NULLIF(TRIM(td.department), ''), 'بدون قسم') as department "
        "FROM order_tests ot JOIN orders o ON o.id = ot.order_id JOIN test_definitions td ON td.id = ot.test_definition_id "
        "WHERE o.visit_id=? AND COALESCE(ot.status,'') NOT IN ('Cancelled','Canceled','Rejected') ORDER BY td.department, ot.id",
        (visit_id,)).fetchall()
    groups = {}
    for r in rows:
        groups.setdefault(r["department"], []).append(dict(r))
    lab_name = get_setting(db, "app_name_ar", "") or get_setting(db, "app_name", "")
    return render_template(
        "front_desk/labels_center.html", visit=visit, groups=groups, draw_time=_fmt_dt(draw_time), lab_name=lab_name,
        request_styles=[(k, v["title"]) for k, v in _REQUEST_LABEL_STYLES.items()],
        request_styles_json=json.dumps(_REQUEST_LABEL_STYLES, ensure_ascii=False))


@app.route("/labels/visit/<int:visit_id>/outside")
@login_required
def labels_outside_print(visit_id):
    """ملصق التحاليل غير الموجودة بالمختبر (تُرسل لمختبر خارجي): اسم المريض ← التحاليل ← تاريخ/وقت السحب ← اسم المختبر."""
    db = get_db()
    visit, tests, draw_time = _visit_barcode_context(db, visit_id)
    if not visit:
        return "Not found", 404
    ids = [int(x) for x in (request.args.get("ots") or "").split(",") if x.strip().isdigit()]
    names = []
    if ids:
        ph = ",".join("?" * len(ids))
        names = [(r["name"] or r["short_name"]) for r in db.execute(
            f"SELECT td.name, td.short_name FROM order_tests ot JOIN test_definitions td ON td.id = ot.test_definition_id "
            f"JOIN orders o ON o.id = ot.order_id WHERE o.visit_id=? AND ot.id IN ({ph}) ORDER BY ot.id", (visit_id, *ids)).fetchall()]
    names += [x.strip() for x in (request.args.get("extra") or "").splitlines() if x.strip()]
    lab_name = get_setting(db, "app_name_ar", "") or get_setting(db, "app_name", "")
    return render_template("front_desk/print_outside_label.html", visit=visit, tests_text="\n".join(names),
                           draw_time=_fmt_dt(draw_time), lab_name=lab_name,
                           style=request.args.get("style") or "centered", copies=request.args.get("copies", type=int) or 1)


@app.route("/front-desk/visits/<int:visit_id>/print/barcode")
@login_required
def print_visit_barcode(visit_id):
    """ملصق باركود الزيارة (لأي قنينة): اسم المريض + كل أسماء التحاليل + باركود واحد
    إذا انمسح بأي قارئ يرجّع رقم الزيارة وأكواد كل تحاليلها. عدد النسخ وحجم
    الملصق وطريقة عرض الأسماء تُحفظ بالإعدادات وتتغير من شريط أعلى الصفحة."""
    db = get_db()
    visit, tests, draw_time = _visit_barcode_context(db, visit_id)
    if not visit:
        return "Not found", 404

    def _int(key, default, lo, hi):
        try:
            return max(lo, min(hi, int(get_setting(db, key, str(default)))))
        except (TypeError, ValueError):
            return default
    lab_name_ar = get_setting(db, "app_name_ar", "") or get_setting(db, "app_name", "")
    mode = get_setting(db, "vb_names_mode", "full")
    if mode not in ("full", "short", "none"):
        mode = "full"
    return render_template(
        "front_desk/print_visit_barcode.html", visit=visit, tests=tests, draw_time=draw_time,
        lab_name_ar=lab_name_ar, show_lab_name=_barcode_show_lab_name(db),
        vb_style=_barcode_style(db, "vb_style"), barcode_styles=BARCODE_STYLES,
        vb_copies=_int("vb_copies", 1, 1, 50), vb_w=_int("vb_w", 50, 20, 200),
        vb_h=_int("vb_h", 30, 15, 200), vb_names_mode=mode,
    )


@app.route("/front-desk/visits/<int:visit_id>/print/balance-slip")
@login_required
def print_balance_slip(visit_id):
    """ورقة صغيرة (بحجم ملصق الباركود) بالمبلغ المتبقي على المريض: الاسم + التاريخ والوقت + المتبقي + الواصل فقط."""
    db = get_db()
    row = db.execute(
        "SELECT v.id, v.registration_number, v.created_at, p.full_name FROM visits v JOIN patients p ON p.id=v.patient_id WHERE v.id=?",
        (visit_id,)).fetchone()
    if not row:
        return "Not found", 404
    bal = _visit_balance(db, visit_id)

    def _int(key, default, lo, hi):
        try:
            return max(lo, min(hi, int(get_setting(db, key, str(default)))))
        except (TypeError, ValueError):
            return default
    return render_template(
        "front_desk/print_balance_slip.html", visit=row, bal=bal,
        printed_at=str(row["created_at"] or "").replace("T", " ")[:16],  # تاريخ ووقت الزيارة (مو وقت الطباعة)
        vb_w=_int("vb_w", 50, 20, 200), vb_h=_int("vb_h", 30, 15, 200),
    )


@app.route("/api/barcode/<code>")
@login_required
def api_barcode_lookup(code):
    """يرجّع معلومات المريض كاملة + كل التحاليل المرتبطة بهذا الباركود —
    سواء كان باركود أنبوب مشترك (tube_barcode، يغطي عدة تحاليل بنفس نوع
    العينة) أو باركود تحليل فردي قديم (barcode). مصمَّم ليكون نقطة وصول
    لأي جهاز/برنامج وسيط خارجي (Middleware) يقرأ الباركود من الأنبوب ويريد
    يعرف شنو التحاليل المطلوبة ولمين، بدون الحاجة يفتح الواجهة."""
    db = get_db()
    # باركود الزيارة (ملصق print/barcode) يحمل "رقم التسجيل|أكواد" — نطابق رقم التسجيل.
    _reg = code.split("|", 1)[0].strip()
    _visit_mode = _reg.isdigit() and db.execute(
        "SELECT 1 FROM order_tests WHERE tube_barcode=? OR barcode=? LIMIT 1", (code, code)).fetchone() is None
    rows = db.execute(
        "SELECT ot.id as order_test_id, ot.status, ot.barcode, ot.tube_barcode, "
        "td.name as test_name, td.sample_type, td.department, "
        "p.id as patient_id, p.full_name, p.full_name_en, p.age, p.age_unit, p.gender, "
        "v.id as visit_id, v.registration_number "
        "FROM order_tests ot JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id "
        + ("WHERE v.registration_number=?" if _visit_mode else "WHERE ot.tube_barcode=? OR ot.barcode=?"),
        (_reg,) if _visit_mode else (code, code),
    ).fetchall()
    if not rows:
        return jsonify({"ok": False, "error": "لا يوجد باركود مطابق"}), 404
    first = rows[0]
    # أي أنبوب يُمسح يرجّع كل تحاليل الزيارة (مو بس تحاليل هذا الأنبوب): نجيب الزيارة من الباركود الممسوح
    # ثم كل تحاليلها، ونعلّم اللي تخص الأنبوب الممسوح بـ in_this_tube.
    tube_ids = {r["order_test_id"] for r in rows}
    all_rows = db.execute(
        "SELECT ot.id as order_test_id, ot.status, td.name as test_name, td.sample_type, td.department "
        "FROM order_tests ot JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id WHERE o.visit_id=? ORDER BY ot.id",
        (first["visit_id"],),
    ).fetchall()
    tests = [
        {"order_test_id": r["order_test_id"], "name": r["test_name"], "sample_type": r["sample_type"],
         "department": r["department"], "status": r["status"], "in_this_tube": r["order_test_id"] in tube_ids}
        for r in all_rows
    ]
    return jsonify({
        "ok": True,
        "barcode": code,
        "patient": {
            "id": first["patient_id"], "name": first["full_name"], "name_en": first["full_name_en"],
            "age": first["age"], "age_unit": first["age_unit"], "gender": first["gender"],
        },
        "visit": {"id": first["visit_id"], "registration_number": first["registration_number"]},
        "tests": tests,                                            # كل تحاليل الزيارة
        "tube_tests": [t for t in tests if t["in_this_tube"]],     # تحاليل هذا الأنبوب فقط
    })


@app.route("/public/results-board")
def public_results_board():
    """شاشة عرض عامة (بدون تسجيل دخول) — تُفتح على شاشة/تلفزيون خارجي
    بصالة الانتظار، تعرض التحاليل المكتملة اليوم بشكل مباشر، وتتحدث
    تلقائيًا كل دقيقة. لا تحتاج صلاحية عمداً لأنها مصممة للعرض العام
    بمواجهة المراجعين، مو للموظفين."""
    return render_template("public/results_board.html")


@app.route("/api/public/completed-today")
def api_public_completed_today():
    """يرجّع آخر التحاليل المكتملة اليوم (اسم المريض + اسم التحليل + وقت
    الإنجاز) — يغذّي شاشة العرض العامة أعلاه. يعتمد وقت آخر نتيجة أُدخلت
    فعليًا (results.entered_at) كـ"وقت الإنجاز"، مو وقت تسجيل الزيارة."""
    db = get_db()
    rows = db.execute(
        "SELECT ot.id as order_test_id, p.full_name, td.name as test_name, "
        "MAX(r.entered_at) as completed_at "
        "FROM order_tests ot "
        "JOIN orders o ON o.id = ot.order_id "
        "JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id "
        "JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN results r ON r.order_test_id = ot.id "
        "WHERE ot.status IN ('Completed', 'Verified') "
        "AND date(r.entered_at) = date('now', 'localtime') "
        "GROUP BY ot.id "
        "ORDER BY completed_at DESC "
        "LIMIT 30"
    ).fetchall()
    return jsonify([
        {"order_test_id": r["order_test_id"], "patient_name": r["full_name"],
         "test_name": r["test_name"], "completed_at": r["completed_at"]}
        for r in rows
    ])


@app.route("/front-desk/print-barcode")
@login_required
def print_barcode_finder():
    """صفحة بحث سريعة: اكتب اسم المريض، تطلعلك آخر زياراته والتحاليل
    المطلوبة بيها، وتضغط زر لتطبع باركوداتها — مفيدة لو تلف باركود أصلي
    وتحتاج تعيد طباعته بسرعة بدون الرجوع لسجل الزيارة الكامل."""
    db = get_db()
    return render_template("front_desk/print_barcode_finder.html",
                           show_lab_name=get_setting(db, "barcode_show_lab_name", "1") != "0")


@app.route("/api/patients/<int:patient_id>/recent-visits")
@login_required
def api_patient_recent_visits(patient_id):
    """يرجّع آخر بضع زيارات لمريض معيّن مع أسماء تحاليل كل زيارة — تغذّي
    صفحة "طباعة باركود" السريعة (البحث بالاسم)."""
    db = get_db()
    visits = db.execute(
        "SELECT id, registration_number, created_at FROM visits "
        "WHERE patient_id=? ORDER BY created_at DESC LIMIT 10",
        (patient_id,),
    ).fetchall()
    out = []
    for v in visits:
        tests = [t["name"] for t in db.execute(
            "SELECT DISTINCT td.name FROM order_tests ot "
            "JOIN orders o ON o.id = ot.order_id "
            "JOIN test_definitions td ON td.id = ot.test_definition_id "
            "WHERE o.visit_id=?",
            (v["id"],),
        ).fetchall()]
        out.append({
            "visit_id": v["id"], "registration_number": v["registration_number"],
            "created_at": v["created_at"], "tests": tests,
        })
    return jsonify(out)


def _inject_request_label_with_tubes(html, visit_id):
    """يضيف ملصق باركود الطلب (اسم المريض بالمنتصف + التاريخ والوقت + الباركود) داخل نفس صفحة طباعة الأنابيب،
    فيطلع بنفس أمر الطباعة (نفس النافذة، بدون نوافذ منبثقة تحجبها المتصفحات) وبقياسه الخاص عبر @page مسماة.
    مفتاح صغير 🏷 بزاوية الصفحة يشغّل/يوقف ذلك (محفوظ بالجهاز) + عدد النسخ. ?req=0 يعطّله، ?req=1 يفرضه، ?rcopies=N للنسخ."""
    if "</body>" not in html:
        return html
    db = get_db()
    visit, tests, draw_time = _visit_barcode_context(db, visit_id)
    if not visit:
        return html
    lab_name = get_setting(db, "app_name_ar", "") or get_setting(db, "app_name", "")
    lay = _get_label_layout(db, "request")
    f = _label_visit_fields(visit, lab_name, tests, draw_time)
    tmode = lay.get("tmode", "full")
    names = {"full": f.get("tests_full", []), "short": f.get("tests_short", [])}.get(tmode, [])
    tests_text = ", ".join(names) if names else f.get("tests_codes", "")
    lines_html = ""
    for ln in lay.get("lines", []):
        k = ln.get("f")
        txt = ln.get("t", "") if k == "custom" else (tests_text if k == "tests" else f.get(k, ""))
        if not txt:
            continue
        st = f"font-size:{ln.get('s', 9)}pt;text-align:{ln.get('a', 'center')};" + ("font-weight:700;" if ln.get("b") else "")
        lines_html += f'<div class="lrq-ln" style="{st}">{html_escape(str(txt))}</div>'
    bc = lay.get("bc") or {}
    bh = bc.get("h", 16)
    if bc.get("type") == "qr":
        src = url_for("visit_request_qr", visit_id=visit_id) + "?scan=" + ",".join(lay.get("scan") or ["reg_no"]) + "&tm=" + ("full" if tmode == "full" else "short")
    else:
        src = url_for("visit_barcode_code128", visit_id=visit_id)
    side = bc.get("pos") == "side"
    img = (f'<img src="{src}" style="height:{bh}mm;max-width:{"45%" if side else "100%"};'
           f'{"" if bc.get("type") == "qr" else ("width:100%;" if not side else "")}object-fit:contain;image-rendering:pixelated;">')
    w, h = lay.get("w") or 60, lay.get("h") or 40
    copies = request.args.get("rcopies", type=int) or lay.get("copies", 1) or 1
    copies = max(1, min(50, copies))
    forced = request.args.get("req")
    label = (f'<div class="lrq-label" style="width:{w}mm;height:{h}mm;">'
             f'<div class="lrq-body" style="flex-direction:{"row" if side else "column"};">'
             f'<div class="lrq-txt">{lines_html}</div><div class="lrq-bc">{img}</div></div></div>')
    block = f"""
<style>
  @page lrqpage {{ size: {w}mm {h}mm; margin: 0; }}
  #lisReqSection {{ margin: 18px auto; text-align: center; }}
  #lisReqSection .lrq-head {{ font: 700 14px Tahoma, Arial, sans-serif; color: #205072; margin-bottom: 8px; }}
  .lrq-label {{ display: inline-block; vertical-align: top; margin: 4px; background: #fff; border: 1px dashed #94A3B8; border-radius: 4px; overflow: hidden; padding: 1.2mm 2mm; box-sizing: border-box; color: #000; }}
  .lrq-body {{ width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; gap: 1.5mm; }}
  .lrq-txt {{ flex: 1 1 auto; min-width: 0; }} .lrq-ln {{ line-height: 1.18; word-break: break-word; unicode-bidi: plaintext; }}
  .lrq-bc {{ flex: 0 0 auto; display: flex; justify-content: center; max-width: 100%; }} .lrq-body[style*="column"] .lrq-bc {{ width: 100%; }}
  #lisReqBox {{ position: fixed; top: 6px; left: 6px; z-index: 99999; background: #fff; border: 1px solid #94A3B8; border-radius: 8px; padding: 3px 8px; font: 12px Tahoma, Arial, sans-serif; direction: rtl; box-shadow: 0 2px 8px rgba(0,0,0,.2); }}
  @media print {{
    #lisReqBox, #lisReqSection .lrq-head {{ display: none !important; }}
    #lisReqSection {{ margin: 0; display: block; }}
    .lrq-label {{ page: lrqpage; display: block; margin: 0; border: none; border-radius: 0; page-break-after: always; break-after: page; }}
    .lrq-label:first-of-type {{ page-break-before: always; break-before: page; }}
    #lisReqSection .lrq-label:last-child {{ page-break-after: auto; break-after: auto; }}
  }}
</style>
<div id="lisReqSection"><div class="lrq-head">🏷 باركود الطلب — يُطبع مع الأنابيب بنفس أمر الطباعة</div><div id="lisReqLabels">{label * copies}</div></div>
<div id="lisReqBox"><label style="cursor:pointer;display:inline-flex;align-items:center;gap:4px;"><input type="checkbox" id="lisReqCb"> 🏷 مع باركود الطلب</label>
 <input type="number" id="lisReqN" min="1" max="50" value="{copies}" title="عدد نسخ ملصق الطلب" style="width:46px;padding:1px 3px;"></div>
<script>(function(){{
  var KEY='lisReqWithTube', forced={json.dumps(forced)}, on=true;
  try{{ on = localStorage.getItem(KEY)!=='0'; }}catch(e){{}}
  if(forced==='0') on=false; if(forced==='1') on=true;
  var cb=document.getElementById('lisReqCb'), sec=document.getElementById('lisReqSection'), n=document.getElementById('lisReqN'), box=document.getElementById('lisReqLabels');
  var one=box.querySelector('.lrq-label').outerHTML;
  function show(){{ sec.style.display = cb.checked ? '' : 'none'; }}
  cb.checked=on; show();
  cb.addEventListener('change',function(){{ try{{ localStorage.setItem(KEY, cb.checked?'1':'0'); }}catch(e){{}} show(); }});
  n.addEventListener('input',function(){{ var c=Math.max(1,Math.min(50,parseInt(n.value,10)||1)); box.innerHTML=new Array(c+1).join(one); }});
}})();</script>
"""
    return html.replace("</body>", block + "</body>", 1)


@app.route("/front-desk/visits/<int:visit_id>/print/samples")
@login_required
def print_sample_barcodes(visit_id):
    db = get_db()
    visit = db.execute(
        "SELECT v.*, p.full_name, p.age, p.age_unit, p.gender FROM visits v JOIN patients p ON p.id = v.patient_id WHERE v.id=?",
        (visit_id,),
    ).fetchone()
    if not visit:
        return "Not found", 404
    rows = db.execute(
        "SELECT ot.id, ot.barcode, ot.tube_barcode, td.name as test_name, td.short_name as test_short_name, "
        "td.sample_type, td.department, ot.selected_param_ids FROM order_tests ot "
        "JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id WHERE o.visit_id=?",
        (visit_id,),
    ).fetchall()
    # فلترة اختيارية من "مركز الباركودات": ?dept=Hematology|Chemistry (قسم/أقسام بعينها) و/أو ?ots=1,2 (تحاليل محددة)
    _f_ots = {int(x) for x in (request.args.get("ots") or "").split(",") if x.strip().isdigit()}
    _f_dept = {x.strip().lower() for x in (request.args.get("dept") or "").split("|") if x.strip()}
    if _f_ots:
        rows = [r for r in rows if r["id"] in _f_ots]
    if _f_dept:
        rows = [r for r in rows if (r["department"] or "").strip().lower() in _f_dept]

    # تجميع تحاليل هذي الزيارة حسب نوع العينة (sample_type) — كل التحاليل
    # اللي تحتاج نفس الأنبوب (Serum مثلاً) تشترك بباركود وحد بدل باركود
    # مستقل لكل تحليل، لأن فعليًا هي نفس الأنبوب المسحوب مرة وحدة. تحليل
    # بدون sample_type محدد (فاضي) ياخذ باركوده الفردي القديم لحاله، لأننا
    # ما نعرف أكيد أي أنبوب يشاركه.
    # الافتراضي الآن: التحاليل التابعة لنفس القسم (department) مثل Hematology
    # تشترك بباركود واحد؛ تحليل بدون قسم يُجمَّع حسب نوع العينة، وبدونهما
    # يبقى ملصقه الفردي. لإرجاع التجميع القديم (حسب نوع العينة فقط):
    # الرابط ?group=sample_type أو إعداد barcode_group_mode = sample_type.
    group_mode = (request.args.get("group") or get_setting(db, "barcode_group_mode", "sample_type") or "sample_type").strip()
    # أسماء التحاليل المطبوعة على الملصق: لو التحليل مطلوب جزئيًا (مثلاً PT و PTT
    # من Coagulation) تُطبع أسماء البارامترات المختارة نفسها بدل اسم التحليل
    # الكامل، بدون بارامترات الـControl ولا INR (تُضاف تلقائيًا مع PT).
    def _label_names(r, short=False):
        raw = (r["selected_param_ids"] or "").strip()
        if raw:
            try:
                _ids = [int(x) for x in raw.split(",") if x.strip()]
            except ValueError:
                _ids = []
            if _ids:
                _ph = ",".join("?" * len(_ids))
                _names = [p["name"] for p in db.execute(
                    f"SELECT name FROM test_parameters WHERE id IN ({_ph}) ORDER BY id", _ids).fetchall()]
                _low = {n.strip().lower() for n in _names}
                _out = [n for n in _names
                        if "control" not in n.lower()
                        and not (n.strip().lower() == "inr" and "pt" in _low)]
                if _out:
                    return _out
        return [(r["test_short_name"] or r["test_name"]) if short else r["test_name"]]

    groups = {}
    ungrouped = []
    for r in rows:
        stype = (r["sample_type"] or "").strip()
        dept = (r["department"] or "").strip()
        key = (dept or stype) if group_mode != "sample_type" else (stype.casefold() or dept)
        if not key:
            ungrouped.append(r)
            continue
        groups.setdefault(key, []).append(r)

    reg_number = visit["registration_number"]
    tube_samples = []
    next_index = 1
    _used_tubes = {r["tube_barcode"] for r in rows if r["tube_barcode"]}
    _changed = False
    for stype in sorted(groups.keys()):
        group_rows = groups[stype]
        existing = next((r["tube_barcode"] for r in group_rows if r["tube_barcode"]), None)
        if existing:
            tube_barcode = existing
        else:
            tube_barcode = f"{reg_number}T{next_index}"
            while tube_barcode in _used_tubes:
                next_index += 1
                tube_barcode = f"{reg_number}T{next_index}"
            next_index += 1
            _used_tubes.add(tube_barcode)
        # كل تحاليل المجموعة تأخذ نفس باركود الأنبوب (حتى لو كانت قبل التجميع الجديد بباركودات مختلفة)
        ids = [r["id"] for r in group_rows if r["tube_barcode"] != tube_barcode]
        if ids:
            placeholders = ",".join("?" * len(ids))
            db.execute(f"UPDATE order_tests SET tube_barcode=? WHERE id IN ({placeholders})",
                       (tube_barcode, *ids))
            _changed = True
        tube_samples.append({
            # اسم القسم ما يُطبع على الملصق (فقط أسماء التحاليل/الأنواع المختارة)؛
            # عند التجميع حسب نوع العينة فقط (?group=sample_type) يبقى العنوان القديم
            "sample_type": ((group_rows[0]["sample_type"] or "").strip() if group_mode == "sample_type" else ""),
            "department": (group_rows[0]["department"] or "") if group_rows else "",
            "barcode": tube_barcode,
            "test_names": [n for r in group_rows for n in _label_names(r)],
            # short_names: نفس الترتيب أعلاه، لكل تحليل اختصاره اليدوي
            # (test_definitions.short_name) لو موجود، وإلا الاسم الكامل
            # نفسه (يتكفل القالب بتقصيره تلقائيًا وقت العرض لو ما فيه
            # اختصار محدد — راجع shortenTestList بالقالب).
            "short_names": [n for r in group_rows for n in _label_names(r, short=True)],
        })
    if _changed:
        db.commit()

    # تحاليل بلا sample_type محدد — ما نعرف أي أنبوب تشاركه بأمان، فتطلع
    # كل وحدة بكارد مستقل لحالها (بباركودها الفردي الأصلي)، بدل ما تختفي
    # كليًا من العرض الرئيسي.
    for r in ungrouped:
        tube_samples.append({
            "sample_type": "",  # بدون عنوان: أسماء التحاليل تظهر تحته مباشرة
            "barcode": r["barcode"],
            "test_names": _label_names(r),
            "short_names": _label_names(r, short=True),
        })

    # باركودات فردية لكل تحليل لحاله — تبقى متوفرة كخيار إضافي (زر منفصل
    # بالقالب) لمن يحتاج يطبع باركود وحيد لتحليل معيّن بس (مثلاً لإرسال
    # عينة لمختبر مُحيل لتحليل واحد فقط)، بدون ما يأثر على السلوك الافتراضي
    # الجديد (باركود واحد لكل أنبوب).
    individual_samples = [
        {"barcode": r["barcode"], "test_name": r["test_name"],
         "test_short_name": r["test_short_name"] or r["test_name"], "sample_type": r["sample_type"]}
        for r in rows
    ]

    # اسم المختبر يطبع دائمًا بالعربي على ملصق الباركود بغض النظر عن لغة
    # الواجهة الحالية (brand_name المحقون عالميًا بـ inject_globals يتبع
    # لغة الجلسة session["lang"] وقد تكون إنكليزية) — فني المختبر يحتاج
    # الاسم العربي دائمًا على الملصق نفسه، فنجيبه هنا مباشرة بمعزل عن اللغة.
    lab_name_ar = get_setting(db, "app_name_ar", "") or get_setting(db, "app_name", "")

    # تفضيلات طباعة الباركود (عدد النسخ + طريقة عرض أسماء التحاليل) —
    # محفوظة كإعدادات عامة (نفس أسلوب get_setting/set_setting بكل الملف)
    # حتى تبقى "ثابتة" بين كل طباعة وطباعة إلى أن يغيّرها المستخدم بنفسه
    # من الشريط أعلى صفحة الطباعة، بدل ما ترجع لقيمة افتراضية كل مرة.
    barcode_copies = get_setting(db, "barcode_copies", "1")
    # عدد النسخ المحدد من صفحة "زيارة جديدة" (?copies=N) يتقدّم على الإعداد المحفوظ
    _cp = request.args.get("copies", type=int)
    if _cp and 1 <= _cp <= 20:
        barcode_copies = str(_cp)
    barcode_test_names_mode = get_setting(db, "barcode_test_names_mode", "full")  # full | short | none

    # تصميم أسطر ملصق الأنبوب (محفوظ) + قيم الحقول لكل ملصق. أول مرة (بدون تصميم محفوظ)
    # نرث خيار "أسماء التحاليل" القديم حتى ما يتغير شكل الملصق.
    _tube_layout = _get_label_layout(db, "tube")
    if not (get_setting(db, "label_layout_tube", "") or "").strip() and barcode_test_names_mode in ("full", "short", "none"):
        _tube_layout["tmode"] = barcode_test_names_mode
    _base = _label_visit_fields(visit, lab_name_ar)
    for _s in tube_samples:
        _s["fields"] = {**_base, "sample_type": _s["sample_type"] or "", "tests_full": _s["test_names"],
                        "tests_short": _s["short_names"], "tests_codes": "",
                        "dept_age_gender": (f"{_s.get('department')} - " if _s.get("department") else "") + _base.get("ga_short", "")}
    for _s in individual_samples:
        _s["fields"] = {**_base, "sample_type": _s["sample_type"] or "", "tests_full": [_s["test_name"]],
                        "tests_short": [_s["test_short_name"]], "tests_codes": ""}

    _tube_html = render_template(
        "front_desk/print_sample_barcodes.html", visit=visit,
        tube_samples=tube_samples, individual_samples=individual_samples,
        samples=individual_samples,  # توافق مع أي نسخة قديمة من القالب لسا تستخدم "samples"
        lab_name_ar=lab_name_ar, show_lab_name=_barcode_show_lab_name(db),
        barcode_style=_barcode_style(db, "barcode_style"), barcode_styles=BARCODE_STYLES,
        label_layout=_tube_layout,
        field_titles=[(k, LABEL_FIELD_TITLES[k]) for k in LABEL_FIELDS_BY_KIND["tube"]],
        barcode_copies=barcode_copies,
        barcode_test_names_mode=barcode_test_names_mode,
    )
    return _inject_request_label_with_tubes(_tube_html, visit_id)


# ============== حفظ تفضيلات طباعة الباركود (عدد النسخ / عرض أسماء التحاليل) ==============
# يستدعيه شريط الإعدادات أعلى front_desk/print_sample_barcodes.html كل ما
# غيّر المستخدم عدد النسخ أو طريقة عرض التحاليل — القيم تُحفظ كإعدادات عامة
# (get_setting/set_setting) فتصير هي الافتراضي لكل طباعة قادمة (لكل
# المستخدمين/الأجهزة) لحد ما تُغيّر مرة ثانية، بدل ما ترجع لـ1 نسخة/الاسم
# الكامل تلقائيًا بكل صفحة جديدة.
@app.route("/api/settings/barcode-print-prefs", methods=["POST"])
@login_required
def api_set_barcode_print_prefs():
    db = get_db()
    body = request.get_json(silent=True) or request.form
    updated = {}
    if "copies" in body:
        try:
            n = int(body.get("copies"))
            if n < 1 or n > 20:
                raise ValueError
        except (TypeError, ValueError):
            return jsonify({"ok": False, "error": "عدد النسخ يجب أن يكون رقمًا صحيحًا بين 1 و20"}), 400
        set_setting(db, "barcode_copies", str(n))
        updated["copies"] = n
    if "test_names_mode" in body:
        mode = (body.get("test_names_mode") or "").strip()
        if mode not in ("full", "short", "none"):
            return jsonify({"ok": False, "error": "قيمة غير صالحة"}), 400
        set_setting(db, "barcode_test_names_mode", mode)
        updated["test_names_mode"] = mode
    # تفضيلات ملصق "باركود الزيارة" (صفحة print/barcode) — مفاتيح منفصلة حتى لا
    # تتأثر ملصقات العينات.
    for key, setting, lo, hi in (("vb_copies", "vb_copies", 1, 50), ("vb_w", "vb_w", 20, 200),
                                 ("vb_h", "vb_h", 15, 200)):
        if key in body:
            try:
                n = int(body.get(key))
                if n < lo or n > hi:
                    raise ValueError
            except (TypeError, ValueError):
                return jsonify({"ok": False, "error": f"{key}: القيمة يجب أن تكون بين {lo} و{hi}"}), 400
            set_setting(db, setting, str(n))
            updated[key] = n
    for key in ("barcode_style", "vb_style"):
        if key in body:
            st = (body.get(key) or "").strip()
            if st not in BARCODE_STYLES:
                return jsonify({"ok": False, "error": "ستايل غير صالح"}), 400
            set_setting(db, key, st)
            updated[key] = st
    if "show_lab_name" in body:
        v = "0" if str(body.get("show_lab_name")).strip().lower() in ("0", "false", "") else "1"
        set_setting(db, "barcode_show_lab_name", v)
        updated["show_lab_name"] = v
    if "vb_names_mode" in body:
        mode = (body.get("vb_names_mode") or "").strip()
        if mode not in ("full", "short", "none"):
            return jsonify({"ok": False, "error": "قيمة غير صالحة"}), 400
        set_setting(db, "vb_names_mode", mode)
        updated["vb_names_mode"] = mode
    db.commit()
    return jsonify({"ok": True, **updated})


@app.route("/front-desk/visits/<int:visit_id>/print/invoice")
@login_required
def print_invoice(visit_id):
    db = get_db()
    visit = db.execute(
        "SELECT v.*, p.full_name, p.age, p.gender, p.phone, "
        "rc.name as referral_center_name "
        "FROM visits v JOIN patients p ON p.id = v.patient_id "
        "LEFT JOIN referral_centers rc ON rc.id = v.referral_center_id "
        "WHERE v.id=?",
        (visit_id,),
    ).fetchone()
    if not visit:
        return "Not found", 404
    items = db.execute(
        "SELECT td.name, td.name_ar, COALESCE(ot.price, td.price) as price FROM order_tests ot "
        "JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id WHERE o.visit_id=?",
        (visit_id,),
    ).fetchall()
    invoice = db.execute("SELECT * FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()
    doctor = None
    if visit["doctor_id"]:
        doctor = db.execute("SELECT * FROM doctors WHERE id=?", (visit["doctor_id"],)).fetchone()
    return render_template("front_desk/print_invoice.html", visit=visit, items=items,
                            invoice=invoice, doctor=doctor)


# طباعة تحاليل ونتائج زيارة واحدة فقط (تُستخدم من زر "طباعة" أمام أي زيارة
# سابقة تظهر بشاشة "زيارة جديدة" عند العثور على المريض بالبحث الفوري).
@app.route("/front-desk/visits/<int:visit_id>/print/results")
@login_required
def print_visit_results(visit_id):
    db = get_db()
    visit = db.execute(
        "SELECT v.*, p.full_name, p.age, p.age_unit, p.gender, p.phone, "
        "rc.name as referral_center_name FROM visits v "
        "JOIN patients p ON p.id = v.patient_id "
        "LEFT JOIN referral_centers rc ON rc.id = v.referral_center_id WHERE v.id=?",
        (visit_id,),
    ).fetchone()
    if not visit:
        return "Not found", 404
    # نفس منطق from_other_lab بصفحة print_report: نعرض العبارة فقط، وما
    # نطبع اسم المختبر المرسل بأي مكان بهذي الصفحة (الجدول الموحّد للزيارة).
    from_other_lab = bool(visit["referral_center_id"]) and visit["referral_center_name"] not in (None, "", "Walk-in")
    # completed_only=1: يُستخدم من زرّي "طباعة/إرسال كل النتائج المكتملة" أعلى
    # شاشة إدخال النتائج، حتى لا تُطبع/تُرسل تحاليل لسا بانتظار الإدخال أو
    # الاعتماد ضمن نفس الملف.
    completed_only = request.args.get("completed_only") == "1"
    query = (
        "SELECT ot.id, ot.barcode, ot.status, td.name as test_name, td.name_ar as test_name_ar "
        "FROM order_tests ot JOIN orders o ON o.id = ot.order_id "
        "JOIN test_definitions td ON td.id = ot.test_definition_id WHERE o.visit_id=?"
    )
    order_tests = db.execute(query, (visit_id,)).fetchall()
    if completed_only:
        order_tests = [ot for ot in order_tests if ot["status"] in ("Completed", "Verified")]
    tests_with_results = []
    for ot in order_tests:
        results = db.execute(
            "SELECT r.*, tp.name as param_name, tp.unit FROM results r "
            "JOIN test_parameters tp ON tp.id = r.test_parameter_id WHERE r.order_test_id=?",
            (ot["id"],),
        ).fetchall()
        tests_with_results.append({"order_test": ot, "results": results})
    return render_template("front_desk/print_visit_results.html", visit=visit,
                            tests_with_results=tests_with_results, from_other_lab=from_other_lab,
                            completed_only=completed_only)


# "طباعة كل النتائج المكتملة" بشاشة إدخال النتائج — بدل الجدول الموحّد
# العام (print_visit_results فوق، الذي لا يستخدم تصميم التقرير الخاص بكل
# تحليل)، هذا الزر يفتح لكل تحليل مكتمل تقريره المخصّص الحقيقي (نفس
# print_report المستخدم من زر "🖨 طباعة التقرير" أسفل كل تحليل مباشرة) —
# كل واحد بنافذة/تبويب منفصلة، حتى يطابق شكل التقرير المطبوع تماماً شكل
# تقرير نفس التحليل لو طبعته لحاله. صفحة "مُشغّل" خفيفة فقط تفتح الروابط
# تلقائياً + تعرضها كروابط احتياطية لو المتصفح منع النوافذ المنبثقة.
@app.route("/front-desk/visits/<int:visit_id>/print/results-bundle")
@login_required
def print_visit_results_bundle(visit_id):
    db = get_db()
    visit = db.execute(
        "SELECT v.*, p.full_name, p.phone FROM visits v JOIN patients p ON p.id = v.patient_id WHERE v.id=?",
        (visit_id,),
    ).fetchone()
    if not visit:
        return "Not found", 404

    order_tests = db.execute(
        "SELECT ot.id, ot.status, td.code as test_code, td.name as test_name, td.department as test_department "
        "FROM order_tests ot JOIN orders o ON o.id = ot.order_id "
        "JOIN test_definitions td ON td.id = ot.test_definition_id "
        "WHERE o.visit_id=? AND ot.status IN ('Completed', 'Verified') ORDER BY ot.id",
        (visit_id,),
    ).fetchall()

    # نفس منطق الترتيب المستخدم بشاشة "إدخال النتائج" بالضبط (ترتيب يدوي من
    # الإعدادات إن وُجد، وإلا حسب أولوية القسم: كيمياء ← فايروسات ← هرمونات ←
    # فيتامينات ← تخثر ← أمراض الدم) — كانت هذي الصفحة تستخدم ترتيب الإضافة
    # الخام (ot.id) فقط بدون أي فرز، فتفتح التقارير بترتيب عشوائي لا علاقة له
    # بترتيب شاشة الإدخال.
    order_pref_raw = get_setting(db, "results_entry_test_order", "")
    order_pref = [ln.strip() for ln in order_pref_raw.splitlines() if ln.strip()]
    if order_pref:
        rank = {name: i for i, name in enumerate(order_pref)}
        order_tests = sorted(
            order_tests,
            key=lambda row: (
                rank.get(row["test_name"], len(order_pref)),
                department_priority_rank(row["test_department"]),
                row["id"],
            ),
        )
    else:
        order_tests = sorted(
            order_tests,
            key=lambda row: (department_priority_rank(row["test_department"]), row["id"]),
        )

    # تجنّب فتح تقرير "لطاخة الدم" مرتين لو الزيارة فيها BF وRETIC كتحليلين
    # منفصلين (بدل BFRETIC الموحّد) — print_report أصلاً يدمجهم بتقرير واحد
    # لو فتحت أي وحدة منهم (انظر BF_RETIC_LINK)، فنكتفي هنا برابط واحد بس.
    if any((_o["test_code"] or "") == "CBC" for _o in order_tests):   # v80: ESR يطلع داخل تقرير CBC
        order_tests = [_o for _o in order_tests if not _v80_is_esr(_o["test_code"], _o["test_name"])]
    seen_codes = set()
    reports = []
    for ot in order_tests:
        code = ot["test_code"]
        if code in BF_RETIC_LINK and BF_RETIC_LINK[code] in seen_codes:
            continue
        seen_codes.add(code)
        reports.append({"order_test_id": ot["id"], "test_name": ot["test_name"]})

    return render_template("front_desk/print_results_bundle.html", visit=visit, reports=reports)


# يبني ملف HTML واحد مدمج من كل التقاريـر المصممة الحقيقية (نفس تصميم
# كل تحليل بالضبط لو طُبع لحاله عبر print_report) لكل تحليل مكتمل بهذي
# الزيارة — يُستخدم لتوليد PDF واحد (أرشفة/واتساب) بدل الجدول العام
# البسيط القديم (print_visit_results)، الذي لا يعكس تصميم أي تقرير.
# نفس منطق الترتيب ودمج Blood Film/Retic المستخدم بصفحة "طباعة كل
# النتائج المكتملة" (print_visit_results_bundle فوق) بالضبط، حتى يطابق
# ملف الـPDF المُرسَل/المؤرشف شكل وترتيب نفس التقارير المعروضة هناك.
# يرجّع None لو ما فيه أي تحليل مكتمل بعد (أو تعذّر توليد أي تقرير منها).
def _render_report_for_merge(otid):
    """يرجّع ("ok", html) أو ("error", traceback) أو ("skip", None) لتقرير تحليل واحد، ليُدمج بصفحة
    مدمجة. الأخطاء كانت تُتجاهل بصمت فيظهر "لا توجد نتائج" — صارت تظهر للمستخدم ومسجلة بـ error_log.txt."""
    try:
        r = _print_report_impl(otid)
    except Exception:
        import traceback
        tb = traceback.format_exc()
        try:
            with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "error_log.txt"), "a", encoding="utf-8") as f:
                f.write("\n" + "=" * 80 + "\n" + datetime.now().isoformat(timespec="seconds")
                        + f"  (merged print) order_test_id={otid}\n" + tb)
        except Exception:
            pass
        return ("error", tb)
    if isinstance(r, tuple):
        r = r[0]
    if hasattr(r, "get_data"):
        if getattr(r, "status_code", 200) != 200:
            return ("skip", None)
        r = r.get_data(as_text=True)
    if not isinstance(r, str):
        return ("skip", None)
    return ("ok", r)


def _collect_report_bodies(order_test_ids):
    """يجمع <head> واحد + أقسام <body> لتقارير التحاليل المعطاة (بنفس ترتيبها) لدمجها بصفحة وحدة."""
    db = get_db()
    head_html = None
    body_sections = []
    for otid in order_test_ids:
        kind, val = _render_report_for_merge(otid)
        if kind == "skip":
            continue
        page_break = "" if not body_sections else ' style="page-break-before:always;"'
        if kind == "error":
            nm = db.execute("SELECT td.name n FROM order_tests ot JOIN test_definitions td ON td.id=ot.test_definition_id "
                            "WHERE ot.id=?", (otid,)).fetchone()
            body_sections.append(
                f'<div{page_break}><div dir="rtl" style="border:2px solid #C0392B;background:#FDECEA;padding:14px;margin:14px;'
                f'font-family:Tahoma,Arial;">❌ تعذّر طباعة تقرير <b>{escape(nm["n"] if nm else str(otid))}</b> — '
                f'صوّر هذا النص وأرسله:<pre style="direction:ltr;text-align:left;white-space:pre-wrap;font-size:11px;">'
                f'{escape(val)}</pre></div></div>')
            continue
        head_match = re.search(r"<head\b[^>]*>(.*?)</head>", val, re.S)
        body_match = re.search(r"<body\b[^>]*>(.*?)</body>", val, re.S)
        if not body_match:
            continue
        if head_html is None and head_match:
            head_html = head_match.group(1)
        body_sections.append(f"<div{page_break}>{body_match.group(1)}</div>")
    return head_html, body_sections


def _build_combined_designed_reports_html(visit_id):
    db = get_db()
    order_tests = db.execute(
        "SELECT ot.id, ot.status, td.code as test_code, td.name as test_name, td.department as test_department "
        "FROM order_tests ot JOIN orders o ON o.id = ot.order_id "
        "JOIN test_definitions td ON td.id = ot.test_definition_id "
        "WHERE o.visit_id=? AND ot.status IN ('Completed', 'Verified') ORDER BY ot.id",
        (visit_id,),
    ).fetchall()
    order_pref_raw = get_setting(db, "results_entry_test_order", "")
    order_pref = [ln.strip() for ln in order_pref_raw.splitlines() if ln.strip()]
    if order_pref:
        rank = {name: i for i, name in enumerate(order_pref)}
        order_tests = sorted(
            order_tests,
            key=lambda row: (
                rank.get(row["test_name"], len(order_pref)),
                department_priority_rank(row["test_department"]),
                row["id"],
            ),
        )
    else:
        order_tests = sorted(
            order_tests,
            key=lambda row: (department_priority_rank(row["test_department"]), row["id"]),
        )

    if any((_o["test_code"] or "") == "CBC" for _o in order_tests):   # v80: ESR يطلع داخل تقرير CBC
        order_tests = [_o for _o in order_tests if not _v80_is_esr(_o["test_code"], _o["test_name"])]
    seen_codes = set()
    order_test_ids = []
    for ot in order_tests:
        code = ot["test_code"]
        if code in BF_RETIC_LINK and BF_RETIC_LINK[code] in seen_codes:
            continue
        seen_codes.add(code)
        order_test_ids.append(ot["id"])

    head_html, body_sections = _collect_report_bodies(order_test_ids)
    if not body_sections:
        return None
    return (
        "<!DOCTYPE html><html lang=\"ar\" dir=\"rtl\"><head>"
        + (head_html or "")
        + "</head><body>"
        + "".join(body_sections)
        + "</body></html>"
    )


# الجدول الموحّد: يدمج نتائج زيارة أو أكثر (عادة زيارة قديمة + الزيارة الجديدة)
# بصفحة واحدة، صف لكل باراميتر وعمود لكل زيارة، حتى تتضح مقارنة النتائج عبر
# الزمن دون الحاجة لنسخ أي بيانات فعليًا داخل قاعدة البيانات.
@app.route("/front-desk/visits/combined")
@login_required
def combined_visits_report():
    ids_param = request.args.get("visit_ids", "")
    visit_ids = [int(x) for x in ids_param.split(",") if x.strip().isdigit()]
    if not visit_ids:
        return "لم يتم تحديد أي زيارات لعرضها بجدول موحّد.", 400
    db = get_db()
    placeholders = ",".join("?" * len(visit_ids))
    visits = db.execute(
        f"SELECT v.*, p.full_name, p.age, p.age_unit, p.gender, rc.name as referral_center_name FROM visits v "
        f"JOIN patients p ON p.id = v.patient_id "
        f"LEFT JOIN referral_centers rc ON rc.id = v.referral_center_id "
        f"WHERE v.id IN ({placeholders}) "
        f"ORDER BY v.created_at ASC",
        visit_ids,
    ).fetchall()
    if not visits:
        return "Not found", 404
    # إذا أي زيارة من الزيارات المدموجة بهذا الجدول أصلها نموذج وارد من
    # مختبر آخر، نعرض نفس العبارة الانكليزية أسفل الجدول (بدون ذكر اسم
    # المختبر بأي مكان).
    from_other_lab = any(
        v["referral_center_id"] and v["referral_center_name"] not in (None, "", "Walk-in") for v in visits
    )

    param_order = []
    param_rows = {}
    for v in visits:
        order_tests = db.execute(
            "SELECT ot.id FROM order_tests ot JOIN orders o ON o.id = ot.order_id WHERE o.visit_id=?",
            (v["id"],),
        ).fetchall()
        for ot in order_tests:
            results = db.execute(
                "SELECT r.*, tp.name as param_name, tp.unit FROM results r "
                "JOIN test_parameters tp ON tp.id = r.test_parameter_id WHERE r.order_test_id=?",
                (ot["id"],),
            ).fetchall()
            for r in results:
                key = r["param_name"]
                if key not in param_rows:
                    param_rows[key] = {"unit": r["unit"], "values": {}}
                    param_order.append(key)
                display_value = r["value_text"] if r["value_text"] else r["value_numeric"]
                param_rows[key]["values"][v["id"]] = {"value": display_value, "flag": r["flag"]}

    return render_template("front_desk/combined_report.html", visits=visits,
                            param_order=param_order, param_rows=param_rows, patient=visits[0],
                            from_other_lab=from_other_lab)


def period_breakdown(db, group_len, base_where, base_params):
    """يجمع الزيارات حسب فترة زمنية (يوم أو شهر) — يرجع صفوف فيها الدخل
    والصرفيات والصافي لكل فترة فرعية، بالإضافة إلى إجمالي الفترة كاملة.
    group_len: طول substr(created_at) المستخدم للتجميع (10=يوم، 7=شهر).
    base_where/base_params: شرط SQL لتحديد الفترة الكبيرة (مثلاً شهر معين أو سنة معينة).

    أي تحليل معلَّم "مجاني" (fee_waived=1) يُستثنى بالكامل من "revenue" هنا
    -- سواء كان معلَّم "يظهر بالسجل" أو "مخفي عنه" (hidden_from_log لا
    علاقة له بالمبلغ إطلاقًا، فقط يتحكم هل اسم التحليل يظهر بعمود
    التحاليل بصفحة daily_report أم لا -- راجع daily_report أدناه).

    expenses هنا يبقى بالمعنى القديم تمامًا (صرفيات + أجور الفاحصين مجموعة
    سوا) — أي قالب موجود يعرضه مباشرة ما ينكسر ولا تتغيّر قيمته. أضفنا
    examining_fees كحقل جديد إضافي بس، يعرض أجور الأطباء الفاحصين لحالها
    (المطلوب: "تُذكر بصفحات الحسابات").
    """
    revenue_rows = db.execute(
        f"SELECT substr(v.created_at,1,{group_len}) as period, "
        f"COALESCE(SUM(COALESCE(ot.price, td.price)),0) as revenue, COUNT(DISTINCT v.id) as visits_count "
        f"FROM visits v JOIN orders o ON o.visit_id=v.id JOIN order_tests ot ON ot.order_id=o.id "
        f"JOIN test_definitions td ON td.id=ot.test_definition_id "
        f"WHERE (ot.fee_waived IS NULL OR ot.fee_waived=0) AND {base_where} GROUP BY period", base_params,
    ).fetchall()
    expense_rows = db.execute(
        f"SELECT substr(v.created_at,1,{group_len}) as period, "
        f"COALESCE(SUM(v.expenses),0) as other_expenses, "
        f"COALESCE(SUM(v.examining_doctor_fee),0) as examining_fees "
        f"FROM visits v WHERE {base_where} GROUP BY period", base_params,
    ).fetchall()
    # forwarded_rows (المطلوب 3): كلفة أي تحليل انسحبت عينته بمختبرك لكن
    # أُرسلت فعليًا لمختبر آخر لإجرائها (راجع order_tests.forwarded_cost
    # بـdatabase.py) -- تُجمع هنا حسب نفس الفترة وتُضاف لـ"other_expenses"
    # تلقائيًا، بدون أي حاجة لإدخالها يدويًا بحقل visits.expenses.
    forwarded_rows = db.execute(
        f"SELECT substr(v.created_at,1,{group_len}) as period, "
        f"COALESCE(SUM(ot.forwarded_cost),0) as forwarded_cost "
        f"FROM visits v JOIN orders o ON o.visit_id=v.id JOIN order_tests ot ON ot.order_id=o.id "
        f"WHERE {base_where} GROUP BY period", base_params,
    ).fetchall()
    forwarded_by_period = {r["period"]: (r["forwarded_cost"] or 0) for r in forwarded_rows}
    data = {}
    for r in revenue_rows:
        data[r["period"]] = {"period": r["period"], "revenue": r["revenue"],
                              "visits_count": r["visits_count"], "expenses": 0.0, "examining_fees": 0.0}
    for r in expense_rows:
        data.setdefault(r["period"], {"period": r["period"], "revenue": 0.0,
                                       "visits_count": 0, "expenses": 0.0, "examining_fees": 0.0})
        # "expenses" يبقى بالضبط بنفس معناه القديم (المجموع الكلي) حتى ما
        # ينكسر أي قالب موجود يعرضه مباشرة — examining_fees إضافة جديدة
        # جنبه بس، مو بديلة عنه. forwarded تُضاف هنا أيضًا لنفس "expenses"
        # الإجمالي (نفس منطق examining_fees تمامًا).
        forwarded_here = forwarded_by_period.get(r["period"], 0)
        data[r["period"]]["expenses"] = r["other_expenses"] + r["examining_fees"] + forwarded_here
        data[r["period"]]["examining_fees"] = r["examining_fees"]
    # v65: صرفيات المختبر العامة (صفحة المصروفات) تُضاف لنفس عمود الصرفيات
    try:
        _ensure_lab_expenses_table(db)
        _lab = db.execute(
            f"SELECT substr(e.expense_date,1,{group_len}) AS period, COALESCE(SUM(e.amount),0) AS amt "
            f"FROM lab_expenses e WHERE {base_where.replace('v.created_at', 'e.expense_date')} GROUP BY period", base_params).fetchall()
    except Exception:
        _lab = []
    for r in _lab:
        data.setdefault(r["period"], {"period": r["period"], "revenue": 0.0, "visits_count": 0,
                                       "expenses": 0.0, "examining_fees": 0.0})
        data[r["period"]]["expenses"] += float(r["amt"] or 0)
    rows = sorted(data.values(), key=lambda x: x["period"])
    for r in rows:
        r["net"] = r["revenue"] - r["expenses"]
    totals = {
        "revenue": sum(r["revenue"] for r in rows),
        "expenses": sum(r["expenses"] for r in rows),
        "examining_fees": sum(r["examining_fees"] for r in rows),
        "visits_count": sum(r["visits_count"] for r in rows),
    }
    totals["net"] = totals["revenue"] - totals["expenses"]
    return rows, totals


_COMMON_TEST_ABBR = [
    ("general urine", "GUE"), ("urine general", "GUE"), ("general stool", "GSE"), ("stool general", "GSE"),
    ("seminal fluid", "SFA"), ("semen", "SFA"), ("complete blood count", "CBC"), ("full blood count", "CBC"),
    ("fasting blood sugar", "FBS"), ("fasting blood glucose", "FBS"), ("random blood sugar", "RBS"),
    ("random blood glucose", "RBS"), ("hemoglobin a1c", "HbA1c"), ("glycated hemoglobin", "HbA1c"),
    ("glycosylated", "HbA1c"), ("blood film", "BF"), ("reticulocyte", "Retic"), ("erythrocyte sedimentation", "ESR"),
    ("blood urea", "B.Urea"), ("serum creatinine", "S.Creat"), ("creatinine", "Creat"), ("uric acid", "U.A"),
    ("total bilirubin", "T.Bil"), ("direct bilirubin", "D.Bil"), ("alkaline phosphatase", "ALP"),
    ("prothrombin time", "PT"), ("partial thromboplastin", "PTT"), ("bleeding time", "BT"), ("clotting time", "CT"),
    ("thyroid stimulating", "TSH"), ("vitamin d", "Vit.D"), ("vitamin b12", "B12"), ("c-reactive", "CRP"),
    ("rheumatoid factor", "RF"), ("blood group", "ABO"), ("bone marrow aspirat", "BMA"),
    ("hepatitis b surface", "HBsAg"), ("hiv", "HIV"), ("widal", "Widal"), ("h. pylori", "H.pylori"),
]


def _abbr_test(name, short_name=None, code=None):
    """اسم التحليل المختصر لعمود "التحاليل" بالتقرير اليومي: short_name إن وُجد، وإلا المختصر المتعارف عليه
    (جدول أعلاه)، وإلا كود التحليل لو قصير، وإلا الأحرف الأولى من الاسم."""
    sn = (short_name or "").strip()
    if sn:
        return sn
    low = (name or "").lower()
    for key, ab in _COMMON_TEST_ABBR:
        if key in low:
            return ab
    cd = (code or "").strip()
    if cd and len(cd) <= 8 and not cd.isdigit():
        return cd
    words = [w for w in re.split(r"[\s/\-_,()]+", name or "") if w]
    if len(words) >= 2:
        return "".join(w[0].upper() for w in words[:6] if w[0].isalnum())
    return (name or "")[:10]



@app.route("/reports/test-analysis")
@login_required
def test_analysis_report():
    """v65: تقرير تحليل التحاليل — ابحث بنوع تحليل (مثل CBC) ضمن فترة: كم ورد، من الطبيب المرسل، المختبر المرسل
    إليه/منه، الفاحص، السعر، وهل واصل أو باقي. يشتغل مع كل الفترات (يوم/شهر/ربع/نصف/سنة/مخصص)."""
    db = get_db()
    today = date.today()
    d_from = (request.args.get("from") or today.replace(day=1).isoformat()).strip()
    d_to = (request.args.get("to") or today.isoformat()).strip()
    q_test = (request.args.get("test") or "").strip()
    q_doc = (request.args.get("doctor") or "").strip()
    q_lab = (request.args.get("lab") or "").strip()
    status = (request.args.get("status") or "all").strip()
    where = ["substr(v.created_at,1,10) BETWEEN ? AND ?", "ot.status NOT IN ('Cancelled','Canceled','Rejected')"]
    params = [d_from, d_to]
    if q_test:
        where.append("(td.name LIKE ? OR td.short_name LIKE ? OR td.code LIKE ?)")
        params += [f"%{q_test}%"] * 3
    if q_doc:
        where.append("(rd.full_name LIKE ? OR od.full_name LIKE ?)")
        params += [f"%{q_doc}%"] * 2
    if q_lab:
        where.append("ot.forwarded_lab_name LIKE ?")
        params.append(f"%{q_lab}%")
    rows_db = db.execute(
        "SELECT v.id AS visit_id, v.registration_number AS reg, substr(v.created_at,1,10) AS day, p.full_name AS patient, "
        "td.name AS test_name, td.short_name, td.code AS test_code, COALESCE(ot.price, td.price) AS price, ot.fee_waived, "
        "COALESCE(rd.full_name, od.full_name, '') AS ref_doctor, COALESCE(v.examining_doctor,'') AS exam_doctor, "
        "COALESCE(ot.forwarded_lab_name,'') AS fwd_lab, COALESCE(ot.forwarded_cost,0) AS fwd_cost, "
        "inv.total_amount AS inv_total, inv.discount_amount AS inv_disc, inv.paid_amount AS inv_paid "
        "FROM order_tests ot JOIN orders o ON o.id = ot.order_id JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id JOIN test_definitions td ON td.id = ot.test_definition_id "
        "LEFT JOIN doctors rd ON rd.id = v.doctor_id LEFT JOIN doctors od ON od.id = ot.doctor_id "
        "LEFT JOIN invoices inv ON inv.visit_id = v.id "
        "WHERE " + " AND ".join(where) + " ORDER BY v.created_at DESC, ot.id LIMIT 5000", params).fetchall()
    rows, by_doc, by_lab = [], {}, {}
    total_amount = total_fwd = 0.0
    for r in rows_db:
        price = 0.0 if r["fee_waived"] else float(r["price"] or 0)
        if r["inv_total"] is not None:
            remaining = float(r["inv_total"] or 0) - float(r["inv_disc"] or 0) - float(r["inv_paid"] or 0)
        else:
            remaining = 0.0
        if status == "remaining" and remaining <= 0:
            continue
        if status == "paid" and remaining > 0:
            continue
        rows.append({"visit_id": r["visit_id"], "day": r["day"], "reg": r["reg"], "patient": r["patient"],
                     "test": r["short_name"] or r["test_name"], "ref_doctor": r["ref_doctor"] or "-",
                     "exam_doctor": r["exam_doctor"] or "-", "fwd_lab": r["fwd_lab"] or "-", "fwd_cost": r["fwd_cost"],
                     "price": price, "waived": bool(r["fee_waived"]), "remaining": remaining})
        total_amount += price
        total_fwd += float(r["fwd_cost"] or 0)
        dk = r["ref_doctor"] or "(بدون طبيب)"
        d = by_doc.setdefault(dk, {"n": 0, "sum": 0.0}); d["n"] += 1; d["sum"] += price
        if r["fwd_lab"]:
            l = by_lab.setdefault(r["fwd_lab"], {"n": 0, "cost": 0.0}); l["n"] += 1; l["cost"] += float(r["fwd_cost"] or 0)
    doctors = [x["full_name"] for x in db.execute("SELECT full_name FROM doctors ORDER BY full_name").fetchall()]
    return render_template("reports/test_analysis.html", rows=rows, d_from=d_from, d_to=d_to, q_test=q_test, q_doc=q_doc,
                           q_lab=q_lab, status=status, total_amount=total_amount, total_fwd=total_fwd,
                           by_doc=sorted(by_doc.items(), key=lambda kv: -kv[1]["n"]),
                           by_lab=sorted(by_lab.items(), key=lambda kv: -kv[1]["n"]), doctors=doctors,
                           truncated=len(rows_db) >= 5000)


@app.route("/reports/daily")
@login_required
def daily_report():
    db = get_db()
    report_date = request.args.get("date", date.today().isoformat())
    visits = db.execute(
        "SELECT v.id, v.registration_number, v.examining_doctor, v.expenses, v.examining_doctor_fee, "
        "rd.full_name as referring_doctor_name, v.tests_display, "
        "v.notes, p.full_name, p.gender, p.age FROM visits v "
        "JOIN patients p ON p.id = v.patient_id "
        "LEFT JOIN doctors rd ON rd.id = v.doctor_id "
        "WHERE substr(v.created_at,1,10)=? ORDER BY v.registration_number",
        (report_date,),
    ).fetchall()

    rows = []
    grand_total = 0
    grand_expenses = 0
    grand_general_expenses = 0
    grand_forwarded_total = 0
    grand_examining_fees = 0
    grand_remaining = 0
    for v in visits:
        # نجيب كل التحاليل بدون أي فلترة أول (نحتاج fee_waived و
        # hidden_from_log لحالهم لنفصل بين "المبلغ" و"العرض بالعمود"):
        # - fee_waived=1: يُستثنى سعره من "total" (الدخل) بكل الأحوال،
        #   سواء ظاهر أو مخفي بالسجل.
        # - hidden_from_log=1: يُستثنى اسمه من عمود "التحاليل" (ما يظهر
        #   إطلاقًا بهذا التقرير)، مع بقاء نتيجته محفوظة بقاعدة البيانات.
        items = db.execute(
            "SELECT td.name, td.short_name, td.code as test_code, td.is_examining_test, "
            "COALESCE(ot.price, td.price) as price, ot.doctor_id, "
            "ot.fee_waived, ot.hidden_from_log, ot.forwarded_cost, ot.forwarded_lab_name FROM order_tests ot "
            "JOIN test_definitions td ON td.id = ot.test_definition_id "
            "JOIN orders o ON o.id = ot.order_id WHERE o.visit_id=?",
            (v["id"],),
        ).fetchall()
        visible_items = [i for i in items if not i["hidden_from_log"]]
        _auto_tests = ", ".join(
            _abbr_test(i["name"], i["short_name"], i["test_code"]) + (" (مجاني)" if i["fee_waived"] else "")
            for i in visible_items
        )
        # تعديل يدوي من موظف المختبر على عمود التحاليل (visits.tests_display) يتقدّم على المختصر التلقائي
        test_names = (v["tests_display"] or "").strip() or _auto_tests
        total = sum((i["price"] or 0) for i in items if not i["fee_waived"])
        grand_total += total
        # forwarded_cost لكل تحليل بهذي الزيارة أُرسل فعليًا لمختبر آخر
        # (المطلوب 3) -- يُضاف لصرفيات هذي الزيارة بالتقرير اليومي، بنفس
        # طريقة period_breakdown() أعلاه المستخدمة بالتقارير الشهرية/نصف
        # السنوية/السنوية (كانت ناقصة هون فقط بالتقرير اليومي).
        # الفحوصات المرسلة فعليًا لمختبر آخر + اجورها لهذي الزيارة تحديدًا
        # (المطلوب: عمود "الفحوصات المرسلة لمختبرات اخرى + اجورها" -- يعرض
        # اسم كل تحليل مُرسَل + اسم المختبر + كلفته، بدل رقم إجمالي فقط).
        forwarded_items = [i for i in items if (i["forwarded_cost"] or 0)]
        forwarded_display = ", ".join(
            f"{_abbr_test(i['name'], i['short_name'], i['test_code'])} → {i['forwarded_lab_name'] or '-'} ({i['forwarded_cost']:.0f})"
            for i in forwarded_items
        )
        forwarded_total = sum((i["forwarded_cost"] or 0) for i in items)
        general_expenses = v["expenses"] or 0
        row_expenses = general_expenses + forwarded_total
        row_examining_fee = v["examining_doctor_fee"] or 0
        grand_expenses += row_expenses
        grand_general_expenses += general_expenses
        grand_forwarded_total += forwarded_total
        grand_examining_fees += row_examining_fee
        doctor_names = set()
        for i in visible_items:
            if i["doctor_id"]:
                d = db.execute("SELECT full_name FROM doctors WHERE id=?", (i["doctor_id"],)).fetchone()
                if d:
                    doctor_names.add(d["full_name"])
        # دكتور المختبر الفاحص + نوع التحليل بين قوسين بنفس الحقل (المطلوب 2)
        # -- نفس المعيار الكانوني المستخدم أصلاً بـshow_exam_signature أعلاه
        # (test_code ضمن EXAM_SIGNATURE_TEST_CODES أو is_examining_test=1)
        # حتى تبقى "أي تحليل يحتاج توقيع دكتور فاحص" معرَّفة بمكان واحد
        # بمنطق واحد بكل التطبيق، بدل معيارين مختلفين لنفس الفكرة.
        exam_names = [
            _abbr_test(i["name"], i["short_name"], i["test_code"]) for i in visible_items
            if i["test_code"] in EXAM_SIGNATURE_TEST_CODES or bool(i["is_examining_test"])
        ]
        examining_doctor_display = v["examining_doctor"] or "-"
        if v["examining_doctor"] and exam_names:
            examining_doctor_display = f"{v['examining_doctor']} ({', '.join(exam_names)})"

        # عمود "الباقي": المبلغ المتبقي فعليًا بعد خصم أي دفعة/خصم مسجّلة
        # على فاتورة هذي الزيارة -- بنفس معادلة "المتبقي" بالفاتورة المفردة
        # (total_amount - discount_amount - paid_amount). لو ما فيه فاتورة
        # مسجَّلة أصلاً لهذي الزيارة (حالة نادرة)، الباقي = سعر التحاليل
        # الكلي (total) بما إنه ما انسجّل أي دفع/خصم بعد.
        invoice = db.execute(
            "SELECT total_amount, discount_amount, paid_amount FROM invoices WHERE visit_id=?",
            (v["id"],),
        ).fetchone()
        if invoice:
            remaining = (invoice["total_amount"] or 0) - (invoice["discount_amount"] or 0) - (invoice["paid_amount"] or 0)
        else:
            remaining = total
        grand_remaining += remaining

        rows.append({
            "id": v["id"], "reg": v["registration_number"], "name": v["full_name"],
            "gender": v["gender"] or "-", "age": v["age"] if v["age"] is not None else "-",
            "referring_doctor": v["referring_doctor_name"] or "-",  # الطبيب المرسل
            "tests": test_names, "total": total, "doctors": ", ".join(doctor_names),
            "examining_doctor": examining_doctor_display,
            "expenses": row_expenses + row_examining_fee,  # توافق قديم: أي قالب لسا يستخدم "expenses" وحده يشتغل متل قبل تمامًا
            "expenses_only": row_expenses,
            "general_expenses": general_expenses,  # الصرفيات العامة لحالها (بدون أجور الفاحص ولا كلفة الإرسال)
            "examining_fee": row_examining_fee,
            "forwarded_display": forwarded_display,  # الفحوصات المرسلة لمختبرات اخرى + اجورها (تفصيلي)
            "forwarded_total": forwarded_total,
            "net": total - (row_expenses + row_examining_fee),  # صافي الوارد الكلي لهذي الزيارة تحديدًا
            "remaining": remaining,
            "notes": v["notes"] or "",
        })

    grand_total_expenses = grand_expenses + grand_examining_fees
    try:
        _ensure_lab_expenses_table(db)
        lab_exp_rows = db.execute("SELECT kind, amount, note FROM lab_expenses WHERE expense_date=? ORDER BY id", (report_date,)).fetchall()
    except Exception:
        lab_exp_rows = []
    lab_exp_total = sum(r["amount"] or 0 for r in lab_exp_rows)
    lab_exp_text = "، ".join(f"{r['kind']} ({r['amount']:.0f})" for r in lab_exp_rows)
    return render_template("front_desk/daily_report.html", rows=rows, report_date=report_date,
                            lab_exp_total=lab_exp_total, lab_exp_text=lab_exp_text,
                            grand_total=grand_total, grand_expenses=grand_total_expenses,
                            grand_expenses_only=grand_expenses, grand_examining_fees=grand_examining_fees,
                            grand_general_expenses=grand_general_expenses,
                            grand_forwarded_total=grand_forwarded_total,
                            grand_net=grand_total - grand_total_expenses - lab_exp_total, grand_remaining=grand_remaining)



def _ensure_lab_expenses_table(db):
    db.execute("CREATE TABLE IF NOT EXISTS lab_expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, expense_date TEXT NOT NULL, "
               "kind TEXT NOT NULL, amount REAL NOT NULL DEFAULT 0, note TEXT, created_at TEXT, created_by INTEGER)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_lab_expenses_date ON lab_expenses(expense_date)")


@app.route("/accounts/expenses", methods=["GET", "POST"])
@login_required
def lab_expenses_page():
    """v65: صرفيات المختبر العامة (مو مرتبطة بمريض): تاريخ + نوع الصرف + مبلغ. تُخصم من الإيراد بالتقارير اليومية/الشهرية/الربعية/النصف سنوية/السنوية."""
    db = get_db()
    _ensure_lab_expenses_table(db)
    if request.method == "POST":
        act = request.form.get("act") or "add"
        if act == "delete":
            db.execute("DELETE FROM lab_expenses WHERE id=?", (request.form.get("id"),))
            db.commit()
            flash("تم حذف الصرف.")
        else:
            kind = (request.form.get("kind") or "").strip()
            try:
                amount = float((request.form.get("amount") or "0").replace(",", ""))
            except ValueError:
                amount = 0
            d = (request.form.get("date") or date.today().isoformat())[:10]
            if kind and amount > 0:
                db.execute("INSERT INTO lab_expenses (expense_date, kind, amount, note, created_at, created_by) VALUES (?,?,?,?,?,?)",
                           (d, kind, amount, (request.form.get("note") or "").strip(),
                            datetime.now().isoformat(timespec="seconds"), session.get("user_id")))
                db.commit()
                log_action("AddLabExpense", "lab_expenses", 0, f"{kind}:{amount}")
                flash("تمت إضافة الصرف.")
            else:
                flash("اكتب نوع الصرف ومبلغًا أكبر من صفر.")
        return redirect(url_for("lab_expenses_page", period=request.args.get("period") or "month", d=d if act != "delete" else request.args.get("d", "")))
    today = date.today()
    period = request.args.get("period") or "month"
    base = (request.args.get("d") or today.isoformat())[:10]
    y, m = base[:4], base[5:7] or "01"
    if period == "day":
        where, params, title = "expense_date=?", (base,), f"يوم {base}"
    elif period == "half":
        h2 = int(m or 1) > 6
        lo, hi = (f"{y}-07-01", f"{y}-12-31") if h2 else (f"{y}-01-01", f"{y}-06-30")
        where, params, title = "expense_date BETWEEN ? AND ?", (lo, hi), f"{y} — {'النصف الثاني' if h2 else 'النصف الأول'}"
    elif period == "year":
        where, params, title = "substr(expense_date,1,4)=?", (y,), f"سنة {y}"
    else:
        period = "month"
        where, params, title = "substr(expense_date,1,7)=?", (f"{y}-{m}",), f"شهر {y}-{m}"
    rows = db.execute("SELECT * FROM lab_expenses WHERE " + where + " ORDER BY expense_date DESC, id DESC", params).fetchall()
    total = sum(r["amount"] or 0 for r in rows)
    by_kind = {}
    for r in rows:
        by_kind[r["kind"]] = by_kind.get(r["kind"], 0) + (r["amount"] or 0)
    kinds = [r["kind"] for r in db.execute("SELECT kind, COUNT(*) c FROM lab_expenses GROUP BY kind ORDER BY c DESC LIMIT 40")]
    from flask import render_template_string
    return render_template_string(
        "{% extends 'base.html' %}{% block page_title %}صرفيات المختبر{% endblock %}{% block content %}"
        "<style>.ex-t{width:100%;border-collapse:collapse}.ex-t th,.ex-t td{border:1px solid #E2E8F0;padding:7px 9px;font-size:13px;text-align:right}"
        ".ex-t th{background:#205072;color:#fff}.ex-q a{text-decoration:none;background:#F3F6F8;color:#205072;padding:5px 11px;border-radius:6px;"
        "border:1px solid #E2E8F0;font-size:12px;margin-inline-end:4px}.ex-q a.on{background:#205072;color:#fff}"
        ".ex-f{display:flex;gap:8px;flex-wrap:wrap;align-items:end;margin:10px 0}.ex-f label{display:flex;flex-direction:column;font-size:12px;gap:3px}"
        ".ex-f input{padding:7px 9px}@media print{.no-print{display:none}}</style>"
        "<div class='card'><h3 style='margin:0 0 8px'>💸 صرفيات المختبر العامة</h3>"
        "<div class='ex-q no-print'>"
        "{% for k,l in [('day','يومي'),('month','شهري'),('half','نصف سنوي'),('year','سنوي')] %}"
        "<a class='{{ 'on' if period==k }}' href='?period={{ k }}&d={{ base }}'>{{ l }}</a>{% endfor %}"
        "<form method='get' style='display:inline'><input type='hidden' name='period' value='{{ period }}'>"
        "<input type='date' name='d' value='{{ base }}' onchange='this.form.submit()'></form>"
        "<button class='btn small secondary' onclick='window.print()' type='button'>🖨 طباعة</button></div>"
        "<form method='post' class='ex-f no-print'>"
        "<label>التاريخ<input type='date' name='date' value='{{ today }}'></label>"
        "<label>نوع الصرف<input type='text' name='kind' list='exKinds' placeholder='مثال: شراء منظفات' required></label>"
        "<datalist id='exKinds'>{% for k in kinds %}<option value='{{ k }}'>{% endfor %}</datalist>"
        "<label>المبلغ<input type='number' name='amount' min='0' step='any' required style='width:130px'></label>"
        "<label>ملاحظة (اختياري)<input type='text' name='note'></label>"
        "<button class='btn' type='submit'>➕ إضافة</button></form>"
        "<h4 style='margin:10px 0 4px'>{{ title }} — الإجمالي: <b>{{ '%.0f'|format(total) }}</b></h4>"
        "{% if by_kind %}<p style='font-size:13px;color:#475569'>حسب النوع: "
        "{% for k,v in by_kind.items() %}{{ k }} ({{ '%.0f'|format(v) }}){{ '، ' if not loop.last }}{% endfor %}</p>{% endif %}"
        "<table class='ex-t'><thead><tr><th>التاريخ</th><th>نوع الصرف</th><th>المبلغ</th><th>ملاحظة</th><th class='no-print'></th></tr></thead><tbody>"
        "{% for r in rows %}<tr><td>{{ r.expense_date }}</td><td>{{ r.kind }}</td><td>{{ '%.0f'|format(r.amount) }}</td><td>{{ r.note or '' }}</td>"
        "<td class='no-print'><form method='post' onsubmit=\"return confirm('حذف هذا الصرف؟')\">"
        "<input type='hidden' name='act' value='delete'><input type='hidden' name='id' value='{{ r.id }}'>"
        "<button class='btn small secondary'>🗑</button></form></td></tr>"
        "{% else %}<tr><td colspan='5' style='text-align:center;color:#64748B;padding:20px'>لا توجد صرفيات بهذي الفترة.</td></tr>{% endfor %}"
        "</tbody></table>"
        "<p style='font-size:12px;color:#64748B'>تُخصم هذي المبالغ من الوارد الكلي بالتقارير اليومية والشهرية والربعية والنصف سنوية والسنوية.</p></div>{% endblock %}",
        rows=rows, total=total, by_kind=by_kind, kinds=kinds, title=title, period=period, base=base, today=today.isoformat())


@app.route("/api/daily/edit", methods=["POST"])
@login_required
def api_daily_edit():
    """تعديل من صفحة الحسابات اليومية. التحاليل: لأي موظف مختبر. بقية الحقول: مسؤول/مشرف بكلمة مرور."""
    db = get_db()
    d = request.get_json(silent=True) or {}
    try:
        vid = int(d.get("visit_id"))
    except (TypeError, ValueError):
        return jsonify(ok=False, error="زيارة غير صالحة"), 400
    field = d.get("field")
    val = str(d.get("value", "")).strip()
    v = db.execute("SELECT id, patient_id FROM visits WHERE id=?", (vid,)).fetchone()
    if not v:
        return jsonify(ok=False, error="الزيارة غير موجودة"), 404
    if field != "tests":
        ok, err = _check_completed_result_gate(db, d)
        if not ok:
            return jsonify(ok=False, error=err), 403
    if field == "tests":
        db.execute("UPDATE visits SET tests_display=? WHERE id=?", (val or None, vid))
    elif field == "name":
        if not val:
            return jsonify(ok=False, error="الاسم فارغ"), 400
        db.execute("UPDATE patients SET full_name=? WHERE id=?", (val, v["patient_id"]))
    elif field == "gender":
        db.execute("UPDATE patients SET gender=? WHERE id=?", (val, v["patient_id"]))
    elif field == "age":
        try:
            a = float(val)
            a = int(a) if a == int(a) else a
        except ValueError:
            return jsonify(ok=False, error="عمر غير صالح"), 400
        db.execute("UPDATE patients SET age=? WHERE id=?", (a, v["patient_id"]))
    elif field == "notes":
        db.execute("UPDATE visits SET notes=? WHERE id=?", (val, vid))
    elif field == "expenses":
        try:
            x = float(val.replace(",", ""))
        except ValueError:
            return jsonify(ok=False, error="رقم غير صالح"), 400
        db.execute("UPDATE visits SET expenses=? WHERE id=?", (x, vid))
    else:
        return jsonify(ok=False, error="حقل غير مسموح"), 400
    db.commit()
    try:
        log_action("daily_edit", "visit", vid, f"{field} -> {val[:80]}")
    except Exception:
        pass
    return jsonify(ok=True, value=val)


@app.route("/reports/monthly")
@roles_required("admin", "accountant", "supervisor")
def monthly_report():
    db = get_db()
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    rows, totals = period_breakdown(db, 10, "substr(v.created_at,1,7)=?", (month,))
    return render_template("front_desk/monthly_report.html", rows=rows, totals=totals, month=month)


@app.route("/reports/half-year")
@roles_required("admin", "accountant", "supervisor")
def half_year_report():
    db = get_db()
    year = request.args.get("year", str(date.today().year))
    half = request.args.get("half", "1" if date.today().month <= 6 else "2")
    start_month, end_month = (1, 6) if half == "1" else (7, 12)
    rows, totals = period_breakdown(
        db, 7,
        "substr(v.created_at,1,4)=? AND CAST(substr(v.created_at,6,2) AS INTEGER) BETWEEN ? AND ?",
        (year, start_month, end_month),
    )
    return render_template("front_desk/half_year_report.html", rows=rows, totals=totals, year=year, half=half)


@app.route("/reports/annual")
@roles_required("admin", "accountant", "supervisor")
def annual_report():
    db = get_db()
    year = request.args.get("year", str(date.today().year))
    rows, totals = period_breakdown(db, 7, "substr(v.created_at,1,4)=?", (year,))
    return render_template("front_desk/annual_report.html", rows=rows, totals=totals, year=year)


# ============================================================================
# الحسابات الربع سنوية + صفحة "كل الحسابات" + البحث والتصدير
# (ميزة مستقلة طلبها المستخدم بمحادثة سابقة — راجع accounts_search.py)
# ============================================================================
@app.route("/reports/quarter")
@roles_required("admin", "accountant", "supervisor")
def quarter_report():
    db = get_db()
    year = request.args.get("year", str(date.today().year))
    quarter = request.args.get("quarter", str((date.today().month - 1) // 3 + 1))
    start_month, end_month = acs.quarter_bounds(year, quarter)
    rows, totals = period_breakdown(
        db, 7,
        "substr(v.created_at,1,4)=? AND CAST(substr(v.created_at,6,2) AS INTEGER) BETWEEN ? AND ?",
        (year, start_month, end_month),
    )
    return render_template("front_desk/quarter_report.html", rows=rows, totals=totals,
                            year=year, quarter=quarter)


@app.route("/reports/accounts")
@roles_required("admin", "accountant", "supervisor")
def accounts_hub():
    return render_template("front_desk/accounts_hub.html")


def _accounts_search_run(db, args):
    """منطق مشترك بين شاشة العرض وكلا رابطي التصدير — حتى نتائج الشاشة
    ونتائج الملف المُصدَّر يطابقان بعض دائمًا (بنفس المعاملات بالضبط)."""
    search_kind = args.get("kind", "basic")  # basic | doctor | lab | referral
    date_from, date_to = acs.resolve_date_range(args)
    test_ids = [int(x) for x in args.getlist("test_id") if x.strip().isdigit()]

    if search_kind == "doctor":
        doctor_name = (args.get("doctor_name") or "").strip()
        if not doctor_name:
            return search_kind, date_from, date_to, None
        result = acs.run_doctor_search(db, doctor_name, date_from, date_to, test_ids)
        return search_kind, date_from, date_to, result

    if search_kind == "lab":
        lab_name = (args.get("lab_name") or "").strip()
        if not lab_name:
            return search_kind, date_from, date_to, None
        result = acs.run_lab_search(db, lab_name, date_from, date_to, test_ids)
        return search_kind, date_from, date_to, result

    if search_kind == "referral":
        referring_doctor = (args.get("referring_doctor") or "").strip() or None
        result = acs.run_referral_search(db, date_from, date_to, test_ids, referring_doctor)
        return search_kind, date_from, date_to, result

    mode = args.get("result_mode", "counts")  # counts | names
    result = acs.run_basic_search(db, date_from, date_to, test_ids, mode)
    result["mode"] = mode
    return search_kind, date_from, date_to, result


@app.route("/reports/accounts/search")
@roles_required("admin", "accountant", "supervisor")
def accounts_search():
    db = get_db()
    has_query = bool(request.args)
    kind, date_from, date_to, result = _accounts_search_run(db, request.args) if has_query else (
        request.args.get("kind", "basic"), None, None, None)
    return render_template(
        "front_desk/accounts_search.html",
        kind=kind, date_from=date_from, date_to=date_to, result=result,
        has_query=has_query,
        test_choices=acs.get_test_choices(db),
        doctor_choices=acs.get_examining_doctor_names(db),
        lab_choices=acs.get_forwarded_lab_names(db),
        referring_doctor_choices=acs.get_referring_doctor_names(db),
        selected_test_ids=[int(x) for x in request.args.getlist("test_id") if x.strip().isdigit()],
        request_args=request.args,
    )


@app.route("/reports/accounts/search/export.xlsx")
@roles_required("admin", "accountant", "supervisor")
def accounts_search_export_xlsx():
    db = get_db()
    kind, date_from, date_to, result = _accounts_search_run(db, request.args)
    if result is None:
        flash("أكمل معايير البحث أولاً.")
        return redirect(url_for("accounts_search", **request.args))

    detail = request.args.get("detail", "full")  # full | short

    if kind == "doctor":
        if detail == "short":
            columns = [("test_name", "التحليل"), ("count", "العدد"),
                       ("rate", "أجر التحليل الواحد"), ("subtotal", "المجموع")]
            rows = result["by_test_total"]
            totals = {"test_name": "المجموع الكلي", "subtotal": result["total"]}
            sheet_title = f"{result['doctor_name']}-مختصر"
        else:
            columns = [("patient_name", "اسم المريض"), ("test_name", "التحليل"),
                       ("date", "التاريخ"), ("rate", "الأجر")]
            rows = [dict(r, date=acs.ddmmyyyy(r["date"])) for r in result["patient_rows"]]
            totals = {"patient_name": "المجموع الكلي", "rate": result["total"]}
            sheet_title = f"{result['doctor_name']}-تفصيلي"
        path = excel_export.export_rows_to_xlsx(columns, rows, sheet_title=sheet_title, totals_row=totals)
        safe_name = re.sub(r"[^\w\-]+", "_", result["doctor_name"])
        download_name = f"{safe_name}_{date_from}_{date_to}.xlsx"
    elif kind == "lab":
        columns = [("patient_name", "اسم المريض"), ("test_name", "التحليل"),
                   ("date", "التاريخ"), ("cost", "الكلفة")]
        rows = [dict(r, date=acs.ddmmyyyy(r["date"])) for r in result["rows"]]
        totals = {"patient_name": "المجموع الكلي", "cost": result["total_cost"]}
        path = excel_export.export_rows_to_xlsx(columns, rows, sheet_title=f"{result['lab_name']}", totals_row=totals)
        safe_name = re.sub(r"[^\w\-]+", "_", result["lab_name"])
        download_name = f"{safe_name}_{date_from}_{date_to}.xlsx"
    elif kind == "referral":
        columns = [("source_type_ar", "المصدر"), ("source_name", "الاسم"),
                   ("patient_count", "عدد المرضى"), ("visit_test_count", "عدد مرات التحليل"),
                   ("revenue", "المبلغ المُستحصَل")]
        source_type_ar = {"doctor": "طبيب مُرسِل", "center": "مختبر آخر", "direct": "مباشر"}
        rows = [dict(r, source_type_ar=source_type_ar[r["source_type"]]) for r in result["rows"]]
        totals = {"source_type_ar": "الإجمالي", "patient_count": result["total_patient_count"],
                   "visit_test_count": result["total_visit_test_count"], "revenue": result["total_revenue"]}
        sheet_title = result["doctor_filter"] or "كل مصادر الإحالة"
        path = excel_export.export_rows_to_xlsx(columns, rows, sheet_title=sheet_title, totals_row=totals)
        safe_name = re.sub(r"[^\w\-]+", "_", result["doctor_filter"] or "referral_sources")
        download_name = f"{safe_name}_{date_from}_{date_to}.xlsx"
    else:
        mode = result.get("mode", "counts")
        if mode == "counts":
            columns = [("test_name", "التحليل"), ("date", "التاريخ"), ("count", "العدد")]
            rows = [dict(r, date=acs.ddmmyyyy(r["date"])) for r in result["rows"]]
            totals = {"test_name": "المجموع الكلي", "count": result["total_count"]}
        elif detail == "short":
            columns = [("test_name", "التحليل"), ("date", "التاريخ"), ("price", "السعر")]
            rows = [dict(r, date=acs.ddmmyyyy(r["date"])) for r in result["rows"]]
            totals = {"test_name": "المجموع الكلي", "price": result["total_price"]}
        else:
            columns = [("patient_name", "اسم المريض"), ("age", "العمر"), ("gender", "الجنس"),
                       ("reg_no", "رقم التسجيل"), ("test_name", "التحليل"),
                       ("date", "التاريخ"), ("price", "السعر")]
            rows = [dict(r, date=acs.ddmmyyyy(r["date"])) for r in result["rows"]]
            totals = {"patient_name": "المجموع الكلي",
                      "price": result.get("total_price", result.get("total_count", 0))}
        path = excel_export.export_rows_to_xlsx(columns, rows, sheet_title="نتائج البحث", totals_row=totals)
        download_name = f"accounts_search_{date_from}_{date_to}.xlsx"

    log_action("Export", "accounts_search", 0, f"xlsx {kind} {date_from}..{date_to}")
    return send_file(path, as_attachment=True, download_name=download_name)


@app.route("/reports/accounts/search/export.pdf")
@roles_required("admin", "accountant", "supervisor")
def accounts_search_export_pdf():
    import pdf_export

    db = get_db()
    kind, date_from, date_to, result = _accounts_search_run(db, request.args)
    if result is None:
        flash("أكمل معايير البحث أولاً.")
        return redirect(url_for("accounts_search", **request.args))

    detail = request.args.get("detail", "full")
    html_content = render_template(
        "front_desk/print_accounts_search.html",
        kind=kind, date_from=date_from, date_to=date_to, result=result, detail=detail,
    )
    pdf_path = pdf_export.make_temp_pdf_path("accounts_search")
    try:
        pdf_export.html_to_pdf(html_content, request.url_root, pdf_path)
    except Exception as exc:
        flash(f"❌ تعذّر توليد ملف PDF: {exc}")
        return redirect(url_for("accounts_search", **request.args))

    log_action("Export", "accounts_search", 0, f"pdf {kind} {date_from}..{date_to}")
    name_part = result["doctor_name"] if kind == "doctor" else (
        result["lab_name"] if kind == "lab" else (
            (result["doctor_filter"] or "referral_sources") if kind == "referral" else "accounts_search"))
    safe_name = re.sub(r"[^\w\-]+", "_", name_part)
    download_name = f"{safe_name}_{date_from}_{date_to}.pdf"
    return send_file(pdf_path, as_attachment=True, download_name=download_name)



_CLOSE_BTN_RE = re.compile(r'onclick="\s*window\.close\(\)\s*;?\s*"')
_SMART_CLOSE_JS = (
    "<script>window.lisSmartClose=function(){try{window.close();}catch(e){}"
    "setTimeout(function(){var ref=document.referrer,same=false;"
    "try{same=!!ref&&new URL(ref).origin===location.origin&&ref!==location.href;}catch(e){}"
    "location.href=same?ref:'/front-desk/visits';"
    "},300);};</script>"
)


@app.after_request
def _smart_close_buttons(resp):
    """زر «إغلاق» بصفحات الطباعة كان window.close() فقط، وهذا يتجاهله المتصفح لو الصفحة ما انفتحت كنافذة منبثقة (وبوضع التطبيق
    ما فيه زر رجوع فيعلق المستخدم). نبدّله بدالة تجرّب الإغلاق ثم ترجع للصفحة اللي فتحتها (الـreferrer) أو لقائمة الزيارات."""
    try:
        if resp.mimetype == "text/html" and resp.status_code == 200 and not resp.direct_passthrough:
            body = resp.get_data(as_text=True)
            if "window.close()" in body and _CLOSE_BTN_RE.search(body) and "lisSmartClose" not in body:
                body = _CLOSE_BTN_RE.sub('onclick="lisSmartClose()"', body)
                i = body.rfind("</body>")
                body = (body[:i] + _SMART_CLOSE_JS + body[i:]) if i >= 0 else (body + _SMART_CLOSE_JS)
                resp.set_data(body)
    except Exception:  # noqa: BLE001 — إضافة فقط، ما توقف أي صفحة
        pass
    return resp


@app.route("/workbench/samples-collection")
@login_required
def samples_collection():
    db = get_db()
    order_tests = db.execute(
        "SELECT ot.id, ot.barcode, ot.status, td.name as test_name, td.sample_type, "
        "p.full_name as patient_name, v.registration_number "
        "FROM order_tests ot JOIN test_definitions td ON td.id=ot.test_definition_id "
        "JOIN orders o ON o.id=ot.order_id JOIN visits v ON v.id=o.visit_id "
        "JOIN patients p ON p.id=v.patient_id WHERE ot.status='Accepted' ORDER BY ot.id DESC"
    ).fetchall()
    return render_template("workbench/samples_collection.html", order_tests=order_tests)


@app.route("/workbench/samples-collection/<int:order_test_id>/collect", methods=["POST"])
@login_required
def collect_sample(order_test_id):
    db = get_db()
    now = datetime.now().isoformat(timespec="seconds")
    db.execute("UPDATE order_tests SET status='Collected', collected_at=? WHERE id=?", (now, order_test_id))
    db.commit()
    log_action("Collect", "order_test", order_test_id)
    flash("Sample marked as collected.")
    return redirect(url_for("samples_collection"))


@app.route("/workbench/order-tests/<int:order_test_id>/forward", methods=["GET", "POST"])
@login_required
def order_test_forward(order_test_id):
    """صفحة "إرسال هذا التحليل لمختبر آخر" (المطلوب 3): تحليل مثل
    البرولاكتين اللي عيّنته تُرسل فعليًا لمختبر القمة لإجرائه هناك --
    تُسجَّل هنا اسم المختبر المُرسَل إليه وكلفته، فتُحسب تلقائيًا ضمن
    صرفيات الزيارة بكل التقارير (اليومي/الشهري/نصف السنوي/السنوي) بدون
    أي إدخال يدوي إضافي بحقل الصرفيات العام. التقرير المطبوع للمريض نفسه
    لا يتأثر إطلاقًا -- يبقى يُطبع بقالب مختبرك (نفس الشعار والدكاترة)
    بغض النظر عن مكان الإرسال الفعلي، لأن forwarded_lab_name/forwarded_cost
    عمودين خاصّين بـorder_tests فقط ولا يُستخدَمان بأي قالب تقرير مريض.
    """
    db = get_db()
    ot = db.execute(
        "SELECT ot.*, td.name as test_name, p.full_name as patient_name, v.registration_number "
        "FROM order_tests ot JOIN test_definitions td ON td.id=ot.test_definition_id "
        "JOIN orders o ON o.id=ot.order_id JOIN visits v ON v.id=o.visit_id "
        "JOIN patients p ON p.id=v.patient_id WHERE ot.id=?",
        (order_test_id,),
    ).fetchone()
    if not ot:
        return "Not found", 404

    if request.method == "POST":
        lab_name = (request.form.get("forwarded_lab_name") or "").strip() or None
        cost_raw = (request.form.get("forwarded_cost") or "").strip()
        try:
            cost = float(cost_raw) if cost_raw else 0
        except ValueError:
            cost = 0
        db.execute(
            "UPDATE order_tests SET forwarded_lab_name=?, forwarded_cost=? WHERE id=?",
            (lab_name, cost, order_test_id),
        )
        db.commit()
        log_action("ForwardTest", "order_tests", order_test_id,
                    f"lab={lab_name} cost={cost}" if lab_name else "cleared")
        flash("تم حفظ بيانات الإرسال." if lab_name else "تم إلغاء الإرسال لمختبر آخر لهذا التحليل.")
        return redirect(url_for("order_test_forward", order_test_id=order_test_id))

    return render_template("workbench/order_test_forward.html", ot=ot)


@app.route("/workbench/samples-accession")
@login_required
def samples_accession():
    db = get_db()
    order_tests = db.execute(
        "SELECT ot.id, ot.barcode, ot.status, td.name as test_name, td.sample_type, td.department, "
        "p.full_name as patient_name, v.registration_number "
        "FROM order_tests ot JOIN test_definitions td ON td.id=ot.test_definition_id "
        "JOIN orders o ON o.id=ot.order_id JOIN visits v ON v.id=o.visit_id "
        "JOIN patients p ON p.id=v.patient_id WHERE ot.status='Collected' ORDER BY ot.id DESC"
    ).fetchall()
    return render_template("workbench/samples_accession.html", order_tests=order_tests)


@app.route("/workbench/samples-accession/<int:order_test_id>/accept", methods=["POST"])
@login_required
def accept_sample(order_test_id):
    db = get_db()
    now = datetime.now().isoformat(timespec="seconds")
    db.execute("UPDATE order_tests SET status='Accessioned', accessioned_at=? WHERE id=?", (now, order_test_id))
    db.commit()
    log_action("Accession", "order_test", order_test_id)
    flash("Sample accepted for testing.")
    return redirect(url_for("samples_accession"))



@app.route("/workbench/orders")
@login_required
def orders_list():
    db = get_db()
    status = request.args.get("status", "")
    # فلتر التاريخ: يبقى ثابت بين الزيارات المتكررة للصفحة (محفوظ بالجلسة)
    # لحد ما المستخدم نفسه يغيّره صراحة — ما يرجع لـ"اليوم" تلقائيًا، لأن
    # بعض التحاليل تتأخر عدة أيام وتحتاج تبقى ظاهرة بالقائمة. فاضي (زر
    # "الكل") = بدون أي فلتر تاريخ إطلاقًا.
    if "date" in request.args:
        order_date = request.args.get("date", "").strip()
        session["orders_date_filter"] = order_date
    else:
        order_date = session.get("orders_date_filter", "")
    # q: بحث حر (اسم مريض / رقم تسجيل / باركود) -- المطلوب: أي موظف مختبر
    # يقدر يدور على أي نتيجة، حتى لو كانت أصلاً "مُرسَلة" للاستقبال
    # واختفت من القائمة الافتراضية تحتها. البحث يتجاهل فلتر "غير المُرسَلة"
    # بالأسفل عمداً لهذا السبب بالذات.
    q = request.args.get("q", "").strip()
    query = (
        "SELECT ot.id, ot.barcode, ot.status, ot.created_at, ot.fee_waived, ot.hidden_from_log, "
        "ot.sent_to_reception, ot.sent_to_reception_at, ot.printed_at, "
        "td.name as test_name, td.code as test_code, td.department, td.sample_type, td.is_examining_test, "
        "p.full_name as patient_name, v.id as visit_id, v.registration_number, v.created_at as visit_created, "
        "rd.full_name as ref_doctor, rc.name as center "
        "FROM order_tests ot "
        "JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id "
        "JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id "
        "LEFT JOIN doctors rd ON rd.id = v.doctor_id "
        "LEFT JOIN referral_centers rc ON rc.id = v.referral_center_id "
    )
    conditions = []
    params = []
    if q:
        conditions.append("(p.full_name LIKE ? OR CAST(v.registration_number AS TEXT) LIKE ? OR ot.barcode LIKE ?)")
        params.extend([f"%{q}%", _scan_like(q), f"%{q}%"])
    else:
        # بدون بحث: التحاليل اللي انرسلت أصلاً للاستقبال تختفي من هذي
        # القائمة الافتراضية (خلصت مهمتها بشاشة المختبر) -- تبقى موجودة
        # وتطلع فقط لو دوّر عليها أي موظف بمربع البحث فوق.
        conditions.append("ot.sent_to_reception = 0")
    if status:
        conditions.append("ot.status = ?")
        params.append(status)
    if order_date:
        conditions.append("substr(ot.created_at,1,10) = ?")
        params.append(order_date)
    if conditions:
        query += "WHERE " + " AND ".join(conditions) + " "
    query += "ORDER BY ot.id DESC LIMIT 400"
    order_tests = db.execute(query, params).fetchall()
    fee_waiver_configured = bool(get_setting(db, "fee_waiver_password_hash", ""))
    # تجميع كل مريض (زيارة) بعنوان واحد وتحته تحاليله — بنفس ترتيب الأحدث أولاً
    groups, by_visit = [], {}
    for ot in order_tests:
        g = by_visit.get(ot["visit_id"])
        if g is None:
            g = {"visit_id": ot["visit_id"], "patient_name": ot["patient_name"], "reg_no": ot["registration_number"],
                 "created": (ot["visit_created"] or "")[:16].replace("T", " "), "ref_doctor": ot["ref_doctor"] or "",
                 "center": ot["center"] or "", "tests": []}
            by_visit[ot["visit_id"]] = g
            groups.append(g)
        g["tests"].append(ot)
    for g in groups:
        g["completed"] = [t for t in g["tests"] if t["status"] in ("Completed", "Verified")]
        g["sendable"] = [t for t in g["completed"] if not t["sent_to_reception"]]
        g["all_done"] = len(g["completed"]) == len(g["tests"])
    return render_template("workbench/orders.html", order_tests=order_tests, groups=groups, status=status,
                            order_date=order_date, fee_waiver_configured=fee_waiver_configured, q=q)


@app.route("/workbench/orders/send-selected", methods=["POST"])
@login_required
def send_selected_to_reception():
    """إرسال تحاليل مختارة (خانات الاختيار بصفحة Orders) لشاشة الاستقبال دفعة واحدة — فقط المكتملة وغير المُرسَلة."""
    db = get_db()
    ids = [int(x) for x in request.form.getlist("ot_id") if x.isdigit()]
    if not ids:
        flash("اختر تحليلًا واحدًا على الأقل.")
        return redirect(url_for("orders_list"))
    ph = ",".join("?" * len(ids))
    ready = [r["id"] for r in db.execute(
        f"SELECT id FROM order_tests WHERE id IN ({ph}) AND status IN ('Completed','Verified') AND sent_to_reception=0", ids)]
    if ready:
        now = datetime.now().isoformat(timespec="seconds")
        db.execute(f"UPDATE order_tests SET sent_to_reception=1, sent_to_reception_at=?, reception_seen=0 "
                   f"WHERE id IN ({','.join('?' * len(ready))})", [now] + ready)
        db.commit()
        log_action("SendToReception", "order_tests", 0, "bulk " + ",".join(map(str, ready)))
    skipped = len(ids) - len(ready)
    flash(f"✅ أُرسلت {len(ready)} نتيجة لشاشة الاستقبال." + (f" (تخطّيت {skipped} غير مكتملة أو مُرسلة سابقًا)" if skipped else ""))
    return redirect(url_for("orders_list"))


@app.route("/workbench/orders/<int:order_test_id>/delete", methods=["POST"])
@roles_required("supervisor")
def delete_order_test(order_test_id):
    """يمسح تحليل مطلوب لحاله (سطر وحد من قائمة Orders) — لا يمسح الزيارة
    ولا التحاليل الثانية المرتبطة فيها، فقط هذا التحليل بالذات (مثلاً طلب
    خطأ بالغلط). يمسح أي نتائج مدخلة له مسبقًا أيضًا حتى لا تبقى نتائج
    يتيمة بقاعدة البيانات.

    المطلوب 2: حذف تحليل مكتمل (نتيجته جاهزة ومحفوظة) محمي بنفس كلمة
    مرور حماية النتائج المكتملة (_check_completed_result_gate) المستخدمة
    بباقي أماكن التعديل على نتيجة مكتملة -- كانت ناقصة هنا تحديداً."""
    db = get_db()
    ot = db.execute("SELECT id, status FROM order_tests WHERE id=?", (order_test_id,)).fetchone()
    if not ot:
        flash("هذا الطلب غير موجود أصلاً.")
        return redirect(url_for("orders_list"))
    if ot["status"] in ("Completed", "Verified"):
        ok, err = _check_completed_result_gate(db, request.form)
        if not ok:
            flash(err)
            return redirect(url_for("orders_list"))
        log_action("DeleteCompletedOrderTest", "order_tests", order_test_id,
                    (request.form.get("gate_person_name") or "").strip())
    db.execute("DELETE FROM results WHERE order_test_id=?", (order_test_id,))
    db.execute("DELETE FROM order_tests WHERE id=?", (order_test_id,))
    db.commit()
    log_action("DeleteOrderTest", "order_tests", order_test_id, "")
    flash("تم حذف هذا الطلب.")
    return redirect(url_for("orders_list"))


@app.route("/workbench/orders/<int:order_test_id>/toggle-fee-waiver", methods=["POST"])
@login_required
def toggle_order_test_fee_waiver(order_test_id):
    """تبديل علامة "تحليل مجاني" (بدون أجر لدكتور المختبر الفاحص، وبدون
    احتساب سعر التحليل نفسه ضمن أي حساب يومي/شهري/نصف سنوي/سنوي) لتحليل
    واحد بالذات -- محمي بكلمة مرور خاصة تُضبط من صفحة الإعدادات
    (fee_waiver_password_hash)، حتى لا يقدر أي شخص بالمختبر يلعب فيها.
    عند التفعيل يُسأل أيضًا (hide_from_log) هل يظهر اسم هذا التحليل بعمود
    "التحاليل" بالسجل اليومي أم يختفي منه كليًا -- بالحالتين تبقى نتيجته
    محفوظة بقاعدة البيانات وتُطبع عاديًا بتقرير المريض. الاسم المُدخَل
    (person_name) يُسجَّل بسجل التدقيق فقط للمراجعة -- لا يوجد تحقق من
    قائمة أسماء مغلقة."""
    db = get_db()
    ot = db.execute(
        "SELECT ot.id, ot.fee_waived, o.visit_id FROM order_tests ot "
        "JOIN orders o ON o.id = ot.order_id WHERE ot.id=?",
        (order_test_id,),
    ).fetchone()
    if not ot:
        return {"ok": False, "error": "هذا الطلب غير موجود"}, 404

    stored_hash = get_setting(db, "fee_waiver_password_hash", "")
    if not stored_hash:
        return {"ok": False, "error": "لم تُضبط كلمة مرور هذه الميزة بعد -- اضبطها من صفحة الإعدادات أولاً."}, 400

    entered_password = request.form.get("password", "")
    if hash_password(entered_password) != stored_hash:
        return {"ok": False, "error": "كلمة المرور غير صحيحة."}, 403

    entered_name = (request.form.get("person_name") or "").strip()
    new_val = 0 if ot["fee_waived"] else 1
    hide_from_log = 1 if (new_val == 1 and request.form.get("hide_from_log") == "1") else 0
    db.execute(
        "UPDATE order_tests SET fee_waived=?, hidden_from_log=? WHERE id=?",
        (new_val, hide_from_log, order_test_id),
    )
    recompute_examining_doctor_fee(db, ot["visit_id"])
    db.commit()
    log_action("ToggleFeeWaiver", "order_tests", order_test_id,
               f"waived={new_val} hidden_from_log={hide_from_log} by={entered_name}")
    return {"ok": True, "fee_waived": new_val, "hidden_from_log": hide_from_log}


@app.route("/workbench/orders/<int:order_test_id>/send-to-reception", methods=["POST"])
@login_required
def send_order_test_to_reception(order_test_id):
    """إرسال نتيجة تحليل واحد مكتملة لشاشة الاستقبال حتى يطبعها موظف
    الاستقبال ويسلمها للمريض -- يختفي هذا التحليل بعدها من القائمة
    الافتراضية بصفحة Orders (شاشة المختبر)، ويظهر بصفحة النتائج بشاشة
    الاستقبال مع إشعار/رنة جرس لموظف الاستقبال. reception_seen يصفّر
    (0) وقت الإرسال حتى يحتسب ضمن الإشعارات غير المقروءة."""
    db = get_db()
    ot = db.execute("SELECT id, status FROM order_tests WHERE id=?", (order_test_id,)).fetchone()
    if not ot:
        flash("هذا الطلب غير موجود أصلاً.")
        return redirect(url_for("orders_list"))
    if ot["status"] not in ("Completed", "Verified"):
        flash("لا يمكن إرسال تحليل نتيجته لسا غير مكتملة.")
        return redirect(url_for("orders_list"))
    db.execute(
        "UPDATE order_tests SET sent_to_reception=1, sent_to_reception_at=?, reception_seen=0 WHERE id=?",
        (datetime.now().isoformat(timespec="seconds"), order_test_id),
    )
    db.commit()
    log_action("SendToReception", "order_tests", order_test_id, "")
    flash("✅ أُرسلت النتيجة لشاشة الاستقبال.")
    return redirect(url_for("orders_list"))


@app.route("/workbench/visits/<int:visit_id>/send-to-reception", methods=["POST"])
@login_required
def send_visit_to_reception(visit_id):
    """إرسال كل نتائج هذي الزيارة المكتملة (Completed/Verified) وغير
    المُرسَلة سابقًا دفعة وحدة لشاشة الاستقبال -- اختصار بدل إرسال كل
    تحليل لحاله لما تكون كل نتائج الزيارة جاهزة سوا."""
    db = get_db()
    rows = db.execute(
        "SELECT ot.id FROM order_tests ot JOIN orders o ON o.id = ot.order_id "
        "WHERE o.visit_id=? AND ot.status IN ('Completed','Verified') AND ot.sent_to_reception=0",
        (visit_id,),
    ).fetchall()
    if not rows:
        flash("لا توجد نتائج مكتملة جديدة بهذي الزيارة لإرسالها.")
        return redirect(url_for("orders_list"))
    now = datetime.now().isoformat(timespec="seconds")
    for r in rows:
        db.execute(
            "UPDATE order_tests SET sent_to_reception=1, sent_to_reception_at=?, reception_seen=0 WHERE id=?",
            (now, r["id"]),
        )
    db.commit()
    log_action("SendVisitToReception", "visits", visit_id, f"count={len(rows)}")
    flash(f"✅ أُرسلت {len(rows)} نتيجة لشاشة الاستقبال.")
    return redirect(url_for("orders_list"))


@app.route("/front-desk/notifications/check")
@login_required
def front_desk_notifications_check():
    """يُستدعى دوريًا (polling) من شريط شاشة الاستقبال بكل صفحاتها —
    يرجّع عدد النتائج المُرسَلة غير المقروءة بعد (لتشغيل رنة الجرس
    والإشعار المرئي) مع تفاصيلها المختصرة لعرضها بالإشعار."""
    db = get_db()
    rows = db.execute(
        "SELECT ot.id, td.name as test_name, p.full_name as patient_name, v.registration_number "
        "FROM order_tests ot "
        "JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id "
        "JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id "
        "WHERE ot.sent_to_reception=1 AND ot.reception_seen=0 "
        "ORDER BY ot.sent_to_reception_at DESC LIMIT 20"
    ).fetchall()
    items = [
        {"id": r["id"], "test_name": r["test_name"], "patient_name": r["patient_name"],
         "registration_number": r["registration_number"]}
        for r in rows
    ]
    return jsonify({"count": len(items), "items": items})


@app.route("/front-desk/notifications/mark-seen", methods=["POST"])
@login_required
def front_desk_notifications_mark_seen():
    """يوقف الإشعار/الرنة بعد ما يشوفها موظف الاستقبال مرة وحدة -- ما
    يمسح الحالة \"مُرسَلة\" نفسها (تبقى النتيجة تظهر بصفحة النتائج لحد
    ما تُطبع فعليًا)، فقط يوقف تكرار رنة الجرس لنفس النتيجة."""
    db = get_db()
    db.execute("UPDATE order_tests SET reception_seen=1 WHERE sent_to_reception=1 AND reception_seen=0")
    db.commit()
    return jsonify({"ok": True})


def save_order_test_results(db, ot, parameters, form, user_id, field_prefix="", patient_id=None, fill_normal=False):
    """يحفظ نتائج تحليل واحد (order_test) من بيانات نموذج مُرسل، بنفس منطق
    الأعلام (Flag) والمرجعيات وتسجيل التأريخ المستخدم بشاشة إدخال النتائج —
    مشتركة بين شاشة الإدخال المفردة وشاشة الإدخال المُجمّع لكل تحاليل الزيارة
    معًا، حتى لا يتكرر نفس المنطق الحساس بمكانين. تعيد True إذا أُدخلت/عُدّلت
    أي قيمة فعليًا لهذا التحليل.

    patient_id: يُمرَّر لـfind_reference_range حتى تُستخدم النسبة الطبيعية
    الخاصة بهذا المريض تحديداً لو موجودة (المطلوب 5) — اختياري، None يعني
    نفس السلوك القديم (نسبة عامة/حسب الجهاز فقط).

    الجهاز (analyzer): يُقرأ من حقل form["{field_prefix}analyzer"] لو
    موجود ويُحفظ على order_tests.analyzer قبل حساب أي flag، حتى يُستخدم
    فورًا بنفس هذا الحفظ (المطلوب 6). حقل غير موجود بالفورم إطلاقاً (شاشة
    قديمة ما عندها هذا الحقل) لا يغيّر شي؛ حقل موجود وفاضي يمسح القيمة
    المحفوظة سابقاً.
    """
    analyzer_field = f"{field_prefix}analyzer"
    if analyzer_field in form:
        analyzer_value = form.get(analyzer_field, "").strip() or None
        db.execute("UPDATE order_tests SET analyzer=? WHERE id=?", (analyzer_value, ot["id"]))
    else:
        analyzer_value = ot["analyzer"] if "analyzer" in ot.keys() else None

    now = datetime.now().isoformat(timespec="seconds")
    touched = False
    # GSE / GUE / SFA: الحقل اللي ما انكتب فيه شي ينزل تلقائيًا بالقيمة الطبيعية (range_text).
    # يُطبَّق (أ) إذا انكتب أي حقل بنفس التحليل → الباقي الفارغ يتعبّى طبيعي، أو
    # (ب) عند الطباعة المباشرة لهذا التحليل (fill_normal=True) حتى لو كل الحقول فارغة.
    # الحفظ العادي لتحليل ما انلمس إطلاقًا لا يعبّي شي (حتى ما يكتمل تحليل لسا ما انفحص).
    _code = ot["test_code"] if "test_code" in ot.keys() else None
    if _code is None:
        _r = db.execute("SELECT code FROM test_definitions WHERE id=?", (ot["test_definition_id"],)).fetchone()
        _code = _r["code"] if _r else None
    _is_exam = _code in ("GUE", "GSE", "SFA")
    _any_typed = _is_exam and any((form.get(f"{field_prefix}param_{p['id']}", "") or "").strip() for p in parameters)
    _auto_normal = _is_exam and (_any_typed or fill_normal)
    for param in parameters:
        field = f"{field_prefix}param_{param['id']}"
        value = form.get(field, "").strip()
        if value == "" and _auto_normal:
            _rr = find_reference_range(db, param["id"], ot["gender"], ot["age"], ot["age_unit"],
                                       patient_id=patient_id, analyzer=analyzer_value)
            _txt = ""
            if _rr is not None:
                try:
                    _txt = (_rr["range_text"] or "").strip()
                except (KeyError, IndexError, TypeError):
                    _txt = ""
            if _txt:
                value = _txt
        if value == "":
            continue
        touched = True
        rng = find_reference_range(db, param["id"], ot["gender"], ot["age"], ot["age_unit"],
                                    patient_id=patient_id, analyzer=analyzer_value)
        flag = "Normal"
        value_numeric = None
        value_text = None
        if param["result_type"] == "Numeric":
            try:
                value_numeric = float(value)
                if rng and rng["low"] is not None and value_numeric < rng["low"]:
                    flag = "Low"
                elif rng and rng["high"] is not None and value_numeric > rng["high"]:
                    flag = "High"
                    if rng["high"] and value_numeric > rng["high"] * 2:
                        flag = "Critical"
            except ValueError:
                value_text = value
        else:
            value_text = value

        existing = db.execute(
            "SELECT id, value_numeric, value_text, flag FROM results WHERE order_test_id=? AND test_parameter_id=?",
            (ot["id"], param["id"]),
        ).fetchone()
        if existing:
            if existing["value_numeric"] != value_numeric or existing["value_text"] != value_text:
                db.execute(
                    "INSERT INTO result_history (result_id, order_test_id, test_parameter_id, "
                    "prev_value_numeric, prev_value_text, prev_flag, changed_by, changed_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (existing["id"], ot["id"], param["id"], existing["value_numeric"],
                     existing["value_text"], existing["flag"], user_id, now),
                )
            db.execute(
                "UPDATE results SET value_numeric=?, value_text=?, flag=?, entered_by=?, entered_at=? WHERE id=?",
                (value_numeric, value_text, flag, user_id, now, existing["id"]),
            )
        else:
            db.execute(
                "INSERT INTO results (order_test_id, test_parameter_id, value_numeric, value_text, "
                "flag, entered_by, entered_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (ot["id"], param["id"], value_numeric, value_text, flag, user_id, now),
            )

    # RETIC ("Retic Count" المفرد فقط): يحتسب Corrected Retic count تلقائيًا
    # من Reticulocyte count وHCT (راجع ensure_retic_parameters بـdatabase.py
    # وتعليق _apply_retic_correction أدناه للتفاصيل الكاملة).
    if "test_code" in ot.keys() and ot["test_code"] == "RETIC":
        _apply_retic_correction(db, ot, parameters, form, field_prefix, user_id, now, patient_id)
    elif "test_code" in ot.keys() and ot["test_code"] == "CBC":
        # v79: لما يُحفظ CBC (فيه HCT) والمريض عنده Retic فيه Reticulocyte count بدون Corrected => يُحسب تلقائيًا
        try:
            _rt = db.execute(
                "SELECT ot2.*, td2.code AS test_code, v.id AS visit_id, p.gender, p.age, p.age_unit "
                "FROM order_tests ot2 JOIN test_definitions td2 ON td2.id=ot2.test_definition_id "
                "JOIN orders o2 ON o2.id=ot2.order_id JOIN visits v ON v.id=o2.visit_id JOIN patients p ON p.id=v.patient_id "
                "WHERE ot2.order_id=? AND td2.code='RETIC'", (ot["order_id"],)).fetchone()
            if _rt:
                _rparams = db.execute("SELECT * FROM test_parameters WHERE test_definition_id=?", (_rt["test_definition_id"],)).fetchall()
                _cp = next((p for p in _rparams if p["name"] == "Corrected Retic count"), None)
                _has = _cp and db.execute("SELECT 1 FROM results WHERE order_test_id=? AND test_parameter_id=? AND (value_numeric IS NOT NULL OR value_text IS NOT NULL)",
                                          (_rt["id"], _cp["id"])).fetchone()
                if not _has:
                    _apply_retic_correction(db, _rt, _rparams, {}, "", user_id, now, patient_id)
        except Exception:
            pass
    elif "test_code" in ot.keys() and ot["test_code"] == "BF":
        _v80_sync_bf_to_retic(db, ot, parameters, user_id, now, patient_id)   # v80: Retic داخل BF

    return touched


def _apply_retic_correction(db, ot, parameters, form, field_prefix, user_id, now, patient_id):
    """يحسب Corrected Retic count تلقائيًا لتحليل Retic Count (RETIC):

        Corrected Retic % = Reticulocyte count % × (HCT الفعلي ÷ HCT الطبيعي
                                                      حسب عمر/جنس المريض)

    "HCT الطبيعي" يُسحب من نفس جداول Reference Ranges العمرية الجاهزة
    (find_reference_range على باراميتر HCT نفسه بهذا التحليل) — منتصف
    المدى (low+high)/2، أو أي طرف موجود لو الثاني فاضي.

    لا يُطبَّق شي إذا:
      - Reticulocyte count أو HCT غير مُدخلين (لا بهذا الإرسال ولا سابقًا).
      - المستخدم كتب هو نفسه قيمة بحقل "Corrected Retic count" بهذا
        الإرسال -- قيمته اليدوية تبقى كما هي (already handled by the
        main loop above)، ما تُستبدَل بالمحسوبة.

    لو الناتج المحسوب أقل من Reticulocyte count الأصلي، تُخزَّن ملاحظة
    قصيرة بعمود results.note لصف Corrected Retic count -- تظهر بالتقرير
    كنص عادي قابل للحذف من معاينة الطباعة (editable-label) بدون أي زر
    جديد. لو الشرط ما انطبق (تصحيح لاحق رفع الناتج)، تُمحى الملاحظة
    القديمة تلقائيًا حتى لا تبقى ملاحظة قديمة غير صحيحة.
    """
    by_name = {p["name"]: p for p in parameters}
    retic_param = by_name.get("Reticulocyte count")
    hct_param = by_name.get("HCT")
    corrected_param = by_name.get("Corrected Retic count")
    if not (retic_param and hct_param and corrected_param):
        return  # قاعدة بيانات قديمة ما انزرعت لها هذي الحقول بعد

    corrected_field = f"{field_prefix}param_{corrected_param['id']}"
    if (form.get(corrected_field, "") or "").strip() != "":
        return  # المستخدم كتب قيمة يدوية بنفسه -- لا نستبدلها بالمحسوبة

    def _current_numeric(param):
        field = f"{field_prefix}param_{param['id']}"
        submitted = (form.get(field, "") or "").strip()
        if submitted != "":
            try:
                return float(submitted)
            except ValueError:
                return None
        existing = db.execute(
            "SELECT value_numeric FROM results WHERE order_test_id=? AND test_parameter_id=?",
            (ot["id"], param["id"]),
        ).fetchone()
        return existing["value_numeric"] if existing else None

    retic_value = _current_numeric(retic_param)
    # v79: HCT يُسحب تلقائيًا من CBC نفس الزيارة إن وُجد؛ وإلا (Retic لحاله بلا CBC) من حقل HCT المكتوب بتحليل Retic
    hct_value = None
    try:
        _vid = ot["visit_id"] if "visit_id" in ot.keys() else None
        if _vid is None:
            _vr = db.execute("SELECT visit_id FROM orders WHERE id=?", (ot["order_id"],)).fetchone()
            _vid = _vr["visit_id"] if _vr else None
        if _vid is not None:
            hct_value = get_visit_hct(db, _vid)
    except Exception:
        hct_value = None
    if hct_value is None:
        hct_value = _current_numeric(hct_param)
    if retic_value is None or hct_value is None:
        return

    normal_range = find_reference_range(db, hct_param["id"], ot["gender"], ot["age"], ot["age_unit"],
                                         patient_id=patient_id)
    normal_hct = None
    if normal_range:
        low, high = normal_range["low"], normal_range["high"]
        if low is not None and high is not None:
            normal_hct = (low + high) / 2
        elif low is not None:
            normal_hct = low
        elif high is not None:
            normal_hct = high
    if not normal_hct:
        # v79: لو تحليل Retic ما عنده مدى HCT نستخدم مدى HCT الخاص بتحليل CBC (نفس العمر والجنس)
        try:
            normal_hct = get_normal_hct(db, ot["gender"], ot["age"], ot["age_unit"])
        except Exception:
            normal_hct = None
    if not normal_hct:
        return  # ماكو مدى طبيعي لـHCT محدد بعمر هذا المريض -- ما نقدر نحسب

    corrected_value = round(retic_value * (hct_value / normal_hct), 1)
    note = ("ملاحظة: النتيجة المصححة (Corrected Retic count) أقل من العدّ الأصلي "
            "(Reticulocyte count) — راجع القيم المُدخلة.") if corrected_value < retic_value else None

    existing = db.execute(
        "SELECT id, value_numeric, value_text, flag FROM results WHERE order_test_id=? AND test_parameter_id=?",
        (ot["id"], corrected_param["id"]),
    ).fetchone()
    if existing:
        if existing["value_numeric"] != corrected_value:
            db.execute(
                "INSERT INTO result_history (result_id, order_test_id, test_parameter_id, "
                "prev_value_numeric, prev_value_text, prev_flag, changed_by, changed_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (existing["id"], ot["id"], corrected_param["id"], existing["value_numeric"],
                 existing["value_text"], existing["flag"], user_id, now),
            )
        db.execute(
            "UPDATE results SET value_numeric=?, value_text=NULL, flag='Normal', note=?, "
            "entered_by=?, entered_at=? WHERE id=?",
            (corrected_value, note, user_id, now, existing["id"]),
        )
    else:
        db.execute(
            "INSERT INTO results (order_test_id, test_parameter_id, value_numeric, value_text, "
            "flag, note, entered_by, entered_at) VALUES (?, ?, ?, NULL, 'Normal', ?, ?, ?)",
            (ot["id"], corrected_param["id"], corrected_value, note, user_id, now),
        )


@app.route("/workbench/result/<int:order_test_id>", methods=["GET", "POST"])
@login_required
def result_entry(order_test_id):
    db = get_db()
    ot = db.execute(
        "SELECT ot.*, td.name as test_name, td.code as test_code, "
        "p.id as patient_id, p.full_name as patient_name, p.gender, p.age, p.age_unit, "
        "v.id as visit_id, v.registration_number "
        "FROM order_tests ot JOIN test_definitions td ON td.id=ot.test_definition_id "
        "JOIN orders o ON o.id=ot.order_id JOIN visits v ON v.id=o.visit_id "
        "JOIN patients p ON p.id=v.patient_id WHERE ot.id=?",
        (order_test_id,),
    ).fetchone()
    if not ot:
        return "Not found", 404

    parameters = db.execute(
        "SELECT * FROM test_parameters WHERE test_definition_id=? ORDER BY sort_order, id", (ot["test_definition_id"],)
    ).fetchall()

    if request.method == "POST":
        if ot["status"] in ("Completed", "Verified") and _ot_has_result_changes(db, ot, parameters, request.form):
            ok, err = _check_completed_result_gate(db, request.form)
            if not ok:
                flash(err)
                return redirect(url_for("result_entry", order_test_id=order_test_id))
        gate_person = (request.form.get("gate_person_name") or "").strip()
        save_order_test_results(db, ot, parameters, request.form, session.get("user_id"), patient_id=ot["patient_id"])
        # التحليل المعتمد (Verified) يبقى معتمَد بعد التعديل — الحقول صارت
        # قابلة للتعديل دائمًا حتى بعد الاعتماد (بطلب المستخدم)، وكل تعديل
        # يبقى مسجّل بجدول result_history (القيمة القديمة + مين عدّلها ووقتها)
        # حتى لو ما تغيّرت حالة الاعتماد ظاهريًا.
        if ot["status"] != "Verified":
            db.execute("UPDATE order_tests SET status='Completed' WHERE id=?", (order_test_id,))
        db.commit()
        _post_save_background(ot["visit_id"], [order_test_id])
        log_action("EnterResult", "order_test", order_test_id, f"gate_person={gate_person}" if gate_person else None)
        flash("Results saved.")
        return redirect(url_for("orders_list"))

    results = db.execute(
        "SELECT r.*, tp.name as param_name FROM results r "
        "JOIN test_parameters tp ON tp.id=r.test_parameter_id WHERE order_test_id=?",
        (order_test_id,),
    ).fetchall()
    results_by_param = {r["test_parameter_id"]: r for r in results}

    ranges = {}
    suggestions_map = {}
    history_map = {}
    for p in parameters:
        r = find_reference_range(db, p["id"], ot["gender"], ot["age"], ot["age_unit"],
                                  patient_id=ot["patient_id"], analyzer=ot["analyzer"] if "analyzer" in ot.keys() else None)
        ranges[p["id"]] = r
        sugg = db.execute("SELECT content FROM suggestions WHERE test_parameter_id=?", (p["id"],)).fetchall()
        suggestions_map[p["id"]] = [s["content"] for s in sugg]
        last_hist = db.execute(
            "SELECT * FROM result_history WHERE order_test_id=? AND test_parameter_id=? "
            "ORDER BY id DESC LIMIT 1", (order_test_id, p["id"]),
        ).fetchone()
        history_map[p["id"]] = last_hist

    return render_template("workbench/result_entry.html", ot=ot, parameters=parameters,
                            results_by_param=results_by_param, ranges=ranges,
                            suggestions_map=suggestions_map, history_map=history_map,
                            patient_hct=get_visit_hct(db, ot["visit_id"]))


# شاشة إدخال النتائج المُجمّعة لكل تحاليل الزيارة معًا: تُظهر كل تحليل طُلب
# لهذا المريض كمستطيل (بطاقة) منفصل بنفس صفوفه/حقوله المعتادة، وزر "حفظ"
# واحد يحفظ كل ما تمت تعبئته دفعة واحدة. فور الحفظ تصبح النتائج متاحة مباشرة
# بريبورت كل تحليل (زر طباعة أمام كل بطاقة)، مع بقاء إمكانية التعديل والحفظ
# مجددًا بنفس الصفحة قبل الطباعة الفعلية.
_HIDDEN_COL_OK = False


def _ensure_hidden_col(db):
    """عمود order_tests.hidden_param_ids (بارامترات محذوفة من تقرير هذا المريض فقط) — يُضاف تلقائيًا مرة وحدة."""
    global _HIDDEN_COL_OK
    if _HIDDEN_COL_OK:
        return
    try:
        cols = [r[1] for r in db.execute("PRAGMA table_info(order_tests)")]
        if "hidden_param_ids" not in cols:
            db.execute("ALTER TABLE order_tests ADD COLUMN hidden_param_ids TEXT")
            db.commit()
        _HIDDEN_COL_OK = True
    except Exception:
        pass


def _hidden_param_ids(db, order_test_id):
    _ensure_hidden_col(db)
    try:
        row = db.execute("SELECT hidden_param_ids FROM order_tests WHERE id=?", (order_test_id,)).fetchone()
    except Exception:
        return set()
    raw = (row["hidden_param_ids"] if row else "") or ""
    return {int(x) for x in raw.split(",") if x.strip().isdigit()}


@app.route("/api/order-tests/<int:order_test_id>/hide-params", methods=["POST"])
@login_required
def api_order_test_hide_params(order_test_id):
    """حذف باراميتر/أكثر من تقرير هذا المريض فقط (لا يمس تعريف التحليل ولا باقي المرضى).
    body: {param_ids:[..]} حذف، أو {restore:[..]} إعادة. القيم المُدخلة لهذي البارامترات تُمسح. التحليل المكتمل يحتاج مسؤول/مشرف."""
    db = get_db()
    _ensure_hidden_col(db)
    ot = db.execute("SELECT id, status, test_definition_id FROM order_tests WHERE id=?", (order_test_id,)).fetchone()
    if not ot:
        return jsonify({"ok": False, "error": "التحليل غير موجود"}), 404
    if ot["status"] == "Verified":
        return jsonify({"ok": False, "error": "النتيجة معتمدة — لا يمكن حذف بارامترات منها."}), 400
    if ot["status"] == "Completed" and session.get("role") not in ("admin", "supervisor"):
        return jsonify({"ok": False, "error": "تعديل نتيجة مكتملة يحتاج مسؤول/مشرف."}), 403
    body = request.get_json(silent=True) or {}
    valid = {r["id"] for r in db.execute("SELECT id FROM test_parameters WHERE test_definition_id=?", (ot["test_definition_id"],))}
    hidden = _hidden_param_ids(db, order_test_id)
    add = {int(x) for x in (body.get("param_ids") or []) if str(x).isdigit()} & valid
    restore = {int(x) for x in (body.get("restore") or []) if str(x).isdigit()}
    if add and not (valid - hidden - add):
        return jsonify({"ok": False, "error": "لا يمكن حذف كل البارامترات — يجب أن يبقى باراميتر واحد على الأقل."}), 400
    hidden = (hidden | add) - restore
    db.execute("UPDATE order_tests SET hidden_param_ids=? WHERE id=?",
               (",".join(str(i) for i in sorted(hidden)) or None, order_test_id))
    if add:
        ph = ",".join("?" * len(add))
        db.execute(f"DELETE FROM results WHERE order_test_id=? AND test_parameter_id IN ({ph})", (order_test_id, *add))
    db.commit()
    log_action("HideParams", "order_tests", order_test_id, f"hide={sorted(add)} restore={sorted(restore)}")
    return jsonify({"ok": True, "hidden": sorted(hidden)})



# ======================================================================
# v55 — تعديل الوحدة / النسبة الطبيعية من شاشة إدخال النتائج
#   scope=all     -> يتغير بتعريف التحليل لكل المرضى (test_parameters.unit / reference_ranges)
#   scope=patient -> يُحفظ بجدول lis_patient_param_overrides لهذا المريض فقط
# ======================================================================
_OVR_OK = False


def _ensure_overrides_table(db):
    global _OVR_OK
    if _OVR_OK:
        return
    try:
        db.execute(
            "CREATE TABLE IF NOT EXISTS lis_patient_param_overrides ("
            "patient_id INTEGER NOT NULL, test_parameter_id INTEGER NOT NULL, "
            "unit TEXT, low REAL, high REAL, range_text TEXT, updated_at TEXT, "
            "PRIMARY KEY (patient_id, test_parameter_id))")
        db.commit()
        _OVR_OK = True
    except Exception:
        pass


def _get_patient_override(db, patient_id, param_id):
    if not patient_id:
        return None
    _ensure_overrides_table(db)
    try:
        return db.execute(
            "SELECT * FROM lis_patient_param_overrides WHERE patient_id=? AND test_parameter_id=?",
            (patient_id, param_id)).fetchone()
    except Exception:
        return None


_orig_find_reference_range = find_reference_range


def find_reference_range(db, param_id, gender, age, age_unit, *args, **kwargs):
    """غلاف حول find_reference_range الأصلية: لو للمريض نسبة طبيعية معدّلة (لهذا المريض فقط) تُفضَّل."""
    base = _orig_find_reference_range(db, param_id, gender, age, age_unit, *args, **kwargs)
    pid = kwargs.get("patient_id")
    ov = _get_patient_override(db, pid, param_id) if pid else None
    if ov is not None and (ov["range_text"] or ov["low"] is not None or ov["high"] is not None):
        d = {}
        if base is not None:
            try:
                d = {k: base[k] for k in base.keys()}
            except Exception:
                d = {}
        d.update({"low": ov["low"], "high": ov["high"], "range_text": ov["range_text"]})
        return d
    return base


def _parse_range_text(txt):
    """'4.0 - 10.0' -> (4.0, 10.0) ; '> 5' -> (5, None) ; '< 5' -> (None, 5) ; غير ذلك -> (None, None)"""
    t = (txt or "").strip().replace("–", "-").replace("—", "-")
    m = re.match(r"^(-?\d+(?:\.\d+)?)\s*-\s*(-?\d+(?:\.\d+)?)$", t)
    if m:
        return float(m.group(1)), float(m.group(2))
    m = re.match(r"^(?:>=?|≥)\s*(-?\d+(?:\.\d+)?)$", t)
    if m:
        return float(m.group(1)), None
    m = re.match(r"^(?:<=?|≤)\s*(-?\d+(?:\.\d+)?)$", t)
    if m:
        return None, float(m.group(1))
    return None, None


@app.route("/api/order-tests/<int:order_test_id>/param-edit", methods=["POST"])
@login_required
def api_order_test_param_edit(order_test_id):
    """body: {param_id, unit?, range?, scope: 'all'|'patient', reset?: true}
    unit/range غير موجودين بالـbody = لا تغيير. reset=true مع patient يلغي تخصيص المريض."""
    db = get_db()
    _ensure_overrides_table(db)
    ot = db.execute(
        "SELECT ot.id, ot.status, ot.analyzer, ot.test_definition_id, p.id AS patient_id, "
        "p.gender, p.age, p.age_unit FROM order_tests ot "
        "JOIN orders o ON o.id=ot.order_id JOIN visits v ON v.id=o.visit_id "
        "JOIN patients p ON p.id=v.patient_id WHERE ot.id=?", (order_test_id,)).fetchone()
    if not ot:
        return jsonify({"ok": False, "error": "التحليل غير موجود"}), 404
    if ot["status"] == "Verified":
        return jsonify({"ok": False, "error": "النتيجة معتمدة — افتحها للتعديل أولاً."}), 400
    body = request.get_json(silent=True) or {}
    try:
        param_id = int(body.get("param_id"))
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "باراميتر غير صالح"}), 400
    prm = db.execute("SELECT * FROM test_parameters WHERE id=? AND test_definition_id=?",
                     (param_id, ot["test_definition_id"])).fetchone()
    if not prm:
        return jsonify({"ok": False, "error": "الباراميتر ليس من هذا التحليل"}), 404
    scope = body.get("scope")
    if scope not in ("all", "patient"):
        return jsonify({"ok": False, "error": "حدّد النطاق (كل المرضى / هذا المريض)"}), 400
    has_unit = "unit" in body
    has_range = "range" in body
    unit = (body.get("unit") or "").strip() if has_unit else None
    rtxt = (body.get("range") or "").strip() if has_range else None
    low, high = _parse_range_text(rtxt) if has_range else (None, None)

    if scope == "patient":
        if body.get("reset"):
            db.execute("DELETE FROM lis_patient_param_overrides WHERE patient_id=? AND test_parameter_id=?",
                       (ot["patient_id"], param_id))
        else:
            cur = _get_patient_override(db, ot["patient_id"], param_id)
            n_unit = unit if has_unit else (cur["unit"] if cur else None)
            if has_range:
                n_low, n_high, n_txt = low, high, (rtxt or None)
            else:
                n_low, n_high, n_txt = ((cur["low"], cur["high"], cur["range_text"]) if cur else (None, None, None))
            db.execute(
                "INSERT INTO lis_patient_param_overrides (patient_id, test_parameter_id, unit, low, high, range_text, updated_at) "
                "VALUES (?,?,?,?,?,?,?) ON CONFLICT(patient_id, test_parameter_id) DO UPDATE SET "
                "unit=excluded.unit, low=excluded.low, high=excluded.high, range_text=excluded.range_text, "
                "updated_at=excluded.updated_at",
                (ot["patient_id"], param_id, n_unit, n_low, n_high, n_txt,
                 datetime.now().isoformat(timespec="seconds")))
    else:
        if has_unit:
            db.execute("UPDATE test_parameters SET unit=? WHERE id=?", (unit, param_id))
            # التعديل العام يلغي أي وحدة مخصصة سابقًا حتى لا تتعارض
            db.execute("UPDATE lis_patient_param_overrides SET unit=NULL WHERE test_parameter_id=?", (param_id,))
        if has_range:
            base = _orig_find_reference_range(db, param_id, ot["gender"], ot["age"], ot["age_unit"],
                                              patient_id=None, analyzer=ot["analyzer"])
            rid = None
            if base is not None:
                try:
                    rid = base["id"]
                except (KeyError, IndexError, TypeError):
                    rid = None
            if rid:
                db.execute("UPDATE reference_ranges SET low=?, high=?, range_text=? WHERE id=?",
                           (low, high, rtxt or None, rid))
            else:
                db.execute(
                    "INSERT INTO reference_ranges (test_parameter_id, gender, age_from, age_from_unit, age_to, "
                    "age_to_unit, low, high, range_text) VALUES (?, 'Both', 0, 'Years', 120, 'Years', ?, ?, ?)",
                    (param_id, low, high, rtxt or None))
            # التعديل العام يلغي تخصيص المرضى للنسبة (حتى يطبّق على الجميع فعلاً)
            db.execute("UPDATE lis_patient_param_overrides SET low=NULL, high=NULL, range_text=NULL "
                       "WHERE test_parameter_id=?", (param_id,))
    db.commit()
    log_action("EditParamUnitRange", "order_tests", order_test_id,
               f"param={param_id} scope={scope} unit={unit!r} range={rtxt!r} reset={bool(body.get('reset'))}")
    return jsonify({"ok": True})


def get_ordered_parameters(db, ot):
    _all = _get_ordered_parameters_raw(db, ot)
    try:
        _hid = _hidden_param_ids(db, ot["id"])
    except Exception:
        _hid = set()
    if _hid:
        _kept = [p for p in _all if p["id"] not in _hid]
        _all = _kept or _all
    # v55: وحدة مخصصة لهذا المريض فقط
    try:
        _pid = ot["patient_id"] if "patient_id" in ot.keys() else None
        if _pid is None:
            _r = db.execute("SELECT v.patient_id AS pid FROM order_tests x JOIN orders o ON o.id=x.order_id "
                            "JOIN visits v ON v.id=o.visit_id WHERE x.id=?", (ot["id"],)).fetchone()
            _pid = _r["pid"] if _r else None
        if _pid:
            _ensure_overrides_table(db)
            _ov = {r["test_parameter_id"]: r["unit"] for r in db.execute(
                "SELECT test_parameter_id, unit FROM lis_patient_param_overrides WHERE patient_id=? AND unit IS NOT NULL",
                (_pid,)).fetchall()}
            if _ov:
                _out = []
                for p in _all:
                    if p["id"] in _ov:
                        d = {k: p[k] for k in p.keys()}
                        d["unit"] = _ov[p["id"]]
                        _out.append(d)
                    else:
                        _out.append(p)
                return _out
    except Exception:
        pass
    return _all


def _get_ordered_parameters_raw(db, ot):
    """يرجّع بارامترات order_test هذا — كلها إذا طُلب التحليل كامل
    (السلوك الافتراضي)، أو بس البارامترات المحدَّدة فعليًا لو استُخدم سهم
    "اختيار بارامترات معيّنة" بشاشة زيارة جديدة (راجع
    order_tests.selected_param_ids بـdatabase.py). تُستخدم بشاشة إدخال
    النتائج (عرض + حفظ) حتى ما تظهر/تُطلب قيم لبارامترات المريض ماطلبها
    أصلاً."""
    all_params = db.execute(
        "SELECT * FROM test_parameters WHERE test_definition_id=? ORDER BY sort_order, id",
        (ot["test_definition_id"],),
    ).fetchall()
    selected_raw = ot["selected_param_ids"] if "selected_param_ids" in ot.keys() else None
    if not selected_raw:
        return all_params
    try:
        selected_ids = {int(x) for x in selected_raw.split(",") if x.strip()}
    except ValueError:
        return all_params
    filtered = [p for p in all_params if p["id"] in selected_ids]
    return filtered or all_params



# ------------------------------------------------------------------------
# الإدخال السريع: اكتب اسم المريض أو رقم/باركود الريكويست ← يطلع مرضى اليوم ← اختر المريض ← اختر التحليل
# ← تظهر حقوله (نفس شاشة إدخال النتائج ?only=) ← حفظ / حفظ وطباعة. يعرض فقط التحاليل غير المكتملة
# (المكتمل ينتقل للاستقبال وصفحة النتائج المكتملة ويظهر هناك بالبحث). المسار بلا بادئة حتى يفتح من أي جهاز/واجهة.
# ------------------------------------------------------------------------
@app.route("/quick-entry")
@login_required
def quick_entry():
    return render_template("front_desk/quick_entry.html")


@app.route("/api/quick-entry/search")
@login_required
def api_quick_entry_search():
    db = get_db()
    q = (request.args.get("q") or "").strip()
    all_days = request.args.get("all") == "1"
    where = ["ot.status NOT IN ('Completed', 'Verified')", "COALESCE(ot.sent_to_reception, 0) = 0"]
    params = []
    _seq = _visit_seq_clause(q) if q else None
    if q:
        _extra = (" OR " + _seq[0]) if _seq else ""
        where.append("(p.full_name LIKE ? OR CAST(v.registration_number AS TEXT) LIKE ? OR ot.barcode LIKE ? "
                     "OR v.id IN (SELECT o2.visit_id FROM order_tests ot2 JOIN orders o2 ON o2.id = ot2.order_id "
                     "WHERE ot2.barcode LIKE ?)" + _extra + ")")
        params += [f"%{q}%", _scan_like(q), f"%{q}%", f"%{q}%"] + (_seq[1] if _seq else [])
    if not all_days and not (q and q.isdigit() and len(q) >= 4):
        where.append("substr(v.created_at,1,10) = ?")
        params.append(datetime.now().strftime("%Y-%m-%d"))
    rows = db.execute(
        "SELECT v.id as visit_id, v.registration_number, v.created_at, p.full_name as patient_name, p.gender, p.age, p.age_unit, "
        "ot.id as ot_id, ot.status, td.name as test_name, td.department "
        "FROM order_tests ot JOIN orders o ON o.id = ot.order_id JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id JOIN test_definitions td ON td.id = ot.test_definition_id "
        "WHERE " + " AND ".join(where) + " ORDER BY v.id DESC, ot.id LIMIT 600", params).fetchall()
    visits, order = {}, []
    for r in rows:
        v = visits.get(r["visit_id"])
        if v is None:
            if len(order) >= 40:
                continue
            v = visits[r["visit_id"]] = {
                "visit_id": r["visit_id"], "reg": r["registration_number"], "name": r["patient_name"],
                "meta": " · ".join(x for x in [r["gender"] or "", f"{r['age']} {r['age_unit'] or ''}".strip() if r["age"] else ""] if x),
                "time": (r["created_at"] or "")[11:16], "tests": [],
            }
            order.append(r["visit_id"])
        v["tests"].append({"id": r["ot_id"], "name": r["test_name"], "group": _dept_group(r["department"]), "status": r["status"]})
    return jsonify({"visits": [visits[i] for i in order]})


@app.route("/front-desk/visits/<int:visit_id>/results", methods=["GET", "POST"])
@login_required
def visit_results_entry(visit_id):
    db = get_db()
    visit = db.execute(
        "SELECT v.*, p.full_name as patient_name, p.gender, p.age, p.age_unit, p.phone "
        "FROM visits v JOIN patients p ON p.id = v.patient_id WHERE v.id=?",
        (visit_id,),
    ).fetchone()
    if not visit:
        return "Not found", 404

    order_tests = db.execute(
        "SELECT ot.*, td.name as test_name, td.code as test_code, td.department as test_department, "
        "p.id as patient_id, p.gender as gender, p.age as age, p.age_unit as age_unit "
        "FROM order_tests ot JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id JOIN visits v2 ON v2.id = o.visit_id "
        "JOIN patients p ON p.id = v2.patient_id "
        "WHERE o.visit_id=? ORDER BY ot.id",
        (visit_id,),
    ).fetchall()
    if not order_tests:
        flash("لا توجد تحاليل مطلوبة بهذي الزيارة.")
        return redirect(url_for("results_list"))

    # ترتيب ثابت لعرض/طباعة/إدخال التحاليل — بغض النظر عن ترتيب طلبها الفعلي
    # بهذي الزيارة (ot.id الافتراضي). الأدمن يحدد الترتيب المطلوب من
    # Management → الإعدادات → "ترتيب التحاليل بشاشة إدخال النتائج" (اسم
    # التحليل بالضبط كما يظهر بالشاشة، مثلاً "HbA1c (BioChemstry)"، سطر لكل
    # تحليل). أي تحليل غير مذكور هناك يُرتَّب افتراضيًا حسب أولوية القسم
    # (DEPARTMENT_PRIORITY_KEYWORDS: كيمياء ← فايروسات ← هرمونات ← فيتامينات
    # ← تخثر ← أمراض الدم)، وبينهم حسب ترتيبهم الأصلي (ot.id) — فلو المريض
    # ماله بعض الأقسام تلقائيًا تنتخطى وتنطبع/تنعرض بس الأقسام الموجودة فعلاً
    # بنفس التسلسل المطلوب.
    order_pref_raw = get_setting(db, "results_entry_test_order", "")
    order_pref = [ln.strip() for ln in order_pref_raw.splitlines() if ln.strip()]
    if order_pref:
        rank = {name: i for i, name in enumerate(order_pref)}
        order_tests = sorted(
            order_tests,
            key=lambda row: (
                rank.get(row["test_name"], len(order_pref)),
                department_priority_rank(row["test_department"]),
                row["id"],
            ),
        )
    else:
        order_tests = sorted(
            order_tests,
            key=lambda row: (department_priority_rank(row["test_department"]), row["id"]),
        )

    if request.method == "POST":
        # حماية من التداخل بين الأجهزة: الحفظ يخص فقط التحاليل المعروضة بهذي الشاشة (shown_ot_ids)،
        # فجهاز ثاني يدخل نتائج تحليل آخر بنفس الزيارة ما يتأثر ولا يُستبدل بقيم قديمة.
        _shown_raw = (request.form.get("shown_ot_ids") or "").strip()
        if _shown_raw:
            _shown_ids = {int(x) for x in _shown_raw.split(",") if x.strip().isdigit()}
            order_tests = [_o for _o in order_tests if _o["id"] in _shown_ids]
        # نفس حماية النتيجة المكتملة (المطلوب 2)، لكن هنا مرة وحدة لكل
        # الطلب بدل كل تحليل لحاله -- إذا أي تحليل بهذي الزيارة مكتمل أصلاً،
        # نطلب كلمة المرور مرة وحدة قبل ما نحفظ أي شي من الدفعة كاملة
        # (all-or-nothing، أبسط وأأمن من فحص جزئي لكل بطاقة على حدة).
        # تعديل: كلمة المرور تُطلب فقط لو الإرسال يغيّر فعلاً قيمة نتيجة
        # مكتملة/معتمدة. الطباعة (أو حفظ بدون أي تغيير) لا تحتاج مسؤول.
        unchanged_done_ids = set()
        needs_gate = False
        for ot in order_tests:
            if ot["status"] in ("Completed", "Verified"):
                _params = get_ordered_parameters(db, ot)
                if _ot_has_result_changes(db, ot, _params, request.form, f"ot{ot['id']}_"):
                    needs_gate = True
                else:
                    unchanged_done_ids.add(ot["id"])
        wants_json = request.headers.get("X-Requested-With") == "fetch"
        if needs_gate:
            ok, err = _check_completed_result_gate(db, request.form)
            if not ok:
                if wants_json:
                    return jsonify({"ok": False, "needs_gate": True, "error": err}), 403
                flash(err)
                return redirect(url_for("visit_results_entry", visit_id=visit_id))
        gate_person = (request.form.get("gate_person_name") or "").strip()
        any_saved = False
        touched_ot_ids = []
        for ot in order_tests:
            if ot["id"] in unchanged_done_ids:
                continue  # نتيجة مكتملة بدون تغيير: لا نعيد كتابتها (يبقى سجل من أدخلها كما هو)
            # التحاليل المعتمدة (Verified) صارت قابلة للتعديل دائمًا هيه
            # بعد، وتبقى معتمَدة بعد الحفظ (ما تحتاج فتح/إلغاء اعتماد أولًا)
            # — كل تعديل يبقى مسجّل بجدول result_history (القيمة القديمة +
            # مين عدّلها ووقتها) بغض النظر عن حالة الاعتماد.
            parameters = get_ordered_parameters(db, ot)
            touched = save_order_test_results(
                db, ot, parameters, request.form, session.get("user_id"), field_prefix=f"ot{ot['id']}_",
                patient_id=ot["patient_id"],
            )
            if touched:
                any_saved = True
                touched_ot_ids.append(ot["id"])
                _rt80 = _v80_retic_sibling_id(db, ot)   # v80: Retic اللي انكمل من BF يدخل بتحديث PDF/الأرشيف
                if _rt80 and _rt80 not in touched_ot_ids:
                    touched_ot_ids.append(_rt80)
                if ot["status"] != "Verified":
                    db.execute("UPDATE order_tests SET status='Completed' WHERE id=?", (ot["id"],))
        db.commit()
        if any_saved:
            _post_save_background(visit_id, touched_ot_ids)
            log_action("EnterResultsBulk", "visit", visit_id, f"gate_person={gate_person}" if gate_person else None)
            if not wants_json:
                flash("تم حفظ النتائج.")
        elif not wants_json:
            flash("لم تُدخل أي قيمة جديدة.")
        if wants_json:
            # عدد التحاليل المكتملة/المعتمدة بالزيارة — تستخدمه أزرار الطباعة العلوية
            # (اللوحة المجمّعة/كل النتائج) لتنبيه المستخدم لو ما فيه شي يُطبع.
            _done_cnt = db.execute(
                "SELECT COUNT(*) c FROM order_tests ot JOIN orders o ON o.id = ot.order_id "
                "WHERE o.visit_id=? AND ot.status IN ('Completed', 'Verified')", (visit_id,),
            ).fetchone()["c"]
            return jsonify({"ok": True, "saved": any_saved, "completed": _done_cnt})
        return redirect(url_for("visit_results_entry", visit_id=visit_id))

    # ?only=12,15 : عرض تحاليل محددة فقط (يجي من \"الإدخال السريع\") مع رابط لعرض كل تحاليل الزيارة.
    _only_raw = (request.args.get("only") or "").strip()
    only_mode, only_hidden = False, 0
    if _only_raw:
        _only_ids = {int(x) for x in _only_raw.split(",") if x.strip().isdigit()}
        _kept = [_o for _o in order_tests if _o["id"] in _only_ids]
        if _kept:
            only_mode, only_hidden = True, len(order_tests) - len(_kept)
            order_tests = _kept

    boxes = []
    for ot in order_tests:
        parameters = get_ordered_parameters(db, ot)
        results = db.execute(
            "SELECT r.*, tp.name as param_name FROM results r "
            "JOIN test_parameters tp ON tp.id=r.test_parameter_id WHERE order_test_id=?",
            (ot["id"],),
        ).fetchall()
        results_by_param = {r["test_parameter_id"]: r for r in results}
        ranges = {}
        suggestions_map = {}
        history_map = {}
        for p in parameters:
            ranges[p["id"]] = find_reference_range(
                db, p["id"], visit["gender"], visit["age"], visit["age_unit"],
                patient_id=visit["patient_id"],
                analyzer=ot["analyzer"] if "analyzer" in ot.keys() else None,
            )
            sugg = db.execute("SELECT content FROM suggestions WHERE test_parameter_id=?", (p["id"],)).fetchall()
            suggestions_map[p["id"]] = [s["content"] for s in sugg]
            history_map[p["id"]] = db.execute(
                "SELECT * FROM result_history WHERE order_test_id=? AND test_parameter_id=? "
                "ORDER BY id DESC LIMIT 1",
                (ot["id"], p["id"]),
            ).fetchone()
        _hid_ids = _hidden_param_ids(db, ot["id"])
        _hidden_params = [{"id": hp["id"], "name": hp["name"]} for hp in db.execute(
            "SELECT id, name FROM test_parameters WHERE test_definition_id=? ORDER BY sort_order, id",
            (ot["test_definition_id"],)).fetchall() if hp["id"] in _hid_ids]
        boxes.append({
            "ot": ot, "parameters": parameters, "results_by_param": results_by_param,
            "ranges": ranges, "suggestions_map": suggestions_map, "history_map": history_map,
            "hidden_params": _hidden_params,
        })

    boxes = _v80_adjust_entry_boxes(db, visit_id, boxes)   # v80
    _pv_cfg = get_result_layout(db)
    _pv_has_merge = bool(get_visit_previous_merges(db, visit_id))
    return render_template("front_desk/visit_results_entry.html", visit=visit, boxes=boxes,
                            prev_visits_count=effective_prev_count(db, visit_id, _pv_cfg, _pv_has_merge),
                            patient_hct=get_visit_hct(db, visit_id),
                            patient_hct_normal=get_normal_hct(db, visit["gender"], visit["age"], visit["age_unit"]),
                            # هل كل تحاليل هذي الزيارة مكتملة/معتمدة؟ — يُستخدم لإظهار
                            # زر "إرسال عبر واتساب" لكل نتائج الزيارة دفعة وحدة بجانب
                            # زر إدخال النتائج (راجع partials/whatsapp_send_button.html).
                            all_completed=all(ot["status"] in ("Completed", "Verified") for ot in order_tests),
                            balance=_visit_balance(db, visit_id),
                            only_mode=only_mode, only_hidden=only_hidden)


# ------------------------------------------------------------------------
# "اللوحة المجمّعة" — تجمع كل التحاليل "البسيطة" لنفس الزيارة (أي تحليل
# ماله تقرير مخصص كبير بـ REPORT_TEMPLATE_MAP، يعني كل شي غير CBC/Blood
# Film/WBC Differential/Fluid exam/Coagulation) بورقة A4 وحدة، مرتّبة
# حسب القسم (Department) اللي حدده الأدمن لكل تحليل بكتالوج التحاليل —
# مثلاً كل تحاليل قسم "Biochemical Test" تحت عنوان وحد، وتحتها "Virology
# screen"، وتحتها "Hormones"، وتحتها "Vitamins"، وهكذا لأي قسم إضافي،
# بنفس ترويسة الشعار والأطباء المشتركة (reports/base_report.html) بدون
# أي تكرار لها. تحليل بدون أي نتيجة مُدخلة بعد يُستبعد من اللوحة تلقائيًا
# حتى ما تطلع أسطر فاضية.
# ------------------------------------------------------------------------

# عناوين أعمدة اللوحة المجمّعة تختلف حسب اسم القسم — قسم Biochemistry تحديداً
# يستخدم تسميات مختلفة ("Laboratory Test Results" / "Conventional Units")
# عن بقية الأقسام ("Test Name" / "Normal Range") بنفس التقرير، مطابقةً
# لتصميم الورقة الأصلية. المطابقة بالاحتواء (case-insensitive) حتى تشتغل
# حتى لو الأدمن كتب اسم القسم بصيغة مختلفة شوي بكتالوج التحاليل (مثلاً
# "Biochemistry" أو "Biochemistry Tests" أو "biochemistry panel").
def _panel_column_labels(department_name):
    d = (department_name or "").strip().lower()
    if "biochem" in d:
        return {"name_header": "Laboratory Test Results", "range_header": "Conventional Units"}
    return {"name_header": "Test Name", "range_header": "Normal Range"}


def build_layout_view(db, style_override=None, cfg=None, theme_override=None):
    """يجهّز كل ما يحتاجه القالب المشترك reports/partials/result_styles.html:
    الأسلوب، التسميات النهائية (الافتراضية + تخصيص المستخدم)، الألوان، وتوزيع
    الأعمدة الإضافية حسب مكانها بالأسلوب المختار."""
    cfg = cfg or get_result_layout(db)
    style = style_override if style_override in RESULT_STYLES else cfg["style"]
    labels = effective_labels(cfg, style)
    ex = {k: [] for k in ("test", "result", "unit", "range", "conv", "si", "name")}
    for c in cfg["extra_cols"]:
        if str(c.get("show", "1")) in ("0", "False", "false"):
            continue
        after = c.get("after") or "test"
        if style in ("a1", "a2", "r2"):
            key = {"conv": "result", "si": "unit"}.get(after, after)
            key = key if key in ("test", "result", "unit", "range") else "test"
        elif style in ("b_grid", "r1"):
            key = {"test": "test", "result": "conv", "unit": "conv", "range": "si",
                   "conv": "conv", "si": "si"}.get(after, "test")
        else:
            key = "name"
        ex[key].append(c)
    theme = theme_override if theme_override in ("default", "green", "custom") else cfg["theme"]
    return {"style": style, "labels": labels, "colors": resolve_theme_colors(cfg, theme), "theme": theme, "ex": ex,
            "prev_order": cfg["prev_order"], "dept_headings": cfg["dept_headings"],
            "prev_count": cfg["prev_count"], "prev_default_show": cfg["prev_default_show"],
            "show_prev_visit_line": cfg["show_prev_visit_line"],
            "extra_cols": cfg["extra_cols"], "unit_gap": cfg.get("unit_gap", 6),
            "row_gap": cfg.get("row_gap", 8), "line_gap": cfg.get("line_gap", 2)}


def _history_with_unit2(hist_list, factor):
    out = []
    for h in hist_list or []:
        out.append({"date": h["date"], "value": h["value"],
                    "value2": format_unit2_value(h["value"], factor) if factor not in (None, "", 0) else None})
    return out


def _row_extras_and_note(ctx, td_id, pname):
    """(extras{id: نص}, note, note_key) لصف معيّن — من ctx اللي تبنيه مسارات الطباعة."""
    key = f"{td_id}|{pname}"
    extras = {}
    for eid, mp in (ctx.get("extra_values") or {}).items():
        v = (mp or {}).get(key)
        if v:
            extras[eid] = v
    note = (ctx.get("notes") or {}).get(key)
    return extras, note, key


def _build_panel_rows_for_ot(db, ot, visit, merged_by_test_def, ctx=None):
    """يبني صفوف عرض تحليل واحد (اسم/نتيجة/وحدة/مدى طبيعي/نتيجة سابقة...)
    بنفس المنطق حرفيًا -- تُستخدم من مسارين: اللوحة المجمّعة (print_combined_panel،
    عدة تحاليل بورقة وحدة) والطباعة المفردة (_print_report_impl، تحليل واحد
    لحاله). دمجهما بدالة وحدة يضمن التطابق الدائم بينهما: أي إصلاح مستقبلي
    هنا ينطبق تلقائيًا على الحالتين، فلا يصير فرق شكل بين "تحليل السكر وحده"
    و"تحليل السكر ضمن تقرير فيه عدة تحاليل" -- وهذا بالضبط المطلوب.
    ot: صف order_tests (لازم يحوي test_definition_id, id, test_name, analyzer,
    panel_color, panel_page_break). ترجع [] لو ما فيه نتائج مُدخلة بعد."""
    params = db.execute(
        "SELECT * FROM test_parameters WHERE test_definition_id=? ORDER BY sort_order, id", (ot["test_definition_id"],)
    ).fetchall()
    if not params:
        return []
    results = db.execute(
        "SELECT r.*, tp.name as pname FROM results r "
        "JOIN test_parameters tp ON tp.id = r.test_parameter_id WHERE order_test_id=?",
        (ot["id"],),
    ).fetchall()
    results_by_name = {r["pname"]: r for r in results}
    multi_param = len(params) > 1
    rows = []
    # التخثر: قيمة "PT Control" / "PTT Control" ما تنعرض كصف مستقل، تُرفق مع صف PT/PTT نفسه
    # (نفس فكرة عمود Control بقالب coagulation.html القديم، ويظهر فقط لو PT أو PTT موجود).
    _is_coag = (ot["test_code"] or "") == "COAG"
    control_by_base = {}
    if _is_coag:
        for _pn, _rr in results_by_name.items():
            if _pn.strip().lower().endswith("control"):
                _cv = _rr["value_text"] if _rr["value_text"] not in (None, "") else _rr["value_numeric"]
                if _cv not in (None, ""):
                    control_by_base[_pn.strip()[:-7].strip().lower()] = _cv
    for p in params:
        r = results_by_name.get(p["name"])
        if r is None:
            continue
        if _is_coag and p["name"].strip().lower().endswith("control"):
            continue
        value = r["value_text"] if r["value_text"] not in (None, "") else r["value_numeric"]
        if value in (None, ""):
            continue
        rng = find_reference_range(db, p["id"], visit["gender"], visit["age"], visit["age_unit"],
                                    patient_id=visit["patient_id"],
                                    analyzer=ot["analyzer"] if "analyzer" in ot.keys() else None)
        if rng and rng["range_text"]:
            range_display = rng["range_text"]
        elif rng and rng["low"] is not None and rng["high"] is not None:
            range_display = f"{rng['low']} - {rng['high']}"
        elif rng and rng["low"] is not None:
            range_display = f"≥ {rng['low']}"
        elif rng and rng["high"] is not None:
            range_display = f"≤ {rng['high']}"
        else:
            range_display = ""
        if rng and rng["range_text"]:
            range_tiers = parse_range_tiers(rng["range_text"])
        elif range_display:
            range_tiers = [{"label": None, "value": range_display}]
        else:
            range_tiers = []
        value2 = unit2 = range2_display = None
        if p["unit2"] and p["unit2_factor"] not in (None, "", 0):
            try:
                factor = float(p["unit2_factor"])
                if r["value_numeric"] is not None:
                    value2 = round(float(r["value_numeric"]) * factor, 2)
                unit2 = p["unit2"]
                if rng and rng["low"] is not None and rng["high"] is not None:
                    range2_display = f"{round(rng['low'] * factor, 2)} - {round(rng['high'] * factor, 2)}"
            except (TypeError, ValueError):
                value2 = unit2 = range2_display = None
        display_name = resolve_label(p) if multi_param else ot["test_name"]
        previous_display = None
        for m in merged_by_test_def.get(ot["test_definition_id"], []):
            prev_val = m["results"].get(p["name"])
            if prev_val not in (None, ""):
                previous_display = f"{display_name}: {prev_val} ({m['date_display']})"
                break
        ctx = ctx or {}
        _hist = []
        if ctx.get("show_prev") and ctx.get("prev_limit", 0) > 0:
            _hcache = ctx.setdefault("_hist_cache", {})
            if ot["test_definition_id"] not in _hcache:
                _hcache[ot["test_definition_id"]] = get_previous_history(
                    db, visit["id"], ot["test_definition_id"], ctx.get("prev_limit", 2), ctx.get("prev_order", "desc"))
            _hist = _history_with_unit2(_hcache[ot["test_definition_id"]].get(p["name"]),
                                        p["unit2_factor"] if p["unit2"] else None)
        _extras, _note, _nkey = _row_extras_and_note(ctx, ot["test_definition_id"], p["name"])
        rows.append({
            "control": control_by_base.get(p["name"].strip().lower()) if _is_coag else None,
            "history": _hist, "extras": _extras, "note": _note, "note_key": _nkey,
            "range2": range2_display,
            "name": display_name,
            "result": value,
            "unit": p["unit"] or "",
            "range_display": range_display,
            "range_tiers": range_tiers,
            "flag": r["flag"] if "flag" in r.keys() else None,
            "value_align": resolve_value_align(p) if multi_param else None,
            "value2": value2,
            "unit2": unit2,
            "range2_display": range2_display,
            "previous_display": previous_display,
            "color": p["panel_color"] or ot["panel_color"] or None,
            "_own_page_break": bool(p["panel_page_break"]),
        })
    if not rows:
        return []
    for row in rows:
        if row.pop("_own_page_break", False):
            row["page_break_before"] = True
    if ot["panel_page_break"]:
        rows[0]["page_break_before"] = True
    return rows



_AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
_NUM_WORDS = {"واحد": 1, "اثنين": 2, "اثنان": 2, "ثنين": 2, "ثلاث": 3, "ثلاثه": 3, "اربع": 4, "اربعه": 4,
              "خمس": 5, "خمسه": 5, "ست": 6, "سته": 6, "سبع": 7, "سبعه": 7, "ثمان": 8, "ثماني": 8, "ثمانيه": 8,
              "تسع": 9, "تسعه": 9, "عشر": 10, "عشره": 10}


def _norm_ar(t):
    t = (t or "").translate(_AR_DIGITS).lower().replace("ـ", "")
    for a, b in (("أ", "ا"), ("إ", "ا"), ("آ", "ا"), ("ى", "ي"), ("ة", "ه"), ("،", " "), (",", " ")):
        t = t.replace(a, b)
    return re.sub(r"\s+", " ", t).strip()


def parse_expected_text(text, now=None):
    """يحوّل وقت مكتوب (ربع ساعة / نصف ساعة / ساعتين / ساعة ونصف / 3 ساعات / 45 دقيقة / يومين / 4:30 /
    الساعة 5 مساء ...) إلى datetime. يرجّع None إذا ما فهم النص (فيُعرض كما كُتب)."""
    now = now or datetime.now()
    t = _norm_ar(text)
    if not t:
        return None
    for w in ("بعد", "خلال", "تقريبا", "حوالي", "نحو", "الي", "في", "ب"):
        t = re.sub(rf"(?<![\w]){w}(?![\w])", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    # ---------- ساعة محددة (4:30 / الساعة 5 مساء) ----------
    m = re.fullmatch(r"(?:الساعه )?(\d{1,2})(?:[:.](\d{2}))?\s*(صباحا|ص|ظهرا|عصرا|العصر|مساء|م|ليلا|الليل|المساء|الصباح|الظهر)?", t)
    if m and (":" in t or "." in t or t.startswith("الساعه") or m.group(3)):
        h, mi, per = int(m.group(1)), int(m.group(2) or 0), m.group(3) or ""
        if h > 23 or mi > 59:
            return None
        pm = per in ("مساء", "م", "عصرا", "العصر", "ليلا", "الليل", "المساء", "ظهرا", "الظهر")
        if pm and h < 12:
            h += 12
        cand = now.replace(hour=h, minute=mi, second=0, microsecond=0)
        if not per and h <= 12:
            if cand <= now:
                cand2 = cand + timedelta(hours=12)
                cand = cand2 if cand2 > now else cand + timedelta(days=1)
        elif cand <= now:
            cand += timedelta(days=1)
        return cand
    # ---------- مدة (ساعة ونصف / 3 ساعات / 45 دقيقة / يومين ...) ----------
    minutes = 0.0
    rest = t
    def take(pattern, mins):
        nonlocal rest, minutes
        hit = re.search(pattern, rest)
        if hit:
            minutes += mins(hit) if callable(mins) else mins
            rest = (rest[:hit.start()] + " " + rest[hit.end():]).strip()
            return True
        return False
    take(r"ثلاث(?:ه)? ارباع (?:ال)?ساعه", 45)
    take(r"(?<![\w])ربع (?:ال)?ساعه", 15)
    take(r"(?<![\w])ثلث (?:ال)?ساعه", 20)
    take(r"(?<![\w])(?:نصف|نص) (?:ال)?ساعه", 30)
    unit_mins = {"دقيقه": 1, "دقايق": 1, "دقائق": 1, "دقيقتين": 2, "ساعه": 60, "ساعات": 60, "ساعتين": 120, "ساعتان": 120,
                 "يوم": 1440, "ايام": 1440, "يومين": 2880, "يومان": 2880, "اسبوع": 10080, "اسابيع": 10080,
                 "اسبوعين": 20160}
    num = r"(\d+(?:\.\d+)?|" + "|".join(sorted(_NUM_WORDS, key=len, reverse=True)) + r")"
    units = "|".join(sorted(unit_mins, key=len, reverse=True))
    # رقم + وحدة
    while True:
        hit = re.search(num + r" (?:ال)?(" + units + r")(?![\w])", rest)
        if not hit:
            break
        n = hit.group(1)
        val = float(n) if re.fullmatch(r"\d+(?:\.\d+)?", n) else _NUM_WORDS[n]
        minutes += val * unit_mins[hit.group(2)]
        rest = (rest[:hit.start()] + " " + rest[hit.end():]).strip()
    # وحدة لحالها (ساعة، ساعتين، يوم، يومين، اسبوع...)
    for mt in re.finditer(r"(?<![\w])(" + units + r")(?![\w])", rest):
        minutes += unit_mins[mt.group(1)]
    rest = re.sub(r"(?<![\w])(" + units + r")(?![\w])", " ", rest)
    # كسور بعد ساعة: ونصف / وربع / وثلث
    take(r"(?<![\w])و ?(?:نصف|نص)(?![\w])", 30)
    take(r"(?<![\w])و ?ربع(?![\w])", 15)
    take(r"(?<![\w])و ?ثلث(?![\w])", 20)
    left = re.sub(r"(?<![\w])(?:و|ال|تقريبا)(?![\w])", " ", rest).strip()
    if minutes <= 0 or left:
        return None
    return (now + timedelta(minutes=minutes)).replace(second=0, microsecond=0)


@app.route("/api/expected/parse")
@login_required
def api_expected_parse():
    txt = (request.args.get("text") or "").strip()[:60]
    dt = parse_expected_text(txt)
    if not dt:
        return {"ok": False}
    return {"ok": True, "iso": dt.strftime("%Y-%m-%dT%H:%M"), "label": dt.strftime("%Y-%m-%d %H:%M")}


def _heading_css_ctx(cfg, dept_names):
    """CSS جاهز لعنوان اللوحة المجمّعة وعناوين الأقسام (من إعدادات مصمم التقارير)."""
    head = text_style_css(cfg.get("head_style") or {})
    per = cfg.get("dept_styles") or {}
    return {"title_css": text_style_css(cfg.get("title_style") or {}), "head_css": head,
            "dept_css_map": {n: head + text_style_css(per[n]) for n in dept_names if n in per}}


def _form_text_style(prefix):
    return sanitize_text_style({k: request.form.get(f"{prefix}_{k}") for k in ("color", "font", "size", "case", "bold", "italic")})


def _print_combined_panel_core(visit_id):
    db = get_db()
    visit = db.execute(
        "SELECT v.*, p.full_name as patient_name, p.age, p.age_unit, p.gender, "
        "d.full_name as referring_doctor_name, rc.name as referral_center_name "
        "FROM visits v JOIN patients p ON p.id = v.patient_id "
        "LEFT JOIN doctors d ON d.id = v.doctor_id "
        "LEFT JOIN referral_centers rc ON rc.id = v.referral_center_id WHERE v.id=?",
        (visit_id,),
    ).fetchone()
    if not visit:
        return "Not found", 404

    order_tests = db.execute(
        "SELECT ot.*, td.code as test_code, td.name as test_name, td.department as department, "
        "td.report_group as report_group, td.done_by_note as done_by_note, "
        "td.panel_color as panel_color, td.panel_page_break as panel_page_break "
        "FROM order_tests ot JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id "
        "WHERE o.visit_id=? AND ot.status IN ('Completed', 'Verified') "
        "ORDER BY COALESCE(NULLIF(TRIM(td.report_group), ''), td.department), td.name",
        (visit_id,),
    ).fetchall()

    # التقرير الشامل: يضم الكيمياء/الهرمونات/الفيتامينات/الفايروسات/الدلائل الورمية/التخثر
    # ويستثني CBC وBlood film وRetic وBMA وBMP وFluid وHb.H وكل Electrophoresis (قائمة
    # الاستثناء قابلة للتعديل من "تصميم التقارير"). أي تحليل له قالب مستقل (GUE/GSE/SFA...) ما يدخل.
    layout_cfg = get_result_layout(db)
    _excl_kws = merged_exclude_keywords(layout_cfg)

    def _merged_ok(_ot):
        _code = _ot["test_code"] or ""
        if _code in REPORT_TEMPLATE_MAP and _code != "COAG":
            return False
        _hay = (_code + " " + (_ot["test_name"] or "")).lower()
        return not any(k in _hay for k in _excl_kws)
    _v80_has_cbc = any((_o["test_code"] or "") == "CBC" for _o in order_tests)   # v80: ESR يطلع داخل تقرير CBC
    order_tests = [_o for _o in order_tests if _merged_ok(_o)
                   and not (_v80_has_cbc and _v80_is_esr(_o["test_code"], _o["test_name"]))]

    # سطر/أسطر "Done by ..." (المطلوب 7) — كل تحليل داخل هذي اللوحة المجمّعة
    # ممكن يكون له done_by_note مختلف (أجهزة مختلفة لكل تحليل)، فنجمع كل
    # القيم غير الفاضية بدون تكرار، بنفس ترتيب ظهور تحاليلها بالتقرير.
    done_by_notes = []
    for _ot in order_tests:
        note = (_ot["done_by_note"] or "").strip() if "done_by_note" in _ot.keys() else ""
        if note and note not in done_by_notes:
            done_by_notes.append(note)

    # التحاليل القديمة (من زيارات سابقة) اللي وافق الموظف صراحة على دمج
    # نتائجها بهذي الزيارة تحديداً — راجع visit_previous_merges. مبوّبة
    # حسب test_definition_id لتسهيل مطابقتها مع تحاليل نفس النوع بالزيارة
    # الحالية (تُعرض كصف "Previous" جنبها)، أو كصف مستقل لو ما تكرر طلب
    # نفس التحليل بهذي الزيارة (راجع الحلقة بعد الحلقة الرئيسية أدناه).
    merged_previous = get_visit_previous_merges(db, visit_id)
    merged_by_test_def = {}
    for m in merged_previous:
        merged_by_test_def.setdefault(m["test_definition_id"], []).append(m)
    current_test_def_ids = {ot["test_definition_id"] for ot in order_tests}

    # عدد الزيارات السابقة = اختيار الموظف بصفحة "زيارة جديدة" (0 = إلغاء)، وترتيبها من الإعدادات.
    prev_count_eff = effective_prev_count(db, visit_id, layout_cfg, bool(merged_by_test_def))
    prev_toggle_available = prev_count_eff > 0
    _sp = request.args.get("show_prev")
    show_prev_values = prev_toggle_available and ((_sp != "0") if _sp is not None else bool(layout_cfg["prev_default_show"]))
    row_ctx = {
        "show_prev": show_prev_values, "prev_limit": prev_count_eff, "prev_order": layout_cfg["prev_order"],
        "notes": get_row_notes(db, visit_id), "extra_values": get_extra_col_values(db),
    }

    groups_by_dept = {}
    dept_order = []
    for ot in order_tests:
        rows = _build_panel_rows_for_ot(db, ot, visit, merged_by_test_def, row_ctx)
        if not rows:
            continue
        # الأولوية دائماً لاسم "الريبورت المجمّع" المخصص (report_group) إذا
        # الأدمن حدده لهذا التحليل من كتالوج التحاليل — وإلا نرجع لاسم
        # القسم (department) القديم كما كان الوضع قبل هذي الميزة.
        dept = (ot["report_group"] or "").strip() or ot["department"] or "Other"
        if dept not in groups_by_dept:
            groups_by_dept[dept] = []
            dept_order.append(dept)
        groups_by_dept[dept].extend(rows)

    # تحاليل قديمة موافَق على دمجها بس ما تكرر طلب نفس نوعها بهذي الزيارة
    # الجديدة إطلاقاً — تُضاف كصفوف "Previous" مستقلة (بدون نتيجة حالية
    # مقابلة) بنفس مجموعة قسمها، بدل ما تُفقَد لأن ما فيه صف حالي تُرفَق
    # جنبه.
    for test_def_id, merges in merged_by_test_def.items():
        if test_def_id in current_test_def_ids or not show_prev_values:
            continue
        td_row = db.execute(
            "SELECT department, report_group, name FROM test_definitions WHERE id=?", (test_def_id,)
        ).fetchone()
        if not td_row:
            continue
        old_params = db.execute(
            "SELECT * FROM test_parameters WHERE test_definition_id=? ORDER BY sort_order, id", (test_def_id,)
        ).fetchall()
        multi_param_prev = len(old_params) > 1
        dept = (td_row["report_group"] or "").strip() or td_row["department"] or "Other"
        hist_all = get_previous_history(db, visit_id, test_def_id, prev_count_eff, layout_cfg["prev_order"])
        prev_rows = []
        for p in old_params:
            hl = hist_all.get(p["name"])
            if not hl:
                continue
            pname = resolve_label(p) if multi_param_prev else td_row["name"]
            _ex, _note, _nkey = _row_extras_and_note(row_ctx, test_def_id, p["name"])
            prev_rows.append({
                "name": pname, "result": None, "unit": p["unit"] or "", "range_display": "",
                "range_tiers": [], "flag": None, "value2": None,
                "unit2": p["unit2"] if p["unit2"] else None, "range2_display": None, "range2": None,
                "color": None,
                "history": _history_with_unit2(hl, p["unit2_factor"] if p["unit2"] else None),
                "extras": _ex, "note": _note, "note_key": _nkey,
            })
        if prev_rows:
            if dept not in groups_by_dept:
                groups_by_dept[dept] = []
                dept_order.append(dept)
            groups_by_dept[dept].extend(prev_rows)

    # ترتيب طباعة أقسام اللوحة المجمّعة — افتراضيًا أبجدي (كما هو بالاستعلام
    # فوق)؛ لو الأدمن حدد ترتيبًا مخصصًا من الإعدادات (combined_panel_group_order)
    # نقدّم الأقسام المذكورة هناك بنفس ترتيبها، وأي قسم غير مذكور يبقى بعدها
    # بترتيبه الأبجدي الأصلي دون أي تغيير.
    group_order_raw = get_setting(db, "combined_panel_group_order", "")
    preferred_order = [ln.strip() for ln in group_order_raw.splitlines() if ln.strip()]
    if preferred_order:
        remaining = [d for d in dept_order if d not in preferred_order]
        dept_order = [d for d in preferred_order if d in dept_order] + remaining
    else:
        # بدون ترتيب مخصص: كيمياء ← فايروسات ← هرمونات ← فيتامينات ← تخثر (نفس ترتيب شاشة النتائج)
        _orig = list(dept_order)
        dept_order = sorted(_orig, key=lambda d: (department_priority_rank(d), _orig.index(d)))

    panel_groups = [
        {"department": d, "rows": groups_by_dept[d], **_panel_column_labels(d)}
        for d in dept_order
    ]

    logo_path = get_setting(db, "logo_path", "")
    logo_url = url_for("static", filename=logo_path) if logo_path else None
    from_other_lab = bool(visit["referral_center_id"]) and visit["referral_center_name"] not in (None, "", "Walk-in")

    try:
        dt = datetime.fromisoformat(visit["created_at"])
        visit_date = f"{dt.day}/{dt.month}/{dt.year}"
    except (TypeError, ValueError):
        visit_date = visit["created_at"] or ""

    age_display = format_age_display(visit["age"], visit["age_unit"])

    auto_flag_color_enabled, show_result_flag, flag_color_map = get_report_flag_settings(db)
    # تباعد الصفوف باللوحة المجمّعة (المطلوب 8) — الصفحة تجمع أكثر من
    # تحليل قد يكون لكل واحد إعداد row_spacing مختلف، فنستخدم أول قيمة
    # مضبوطة فعليًا (غير فاضية) بترتيب ظهور التحاليل بالصفحة كقيمة موحّدة
    # للصفحة كلها؛ ما فيه أي تحليل مضبوط له شي = يبقى التباعد الافتراضي
    # القديم تمامًا (بدون أي تغيير).
    _panel_row_spacing_raw = None
    for _ot in order_tests:
        _td_rs = db.execute(
            "SELECT row_spacing FROM test_definitions WHERE id=?", (_ot["test_definition_id"],)
        ).fetchone()
        if _td_rs and _td_rs["row_spacing"]:
            _panel_row_spacing_raw = _td_rs["row_spacing"]
            break
    _view = build_layout_view(db, style_override=request.args.get("style"), cfg=layout_cfg,
                              theme_override=request.args.get("theme"))
    _h = request.args.get("headings")
    if _h in ("0", "1"):
        show_dept_headings = _h == "1"
    elif layout_cfg["dept_headings"] in ("show", "hide"):
        show_dept_headings = layout_cfg["dept_headings"] == "show"
    else:
        show_dept_headings = _view["style"] in ("a1", "a2", "r3")
    all_rows = [r for g in panel_groups for r in g["rows"]]
    # فاصل الصفحة (page_break_before) على أول صف بأول لوحة يطلّع صفحة أولى فاضية (ترويسة فقط) والنتائج تنزل
    # للصفحة 2 — ما له معنى قبل أول صف أصلاً، فنتجاهله هنا (الفواصل بين باقي الصفوف تبقى كما هي).
    for _g in panel_groups[:1]:
        for _r in _g["rows"][:1]:
            _r["page_break_before"] = False
    # نفس بيانات رأس التقرير المفرد (اسم إنكليزي، وقت العينة، Number Of) — كانت ناقصة بالتقرير الشامل/اللوحة المجمّعة
    _pt_en_row = db.execute("SELECT full_name_en FROM patients WHERE id=?", (visit["patient_id"],)).fetchone()
    _panel_name_en = (_pt_en_row["full_name_en"] or "") if _pt_en_row else ""
    _panel_time, _panel_number_of = "", ""
    if order_tests:
        _t0 = order_tests[0]
        _k0 = _t0.keys()
        _panel_time = _fmt_hhmm((_t0["collected_at"] if "collected_at" in _k0 and _t0["collected_at"] else "")
                                or (_t0["accessioned_at"] if "accessioned_at" in _k0 and _t0["accessioned_at"] else "")
                                or "")
        try:
            _panel_number_of = get_patient_number_of_day(db, _t0["id"])
        except Exception:  # noqa: BLE001 — ما نوقف الطباعة لو تعذّر حساب العدد
            _panel_number_of = ""
    return render_template(
        "reports/combined_panel.html",
        patient_name_en=_panel_name_en, sample_time=_panel_time, number_of=_panel_number_of,
        panel_groups=panel_groups, logo_url=logo_url, from_other_lab=from_other_lab, other_lab_visit_id=visit["id"],
        show_dept_headings=show_dept_headings, all_rows=all_rows, merged_title=layout_cfg["merged_title"],
        **_heading_css_ctx(layout_cfg, [g["department"] for g in panel_groups]),
        sample_no=(visit["sample_no"] if "sample_no" in visit.keys() else "") or "",
        layout_view=_view, note_visit_id=visit_id,
        report_layout={}, report_layout_has_patient_override=False,
        prev_toggle_available=prev_toggle_available, show_prev_values=show_prev_values,
        prev_toggle_checked=show_prev_values,
        visit_date=visit_date, sex=visit["gender"] or "", age=age_display,
        patient_name=visit["patient_name"], patient_id=visit["registration_number"],
        referring_doctor_name=visit["referring_doctor_name"] or "",
        show_exam_signature=False,
        auto_flag_color_enabled=auto_flag_color_enabled, show_result_flag=show_result_flag, AUTO_FLAG_COLORS=flag_color_map,
        row_spacing_px=row_spacing_px(_panel_row_spacing_raw),
        done_by_notes=done_by_notes,
        # مكتبة الأختام/التواقيع + أي ختم مُلصق فعلاً فوق هذا التقرير الموحّد
        # حاليًا (راجع partials/stamp_picker.html لطريقة استخدامها بالقالب).
        stamp_target_type="visit", stamp_target_id=visit_id,
        digital_stamps=get_digital_stamps(db),
        stamp_placements=_serialize_stamp_placements(get_stamp_placements(db, "visit", visit_id)),
    )


@app.route("/front-desk/visits/<int:visit_id>/print/combined-panel")
@login_required
def print_combined_panel(visit_id):
    """اللوحة المجمّعة (كيمياء/هرمونات/...) + تقارير التحاليل ذات القالب المستقل (GUE/GSE/SFA وتقارير
    أمراض الدم...) بصفحة وحدة بعدها — بدل ما تُهمَل هذي التقارير وتطلع الصفحة فاضية."""
    db = get_db()
    cfg = get_result_layout(db)
    kws = merged_exclude_keywords(cfg)
    rows = db.execute(
        "SELECT ot.id, td.code AS code, td.name AS name, td.department AS dept "
        "FROM order_tests ot JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id WHERE o.visit_id=? AND ot.status IN ('Completed','Verified') ORDER BY ot.id",
        (visit_id,),
    ).fetchall()
    if any((_r["code"] or "") == "CBC" for _r in rows):   # v80: ESR يطلع داخل تقرير CBC
        rows = [_r for _r in rows if not _v80_is_esr(_r["code"], _r["name"])]
    panel_ids, extra_ids = [], []
    for r in rows:
        code = r["code"] or ""
        hay = (code + " " + (r["name"] or "")).lower()
        if (code in REPORT_TEMPLATE_MAP and code != "COAG") or any(k in hay for k in kws):
            extra_ids.append(r)
        else:
            panel_ids.append(r)
    if not extra_ids:
        return _print_combined_panel_core(visit_id)
    extra_ids.sort(key=lambda r: (department_priority_rank(r["dept"]), r["id"]))
    # v79: أزواج BF+RETIC (و SICKLE+HBPREP) تُطبع بتقرير واحد: نُبقي تحليلًا واحدًا من كل زوج (print_report يدمج الثاني معه).
    # (قبل: كان يحذف الاثنين معًا فيختفي BF/Retic من اللوحة المجمّعة أو يطلعون بملف منفصل)
    _kept_codes, _kept = set(), []
    for _r in extra_ids:
        _c = _r["code"]
        if _c in BF_RETIC_LINK and BF_RETIC_LINK[_c] in _kept_codes:
            continue
        _kept_codes.add(_c); _kept.append(_r["id"])
    extra_ids = _kept
    from werkzeug.datastructures import MultiDict
    orig_args = request.args
    want_auto = orig_args.get("auto") == "1"
    try:
        request.args = MultiDict([(k, v) for k, v in orig_args.items(multi=True) if k != "auto"])
    except Exception:
        pass
    try:
        panel_html = _print_combined_panel_core(visit_id) if panel_ids else None
        head_html, bodies = _collect_report_bodies(extra_ids)
    finally:
        try:
            request.args = orig_args
        except Exception:
            pass
    sections = []
    if isinstance(panel_html, str):
        hm = re.search(r"<head\b[^>]*>(.*?)</head>", panel_html, re.S)
        bm = re.search(r"<body\b[^>]*>(.*?)</body>", panel_html, re.S)
        if bm:
            sections.append(f"<div>{bm.group(1)}</div>")
            head_html = (hm.group(1) if hm else "") or head_html
    for b in bodies:
        sections.append(b if sections else b.replace(' style="page-break-before:always;"', "", 1))
    if not sections:
        return _print_combined_panel_core(visit_id)
    html_out = ('<!DOCTYPE html><html lang="ar" dir="rtl"><head>' + (head_html or "") + "</head><body>"
                + "".join(s_ if i == 0 else s_.replace("<div>", '<div style="page-break-before:always;">', 1)
                          if s_.startswith("<div>") else s_ for i, s_ in enumerate(sections)) + "</body></html>")
    if want_auto:
        html_out = html_out.replace("</body>", "<script>window.addEventListener('load',function(){setTimeout(function(){"
                                    "if(window.__lisPrinted)return;window.__lisPrinted=true;window.print();},700);});</script></body>", 1)
    return html_out


@app.route("/reports/print/<int:order_test_id>")
@login_required
def print_report(order_test_id):
    try:
        return _print_report_impl(order_test_id)
    except Exception:
        # تشخيص مؤقت: بدل صفحة "Internal Server Error" الفاضية اللي يعرضها
        # فلاسك بوضع الإنتاج (production)، نعرض هنا نص الخطأ الكامل
        # (Traceback) بالضبط مثل وضع debug، ونسجله كمان بملف نصي بجذر
        # البرنامج (error_log.txt) — حتى لو ما انتبه المستخدم يصوّر الشاشة
        # بنفس اللحظة، يكدر يفتح الملف بعدين ويرسله. احذف هذا الـ try/except
        # (رجّع فقط الجسم الأصلي لـ print_report) بعد ما تنحل المشكلة نهائيًا،
        # لأنه مو مناسب يبقى دائمًا مفعّل بنسخة تشتغل عند الزبون (يفضح تفاصيل
        # داخلية تقنية للمستخدم لو صار خطأ مستقبلي غير متوقع).
        import traceback
        tb_text = traceback.format_exc()
        try:
            log_path = os.path.join(os.path.dirname(__file__), "error_log.txt")
            with open(log_path, "a", encoding="utf-8") as f:
                f.write("\n" + "=" * 80 + "\n")
                f.write(datetime.now().isoformat(timespec="seconds") + f"  order_test_id={order_test_id}\n")
                f.write(tb_text)
        except Exception:
            pass
        return (
            "<h1>خطأ أثناء طباعة التقرير — order_test_id="
            + str(order_test_id)
            + "</h1><p>صوّر هذا النص كامل وأرسله:</p>"
            + "<pre style='direction:ltr; text-align:left; white-space:pre-wrap; "
            + "background:#f5f5f5; border:1px solid #ccc; padding:12px;'>"
            + escape(tb_text)
            + "</pre>"
        ), 500


def _fmt_hhmm(iso):
    """وقت سحب العينة بصيغة HH:MM (مثل 09:12) بدل النص الخام للـISO."""
    try:
        return datetime.fromisoformat(iso).strftime("%H:%M")
    except (TypeError, ValueError):
        return iso or ""


def _coag_table_mode(db):
    """تقارير التخثر المنفردة (D-Dimer / Fibrinogen / PT&INR / PTT / Bleeding time): هل تطبع
    بأسلوب جدول النتائج (نفس الكيمياء والهرمونات: Style A/B + الألوان + الملاحظات + النتائج السابقة)؟
    الافتراضي نعم. الخيار "1..4" القديم (قالب coagulation.html) يبقى متاحًا من بطاقة التصاميم.
    ?design=table|1..4 بالرابط يغلب الإعداد المحفوظ (معاينة مؤقتة)."""
    try:
        q = request.args.get("design")
        if q == "table":
            return True
        if q in ("1", "2", "3", "4"):
            return False
    except RuntimeError:
        pass
    return get_setting(db, "report_design_coag", "table") == "table"


def _coag_view(view, is_coag):
    """التخثر بأسلوب B Matching Image: عمود SI Units يُستبدل بعمود Normal Range (لا وحدات SI بالتخثر)."""
    if view is not None and is_coag:
        view["range_col3"] = True
    return view


def _coag_fold_control(rows):
    """يدمج قيمة "PT Control"/"PTT Control" كعمود Control مع صف PT/PTT نفسه، ولا يطبعها كصف مستقل.
    Control يظهر فقط لو PT أو PTT موجود (INR/BT/Fibrinogen/D-Dimer بلا Control)."""
    ctl = {}
    for r in rows:
        nm = (r.get("param_name") or r.get("name") or "").strip()
        if nm.lower().endswith("control"):
            ctl[nm[:-7].strip().lower()] = r.get("result")
    out = []
    for r in rows:
        nm = (r.get("param_name") or r.get("name") or "").strip()
        if nm.lower().endswith("control"):
            continue
        key = nm.lower()
        if key in ("pt", "ptt") and ctl.get(key) not in (None, ""):
            r["control"] = ctl[key]
        out.append(r)
    return out


def _auto_report_template(db, test_definition_id, test_name):
    """تصميم افتراضي تلقائي لتحليل ما له صف report_templates: يعرض كل باراميترات التحليل
    (بترتيبها) بالستايل المختار من "تصميم التقارير". هكذا تحليل واحد (مثل FBS) تكتب نتيجته
    وتطبعه مباشرة بدون ما تصمم له قالب يدوي. ترجع None لو التحليل بلا باراميترات."""
    params = db.execute(
        "SELECT name FROM test_parameters WHERE test_definition_id=? ORDER BY sort_order, id", (test_definition_id,)
    ).fetchall()
    if not params:
        return None
    return {
        "heading": test_name or "", "heading_align": "center", "rows_align": "right",
        "rows_json": json.dumps([{"param_name": p["name"]} for p in params], ensure_ascii=False),
    }


def _print_report_impl_v79(order_test_id):
    db = get_db()
    ot = db.execute(
        "SELECT ot.*, td.code as test_code, td.name as test_name, td.department as test_department, "
        "td.is_examining_test as is_examining_test, td.enable_stamp_widget as enable_stamp_widget, "
        "td.done_by_note as done_by_note, "
        "td.show_lab_stamp as show_lab_stamp, td.show_doctor_stamp as show_doctor_stamp, "
        "td.hide_signature_box as hide_signature_box, td.signature_position as signature_position, "
        "p.id as patient_id, p.full_name as patient_name, p.gender, p.age, p.age_unit, "
        "v.id as visit_id, v.created_at as visit_created_at, v.registration_number, v.sample_no as visit_sample_no, "
        "v.doctor_id, v.referral_center_id, v.examining_doctor, "
        "d.full_name as referring_doctor_name, rc.name as referral_center_name "
        "FROM order_tests ot "
        "JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id "
        "JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id "
        "LEFT JOIN doctors d ON d.id = v.doctor_id "
        "LEFT JOIN referral_centers rc ON rc.id = v.referral_center_id "
        "WHERE ot.id = ?",
        (order_test_id,),
    ).fetchone()
    if not ot:
        return "Not found", 404

    # أول فتحة فعلية لتقرير هذا التحليل (طباعة مفردة، ضمن حزمة نتائج
    # الزيارة، أو حتى توليد PDF لواتساب/الأرشيف يمر من هنا) تُثبَّت
    # كـ"تمت طباعتها" -- بعدها أي تعديل على النتيجة أو معلومات المريض
    # يحتاج دخول يوزر/باسورد مسؤول أو مشرف (راجع _check_completed_result_gate).
    if ot["status"] in ("Completed", "Verified") and not ot["printed_at"]:
        db.execute(
            "UPDATE order_tests SET printed_at=? WHERE id=?",
            (datetime.now().isoformat(timespec="seconds"), order_test_id),
        )
        db.commit()

    template_name = REPORT_TEMPLATE_MAP.get(ot["test_code"])
    _coag_table = (ot["test_code"] == "COAG" and _coag_table_mode(db))
    if _coag_table:
        template_name = None

    sibling_ot = None
    if ot["test_code"] in BF_RETIC_LINK:
        sibling_code = BF_RETIC_LINK[ot["test_code"]]
        sibling_ot = db.execute(
            "SELECT ot2.*, td2.code as test_code FROM order_tests ot2 "
            "JOIN test_definitions td2 ON td2.id = ot2.test_definition_id "
            "WHERE ot2.order_id = ? AND td2.code = ?",
            (ot["order_id"], sibling_code),
        ).fetchone()
        if sibling_ot:
            template_name = (REPORT_TEMPLATE_MAP[ot["test_code"]] if ot["test_code"] in ("SICKLE", "HBPREP")
                             else REPORT_TEMPLATE_MAP["BF"])

    custom_template = None
    auto_template = False
    if not template_name:
        # report_style='generic_exam': تحليل بُني بالكامل من صفحة المعاينة
        # نفسها (سحب أقسام/باراميترات) بدل قالب HTML مكتوب يدويًا — راجع
        # /management/report-designer/<id>/start-generic-exam أدناه.
        td_row = db.execute(
            "SELECT report_style FROM test_definitions WHERE id=?", (ot["test_definition_id"],)
        ).fetchone()
        if td_row and td_row["report_style"] == "generic_exam":
            template_name = "reports/generic_exam.html"
    if not template_name:
        custom_template = get_report_template(db, ot["test_definition_id"])
        if not custom_template:
            # ما له تصميم محفوظ → نبني تصميم تلقائي من باراميتراته بالستايل المختار (ما نرفض الطباعة).
            custom_template = _auto_report_template(db, ot["test_definition_id"], ot["test_name"])
            auto_template = custom_template is not None
        if not custom_template:
            if session.get("role") == "admin":
                flash("لا يوجد تصميم طباعة لهذا التحليل بعد (ولا باراميترات له). صممه من: الإدارة ← مصمم التقارير.")
                return redirect(url_for("report_designer", test_definition_id=ot["test_definition_id"]))
            flash("No printable report layout is defined for this test yet.")
            return redirect(url_for("orders_list"))
        _ot_dept_row = db.execute(
            "SELECT department, report_style FROM test_definitions WHERE id=?", (ot["test_definition_id"],)
        ).fetchone()
        if auto_template or (_ot_dept_row and uses_order_style_report(_ot_dept_row["department"], _ot_dept_row["report_style"])):
            template_name = "reports/custom_v2.html"
        else:
            template_name = "reports/custom.html"

    # When Blood Film and Retic Count are both ordered for this visit, pull
    # parameters/results from BOTH order_tests so the one combined report
    # has everything — regardless of which of the two fields (Retic count,
    # Corrected Retic count) happen to live under which test definition.
    test_def_ids = [ot["test_definition_id"]]
    order_test_ids = [order_test_id]
    if sibling_ot:
        test_def_ids.append(sibling_ot["test_definition_id"])
        order_test_ids.append(sibling_ot["id"])

    parameters = []
    seen_param_names = set()
    for tdid in test_def_ids:
        for p in db.execute("SELECT * FROM test_parameters WHERE test_definition_id=? ORDER BY sort_order, id", (tdid,)).fetchall():
            if p["name"] not in seen_param_names:
                parameters.append(p)
                seen_param_names.add(p["name"])

    # بارامترات محذوفة من تقرير هذا المريض فقط (زر 🗑 بشاشة الإدخال) لا تظهر بالطباعة/الـPDF
    _hid_print = set()
    for _oid in order_test_ids:
        _hid_print |= _hidden_param_ids(db, _oid)
    if _hid_print:
        _kept_print = [p for p in parameters if p["id"] not in _hid_print]
        parameters = _kept_print or parameters

    # قاموس اسم -> صف test_parameters (المطلوب 9ب/11) — يستخدمه custom_rows
    # وcbc_groups أدناه لجلب display_label/value_align لكل باراميتر بدون
    # إعادة الاستعلام لكل صف لحاله.
    params_by_name_row = {p["name"]: p for p in parameters}
    _td_row_spacing = db.execute(
        "SELECT row_spacing FROM test_definitions WHERE id=?", (ot["test_definition_id"],)
    ).fetchone()
    row_spacing_px_value = row_spacing_px(_td_row_spacing["row_spacing"] if _td_row_spacing else None)

    results = []
    for otid in order_test_ids:
        results.extend(db.execute(
            "SELECT r.*, tp.name as param_name FROM results r "
            "JOIN test_parameters tp ON tp.id = r.test_parameter_id WHERE order_test_id=?",
            (otid,),
        ).fetchall())
    results_by_name = {r["param_name"]: r for r in results}

    # وحدة كل باراميتر (اسم → وحدة) — يحتاجه بعض القوالب المخصّصة الجاهزة
    # (مثل blood_film.html) مباشرة كمتغيّر Jinja اسمه units.get('...')،
    # عكس params/ranges اللي تُبنى وتُستخدم فقط داخل مسارات CBC/custom
    # أدناه. يُبنى هنا مرة وحدة ويُمرَّر دائمًا لكل template_name بلا استثناء،
    # حتى لا يتكرر نفس الخطأ (UndefinedError: 'units' is undefined) لأي
    # قالب جاهز آخر يتوقع نفس المتغيّر مستقبلاً.
    units = {p["name"]: (p["unit"] or "") for p in parameters}

    params = {}
    ranges = {}
    # notes: ملاحظة نصية اختيارية محفوظة على صف النتيجة نفسها (عمود
    # results.note) -- تُستخدم حاليًا فقط لملاحظة "النتيجة المصححة أقل من
    # العدّ الأصلي" بتحليل Retic Count (راجع _apply_retic_correction)، لكنها
    # عامة لأي باراميتر مستقبلاً. القالب يعرضها كنص عادي بـeditable-label
    # حتى يقدر المستخدم يحذفها من معاينة الطباعة بنفس طريقة تعديل أي نص آخر
    # بالتقرير، بدون أي زر/ميزة جديدة.
    notes = {}
    for p in parameters:
        r = results_by_name.get(p["name"])
        if r is not None:
            if r["value_text"] not in (None, ""):
                value = r["value_text"]
            else:
                value = r["value_numeric"]
                # رقم صحيح (مثلاً 33.0) يُعرض بدون ".0" الزائدة -- 33 بدل
                # 33.0 -- بينما أي رقم فيه كسر فعلي (مثلاً 12.5) يبقى يظهر
                # بكسره كما هو. يشمل هذا كل نتيجة عددية بأي قالب جاهز يستخدم
                # params.get(...) مباشرة (blood_film.html وغيره)، بما فيها
                # أنواع الفلم الدموي (WBC differential).
                if isinstance(value, float) and value == int(value):
                    value = int(value)
        else:
            value = None
        params[p["name"]] = "" if value is None else value
        notes[p["name"]] = (r["note"] if (r is not None and "note" in r.keys()) else None) or ""
        ranges[p["name"]] = find_reference_range(db, p["id"], ot["gender"], ot["age"], ot["age_unit"],
                                                  patient_id=ot["patient_id"],
                                                  analyzer=ot["analyzer"] if "analyzer" in ot.keys() else None)

    logo_path = get_setting(db, "logo_path", "")
    logo_url = url_for("static", filename=logo_path) if logo_path else None

    # Only show the "received from another lab" note when the visit was
    # actually referred in via a referral center, not a plain walk-in.
    from_other_lab = bool(ot["referral_center_id"]) and ot["referral_center_name"] not in (None, "", "Walk-in")

    font_size = 14 if ot["test_code"] == "CBC" else 16
    # مربع "توقيع وختم الدكتور الفاحص" كان مُلغى بكل التقارير (فراغ فاضي
    # بانتظار ختم/توقيع حقيقي يُلصق يدويًا على الورقة المطبوعة). الآن رجع
    # كصورة ختم/توقيع رقمية فعلية تُختار من مكتبة الأختام وتُسحب لموضعها —
    # راجع digital_stamps/stamp_placements أدناه وpartials/stamp_picker.html.
    show_exam_signature = ot["test_code"] in EXAM_SIGNATURE_TEST_CODES or bool(ot["is_examining_test"])

    try:
        dt = datetime.fromisoformat(ot["visit_created_at"])
        visit_date = f"{dt.day}/{dt.month}/{dt.year}"
    except (TypeError, ValueError):
        visit_date = ot["visit_created_at"] or ""

    # زيارة سابقة لنفس الشخص (تطابق كامل بالاسم + العمر) — تُعرض بالتقرير
    # (تاريخها + قيم باراميتراتها) فقط إذا وافق الموظف صراحة على دمجها
    # لحظة تسجيل هذي الزيارة (بنك تنبيه الزيارة السابقة بشاشة "زيارة
    # جديدة")، راجع visit_previous_merges — لا يوجد أي عرض تلقائي بعد
    # اليوم بغض النظر عن قسم التحليل. ?show_prev=0 يبقى يقدر يخفيها لحظة
    # الطباعة حتى لو انوافَق عليها، لكن ?show_prev=1 ما يقدر يظهرها من
    # غير موافقة أصلاً (مافيه بيانات تُعرض أصلاً بهاي الحالة).
    merged_previous = get_visit_previous_merges(db, ot["visit_id"])
    matched_merge = next(
        (m for m in merged_previous if m["test_definition_id"] == ot["test_definition_id"]), None,
    )
    show_prev_values = matched_merge is not None
    show_prev_override = request.args.get("show_prev")
    if show_prev_override == "0":
        show_prev_values = False
    previous_visit_date = matched_merge["date_display"] if matched_merge else None
    previous_values = matched_merge["results"] if matched_merge else {}

    # أسلوب الجدول (Style A/B) + عدد النتائج السابقة + الأعمدة الإضافية + الملاحظات.
    # الإلغاء لحظة الطباعة/التنزيل: ?show_prev=0 (نفس الخيار القديم بالضبط).
    layout_cfg = get_result_layout(db)
    prev_count_eff = effective_prev_count(db, ot["visit_id"], layout_cfg, matched_merge is not None)
    prev_toggle_available = prev_count_eff > 0
    _sp = request.args.get("show_prev")
    result_show_prev = prev_toggle_available and ((_sp != "0") if _sp is not None else bool(layout_cfg["prev_default_show"]))
    row_ctx = {"notes": get_row_notes(db, ot["visit_id"]), "extra_values": get_extra_col_values(db)}
    hist_all = (get_previous_history(db, ot["visit_id"], ot["test_definition_id"], prev_count_eff, layout_cfg["prev_order"])
                if result_show_prev else {})

    cbc_groups = None
    if ot["test_code"] == "CBC":
        units_by_name = {p["name"]: p["unit"] for p in parameters}
        highlight_by_name = {p["name"]: bool(p["highlight"]) for p in parameters}
        cbc_groups = []
        for group in CBC_ROW_GROUPS:
            rows = []
            for name in group:
                rng = ranges.get(name)
                res_row = results_by_name.get(name)
                rows.append({
                    "name": resolve_label(params_by_name_row.get(name)),
                    "result": params.get(name, ""),
                    "unit": units_by_name.get(name, ""),
                    "low": rng["low"] if rng else "",
                    "high": rng["high"] if rng else "",
                    "highlight": highlight_by_name.get(name, False),
                    "previous": previous_values.get(name, "") if show_prev_values else "",
                    "flag": res_row["flag"] if res_row else None,
                    "value_align": resolve_value_align(params_by_name_row.get(name)),
                })
            cbc_groups.append(rows)

    custom_rows = None
    custom_heading = None
    custom_heading_align = "center"
    custom_rows_align = "right"
    if custom_template:
        units_by_name = {p["name"]: p["unit"] for p in parameters}
        unit2_by_name = {p["name"]: p["unit2"] for p in parameters}
        unit2_factor_by_name = {p["name"]: p["unit2_factor"] for p in parameters}
        custom_heading = custom_template["heading"] or ot["test_name"]
        custom_heading_align = custom_template["heading_align"] or "center"
        custom_rows_align = custom_template["rows_align"] or "right"
        row_defs = json.loads(custom_template["rows_json"] or "[]")
        custom_rows = []
        for rd in row_defs:
            pname = rd.get("param_name", "")
            rng = ranges.get(pname)
            normal_range = ""
            if rng:
                if rng["range_text"]:
                    normal_range = rng["range_text"]
                elif rng["low"] is not None and rng["high"] is not None:
                    normal_range = f"{rng['low']} - {rng['high']}"
                elif rng["low"] is not None:
                    normal_range = f"> {rng['low']}"
                elif rng["high"] is not None:
                    normal_range = f"< {rng['high']}"
            result_val = params.get(pname, "")
            res_row = results_by_name.get(pname)
            flag_val = res_row["flag"] if res_row else None

            # حقل "This test done by ... (FDA Approved)" (source_note) أُلغي
            # عرضه نهائيًا بالتقرير المطبوع بناءً على الطلب — يبقى العمود
            # موجود بجدول reference_ranges (ما يُحذف) لكن لا يُقرأ ولا يُمرَّر
            # للقالب أبداً بعد الآن، فلا يظهر إطلاقًا مهما كانت قيمته بقاعدة
            # البيانات.

            # مستويات Normal Range المفصّلة (زي Triglycerides بالنموذج
            # المرجعي) — من range_text لو موجود، وإلا من normal_range
            # الجاهزة (سطر واحد بلا تسمية، زي أغلب التحاليل العادية).
            if rng and rng["range_text"]:
                range_tiers = parse_range_tiers(rng["range_text"])
            elif normal_range:
                range_tiers = [{"label": None, "value": normal_range}]
            else:
                range_tiers = []

            # مدى الوحدة الثانية (unit2) — يُحسب تلقائيًا بنفس معامل تحويل
            # النتيجة (unit2_factor) على low/high، فقط لمدى بسيط (سطر واحد
            # رقمي بلا مستويات)؛ لا ينطبق على مدى متدرّج (range_tiers متعدد).
            normal_range2 = None
            if rng and not (rng["range_text"] and len(range_tiers) > 1) and rng["low"] is not None and rng["high"] is not None:
                factor = unit2_factor_by_name.get(pname)
                low2 = format_unit2_value(rng["low"], factor)
                high2 = format_unit2_value(rng["high"], factor)
                if low2 is not None and high2 is not None:
                    normal_range2 = f"{low2} - {high2}"

            _prow = params_by_name_row.get(pname)
            _ex, _note, _nkey = _row_extras_and_note(row_ctx, ot["test_definition_id"], pname)
            _lbl = resolve_label(_prow, rd.get("label"))
            custom_rows.append({
                "param_name": pname,
                "name": _lbl, "value2": format_unit2_value(result_val, unit2_factor_by_name.get(pname)),
                "range2": normal_range2, "show_blank": True,
                "history": _history_with_unit2(hist_all.get(pname), unit2_factor_by_name.get(pname) if unit2_by_name.get(pname) else None),
                "extras": _ex, "note": _note, "note_key": _nkey,
                "label": resolve_label(params_by_name_row.get(pname), rd.get("label")),
                "result": result_val,
                "unit": units_by_name.get(pname, ""),
                "normal_range": normal_range,
                "range_tiers": range_tiers,
                "normal_range2": normal_range2,
                "previous": previous_values.get(pname, "") if show_prev_values else "",
                "result2": format_unit2_value(result_val, unit2_factor_by_name.get(pname)),
                "unit2": unit2_by_name.get(pname) or "",
                # حرية تحريك موضع الحقول لكل صف على حدة (يُضبط من مصمم
                # التقرير مستقبلاً، يُقرأ من rows_json): name_side='right'
                # ينقل اسم التحليل فيزيائيًا لعمود القيمة بدل عمود الاسم،
                # range_position='below' يرجع المدى الطبيعي لسطر مستقل تحت
                # اسم التحليل بدل عمود محاذي لعمود النتيجة (الافتراضي).
                "name_side": rd.get("name_side") or "left",
                "range_position": rd.get("range_position") or "inline",
                "name_align": rd.get("name_align"),
                "color": rd.get("color"),
                "value_align": resolve_value_align(params_by_name_row.get(pname)),
                "flag": flag_val,
                "page_break_before": rd.get("page_break_before", False),
            })

    age_display = format_age_display(ot["age"], ot["age_unit"])

    # ترويسة متكرّرة تلقائيًا بأعلى كل صفحة إضافية عند الطباعة (نفس الشعار،
    # أسماء الأطباء، الدكتور المرسل، اسم المريض، التاريخ...) — فقط لتقارير
    # الكيمياء/الهرمونات/الفيتامينات/الدلائل الورمية/التخثر/الفايروسات (اللي
    # تُطبع كبطاقات وقد تطول لأكثر من صفحة)، وليس لتحاليل أمراض الدم إطلاقًا
    # (CBC وغيره من التقارير الجاهزة أبدًا ما يُمرَّر لها هذا المتغيّر، فتبقى
    # بسلوكها القديم تمامًا). راجع base_report.html لآلية التكرار الفعلية.
    repeat_header_on_print = department_shows_previous_values(ot["test_department"])

    _pt_en_row = db.execute(
        "SELECT full_name_en FROM patients WHERE id=?", (ot["patient_id"],)
    ).fetchone()
    patient_name_en_value = (_pt_en_row["full_name_en"] or "") if _pt_en_row else ""

    # تخصيص مظهر التقرير (سحب باراميتر، لون/خط/حجم، إزاحة صفحة...) —
    # يُمزَج مستوى التحليل (كل المرضى) مع استثناء هذا المريض بالذات لو
    # موجود. report_layout_has_patient_override يتحكم بإظهار زر "إرجاع
    # لتصميم افتراضي" بالقالب (يظهر فقط لو فيه استثناء فعلي لهذا المريض).
    report_layout, report_layout_has_patient_override = get_report_layout(
        db, ot["test_definition_id"], order_test_id
    )
    # ملاحظة: تُمرَّر "parameters" هنا (قائمة صفوف test_parameters الخام) —
    # وليس "params" (dict بصيغة name→value المبني أعلاه بسطر 3710 للقوالب
    # القديمة CBC/custom). كان بالخطأ يُمرَّر params هنا، فـ Python يتكرّر
    # على مفاتيح الـ dict (نصوص) بدل صفوف Row، مما يسبب TypeError فوري لأي
    # تحليل — هذا الفرق هو سبب انهيار كل طباعة (CBC وGUE/GSE/SFA سوا).
    macro_params, micro_params = _build_exam_sections(ot["test_code"], parameters, report_layout)

    auto_flag_color_enabled, show_result_flag, flag_color_map = get_report_flag_settings(db)

    # الإلصاق التلقائي للختم/التوقيع (المطلوب: يظهر ختم الدكتور الفاحص
    # تلقائيًا بمجرد اختياره كفاحص لهذي الزيارة، بدون أي سحب يدوي، +
    # ختم المختبر الافتراضي إن وُجد). يشتغل فقط لو صندوق الختم مفعّل لهذا
    # التحليل (enable_stamp_widget) ولو ما فيه أي إلصاق يدوي محفوظ مسبقًا
    # لهذا التقرير بالذات — أي تحريك يدوي سابق (سحب المستخدم للختم بنفسه)
    # يبقى له الأولوية دائمًا ولا يُتجاوَز أبدًا. راجع find_stamps_for_report
    # وupsert_stamp_placement بـdatabase.py.
    _stamp_placements = get_stamp_placements(db, "order_test", order_test_id)
    if bool(ot["enable_stamp_widget"]) if "enable_stamp_widget" in ot.keys() else False:
        if not _stamp_placements:
            _auto_stamps = find_stamps_for_report(db, ot["examining_doctor"] if "examining_doctor" in ot.keys() else "")
            # خيارات مصمم التقارير: إيقاف ختم المختبر و/أو ختم الدكتور الفاحص
            # تلقائيًا لهذا التحليل (NULL/1 = الافتراضي القديم، يلصق الاثنين).
            _show_lab = ot["show_lab_stamp"] is None or bool(ot["show_lab_stamp"])
            _show_doc = ot["show_doctor_stamp"] is None or bool(ot["show_doctor_stamp"])
            _auto_stamps = [_s for _s in _auto_stamps
                            if (_show_lab if _s["is_lab_default"] else _show_doc)]
            _auto_x = 40
            for _s in _auto_stamps:
                # كل ختم بموضع افتراضي مختلف بالبداية حتى ما ينلصقون فوق
                # بعض — يبقى كل واحد قابل للسحب لموضعه المفضّل بعدها بحرّية،
                # وبمجرد ما يُسحب مرة وحدة يتسجّل بـreport_stamp_placements
                # فيتوقف الإلصاق التلقائي لصالح الموضع المحفوظ من هذي اللحظة.
                _stamp_placements.append({
                    "id": None, "stamp_id": _s["id"], "label": _s["label"],
                    "pos_x": _auto_x, "pos_y": 40, "width": _s["default_width"],
                    "image_filename": _s["image_filename"], "signature_filename": _s["signature_filename"],
                })
                _auto_x += (_s["default_width"] or 140) + 20

    if _coag_table and custom_rows is not None:
        # التخثر بأسلوب الجدول: Control يندمج مع PT/PTT (لا يُطبع كصف مستقل)
        _hasres = [_r for _r in custom_rows if _r["result"] not in (None, "")]
        custom_rows = _coag_fold_control(_hasres)
    elif auto_template:
        # تصميم تلقائي: نعرض فقط الباراميترات اللي انكتبت لها نتيجة حالية
        custom_rows = [_r for _r in custom_rows if _r["result"] not in (None, "")]

    return render_template(
        template_name,
        ot=ot, params=params, ranges=ranges, units=units, notes=notes, cbc_groups=cbc_groups,
        custom_rows=custom_rows, custom_heading=custom_heading,
        custom_heading_align=custom_heading_align, custom_rows_align=custom_rows_align,
        show_prev_values=show_prev_values, previous_visit_date=previous_visit_date,
        previous_values=previous_values, repeat_header_on_print=repeat_header_on_print,
        # الأساليب الجديدة (Style A/B + قوائم الستايل/الألوان + النتائج السابقة + ملاحظات الصفوف) تُمرَّر فقط
        # للقالب الجديد custom_v2. باقي التقارير (GUE/GSE/SFA/التخثر/CBC/Blood film/BMA/...) تبقى بدون أي
        # عنصر إضافي بشريط الطباعة.
        layout_view=(_coag_view(build_layout_view(db, style_override=request.args.get("style"), cfg=layout_cfg,
                                                  theme_override=request.args.get("theme")), _coag_table)
                     if template_name == "reports/custom_v2.html" else None),
        note_visit_id=(ot["visit_id"] if template_name == "reports/custom_v2.html" else None),
        prev_toggle_available=(prev_toggle_available if template_name == "reports/custom_v2.html" else False),
        prev_toggle_checked=result_show_prev,
        logo_url=logo_url, from_other_lab=from_other_lab, other_lab_visit_id=ot["visit_id"], font_size=font_size,
        show_exam_signature=show_exam_signature,
        hide_signature_box=bool(ot["hide_signature_box"]),
        signature_position=(ot["signature_position"] if ot["signature_position"] in ("left", "center", "right") else ""),
        # enable_stamp_widget: يتحكم فقط بصندوق "إضافة ختم / توقيع" التفاعلي
        # (stamp_picker.html) — منفصل تماماً عن show_exam_signature أعلاه
        # (صندوق التوقيع الثابت الخاص بالفحوصات). الافتراضي 0 لأي تحليل ما
        # فُعِّل له صراحةً من مصمم التقارير.
        enable_stamp_widget=bool(ot["enable_stamp_widget"]) if "enable_stamp_widget" in ot.keys() else False,
        test_definition_id=ot["test_definition_id"],
        stamp_target_type="order_test", stamp_target_id=order_test_id,
        digital_stamps=get_digital_stamps(db),
        # المطلوب: صورة التوقيع (الطبقة العلوية) كانت تختفي بمجرد ما يُحفظ
        # أي إلصاق فعليًا بقاعدة البيانات (get_stamp_placements ما كانت
        # تجيب عمود signature_filename أصلاً، وهنا كنا نمرر _stamp_placements
        # الخام بدون تمريره عبر _serialize_stamp_placements) — النتيجة كانت
        # صندوق ختم فاضي بلا توقيع فوقه بعد أول حفظ/سحب. صُحح بالسطرين
        # سوا (راجع get_stamp_placements بـdatabase.py أيضًا).
        stamp_placements=_serialize_stamp_placements(_stamp_placements),
        visit_date=visit_date, sex=ot["gender"] or "", age=age_display,
        patient_name=ot["patient_name"], patient_id=ot["registration_number"],
        referring_doctor_name=ot["referring_doctor_name"] or "",
        sample_no=(ot["visit_sample_no"] or (ot["barcode"] if "barcode" in ot.keys() else "") or ""),
        sample_time=_fmt_hhmm((ot["collected_at"] or ot["accessioned_at"] or "") if "collected_at" in ot.keys() else ""),
        number_of=get_patient_number_of_day(db, order_test_id),
        patient_name_en=patient_name_en_value,
        # order_test_id / results_by_name / param_notes / report_comment:
        # مطلوبة لقوالب فحوصات exam_report_shared.html (GUE/GSE/SFA وأي
        # تحليل مستقبلي بنفس النمط) — تُمرَّر دائمًا بلا استثناء (نفس منطق
        # units أعلاه) حتى لا تتكرر مشكلة NameError/UndefinedError.
        order_test_id=order_test_id,
        results_by_name=results_by_name,
        param_notes={
            name: {"text": r["note"], "label": r["note_label"] or "", "visible": bool(r["note_visible"])}
            for name, r in results_by_name.items() if r["note"]
        },
        report_layout=report_layout,
        report_layout_has_patient_override=report_layout_has_patient_override,
        macro_params=macro_params,
        micro_params=micro_params,
        auto_flag_color_enabled=auto_flag_color_enabled, show_result_flag=show_result_flag, AUTO_FLAG_COLORS=flag_color_map,
        row_spacing_px=row_spacing_px_value,
        done_by_note=(ot["done_by_note"] or "") if "done_by_note" in ot.keys() else "",
        # params_list: نفس "parameters" (قائمة صفوف test_parameters الخام)
        # بس باسم متاح مباشرة للقالب — قوالب الفحص (urine_exam.html وغيرها)
        # تستدعي shared.render_report_body(..., params_list, ...) بالضبط
        # بهذا الاسم (مو "params" — هذاك محجوز لصيغة dict القديمة name→value
        # اللي تستخدمها cbc.html/custom.html، وتمرير القائمة تحت نفس الاسم
        # كان يكسر عرض GUE/GSE/SFA بالكامل: كل صف يطلع فاضي بلا اسم/قيمة
        # لأن render_report_body يتكرر على مفاتيح الـ dict بدل صفوف Row).
        params_list=parameters,
    )



# ---------------------------------------------------------------- exam reports --
# نقطتا API لقوالب الفحص الجديدة (GUE/GSE/SFA — reports/urine_exam.html
# وغيرها، عبر editor_script() بـ exam_report_shared.html): ملاحظة عامة أسفل
# التقرير كامل، وملاحظة قصيرة أمام باراميتر واحد بالذات. مفصولتان تمامًا
# (جدولان مختلفان) حتى تُحفظ كل وحدة بشكل مستقل دون التأثير على الثانية.
@app.route("/order-tests/<int:order_test_id>/report-comment", methods=["POST"])
@login_required
def order_test_report_comment(order_test_id):
    # الميزة أُلغيت نهائيًا (المطلوب 1) — العمود report_comment يبقى بقاعدة
    # البيانات بدون استخدام، لكن هذا الراوت ما يعود يحفظ فيه أي شي بعد الآن.
    return jsonify({"ok": False, "error": "This feature has been removed."}), 410


@app.route("/order-tests/<int:order_test_id>/param-note", methods=["POST"])
@login_required
def order_test_param_note(order_test_id):
    db = get_db()
    order_test = db.execute("SELECT id FROM order_tests WHERE id=?", (order_test_id,)).fetchone()
    if not order_test:
        return jsonify({"error": "Not found"}), 404
    try:
        test_parameter_id = int(request.form.get("test_parameter_id"))
    except (TypeError, ValueError):
        return jsonify({"error": "بيانات غير صالحة"}), 400
    note = request.form.get("note", "")
    note_label = request.form.get("note_label", "")
    existing = db.execute(
        "SELECT id FROM results WHERE order_test_id=? AND test_parameter_id=?",
        (order_test_id, test_parameter_id),
    ).fetchone()
    if existing:
        db.execute("UPDATE results SET note=?, note_label=? WHERE id=?", (note, note_label, existing["id"]))
    else:
        db.execute(
            "INSERT INTO results (order_test_id, test_parameter_id, note, note_label) VALUES (?, ?, ?, ?)",
            (order_test_id, test_parameter_id, note, note_label),
        )
    db.commit()
    return jsonify({"ok": True})


@app.route("/order-tests/<int:order_test_id>/param-note-visibility", methods=["POST"])
@login_required
def order_test_param_note_visibility(order_test_id):
    # يبدّل note_visible بس (0/1) — خطوة مستقلة عن كتابة نص الملاحظة (مدموج من v10).
    db = get_db()
    order_test = db.execute("SELECT id FROM order_tests WHERE id=?", (order_test_id,)).fetchone()
    if not order_test:
        return jsonify({"error": "Not found"}), 404
    try:
        test_parameter_id = int(request.form.get("test_parameter_id"))
    except (TypeError, ValueError):
        return jsonify({"error": "بيانات غير صالحة"}), 400
    visible = 1 if request.form.get("visible") == "1" else 0
    db.execute(
        "UPDATE results SET note_visible=? WHERE order_test_id=? AND test_parameter_id=?",
        (visible, order_test_id, test_parameter_id),
    )
    db.commit()
    return jsonify({"ok": True, "visible": bool(visible)})


# ---------------------------------------------------------------- report layout --
# نظام تخصيص مظهر التقرير (سحب باراميتر، لون/خط/حجم، إزاحة صفحة، إخفاء/
# تسمية عرض مخصصة) — راجع editor_script + applyReportLayout بـ
# exam_report_shared.html. "scope" دائمًا واحدة من: "test" (scope_id =
# test_definition_id، يطبّق على كل مريض عنده هذا التحليل) أو "order_test"
# (scope_id = order_test_id، استثناء خاص بمريض واحد بالذات، يتفوّق على
# scope="test" لو موجود ولا يأثر على أي مريض ثاني).
VALID_LAYOUT_SCOPES = ("test", "order_test")


@app.route("/api/reports/layout/<int:test_definition_id>", methods=["GET"])
@login_required
def api_report_layout_get(test_definition_id):
    db = get_db()
    order_test_id = request.args.get("order_test_id", type=int)
    test_layout = get_raw_layout(db, "test", test_definition_id)
    patient_layout = None
    merged = test_layout
    has_patient_override = False
    if order_test_id:
        merged, has_patient_override = get_report_layout(db, test_definition_id, order_test_id)
        if has_patient_override:
            patient_layout = get_raw_layout(db, "order_test", order_test_id)
    return jsonify({
        "test_layout": test_layout,
        "patient_layout": patient_layout,
        "merged": merged,
        "has_patient_override": has_patient_override,
    })


@app.route("/api/reports/layout", methods=["POST"])
@login_required
def api_report_layout_save():
    db = get_db()
    body = request.get_json(silent=True) or {}
    scope = body.get("scope")
    scope_id = body.get("scope_id")
    layout = body.get("layout")
    if scope not in VALID_LAYOUT_SCOPES:
        return jsonify({"error": "scope غير صحيح"}), 400
    try:
        scope_id = int(scope_id)
    except (TypeError, ValueError):
        return jsonify({"error": "scope_id غير صالح"}), 400
    if not isinstance(layout, dict):
        return jsonify({"error": "layout غير صالح"}), 400
    save_report_layout(db, scope, scope_id, layout, user_id=session.get("user_id"))
    log_action("SaveReportLayout", scope, scope_id)
    return jsonify({"ok": True})


@app.route("/api/reports/layout/reset", methods=["POST"])
@login_required
def api_report_layout_reset():
    db = get_db()
    body = request.get_json(silent=True) or {}
    scope = body.get("scope")
    scope_id = body.get("scope_id")
    if scope not in VALID_LAYOUT_SCOPES:
        return jsonify({"error": "scope غير صحيح"}), 400
    try:
        scope_id = int(scope_id)
    except (TypeError, ValueError):
        return jsonify({"error": "scope_id غير صالح"}), 400
    reset_report_layout(db, scope, scope_id)
    log_action("ResetReportLayout", scope, scope_id)
    return jsonify({"ok": True})


# ============== إدارة دكاترة الترويسة من نفس صفحة معاينة الطباعة ==============
# نسخة JSON خفيفة من نفس شاشة (الإدارة ← الإعدادات ← إدارة قائمة الدكاترة
# examining_doctors_manage أعلاه) — تفتح كنافذة منبثقة فوق أي معاينة تقرير
# بدل الاضطرار للخروج من المعاينة والذهاب للإعدادات. تستخدم نفس دوال
# database.py حرفيًا (get/add/update/delete_examining_doctor*) فالقائمتان
# يبقيان متطابقتين ومتزامنتين دائمًا.
@app.route("/api/examining-doctors", methods=["GET"])
@roles_required("admin")
def api_examining_doctors_list():
    db = get_db()
    rows = get_examining_doctors_full(db)
    return jsonify({"doctors": [dict(r) for r in rows]})


@app.route("/api/examining-doctors", methods=["POST"])
@roles_required("admin")
def api_examining_doctors_add():
    db = get_db()
    body = request.get_json(silent=True) or {}
    name = (body.get("name") or "").strip()
    if not name:
        return jsonify({"error": "اسم الدكتور مطلوب"}), 400
    font_size = body.get("font_size")
    try:
        font_size = max(8, min(30, int(font_size))) if font_size not in (None, "") else None
    except (TypeError, ValueError):
        font_size = None
    add_examining_doctor_full(
        db, name, body.get("title") or "الدكتور", body.get("degree_ar") or "", body.get("degree_en") or "",
        bool(body.get("show_on_letterhead", True)), font_size,
    )
    log_action("AddExaminingDoctor", "examining_doctors_list", None, name)
    return jsonify({"ok": True, "doctors": [dict(r) for r in get_examining_doctors_full(db)]})


@app.route("/api/examining-doctors/<int:doctor_id>", methods=["POST"])
@roles_required("admin")
def api_examining_doctors_update(doctor_id):
    db = get_db()
    body = request.get_json(silent=True) or {}
    name = (body.get("name") or "").strip()
    if not name:
        return jsonify({"error": "اسم الدكتور مطلوب"}), 400
    font_size = body.get("font_size")
    try:
        font_size = max(8, min(30, int(font_size))) if font_size not in (None, "") else None
    except (TypeError, ValueError):
        font_size = None
    update_examining_doctor(
        db, doctor_id, name, body.get("title") or "الدكتور", body.get("degree_ar") or "", body.get("degree_en") or "",
        bool(body.get("show_on_letterhead", True)), font_size,
    )
    log_action("UpdateExaminingDoctor", "examining_doctors_list", doctor_id, name)
    return jsonify({"ok": True, "doctors": [dict(r) for r in get_examining_doctors_full(db)]})


@app.route("/api/examining-doctors/<int:doctor_id>/delete", methods=["POST"])
@roles_required("admin")
def api_examining_doctors_delete(doctor_id):
    db = get_db()
    delete_examining_doctor(db, doctor_id)
    log_action("DeleteExaminingDoctor", "examining_doctors_list", doctor_id)
    return jsonify({"ok": True, "doctors": [dict(r) for r in get_examining_doctors_full(db)]})


# ============== إضافة باراميتر جديد مباشرة من صفحة معاينة التقرير ==============
# يستدعيه زر "+ إضافة باراميتر جديد لهذا القسم" (add_param_row بـ
# exam_report_shared.html) — بديل حقيقي عن رسالة placeholder السابقة.
# ينشئ صف test_parameters فعلي (اسم فقط، بلا وحدة/مدى طبيعي — تُضاف لاحقًا
# من كتالوج التحاليل لو احتاجها الأدمن)؛ ينزل تلقائيًا بقسم "Other Results"
# بأي تقرير فحص لهذا التحليل لحد ما يُسحب لمكانه الصحيح ويُحفظ التصميم.
@app.route("/api/test-parameters", methods=["POST"])
@roles_required("admin")
def api_add_test_parameter():
    db = get_db()
    body = request.get_json(silent=True) or {}
    try:
        test_definition_id = int(body.get("test_definition_id"))
    except (TypeError, ValueError):
        return jsonify({"error": "بيانات غير صالحة"}), 400
    name = (body.get("name") or "").strip()
    if not name:
        return jsonify({"error": "اسم الباراميتر مطلوب"}), 400
    td = db.execute("SELECT id FROM test_definitions WHERE id=?", (test_definition_id,)).fetchone()
    if not td:
        return jsonify({"error": "التحليل غير موجود"}), 404
    existing = db.execute(
        "SELECT id FROM test_parameters WHERE test_definition_id=? AND name=?", (test_definition_id, name)
    ).fetchone()
    if existing:
        return jsonify({"error": "فيه باراميتر بنفس هذا الاسم أصلاً لهذا التحليل"}), 400
    cur = db.execute(
        "INSERT INTO test_parameters (test_definition_id, name, unit, result_type) VALUES (?, ?, '', 'Text')",
        (test_definition_id, name),
    )
    db.commit()
    log_action("AddTestParameter", "test_parameters", cur.lastrowid, name)
    return jsonify({"ok": True, "id": cur.lastrowid, "name": name})


# ============== v56: إضافة حقل (باراميتر) لأي تقرير من شاشة إدخال النتائج ==============
# المستخدم يكتب الاسم/الوحدة/النوع، يختار المكان (بداية التقرير أو بعد أي باراميتر موجود)،
# ويحدد المدى الطبيعي (مدى واحد للجنسين أو مختلف للذكور/الإناث، أو نص مثل Negative).
# يُضاف لتعريف التحليل نفسه (يظهر لكل المرضى لاحقًا) وتُعاد ترقيم sort_order للباراميترات
# بحيث تبقى بنفس ترتيبها القديم والجديد بالمكان المطلوب.
@app.route("/api/test-definitions/<int:tdid>/add-parameter", methods=["POST"])
@roles_required("supervisor")
def api_add_parameter_with_ranges(tdid):
    db = get_db()
    td = db.execute("SELECT id, name FROM test_definitions WHERE id=?", (tdid,)).fetchone()
    if not td:
        return jsonify({"ok": False, "error": "التحليل غير موجود"}), 404
    body = request.get_json(silent=True) or {}
    name = str(body.get("name") or "").strip()
    if not name:
        return jsonify({"ok": False, "error": "اسم الحقل مطلوب"}), 400
    unit = str(body.get("unit") or "").strip()
    rtype = body.get("result_type")
    rtype = rtype if rtype in ("Numeric", "Text") else "Numeric"
    if db.execute("SELECT 1 FROM test_parameters WHERE test_definition_id=? AND LOWER(TRIM(name))=LOWER(?)",
                  (tdid, name)).fetchone():
        return jsonify({"ok": False, "error": "يوجد حقل بنفس الاسم بهذا التقرير"}), 409

    def _num(v):
        if v is None or str(v).strip() == "":
            return None
        return float(str(v).strip().replace(",", ""))

    clean_ranges = []
    for r in (body.get("ranges") or [])[:3]:
        gender = r.get("gender") if r.get("gender") in ("Both", "Male", "Female") else "Both"
        try:
            low, high = _num(r.get("low")), _num(r.get("high"))
        except ValueError:
            return jsonify({"ok": False, "error": "المدى الطبيعي لازم أرقام فقط (النص يُكتب بخانة نص المدى)"}), 400
        text = str(r.get("text") or "").strip() or None
        if rtype == "Text":
            low = high = None
        if low is not None and high is not None and low > high:
            return jsonify({"ok": False, "error": "بداية المدى أكبر من نهايته"}), 400
        if low is None and high is None and not text:
            continue
        if text is None and (low is None) != (high is None):      # مدى بحد واحد: نكتب نصه للعرض
            text = ("> %g" % low) if high is None else ("< %g" % high)
        clean_ranges.append((gender, low, high, text))

    ids = [r["id"] for r in db.execute(
        "SELECT id FROM test_parameters WHERE test_definition_id=? ORDER BY sort_order, id", (tdid,)).fetchall()]
    cur = db.execute(
        "INSERT INTO test_parameters (test_definition_id, name, unit, result_type) VALUES (?, ?, ?, ?)",
        (tdid, name, unit, rtype))
    new_id = cur.lastrowid
    after = body.get("after")
    if after == "start":
        pos = 0
    else:
        try:
            aid = int(after)
            pos = ids.index(aid) + 1 if aid in ids else len(ids)
        except (TypeError, ValueError):
            pos = len(ids)
    ids.insert(pos, new_id)
    for i, pid in enumerate(ids, start=1):
        db.execute("UPDATE test_parameters SET sort_order=? WHERE id=?", (i, pid))
    for gender, low, high, text in clean_ranges:
        db.execute(
            "INSERT INTO reference_ranges (test_parameter_id, gender, age_from, age_from_unit, age_to, age_to_unit, "
            "low, high, range_text) VALUES (?, ?, 0, 'Years', 120, 'Years', ?, ?, ?)",
            (new_id, gender, low, high, text))
    db.commit()
    log_action("AddTestParameter", "test_parameters", new_id, f"{td['name']} / {name} (pos {pos + 1})")
    return jsonify({"ok": True, "id": new_id, "name": name, "position": pos + 1})


# ============== تحديد/تعديل سعر باراميتر مفرد ==============
# يُستخدم فقط لما موظف الاستقبال يطلب بارامترات معيّنة بس من تحليل متعدد
# الباراميترات (سهم ▾ بشاشة "زيارة جديدة" — راجع شرح كامل عند
# order_tests.selected_param_ids بـdatabase.py). لو الباراميتر ما عنده
# سعر بعد، الموظف يكتبه أول مرة من نفس شاشة الطلب وينحفظ هنا دائمًا
# للطلبات الجاية. @login_required بدل admin عمداً — هذا إجراء تشغيلي
# اعتيادي وقت استقبال المريض، مو إعداد إداري.
@app.route("/api/test-parameters/<int:param_id>/set-price", methods=["POST"])
@login_required
def api_set_test_parameter_price(param_id):
    db = get_db()
    param = db.execute("SELECT * FROM test_parameters WHERE id=?", (param_id,)).fetchone()
    if not param:
        return jsonify({"ok": False, "error": "الباراميتر غير موجود"}), 404
    body = request.get_json(silent=True) or request.form
    try:
        price = float(body.get("price"))
        if price < 0:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "السعر يجب أن يكون رقمًا صحيحًا"}), 400
    db.execute("UPDATE test_parameters SET price=? WHERE id=?", (price, param_id))
    db.commit()
    log_action("SetParameterPrice", "test_parameters", param_id, str(price))
    return jsonify({"ok": True, "price": price})


@app.route("/api/test-parameters/<int:param_id>/rename", methods=["POST"])
@login_required
def api_rename_test_parameter(param_id):
    """يعيد تسمية باراميتر تابع لتحليل — يُستخدم بالقلم ✏️ الجديد بلوحة
    اختيار البارامترات بشاشة "زيارة جديدة" (سهم ▾)، للسرعة بدون فتح صفحة
    Reference Range. @login_required بدل admin عمداً لنفس سبب set-price."""
    db = get_db()
    param = db.execute("SELECT * FROM test_parameters WHERE id=?", (param_id,)).fetchone()
    if not param:
        return {"ok": False, "error": "الباراميتر غير موجود"}, 404
    body = request.get_json(silent=True) or request.form
    new_name = (body.get("name") or "").strip()
    if not new_name:
        return {"ok": False, "error": "الاسم لا يمكن أن يكون فارغًا"}, 400
    db.execute("UPDATE test_parameters SET name=? WHERE id=?", (new_name, param_id))
    db.commit()
    log_action("RenameParameter", "test_parameters", param_id, new_name)
    return {"ok": True, "name": new_name}


@app.route("/api/test-definitions/<int:test_definition_id>/parameters")
@login_required
def api_test_definition_parameters(test_definition_id):
    """يرجّع بارامترات تحليل معيّن (id/name/price) — يغذّي سهم ▾ بشاشة
    "زيارة جديدة" لاختيار بارامترات معيّنة بس من داخل تحليل متعدد
    الباراميترات بدل طلبه كامل (راجع order_tests.selected_param_ids)."""
    db = get_db()
    params = db.execute(
        "SELECT id, name, price FROM test_parameters WHERE test_definition_id=? ORDER BY sort_order, id",
        (test_definition_id,),
    ).fetchall()
    return jsonify([dict(p) for p in params])


# ============== حذف باراميتر نهائيًا مباشرة من صفحة معاينة التقرير ==============
# يستدعيه زر ❌ (examDeleteParam بـexam_report_shared.html) — حذف حقيقي من
# test_parameters، مختلف تمامًا عن 🗑️/👁️ (إخفاء/إظهار فقط، ما يمس البيانات).
# محمي عمداً: يرفض الحذف لو فيه أي نتيجة محفوظة سابقًا لهذا الباراميتر (أي
# مريض/زيارة) — حتى ما نفقد تأريخ نتائج حقيقية بالغلط، ونقترح الإخفاء
# كبديل آمن بهذي الحالة. لا يحتاج تنظيف report_layout يدويًا بعدها: exam_row
# أصلاً ما يطبع إلا الأسماء الموجودة فعليًا بـtest_parameters (راجع
# `{% if name in params_by_name %}` بـrender_report_body)، فبمجرد الحذف
# يختفي الصف تلقائيًا من كل تقرير مستقبلي لهذا التحليل.
@app.route("/api/test-parameters/<int:param_id>", methods=["DELETE"])
@roles_required("admin")
def api_delete_test_parameter(param_id):
    db = get_db()
    p = db.execute("SELECT * FROM test_parameters WHERE id=?", (param_id,)).fetchone()
    if not p:
        return jsonify({"error": "الباراميتر غير موجود"}), 404
    used = db.execute(
        "SELECT COUNT(*) as c FROM results WHERE test_parameter_id=?", (param_id,)
    ).fetchone()["c"]
    if used:
        return jsonify({
            "error": f"عنده {used} نتيجة محفوظة سابقًا (لمرضى/زيارات مختلفة) — "
                     f"حذفه يفقد تأريخ هذي النتائج نهائيًا. استخدم زر 🗑️ (إخفاء) بدل الحذف.",
        }), 400
    db.execute("DELETE FROM reference_ranges WHERE test_parameter_id=?", (param_id,))
    db.execute("DELETE FROM test_parameters WHERE id=?", (param_id,))
    db.commit()
    log_action("DeleteTestParameter", "test_parameters", param_id, p["name"])
    return jsonify({"ok": True})


def _whatsapp_flush_pdf_dir():
    d = os.path.join(app.static_folder, "whatsapp_pdfs")
    os.makedirs(d, exist_ok=True)
    return d


def _open_whatsapp_with_pdf(phone, pdf_path, country_code):
    """يفتح محادثة واتساب مع رقم المريض مباشرة (تطبيق سطح المكتب المثبّت
    أصلاً على هذا الجهاز، عبر رابط whatsapp://)، ويفتح مجلد الملف ومحدِّد
    عليه بمستكشف الملفات — حتى يقدر المستخدم يسحب ملف الـPDF ويرفقه
    بنفسه بضغطة وحدة، بدل الاعتماد على أتمتة Selenium الهشة (اللي كانت
    تحتاج Chrome منفصل، وتسبب أقفال ملفات، وتوقف البرنامج بالكامل).
    يرجّع (opened_whatsapp: bool, opened_folder: bool)."""
    import re as _re
    digits = _re.sub(r"\D", "", phone or "")
    if not digits:
        return False, False
    if digits.startswith("00"):
        digits = digits[2:]
    elif digits.startswith("0"):
        digits = country_code + digits[1:]
    elif not digits.startswith(country_code):
        digits = country_code + digits

    opened_wa = False
    try:
        os.startfile(f"whatsapp://send?phone={digits}")
        opened_wa = True
    except OSError:
        try:
            webbrowser.open(f"https://wa.me/{digits}")
            opened_wa = True
        except Exception:
            opened_wa = False

    opened_folder = False
    try:
        subprocess.run(["explorer", "/select,", os.path.normpath(pdf_path)])
        opened_folder = True
    except Exception:
        opened_folder = False

    return opened_wa, opened_folder


def _safe_pdf_name_part(text):
    """ينظّف نص (اسم مريض/تحليل) حتى يصلح كجزء من اسم ملف PDF بويندوز —
    يشيل الأحرف الممنوعة (\\ / : * ? " < > |) بس، ويحافظ على باقي النص
    (بما فيه المسافات والعربي) زي ما هو، حتى يبقى اسم المريض مقروء
    بالظبط متل ما يظهر بالتقرير المطبوع، لتسهيل البحث بين ملفات الـPDF."""
    return re.sub(r'[\\/:*?"<>|]+', " ", (text or "").strip()).strip() or "ملف"


def _whatsapp_generate_and_queue(db, visit_row, patient_id, patient_name, phone,
                                  label, html_content, order_test_id=None):
    """يولّد PDF من الـHTML الجاهز (نفس صفحة الطباعة)، يسجّل صف بطابور
    whatsapp_sends، ثم يفتح واتساب على رقم المريض ومجلد الملف جنب بعض —
    الإرسال الفعلي خطوة يدوية بسيطة (سحب وإفلات) بدل إرسال آلي عبر متصفح
    منفصل يتحكم فيه Selenium، تفاديًا لكل مشاكل القفل والكراش السابقة."""
    import pdf_export

    now = datetime.now().isoformat(timespec="seconds")
    # اسم الملف يبدأ باسم المريض (مثل ما يظهر بالتقرير بالضبط) بدل رقم
    # الزيارة، حتى يقدر المستخدم يميّز فوراً بأي ملف بمجلد واتساب وهو
    # يدور عن نتيجة مريض معيّن، بدل أرقام زيارات ما تعني له شي بالنظرة.
    pdf_path = pdf_export.make_temp_pdf_path(_safe_pdf_name_part(patient_name))

    # توليد PDF نفسه كان بدون أي حماية — أي خطأ يصير أثناء التحويل (خط
    # ناقص، مسار شعار كسران، أي عطل بمكتبة التحويل) كان يطيح الطلب كامل
    # بصفحة 500 بيضاء بدون أي رسالة توضح شنو صار. الآن أي فشل هنا يُسجَّل
    # كصف "failed" بنفس الطابور بدل ما يكسر الصفحة بالكامل.
    try:
        pdf_export.html_to_pdf(html_content, request.url_root, pdf_path)
    except Exception as exc:
        db.execute(
            "INSERT INTO whatsapp_sends (visit_id, order_test_id, patient_id, patient_name, "
            "phone, label, pdf_path, status, attempts, error, requested_by, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, 'failed', 1, ?, ?, ?)",
            (visit_row["id"], order_test_id, patient_id, patient_name, phone, label,
             pdf_path, f"فشل توليد PDF: {exc}", session.get("user_id"), now),
        )
        db.commit()
        log_action("WhatsAppSend", "order_test", order_test_id or visit_row["id"], f"PDF generation failed: {exc}")
        return False, f"فشل توليد ملف PDF: {exc}"

    opened_wa, opened_folder = _open_whatsapp_with_pdf(
        phone, pdf_path, get_setting(db, "whatsapp_country_code", "964")
    )

    # status='opened' (مو 'sent') لأننا فعلياً ما نتحقق برمجيًا إن الملف
    # انرسل فعلاً — هذا فتح واتساب + المجلد بس، الضغطة الأخيرة (سحب
    # الملف وإرسال) يسويها المستخدم بنفسه.
    status = "opened" if opened_wa else "failed"
    error = None if opened_wa else "تعذّر فتح تطبيق واتساب — تأكد إنه مثبّت على هذا الجهاز."
    db.execute(
        "INSERT INTO whatsapp_sends (visit_id, order_test_id, patient_id, patient_name, "
        "phone, label, pdf_path, status, attempts, error, requested_by, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)",
        (visit_row["id"], order_test_id, patient_id, patient_name, phone, label,
         pdf_path, status, error, session.get("user_id"), now),
    )
    db.commit()

    if opened_wa:
        return True, None
    return False, error


def _maybe_auto_whatsapp_send(db, visit_id):
    """إرسال تلقائي عبر واتساب لكل نتائج الزيارة دفعة واحدة (بملف PDF واحد،
    نفس أسلوب زر 'إرسال كل النتائج' اليدوي) — بس إذا تحققت الشروط الثلاثة:
    (1) رقم هاتف المريض مسجّل بملفه، (2) كل تحليل مطلوب بهذي الزيارة صار
    Completed أو Verified (ولا تحليل واحد لسا ناقص نتيجة)، و(3) ما سبق
    إرسال (تلقائي أو يدوي) لكل نتائج هذي الزيارة مجموعة من قبل — تفاديًا
    لتكرار الإرسال في كل مرة تُعدَّل فيها نتيجة بعد اكتمال الزيارة.
    تُستدعى بعد أي حفظ نتيجة (مفردة من result_entry، أو مُجمّعة من
    visit_results_entry). أي خطأ بتوليد الـPDF أو الإرسال لا يوقف حفظ
    النتائج أبدًا — يُسجَّل بطابور واتساب كـ pending/failed مثل أي محاولة
    إرسال يدوية عادية، وتلتقطه المهمة الخلفية أو زر 'إعادة المحاولة' لاحقًا."""
    visit = db.execute(
        "SELECT v.*, p.id as patient_id, p.full_name, p.phone FROM visits v "
        "JOIN patients p ON p.id = v.patient_id WHERE v.id=?",
        (visit_id,),
    ).fetchone()
    if not visit or not (visit["phone"] or "").strip():
        return False

    statuses = [row["status"] for row in db.execute(
        "SELECT ot.status FROM order_tests ot JOIN orders o ON o.id = ot.order_id WHERE o.visit_id=?",
        (visit_id,),
    ).fetchall()]
    if not statuses or any(s not in ("Completed", "Verified") for s in statuses):
        return False  # لسا فيه تحليل ناقص نتيجة — ما نرسل شي بعد

    already = db.execute(
        "SELECT id FROM whatsapp_sends WHERE visit_id=? AND order_test_id IS NULL "
        "AND status IN ('pending', 'sent', 'opened')",
        (visit_id,),
    ).fetchone()
    if already:
        return False  # سبق إرسال/طابور كل نتائج هذي الزيارة مجموعة من قبل

    try:
        html_content = _build_combined_designed_reports_html(visit_id)
    except Exception:
        return False
    if not html_content:
        return False

    ok, error = _whatsapp_generate_and_queue(
        db, visit, visit["patient_id"], visit["full_name"], visit["phone"],
        "كل نتائج الزيارة (إرسال تلقائي)", html_content, order_test_id=None,
    )
    log_action("WhatsAppAutoSend", "visit", visit_id, "OK" if ok else f"queued: {error}")
    if ok:
        flash("📱 النتائج مكتملة — تم إرسالها تلقائيًا عبر واتساب للمريض.")
    else:
        flash(f"📱 النتائج مكتملة لكن تعذّر الإرسال الفوري — انضافت لطابور واتساب وسترسل تلقائيًا عند توفر الإنترنت. ({error})")
    return True


def _get_pdf_archive_dir(db):
    """مجلد أرشفة الـPDF الدائم كما ظبطه المدير من Management → Settings
    (settings.pdf_archive_dir). يرجّع None إذا لسا فاضي (غير مُعد بعد) —
    وبهذي الحالة الأرشفة التلقائية تُتجاهل بصمت بدل ما تكسر حفظ النتائج."""
    d = (get_setting(db, "pdf_archive_dir", "") or "").strip()
    if not d:
        # v71: لو المدير ما حدد مجلد، نستخدم مجلد افتراضي بجانب قاعدة البيانات (PDF_Archive) حتى تشتغل الأرشفة تلقائيًا
        try:
            from database import DB_PATH as _DBP
            d = os.path.join(os.path.dirname(os.path.abspath(_DBP)), "PDF_Archive")
        except Exception:
            return None
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        return None
    return d



# ---- أرشفة PDF + واتساب التلقائي بعد حفظ النتائج: صارت بالخلفية. قبل كانت تتنفذ داخل نفس الطلب
# (ملف PDF لكل تحليل + ملف للزيارة بمحرك المتصفح) فتصفن الصفحة عند زر الطباعة/الحفظ. ----
_POSTSAVE_LOCKS = {}
_POSTSAVE_LOCKS_GUARD = threading.Lock()


def _post_save_background(visit_id, order_test_ids=()):
    url_root = request.url_root
    ids = list(order_test_ids or [])

    def _worker():
        with _POSTSAVE_LOCKS_GUARD:
            lk = _POSTSAVE_LOCKS.setdefault(visit_id, threading.Lock())
        with lk:
            try:
                with app.test_request_context("/", base_url=url_root):
                    wdb = get_db()
                    try:
                        for _tid in ids:
                            try:
                                _archive_single_test_pdf(wdb, _tid)
                            except Exception:
                                pass
                        try:
                            _maybe_auto_whatsapp_send(wdb, visit_id)
                        except Exception:
                            pass
                        try:
                            _maybe_archive_visit_pdf(wdb, visit_id)
                        except Exception:
                            pass
                    finally:
                        try:
                            wdb.close()
                        except Exception:
                            pass
            except Exception:
                pass

    threading.Thread(target=_worker, daemon=True).start()


def _maybe_archive_visit_pdf(db, visit_id):
    """يحفظ نسخة PDF دائمة (موحّدة لكل نتائج الزيارة) بمجلد الأرشيف الثابت،
    بس إذا: (1) المدير ظبط مجلد أرشفة من الإعدادات، و(2) كل تحليل مطلوب
    بهذي الزيارة صار Completed أو Verified. تُستدعى من نفس نقطتي حفظ
    النتائج اللي تستدعي _maybe_auto_whatsapp_send (مفردة ومُجمّعة)، وتُعيد
    توليد/استبدال نفس الملف (upsert بـ visit_id) في كل مرة — حتى يبقى
    الملف المؤرشف مطابقًا دائمًا لآخر تعديل على النتائج، حتى لو تم تعديلها
    بعد الاكتمال. أي خطأ بالتوليد لا يوقف حفظ النتائج أبدًا."""
    archive_dir = _get_pdf_archive_dir(db)
    if not archive_dir:
        return False

    visit = db.execute(
        "SELECT v.*, p.id as patient_id, p.full_name, "
        "d.full_name as referring_doctor_name, rc.name as referral_center_name "
        "FROM visits v JOIN patients p ON p.id = v.patient_id "
        "LEFT JOIN doctors d ON d.id = v.doctor_id "
        "LEFT JOIN referral_centers rc ON rc.id = v.referral_center_id "
        "WHERE v.id=?",
        (visit_id,),
    ).fetchone()
    if not visit:
        return False

    statuses = [row["status"] for row in db.execute(
        "SELECT ot.status FROM order_tests ot JOIN orders o ON o.id = ot.order_id WHERE o.visit_id=?",
        (visit_id,),
    ).fetchall()]
    if not statuses or any(s not in ("Completed", "Verified") for s in statuses):
        return False  # لسا فيه تحليل ناقص نتيجة — ما نؤرشف بعد

    # v72: نفس "اللوحة المجمّعة" المصممة اللي تنطبع بالضبط؛ لو فشلت نرجع لمولّد التصاميم القديم
    html_content = None
    try:
        session.setdefault("interface", "both")
        _h = print_combined_panel(visit_id)
        html_content = _h if isinstance(_h, str) and len(_h) > 500 else None
    except Exception:
        html_content = None
    if not html_content:
        try:
            html_content = _build_combined_designed_reports_html(visit_id)
        except Exception:
            html_content = None
    if not html_content:
        return False

    import pdf_export
    try:
        # اسم ملف واضح للبحث اليدوي بمجلد الأرشيف نفسه من خارج البرنامج:
        # رقم_التسجيل - اسم المريض - تاريخ الزيارة.pdf (كل رمز غير آمن
        # بالاسم يُستبدل بشرطة سفلية).
        # v71: عنوان الـPDF = الاسم الكامل للمريض + تاريخ ووقت الزيارة (ثابت لنفس الزيارة فيتحدّث نفس الملف)
        import re as _re2
        safe_name = _re2.sub(r'[\\/:*?"<>|\r\n\t]+', " ", (visit["full_name"] or "patient")).strip() or "patient"
        try:
            dt = datetime.fromisoformat(visit["created_at"])
        except (TypeError, ValueError):
            dt = datetime.now()
        stamp_part = dt.strftime("%Y-%m-%d %H-%M")
        filename = f"{safe_name} - {stamp_part}.pdf"
        pdf_path = os.path.join(archive_dir, filename)
        _other = db.execute("SELECT visit_id FROM saved_reports WHERE pdf_path=? AND visit_id<>?", (pdf_path, visit_id)).fetchone()
        if _other:  # نفس الاسم ونفس الدقيقة لزيارة ثانية: نضيف رقم التسجيل
            pdf_path = os.path.join(archive_dir, f"{safe_name} - {stamp_part} - {visit['registration_number']}.pdf")
        pdf_export.html_to_pdf(html_content, request.url_root, pdf_path)
    except Exception:
        _v74_log_exc("PDF archive generation failed for visit %s" % visit_id)
        return False

    save_saved_report(
        db, visit_id, visit["patient_id"], visit["full_name"], visit["registration_number"],
        pdf_path, referring_doctor_name=visit["referring_doctor_name"],
        referral_center_name=visit["referral_center_name"],
    )
    try:   # نتائج انحفظت/تعدّلت بعد الحذف => ترجع للأرشيف
        db.execute("DELETE FROM archive_deleted WHERE visit_id=?", (visit_id,)); db.commit()
    except Exception:
        pass
    return True


def _archive_single_test_pdf(db, order_test_id):
    """يحفظ/يستبدل نسخة PDF دائمة لنتيجة تحليل واحد بمجلد الأرشيف (نفس المجلد
    اللي يضبطه المدير من الإعدادات). تُستدعى عند كل حفظ نتيجة، فلما مسؤول
    المختبر يعدّل نتيجة مكتملة (بعد كلمة المرور) الملف يتجدد تلقائيًا بالقيم
    الجديدة. لا تعلّم النتيجة كـ\"مطبوعة\" (تعيد printed_at لقيمته السابقة).
    أي فشل لا يوقف الحفظ أبدًا. ترجع مسار الملف أو None."""
    archive_dir = _get_pdf_archive_dir(db)
    if not archive_dir:
        return None
    row = db.execute(
        "SELECT ot.status, ot.printed_at, td.code as test_code, td.name as test_name, "
        "v.registration_number, v.created_at, p.full_name "
        "FROM order_tests ot JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id WHERE ot.id=?", (order_test_id,),
    ).fetchone()
    if not row or row["status"] not in ("Completed", "Verified"):
        return None
    prev_printed_at = row["printed_at"]
    try:
        import re as _re
        import pdf_export
        html_content = print_report(order_test_id)
        if not isinstance(html_content, str):
            return None
        def _clean(x):
            return _re.sub(r'[\\/:*?"<>|\s]+', "_", (x or "").strip()).strip("_") or "x"
        try:
            date_part = datetime.fromisoformat(row["created_at"]).strftime("%Y-%m-%d")
        except (TypeError, ValueError):
            date_part = datetime.now().strftime("%Y-%m-%d")
        filename = f"{row['registration_number']}_{_clean(row['full_name'])}_{_clean(row['test_code'] or row['test_name'])}_{date_part}.pdf"
        pdf_path = os.path.join(archive_dir, filename)
        pdf_export.html_to_pdf(html_content, request.url_root, pdf_path)
        return pdf_path
    except Exception:
        return None
    finally:
        # print_report يثبّت printed_at أول مرة يُفتح فيها؛ الأرشفة ما تُعتبر طباعة
        try:
            db.execute("UPDATE order_tests SET printed_at=? WHERE id=?", (prev_printed_at, order_test_id))
            db.commit()
        except Exception:
            pass


@app.route("/reports/print-and-save/<int:order_test_id>", methods=["POST"])
@login_required
def print_and_save_result(order_test_id):
    """زر الطباعة بشاشة إدخال النتائج (أي واجهة: استقبال/مختبر/الاثنين):
    1) يحفظ قيم هذا التحليل المُدخلة حاليًا (ويعلّمه Completed) لو كان جديد،
    2) يحفظ نسخة PDF بمجلد الأرشيف، 3) يرجّع رابط الطباعة.
    نتيجة مكتملة بدون تعديل تُطبع مباشرة بدون كلمة مرور؛ لو فيه تعديل فعلي
    على نتيجة مكتملة يُطلب يوزر/باسورد مسؤول أو مشرف (needs_gate)."""
    db = get_db()
    base_sql = (
        "SELECT ot.*, td.name as test_name, td.code as test_code, "
        "p.id as patient_id, p.gender as gender, p.age as age, p.age_unit as age_unit, "
        "v.id as visit_id FROM order_tests ot "
        "JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id WHERE "
    )
    ot = db.execute(base_sql + "ot.id=?", (order_test_id,)).fetchone()
    if not ot:
        return jsonify({"ok": False, "error": "التحليل غير موجود."}), 404
    targets = [ot]
    if ot["test_code"] in BF_RETIC_LINK:
        sib = db.execute(
            base_sql + "ot.order_id=? AND td.code=?", (ot["order_id"], BF_RETIC_LINK[ot["test_code"]])
        ).fetchone()
        if sib:
            targets.append(sib)

    done = ("Completed", "Verified")
    plan = []
    needs_gate = False
    for t in targets:
        params = get_ordered_parameters(db, t)
        prefix = f"ot{t['id']}_"
        changed = _ot_has_result_changes(db, t, params, request.form, prefix)
        if t["status"] in done and changed:
            needs_gate = True
        plan.append((t, params, prefix, changed))
    if needs_gate:
        ok, err = _check_completed_result_gate(db, request.form)
        if not ok:
            return jsonify({"ok": False, "needs_gate": True, "error": err}), 403

    saved_any = False
    for t, params, prefix, changed in plan:
        if t["status"] in done and not changed:
            continue
        if save_order_test_results(db, t, params, request.form, session.get("user_id"),
                                   field_prefix=prefix, patient_id=t["patient_id"],
                                   fill_normal=(t["id"] == order_test_id)):
            saved_any = True
    for t, _p, _pre, _c in plan:
        has_res = db.execute("SELECT COUNT(*) c FROM results WHERE order_test_id=?", (t["id"],)).fetchone()["c"]
        if has_res and t["status"] not in done:
            db.execute("UPDATE order_tests SET status='Completed' WHERE id=?", (t["id"],))
    db.commit()

    if not db.execute("SELECT COUNT(*) c FROM results WHERE order_test_id=?", (order_test_id,)).fetchone()["c"]:
        return jsonify({"ok": False, "error": "لا توجد نتيجة مُدخلة لهذا التحليل — أدخل قيمة واحدة على الأقل قبل الطباعة."}), 400

    archived = False
    _post_save_background(ot["visit_id"], [t["id"] for t, _p, _pre, _c in plan] if saved_any else [])
    log_action("PrintAndSaveResult", "order_test", order_test_id,
               f"saved={int(saved_any)} archived={int(archived)}")
    return jsonify({"ok": True, "saved": saved_any, "archived": archived,
                    "print_url": url_for("print_report", order_test_id=order_test_id)})


def _whatsapp_generate_and_queue_multi(db, visit_row, patient_id, patient_name, phone, items):
    """نفس _whatsapp_generate_and_queue فوق، بس لعدة تحاليل كملفات PDF
    منفصلة دفعة وحدة (بدل ملف مجمّع واحد) — items: قائمة عناصر بشكل
    (label, html_content, order_test_id). يولّد كل الملفات بنفس المجلد،
    يسجّل صف طابور لكل واحد منها، ثم يفتح واتساب مرة وحدة + يفتح نفس
    المجلد (بدون تحديد ملف معيّن، خلافاً عن opened_folder المفرد) حتى
    يقدر المستخدم يحدد كل الملفات مرة وحدة (Ctrl+A أو تحديد متعدد)
    ويسحبها كلها سوا لمحادثة واتساب بضغطة وحدة."""
    import pdf_export

    now = datetime.now().isoformat(timespec="seconds")
    generated_paths = []
    for label, html_content, order_test_id in items:
        # كل ملف بالوضع "منفصل" اسمه "اسم المريض - اسم التحليل"، حتى لو
        # فتحت المجلد ولقيت عدة ملفات لنفس الزيارة تعرف فوراً أي ملف
        # لأي تحليل بدون ما تفتحه.
        prefix = f"{_safe_pdf_name_part(patient_name)} - {_safe_pdf_name_part(label)}"
        pdf_path = pdf_export.make_temp_pdf_path(prefix)
        try:
            pdf_export.html_to_pdf(html_content, request.url_root, pdf_path)
        except Exception as exc:
            db.execute(
                "INSERT INTO whatsapp_sends (visit_id, order_test_id, patient_id, patient_name, "
                "phone, label, pdf_path, status, attempts, error, requested_by, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, 'failed', 1, ?, ?, ?)",
                (visit_row["id"], order_test_id, patient_id, patient_name, phone, label,
                 pdf_path, f"فشل توليد PDF: {exc}", session.get("user_id"), now),
            )
            continue
        generated_paths.append((pdf_path, label, order_test_id))

    if not generated_paths:
        db.commit()
        return False, "تعذّر توليد أي ملف PDF لأي تحليل."

    # نفتح واتساب مرة وحدة بس (مو لكل ملف)، ونفتح مجلد الملفات (بدون
    # تحديد ملف معيّن — عكس _open_whatsapp_with_pdf المفرد اللي يحدد ملف
    # واحد بعينه) حتى يقدر المستخدم يحدد كل الملفات المولَّدة الجديدة
    # مرة وحدة ويسحبها سوا.
    import re as _re
    digits = _re.sub(r"\D", "", phone or "")
    country_code = get_setting(db, "whatsapp_country_code", "964")
    if digits.startswith("00"):
        digits = digits[2:]
    elif digits.startswith("0"):
        digits = country_code + digits[1:]
    elif digits and not digits.startswith(country_code):
        digits = country_code + digits

    opened_wa = False
    if digits:
        try:
            os.startfile(f"whatsapp://send?phone={digits}")
            opened_wa = True
        except OSError:
            try:
                webbrowser.open(f"https://wa.me/{digits}")
                opened_wa = True
            except Exception:
                opened_wa = False

    try:
        folder = os.path.dirname(os.path.normpath(generated_paths[0][0]))
        subprocess.run(["explorer", folder])
    except Exception:
        pass

    status = "opened" if opened_wa else "failed"
    error = None if opened_wa else "تعذّر فتح تطبيق واتساب — تأكد إنه مثبّت على هذا الجهاز."
    for pdf_path, label, order_test_id in generated_paths:
        db.execute(
            "INSERT INTO whatsapp_sends (visit_id, order_test_id, patient_id, patient_name, "
            "phone, label, pdf_path, status, attempts, error, requested_by, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)",
            (visit_row["id"], order_test_id, patient_id, patient_name, phone, label,
             pdf_path, status, error, session.get("user_id"), now),
        )
    db.commit()

    if opened_wa:
        return True, f"جهّزنا {len(generated_paths)} ملف PDF منفصل وفتحنا واتساب + مجلد الملفات — حدد كل الملفات (Ctrl+A) واسحبها سوا للمحادثة."
    return False, error

def _do_whatsapp_send_visit(visit_id, mode):
    """المنطق الفعلي لإرسال كل نتائج الزيارة عبر واتساب — mode='combined'
    (ملف PDF واحد مجمّع، الافتراضي القديم) أو 'separate' (ملف PDF مستقل
    لكل تحليل مكتمل). يرجّع (ok, message)."""
    db = get_db()
    visit = db.execute(
        "SELECT v.*, p.id as patient_id, p.full_name, p.phone FROM visits v "
        "JOIN patients p ON p.id = v.patient_id WHERE v.id=?",
        (visit_id,),
    ).fetchone()
    if not visit:
        return False, "الزيارة غير موجودة."
    if not visit["phone"]:
        return False, "لا يوجد رقم هاتف مسجّل لهذا المريض — أضِفه من ملف المريض أولًا."

    if mode == "separate":
        order_tests = db.execute(
            "SELECT ot.id, td.code as test_code, td.name as test_name "
            "FROM order_tests ot JOIN orders o ON o.id = ot.order_id "
            "JOIN test_definitions td ON td.id = ot.test_definition_id "
            "WHERE o.visit_id=? AND ot.status IN ('Completed', 'Verified') ORDER BY ot.id",
            (visit_id,),
        ).fetchall()
        if any((_o["test_code"] or "") == "CBC" for _o in order_tests):   # v80: ESR يطلع داخل تقرير CBC
            order_tests = [_o for _o in order_tests if not _v80_is_esr(_o["test_code"], _o["test_name"])]
        seen_codes = set()
        items = []
        for ot in order_tests:
            code = ot["test_code"]
            if code in BF_RETIC_LINK and BF_RETIC_LINK[code] in seen_codes:
                continue
            seen_codes.add(code)
            report_html = print_report(ot["id"])
            if not isinstance(report_html, str):
                continue
            items.append((ot["test_name"], report_html, ot["id"]))
        if not items:
            return False, "لا توجد نتائج مكتملة بهذي الزيارة لإرسالها بعد."
        ok, error = _whatsapp_generate_and_queue_multi(
            db, visit, visit["patient_id"], visit["full_name"], visit["phone"], items,
        )
        log_action("WhatsAppSend", "visit", visit_id, "opened" if ok else f"failed: {error}")
        return ok, error

    html_content = _build_combined_designed_reports_html(visit_id)
    if not html_content:
        return False, "لا توجد نتائج مكتملة بهذي الزيارة لإرسالها بعد."

    ok, error = _whatsapp_generate_and_queue(
        db, visit, visit["patient_id"], visit["full_name"], visit["phone"],
        "كل نتائج الزيارة", html_content, order_test_id=None,
    )
    log_action("WhatsAppSend", "visit", visit_id, "opened" if ok else f"failed: {error}")
    if ok:
        return True, "📎 جهّزنا ملف PDF واحد بكل نتائج الزيارة وفتحنا واتساب — اسحب الملف من نافذة المجلد وأرفقه بالمحادثة."
    return False, error


def _do_whatsapp_send_result(order_test_id):
    """المنطق الفعلي لإرسال نتيجة تحليل واحد عبر واتساب — يرجّع (ok, message,
    visit_id أو None). تُستخدم من مسارين: الرابط الكلاسيكي (فورم + flash +
    redirect) للاستخدام خارج أي iframe، والـAPI JSON (fetch من جوّه مودال
    'طباعة كل النتائج المكتملة') بدون أي تنقّل/إعادة تحميل."""
    db = get_db()
    ot = db.execute(
        "SELECT ot.*, td.name as test_name, v.id as visit_id, "
        "p.id as patient_id, p.full_name as patient_name, p.phone "
        "FROM order_tests ot "
        "JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id "
        "JOIN visits v ON v.id = o.visit_id "
        "JOIN patients p ON p.id = v.patient_id WHERE ot.id=?",
        (order_test_id,),
    ).fetchone()
    if not ot:
        return False, "النتيجة غير موجودة.", None
    if not ot["phone"]:
        return False, "لا يوجد رقم هاتف مسجّل لهذا المريض — أضِفه من ملف المريض أولًا.", ot["visit_id"]

    html_content = print_report(order_test_id)
    if not isinstance(html_content, str):
        return False, "لا يوجد تصميم طباعة لهذا التحليل بعد.", ot["visit_id"]

    ok, error = _whatsapp_generate_and_queue(
        db, ot, ot["patient_id"], ot["patient_name"], ot["phone"],
        ot["test_name"], html_content, order_test_id=order_test_id,
    )
    log_action("WhatsAppSend", "order_test", order_test_id, "opened" if ok else f"failed: {error}")
    if ok:
        return True, f"📎 جهّزنا ملف PDF لنتيجة {ot['test_name']} وفتحنا واتساب — اسحب الملف من نافذة المجلد وأرفقه بالمحادثة.", ot["visit_id"]
    return False, error, ot["visit_id"]


@app.route("/whatsapp/send-result/<int:order_test_id>", methods=["POST"])
@login_required
def whatsapp_send_result(order_test_id):
    """إرسال نتيجة تحليل واحد محدّد (مو كل نتائج الزيارة) عبر واتساب —
    نفس زر '🖨 طباعة التقرير' لكن يولّد PDF ويرسله بدل ما يفتحه بالمتصفح.
    (فورم كلاسيكي: flash + redirect — للاستخدام خارج أي iframe)."""
    ok, message, visit_id = _do_whatsapp_send_result(order_test_id)
    flash(message if ok else f"❌ {message}")
    return redirect(url_for("visit_results_entry", visit_id=visit_id) if visit_id else url_for("results_list"))


@app.route("/whatsapp/api/send-result/<int:order_test_id>", methods=["POST"])
@login_required
def whatsapp_api_send_result(order_test_id):
    """نفس whatsapp_send_result فوق بالضبط، بس يرجّع JSON بدل flash+redirect —
    يُستخدم بزر 📱 المفرد جوّه مودال 'طباعة كل النتائج المكتملة' (iframe)
    عبر fetch()، حتى ما يحتاج أي تنقّل/إعادة تحميل يكسر المودال."""
    ok, message, _visit_id = _do_whatsapp_send_result(order_test_id)
    return jsonify({"ok": ok, "message": message})


@app.route("/whatsapp/send-visit/<int:visit_id>", methods=["POST"])
@login_required
def whatsapp_send_visit(visit_id):
    """إرسال كل نتائج الزيارة عبر واتساب — mode بحقل الفورم: 'combined'
    (الافتراضي، ملف PDF واحد مجمّع) أو 'separate' (ملف PDF مستقل لكل
    تحليل). فورم كلاسيكي: flash + redirect — للاستخدام خارج أي iframe."""
    mode = request.form.get("mode", "combined")
    ok, message = _do_whatsapp_send_visit(visit_id, mode)
    flash(message if ok else f"❌ {message}")
    return redirect(url_for("visit_results_entry", visit_id=visit_id))


@app.route("/whatsapp/api/send-visit/<int:visit_id>", methods=["POST"])
@login_required
def whatsapp_api_send_visit(visit_id):
    """نفس whatsapp_send_visit فوق بالضبط، بس يرجّع JSON بدل flash+redirect —
    يُستخدم بأزرار 📱 'إرسال الكل' جوّه مودال 'طباعة كل النتائج المكتملة'
    (iframe) عبر fetch()."""
    mode = request.form.get("mode", "combined")
    ok, message = _do_whatsapp_send_visit(visit_id, mode)
    return jsonify({"ok": ok, "message": message})


@app.route("/reports/archive")
@login_required
def pdf_archive():
    """بحث سريع بأرشيف الـPDF الدائم (باسم المريض أو رقم التسجيل)، من داخل
    البرنامج مباشرة — بدل ما يفتّش المستخدم يدويًا بمجلد الأرشيف بالحاسبة."""
    db = get_db()
    q = request.args.get("q", "").strip()
    archive_dir = _get_pdf_archive_dir(db)
    # v78: القائمة = كل الزيارات المكتملة (غير المحذوفة من الأرشيف) — الـPDF يتولّد عند الفتح لو مو موجود
    db.execute("CREATE TABLE IF NOT EXISTS archive_deleted (visit_id INTEGER PRIMARY KEY, deleted_at TEXT, deleted_by TEXT)")
    like = f"%{q}%"
    rows = db.execute(
        "SELECT v.id AS visit_id, v.registration_number, p.full_name, v.created_at AS visit_at, "
        "COALESCE(sr.updated_at, v.created_at) AS updated_at, "
        "COALESCE(NULLIF(sr.referring_doctor_name,''), d.full_name, '') AS doctor_name, "
        "COALESCE(NULLIF(sr.referral_center_name,''), rc.name, '') AS center_name "
        "FROM visits v JOIN patients p ON p.id = v.patient_id LEFT JOIN saved_reports sr ON sr.visit_id = v.id "
        "LEFT JOIN doctors d ON d.id = v.doctor_id LEFT JOIN referral_centers rc ON rc.id = v.referral_center_id "
        "WHERE (? = '%%' OR p.full_name LIKE ? OR CAST(v.registration_number AS TEXT) LIKE ? OR p.phone LIKE ?) "
        "AND v.id NOT IN (SELECT visit_id FROM archive_deleted) "
        "AND EXISTS (SELECT 1 FROM order_tests ot JOIN orders o ON o.id=ot.order_id WHERE o.visit_id=v.id) "
        "AND NOT EXISTS (SELECT 1 FROM order_tests ot JOIN orders o ON o.id=ot.order_id WHERE o.visit_id=v.id "
        "AND ot.status NOT IN ('Completed','Verified')) "
        "ORDER BY v.id DESC LIMIT 200", (like, like, like, like)).fetchall()
    return render_template("pdf_archive.html", rows=rows, q=q, archive_configured=True)


@app.route("/reports/archive/<int:visit_id>/open")
@login_required
def pdf_archive_open(visit_id):
    """يفتح/يحمّل نسخة الأرشيف الدائمة مباشرة (نفس ملف مجلد الأرشفة بالضبط،
    وليس توليدًا جديدًا) — لو الملف انمسح يدويًا من مجلد الأرشيف من خارج
    البرنامج (نقل/حذف)، نرجّع رسالة واضحة بدل خطأ سيرفر غامض."""
    db = get_db()
    row = get_saved_report(db, visit_id)
    if not row or not row["pdf_path"] or not os.path.exists(row["pdf_path"]):
        # v72: غير مؤرشف (زيارة قديمة أو انحذف الملف) => نولّده الآن من نفس اللوحة المصممة ونحفظه
        try:
            _maybe_archive_visit_pdf(db, visit_id)
        except Exception:
            pass
        row = get_saved_report(db, visit_id)
    if not row or not row["pdf_path"] or not os.path.exists(row["pdf_path"]):
        # v74: تعذّر توليد/إيجاد الملف المؤرشف — نفتح التقرير نفسه (PDF أو صفحة جاهزة للطباعة) بدل الرجوع للأرشيف برسالة
        return redirect(url_for("report_pdf_visit", visit_id=visit_id))
    return send_file(row["pdf_path"], as_attachment=(request.args.get("download") == "1"),
                      download_name=os.path.basename(row["pdf_path"]))


@app.route("/reports/archive/<int:visit_id>/delete", methods=["POST"])
@login_required
def pdf_archive_delete(visit_id):
    """v78: حذف من الأرشيف — لا يتم إلا بموافقة مسؤول/مشرف المختبر (يوزر + باسورد حساب admin/supervisor).
    يحذف ملف الـPDF المؤرشف ويخفي الزيارة من القائمة؛ بيانات المريض ونتائجه ما تنمس."""
    db = get_db()
    ok, err = _check_completed_result_gate(db, request.form)
    if not ok:
        return jsonify(ok=False, message=err), 403
    db.execute("CREATE TABLE IF NOT EXISTS archive_deleted (visit_id INTEGER PRIMARY KEY, deleted_at TEXT, deleted_by TEXT)")
    row = get_saved_report(db, visit_id)
    if row and row["pdf_path"]:
        try:
            os.remove(row["pdf_path"])
        except OSError:
            pass
    db.execute("DELETE FROM saved_reports WHERE visit_id=?", (visit_id,))
    db.execute("INSERT OR REPLACE INTO archive_deleted (visit_id, deleted_at, deleted_by) VALUES (?,?,?)",
               (visit_id, datetime.now().isoformat(timespec="seconds"), (request.form.get("gate_username") or "").strip()))
    db.commit()
    log_action("ArchiveDelete", "visit", visit_id, "approved_by=%s" % (request.form.get("gate_username") or "shared-password"))
    return jsonify(ok=True, message="تم الحذف من الأرشيف")


@app.route("/whatsapp/queue")
@roles_required("supervisor")
def whatsapp_queue():
    db = get_db()
    rows = db.execute(
        "SELECT * FROM whatsapp_sends ORDER BY id DESC LIMIT 200"
    ).fetchall()
    return render_template("whatsapp_queue.html", rows=rows)


@app.route("/whatsapp/queue/<int:send_id>/retry", methods=["POST"])
@roles_required("supervisor")
def whatsapp_retry(send_id):
    db = get_db()
    row = db.execute("SELECT * FROM whatsapp_sends WHERE id=?", (send_id,)).fetchone()
    if not row:
        flash("العنصر غير موجود.")
        return redirect(url_for("whatsapp_queue"))
    opened_wa, _ = _open_whatsapp_with_pdf(
        row["phone"], row["pdf_path"], get_setting(db, "whatsapp_country_code", "964")
    )
    if opened_wa:
        db.execute(
            "UPDATE whatsapp_sends SET status='opened', sent_at=?, attempts=attempts+1, error=NULL WHERE id=?",
            (datetime.now().isoformat(timespec="seconds"), send_id),
        )
        db.commit()
        flash("📎 فتحنا واتساب ومجلد الملف من جديد — أرفقه وأرسله يدويًا.")
    else:
        db.execute(
            "UPDATE whatsapp_sends SET status='failed', error=?, attempts=attempts+1 WHERE id=?",
            ("تعذّر فتح تطبيق واتساب — تأكد إنه مثبّت على هذا الجهاز.", send_id),
        )
        db.commit()
        flash("❌ تعذّر فتح تطبيق واتساب.")
    return redirect(url_for("whatsapp_queue"))


@app.route("/whatsapp/queue/<int:send_id>/delete", methods=["POST"])
@roles_required("supervisor")
def whatsapp_delete(send_id):
    db = get_db()
    db.execute("DELETE FROM whatsapp_sends WHERE id=? AND status<>'sent'", (send_id,))
    db.commit()
    log_action("DeleteWhatsappQueue", "whatsapp_send", send_id)
    flash("🗑 تم حذف العنصر من الطابور.")
    return redirect(url_for("whatsapp_queue"))


@app.route("/whatsapp/queue/delete-failed", methods=["POST"])
@roles_required("supervisor")
def whatsapp_delete_failed():
    db = get_db()
    n = db.execute("DELETE FROM whatsapp_sends WHERE status IN ('failed','pending')").rowcount
    db.commit()
    log_action("DeleteWhatsappQueue", "whatsapp_send", 0, f"bulk {n}")
    flash(f"🗑 تم حذف {n} عنصر (فاشل/بالانتظار).")
    return redirect(url_for("whatsapp_queue"))


def whatsapp_background_worker():
    """كانت هذي المهمة تحاول تفتح Chrome بالخلفية كل 3 دقائق لإعادة إرسال
    أي عنصر فاشل عبر Selenium — بدون علم المستخدم، وهذا سبب رئيسي محتمل
    لتراكم نوافذ Chrome عالقة وأقفال ملفات (بما فيها مشاكل التثبيت اللي
    واجهناها). بما إن الإرسال صار خطوة يدوية بالكامل (فتح واتساب + سحب
    الملف من المستخدم نفسه)، ما فيه داعي لإعادة محاولة تلقائية بالخلفية
    إطلاقاً — المستخدم يعيد المحاولة بنفسه من "طابور واتساب" وقت ما يريد.
    خليت الدالة موجودة بس بدون أي فعل، تفاديًا لأي خطأ لو استدعاها كود
    ثاني بالمشروع."""
    return


@app.route("/workbench/verify/<int:order_test_id>", methods=["POST"])
@roles_required("supervisor")
def verify_result(order_test_id):
    db = get_db()
    now = datetime.now().isoformat(timespec="seconds")
    db.execute("UPDATE results SET verified_by=?, verified_at=? WHERE order_test_id=?",
               (session.get("user_id"), now, order_test_id))
    db.execute("UPDATE order_tests SET status='Verified' WHERE id=?", (order_test_id,))
    db.commit()
    log_action("Verify", "order_test", order_test_id)
    flash("Result verified & approved.")
    next_visit_id = request.form.get("next_visit_id")
    if next_visit_id:
        return redirect(url_for("visit_results_entry", visit_id=next_visit_id))
    return redirect(url_for("orders_list"))


@app.route("/workbench/unverify/<int:order_test_id>", methods=["POST"])
@roles_required("supervisor")
def unverify_result(order_test_id):
    # Reopens a previously verified/released result for correction. Never
    # silent: it clears verified_by/verified_at (so it visibly shows as
    # un-verified again everywhere, including on any printed report) and
    # writes an audit log entry with who reopened it and why, then sends
    # the person straight back into the edit form. Re-verification is
    # required again afterward — nothing about a corrected result skips the
    # normal approval step.
    db = get_db()
    reason = request.form.get("reason", "").strip()
    db.execute("UPDATE results SET verified_by=NULL, verified_at=NULL WHERE order_test_id=?", (order_test_id,))
    db.execute("UPDATE order_tests SET status='Completed' WHERE id=?", (order_test_id,))
    db.commit()
    log_action("Unverify", "order_test", order_test_id, reason or "(no reason given)")
    flash("Result reopened for editing — re-verification will be required after saving.")
    next_visit_id = request.form.get("next_visit_id")
    if next_visit_id:
        return redirect(url_for("visit_results_entry", visit_id=next_visit_id))
    return redirect(url_for("result_entry", order_test_id=order_test_id))



# ---------------------------------------------------------------- billing --
@app.route("/billing/rates", methods=["GET", "POST"])
@roles_required("admin", "accountant")
def rates():
    db = get_db()
    if request.method == "POST":
        if request.form.get("add_test_form") is not None:
            # فورم إضافة تحليل جديد لسريع من نفس صفحة Rates (زر إضافة/حذف
            # المطلوب هنا) -- بديل مختصر عن الذهاب لصفحة Test Catalog، يضيف
            # code/name/department/price فقط بدون باراميترات (تُضاف لاحقًا
            # من Test Catalog لو احتاج التحليل نتائج مفصّلة).
            code = request.form.get("new_code", "").strip()
            name = request.form.get("new_name", "").strip()
            department = request.form.get("new_department", "").strip()
            price = float(request.form.get("new_price") or 0)
            if not code or not name:
                flash("الكود والاسم مطلوبان لإضافة تحليل جديد.")
            else:
                try:
                    db.execute(
                        "INSERT INTO test_definitions (code, name, department, price) VALUES (?, ?, ?, ?)",
                        (code, name, department, price),
                    )
                    db.commit()
                    log_action("AddTest", "test_definitions", 0, f"{code}:{name}")
                    flash(f'تمت إضافة "{name}" لكتالوج الأسعار.')
                except Exception:
                    flash("تعذّر الإضافة -- على الأغلب هذا الكود مستخدم أصلاً لتحليل آخر.")
            return redirect(url_for("rates"))

        if request.form.get("update_department_form") is not None:
            test_id = request.form.get("test_id")
            department = request.form.get("department", "").strip()
            db.execute("UPDATE test_definitions SET department=? WHERE id=?", (department, test_id))
            db.commit()
            flash("Department updated.")
            return redirect(url_for("rates"))

        test_id = request.form.get("test_id")
        price = float(request.form.get("price") or 0)
        db.execute("UPDATE test_definitions SET price=? WHERE id=?", (price, test_id))
        db.commit()
        flash("Price updated.")
        return redirect(url_for("rates"))
    tests = db.execute("SELECT * FROM test_definitions ORDER BY department, name").fetchall()
    return render_template("billing/rates.html", tests=tests)


@app.route("/billing/rates/<int:test_id>/delete", methods=["POST"])
@roles_required("admin")
def delete_rate_test(test_id):
    """يمسح تحليل كامل من الكتالوج (زر حذف بصفحة Rates) — بس لو ما فيه أي
    طلب سابق (order_tests) مرتبط فيه، حتى ما ننكسر تقارير/فواتير قديمة.
    لو مستخدم فعلاً بزيارة قديمة، نعطّله بدل مسحه (is_active=0) ونوضح
    السبب بدل رفض صامت."""
    db = get_db()
    test = db.execute("SELECT id, name FROM test_definitions WHERE id=?", (test_id,)).fetchone()
    if not test:
        flash("هذا التحليل غير موجود أصلاً.")
        return redirect(url_for("rates"))
    used = db.execute("SELECT COUNT(*) as c FROM order_tests WHERE test_definition_id=?", (test_id,)).fetchone()["c"]
    if used:
        db.execute("UPDATE test_definitions SET is_active=0 WHERE id=?", (test_id,))
        db.commit()
        flash(f"\"{test['name']}\" مستخدم بـ{used} طلب سابق فما يُمسح نهائيًا — تم تعطيله بدل ذلك (ما يظهر بقوائم الطلب الجديدة).")
    else:
        db.execute("DELETE FROM test_parameters WHERE test_definition_id=?", (test_id,))
        db.execute("DELETE FROM reference_ranges WHERE test_parameter_id IN "
                   "(SELECT id FROM test_parameters WHERE test_definition_id=?)", (test_id,))
        db.execute("DELETE FROM test_definitions WHERE id=?", (test_id,))
        db.commit()
        flash(f"تم حذف \"{test['name']}\" نهائيًا.")
    log_action("DeleteOrDeactivateTest", "test_definitions", test_id, "")
    return redirect(url_for("rates"))


@app.route("/billing/invoices")
@login_required
def invoices_list():
    db = get_db()
    rows = db.execute(
        "SELECT i.id, i.total_amount, i.discount_amount, i.paid_amount, i.status, i.created_at, i.is_locked, "
        "p.full_name as patient_name, v.registration_number, v.id as visit_id "
        "FROM invoices i JOIN visits v ON v.id = i.visit_id JOIN patients p ON p.id = v.patient_id "
        "ORDER BY i.id DESC LIMIT 200"
    ).fetchall()
    return render_template("billing/invoices.html", rows=rows)


@app.route("/billing/invoices/<int:invoice_id>/toggle-lock", methods=["POST"])
@roles_required("admin", "accountant")
def toggle_invoice_lock(invoice_id):
    db = get_db()
    inv = db.execute("SELECT is_locked FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    new_val = 0 if inv["is_locked"] else 1
    db.execute("UPDATE invoices SET is_locked=? WHERE id=?", (new_val, invoice_id))
    db.commit()
    log_action("ToggleLock", "invoice", invoice_id, str(new_val))
    flash("Invoice locked." if new_val else "Invoice reopened.")
    return redirect(url_for("invoices_list"))


@app.route("/billing/invoices/<int:invoice_id>/discount", methods=["POST"])
@roles_required("admin", "accountant")
def apply_discount(invoice_id):
    db = get_db()
    inv = db.execute("SELECT is_locked FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    if inv and inv["is_locked"]:
        flash("Invoice is locked. Reopen it first to make changes.")
        return redirect(url_for("invoices_list"))
    amount = float(request.form.get("discount_amount") or 0)
    db.execute("UPDATE invoices SET discount_amount=? WHERE id=?", (amount, invoice_id))
    db.commit()
    log_action("Discount", "invoice", invoice_id, f"amount={amount}")
    flash("Discount applied.")
    return redirect(url_for("invoices_list"))



@app.route("/billing/registers")
@login_required
def registers():
    db = get_db()
    rows = db.execute(
        "SELECT u.full_name as user, "
        "COALESCE(SUM(pay.amount),0) as payments, "
        "COALESCE((SELECT SUM(discount_amount) FROM invoices WHERE created_by=u.id),0) as discounts "
        "FROM users u LEFT JOIN payments pay ON pay.user_id = u.id "
        "GROUP BY u.id ORDER BY payments DESC"
    ).fetchall()
    return render_template("billing/registers.html", rows=rows)


@app.route("/billing/pay/<int:visit_id>", methods=["POST"])
@login_required
def pay_invoice(visit_id):
    db = get_db()
    amount = float(request.form.get("amount") or 0)
    invoice = db.execute("SELECT * FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()
    if invoice:
        now = datetime.now().isoformat(timespec="seconds")
        db.execute("INSERT INTO payments (invoice_id, amount, method, user_id, paid_at) "
                   "VALUES (?, ?, 'Cash', ?, ?)", (invoice["id"], amount, session.get("user_id"), now))
        new_paid = invoice["paid_amount"] + amount
        status = "Paid" if new_paid >= invoice["total_amount"] else "Partial"
        db.execute("UPDATE invoices SET paid_amount=?, status=? WHERE id=?",
                   (new_paid, status, invoice["id"]))
        db.commit()
        log_action("Payment", "invoice", invoice["id"], f"amount={amount}")
        flash("Payment recorded.")
    return redirect(url_for("visits_list"))


# ------------------------------------------------------- master definitions
@app.route("/master/packages", methods=["GET", "POST"])
@roles_required("supervisor")
def packages_list():
    db = get_db()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        code = request.form.get("code", "").strip()
        test_ids = request.form.getlist("tests")
        cur = db.execute("INSERT INTO packages (name, code) VALUES (?, ?)", (name, code))
        pkg_id = cur.lastrowid
        for tid in test_ids:
            db.execute("INSERT INTO package_tests (package_id, test_definition_id) VALUES (?, ?)", (pkg_id, tid))
        db.commit()
        flash("Package created.")
        return redirect(url_for("packages_list"))

    packages = db.execute("SELECT * FROM packages ORDER BY name").fetchall()
    pkg_tests = {}
    for pkg in packages:
        tests = db.execute(
            "SELECT td.name FROM package_tests pt JOIN test_definitions td ON td.id = pt.test_definition_id "
            "WHERE pt.package_id=?", (pkg["id"],),
        ).fetchall()
        pkg_tests[pkg["id"]] = [t["name"] for t in tests]
    all_tests = db.execute("SELECT * FROM test_definitions WHERE is_active=1 ORDER BY name").fetchall()
    return render_template("master/packages.html", packages=packages, pkg_tests=pkg_tests, all_tests=all_tests)


@app.route("/master/parameters/<int:param_id>/rename", methods=["POST"])
@roles_required("supervisor")
def rename_test_parameter(param_id):
    """يعدّل اسم الـParameter نفسه بكتالوج التحاليل (وليس فقط أي اقتراح
    مرتبط فيه) -- من نفس صفحة Suggestions (المطلوب 5/9). تنبيه: لو هذا
    الباراميتر يُستخدم داخل قالب تقرير جاهز (مثل CBC أو Retic Count) بالاسم
    القديم صراحةً (params.get('الاسم القديم') بملف الـtemplate)، تغيير
    الاسم هنا بيخلّي هذا السطر يختفي من ذاك التقرير لحد ما يتحدّث القالب
    بالاسم الجديد يدويًا -- آمن تمامًا فقط للباراميترات العامة (قسم
    Other Results) اللي ما مربوطة بقالب مخصّص."""
    db = get_db()
    new_name = (request.form.get("new_name") or "").strip()
    if not new_name:
        flash("اسم الـParameter لا يمكن أن يكون فارغًا.")
        return redirect(url_for("suggestions_list"))
    row = db.execute("SELECT id FROM test_parameters WHERE id=?", (param_id,)).fetchone()
    if not row:
        flash("هذا الـParameter غير موجود.")
        return redirect(url_for("suggestions_list"))
    db.execute("UPDATE test_parameters SET name=? WHERE id=?", (new_name, param_id))
    db.commit()
    log_action("RenameParameter", "test_parameters", param_id, new_name)
    flash("تم تعديل اسم الـParameter.")
    return redirect(url_for("suggestions_list"))


@app.route("/master/tests/<int:test_definition_id>/rename", methods=["POST"])
@roles_required("supervisor")
def rename_test_definition_name(test_definition_id):
    """يعدّل اسم التحليل (Test) نفسه بكتالوج التحاليل -- من نفس صفحة
    Suggestions (المطلوب 5/9). يغيّر الاسم بكل مكان يستخدمه (شاشات الإدخال،
    الفواتير، التقارير...) لأنه نفس صف test_definitions.name المستخدم
    بكل الاستعلامات، وليس نسخة منفصلة خاصة بهذي الصفحة."""
    db = get_db()
    new_name = (request.form.get("new_name") or "").strip()
    if not new_name:
        flash("اسم التحليل لا يمكن أن يكون فارغًا.")
        return redirect(url_for("suggestions_list"))
    row = db.execute("SELECT id FROM test_definitions WHERE id=?", (test_definition_id,)).fetchone()
    if not row:
        flash("هذا التحليل غير موجود.")
        return redirect(url_for("suggestions_list"))
    db.execute("UPDATE test_definitions SET name=? WHERE id=?", (new_name, test_definition_id))
    db.commit()
    log_action("RenameTest", "test_definitions", test_definition_id, new_name)
    flash("تم تعديل اسم التحليل.")
    return redirect(url_for("suggestions_list"))


@app.route("/master/suggestions", methods=["GET", "POST"])
@roles_required("supervisor")
def suggestions_list():
    db = get_db()
    if request.method == "POST":
        param_id = request.form.get("test_parameter_id")
        content = request.form.get("content", "").strip()
        if content:
            db.execute("INSERT INTO suggestions (test_parameter_id, content) VALUES (?, ?)", (param_id, content))
            db.commit()
            flash("Suggestion added.")
        return redirect(url_for("suggestions_list"))

    rows = db.execute(
        "SELECT s.id, s.content, s.test_parameter_id, tp.name as param_name, td.name as test_name, "
        "td.id as test_definition_id FROM suggestions s "
        "JOIN test_parameters tp ON tp.id = s.test_parameter_id "
        "JOIN test_definitions td ON td.id = tp.test_definition_id ORDER BY td.name LIMIT 200"
    ).fetchall()
    parameters = db.execute(
        "SELECT tp.id, tp.name, td.name as test_name, td.id as test_definition_id FROM test_parameters tp "
        "JOIN test_definitions td ON td.id = tp.test_definition_id ORDER BY td.name"
    ).fetchall()
    return render_template("master/suggestions.html", rows=rows, parameters=parameters)


@app.route("/master/suggestions/<int:suggestion_id>/update", methods=["POST"])
@roles_required("supervisor")
def update_suggestion(suggestion_id):
    """يعدّل اقتراح موجود — الباراميتر المرتبط فيه و/أو نصّه — من نفس
    صفحة Suggestions (زر ✏️ لكل صف)."""
    db = get_db()
    row = db.execute("SELECT id FROM suggestions WHERE id=?", (suggestion_id,)).fetchone()
    if not row:
        flash("هذا الاقتراح غير موجود.")
        return redirect(url_for("suggestions_list"))
    param_id = request.form.get("test_parameter_id")
    content = request.form.get("content", "").strip()
    if not content:
        flash("نص الاقتراح لا يمكن أن يكون فارغًا.")
        return redirect(url_for("suggestions_list"))
    db.execute(
        "UPDATE suggestions SET test_parameter_id=?, content=? WHERE id=?",
        (param_id, content, suggestion_id),
    )
    db.commit()
    flash("تم تعديل الاقتراح.")
    return redirect(url_for("suggestions_list"))


@app.route("/master/suggestions/<int:suggestion_id>/delete", methods=["POST"])
@roles_required("supervisor")
def delete_suggestion(suggestion_id):
    db = get_db()
    db.execute("DELETE FROM suggestions WHERE id=?", (suggestion_id,))
    db.commit()
    flash("تم حذف الاقتراح.")
    return redirect(url_for("suggestions_list"))



@app.route("/master/mapcodes/bulk_add_test", methods=["POST"])
@roles_required("supervisor")
def mapcodes_bulk_add_test():
    """يضيف مرة وحدة سطر Mapcode لكل عناصر تحليل معيّن دفعة وحدة (مثلاً كل
    الـ 21 عنصر بتحليل CBC) بدل ما تضيفهم واحد واحد يدوياً من القائمة.
    الكود الافتراضي المكتوب بـ machine_code هو اسم العنصر نفسه كبداية —
    لازم بعدها تراجعه وتصححه بالكود الحقيقي اللي يرسله جهازك بالذات (شوف
    صفحة Host Interface بعد أول عينة تجريبية). العناصر النصية (Text، مثل
    Comment أو Conclusion) تُستثنى لأنه الأجهزة لا ترسل نصوص حرة عادةً،
    وأي عنصر عنده Mapcode موجود مسبقاً يُتخطّى حتى ما يتكرر."""
    db = get_db()
    test_definition_id = request.form.get("test_definition_id")
    machine_name = request.form.get("bulk_machine_name", "").strip()
    params = db.execute(
        "SELECT id, name FROM test_parameters WHERE test_definition_id=? AND result_type='Numeric' ORDER BY id",
        (test_definition_id,),
    ).fetchall()
    added = 0
    skipped = 0
    for p in params:
        exists = db.execute(
            "SELECT 1 FROM mapcodes WHERE test_parameter_id=? LIMIT 1", (p["id"],)
        ).fetchone()
        if exists:
            skipped += 1
            continue
        db.execute(
            "INSERT INTO mapcodes (test_parameter_id, machine_name, machine_code, send_enabled, receive_enabled) "
            "VALUES (?, ?, ?, 1, 1)",
            (p["id"], machine_name, p["name"]),
        )
        added += 1
    db.commit()
    flash(f"تمت إضافة {added} عنصر — راجع وصحّح الأكواد بالأكواد الحقيقية من جهازك. ({skipped} كانوا موجودين مسبقاً وتُخطّوا)" if added or skipped else "هذا التحليل ما عنده عناصر رقمية.")
    return redirect(url_for("mapcodes_list"))


@app.route("/master/mapcodes", methods=["GET", "POST"])
@roles_required("supervisor")
def mapcodes_list():
    db = get_db()
    if request.method == "POST":
        param_id = request.form.get("test_parameter_id")
        machine_name = request.form.get("machine_name", "").strip()
        machine_code = request.form.get("machine_code", "").strip()
        send_enabled = 1 if request.form.get("send_enabled") else 0
        receive_enabled = 1 if request.form.get("receive_enabled") else 0
        db.execute(
            "INSERT INTO mapcodes (test_parameter_id, machine_name, machine_code, send_enabled, receive_enabled) "
            "VALUES (?, ?, ?, ?, ?)",
            (param_id, machine_name, machine_code, send_enabled, receive_enabled),
        )
        db.commit()
        flash("Mapcode added.")
        return redirect(url_for("mapcodes_list"))

    rows = db.execute(
        "SELECT m.*, tp.name as param_name, td.name as test_name FROM mapcodes m "
        "JOIN test_parameters tp ON tp.id = m.test_parameter_id "
        "JOIN test_definitions td ON td.id = tp.test_definition_id ORDER BY td.name LIMIT 200"
    ).fetchall()
    parameters = db.execute(
        "SELECT tp.id, tp.name, td.name as test_name FROM test_parameters tp "
        "JOIN test_definitions td ON td.id = tp.test_definition_id ORDER BY td.name"
    ).fetchall()
    tests = db.execute(
        "SELECT id, name FROM test_definitions ORDER BY name"
    ).fetchall()
    return render_template("master/mapcodes.html", rows=rows, parameters=parameters, tests=tests)


@app.route("/master/mapcodes/<int:mapcode_id>/edit", methods=["POST"])
@roles_required("supervisor")
def update_mapcode(mapcode_id):
    db = get_db()
    machine_name = request.form.get("machine_name", "").strip()
    machine_code = request.form.get("machine_code", "").strip()
    send_enabled = 1 if request.form.get("send_enabled") else 0
    receive_enabled = 1 if request.form.get("receive_enabled") else 0
    db.execute(
        "UPDATE mapcodes SET machine_name=?, machine_code=?, send_enabled=?, receive_enabled=? WHERE id=?",
        (machine_name, machine_code, send_enabled, receive_enabled, mapcode_id),
    )
    db.commit()
    flash(t(session.get("lang", "en"), "mapcode_updated"))
    return redirect(url_for("mapcodes_list"))


@app.route("/master/mapcodes/<int:mapcode_id>/delete", methods=["POST"])
@roles_required("supervisor")
def delete_mapcode(mapcode_id):
    db = get_db()
    db.execute("DELETE FROM mapcodes WHERE id=?", (mapcode_id,))
    db.commit()
    flash(t(session.get("lang", "en"), "mapcode_deleted"))
    return redirect(url_for("mapcodes_list"))




# ============== حزمة الإعدادات (v65): نقل التصاميم/الأطباء/الباركودات/الكتالوج من نسخة لنسخة ==============
# سبب المشكلة: كل هذي الأشياء مخزّنة بقاعدة البيانات (settings + جداول)، والتحديث/التنصيب ينقل الكود والقوالب فقط
# (بدون قاعدة بيانات عن قصد). هذي الصفحة تصدّر الإعدادات بملف zip وحدة وتستوردها بجهاز العميل الجديد.
_CFG_SKIP_KEYS = re.compile(r"(token|api_key|secret|password|license|hardware|github|updater|auto_update|"
                            r"host_listener|analyzer_ip_map|signing|whatsapp_session|"
                            r"^portal_(url|api_key|enabled|mode)$|^update_channel$|^last_backup_at$|^pdf_archive_dir$|"
                            r"^backup_gate_username$|^fee_waiver_gate_username$|^fee_waiver_authorized_name$)", re.I)
# هوية المختبر: اسم/هاتف/عنوان/عنوان الصفحة الرئيسية — تنتقل فقط لو فعّلت خيار "تضمين اسم المختبر"
_CFG_IDENTITY_KEYS = re.compile(r"^(app_name|app_name_ar|lab_name|lab_phone|lab_address|lab_email|brand|landing_title|landing_title_en)", re.I)
_CFG_GROUPS = [
    ("settings", "الإعدادات والتصاميم (تصاميم التقارير، الباركودات، الملصقات، الترويسة، الألوان، الخيارات)",
     [], False),
    ("lab_doctors", "أطباء المختبر الفاحصين وشهاداتهم + الأختام والتواقيع الرقمية",
     ["examining_doctors_list", "examining_doctor_rates", "digital_stamps"], True),
    ("catalog", "كتالوج التحاليل (التحاليل + الباراميترات + المديات الطبيعية + ربط الأجهزة Mapcodes + الباقات + قوالب التقارير)",
     ["test_definitions", "test_parameters", "reference_ranges", "mapcodes", "packages", "package_tests",
      "quick_add_items", "suggestions", "report_templates", "report_layout_overrides", "partner_labs", "partner_lab_prices"], True),
    ("doctors", "الأطباء المرسلين ومراكز الإحالة وأسعارهم الخاصة",
     ["doctors", "referral_centers", "doctor_test_prices", "center_test_prices"], True),
]


def _cfg_tables_present(db):
    return {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}


def _cfg_is_fresh(db):
    try:
        n1 = db.execute("SELECT COUNT(*) FROM visits").fetchone()[0]
        n2 = db.execute("SELECT COUNT(*) FROM order_tests").fetchone()[0]
        return (n1 or 0) == 0 and (n2 or 0) == 0
    except Exception:
        return False


def _cfg_page(db, msg=""):
    from flask import render_template_string
    return render_template_string(
        "<!doctype html><meta charset='utf-8'><body dir='rtl' style='font-family:Tahoma,Arial;padding:20px;max-width:820px'>"
        "<h2>📦 حزمة الإعدادات (نقل التصاميم والأطباء والباركودات)</h2>"
        "{% if msg %}<div style='background:#ECFDF5;border:1px solid #6EE7B7;padding:10px;border-radius:8px;margin-bottom:12px'>{{ msg }}</div>{% endif %}"
        "<p style='color:#475569'>التحديث والتنصيب ينقلان الكود والقوالب فقط. التصاميم والأطباء والباركودات مخزّنة بقاعدة البيانات، "
        "فتُنقل من هنا: <b>صدّر</b> ثم <b>استورد</b> بجهاز العميل، أو <b>أرسلها لعميل عن بُعد</b>.</p>"
        "<h3>1) تصدير (ملف zip)</h3>"
        "<form method='post' action='{{ url_for(\"config_pack_export\") }}'>"
        "{% for key, label, tables, fresh in groups %}<label style='display:block;margin:6px 0'>"
        "<input type='checkbox' name='g' value='{{ key }}' checked> {{ label }}</label>{% endfor %}"
        "<label style='display:block;margin:6px 0'><input type='checkbox' name='identity' value='1'> "
        "تضمين اسم المختبر وعنوانه وهاتفه وعنوان الصفحة الرئيسية</label>"
        "<label style='display:block;margin:6px 0'><input type='checkbox' name='files' value='1' checked> "
        "تضمين الصور (الشعار، التواقيع، الأختام)</label>"
        "<button class='btn' style='padding:8px 16px'>⬇ تصدير الحزمة</button></form>"
        "<h3 style='margin-top:26px'>2) استيراد (على جهاز العميل)</h3>"
        "<p style='color:#92400E'>الإعدادات تُدمج دائمًا. أطباء المختبر وشهاداتهم تُدمج بالاسم إذا فيه زيارات. الكتالوج والأطباء المرسلين "
        "تُستورد <b>فقط</b> على نسخة بلا زيارات ({{ 'هذي النسخة فارغة ✓' if fresh else 'هذي النسخة فيها زيارات ✗' }}).</p>"
        "<form method='post' enctype='multipart/form-data' action='{{ url_for(\"config_pack_import\") }}'>"
        "<input type='file' name='pack' accept='.zip' required><br>"
        "{% for key, label, tables, fresh in groups %}<label style='display:block;margin:6px 0'>"
        "<input type='checkbox' name='g' value='{{ key }}' checked> {{ label }}</label>{% endfor %}"
        "<button class='btn' style='padding:8px 16px;margin-top:8px'>⬆ استيراد</button></form>"
        "<h3 style='margin-top:26px'>3) إرسال لعميل عن بُعد (بدون الدخول على جهازه)</h3>"
        "<p style='color:#475569;font-size:13px'>يُرفع الإعداد موقّعًا (بنفس مفتاح التحديثات) لمستودعك الخاص، ويطبّقه جهاز العميل لحاله عند الفحص الدوري "
        "(كل 6 ساعات) أو لما يضغط «تحقق من تحديث الآن». يُرسَل فقط: الإعدادات + أطباء المختبر وشهاداتهم + الصور "
        "(الكتالوج والأطباء المرسلين لا يُرسلون لجهاز فيه زيارات). لازم يكون جهاز العميل «مربوط بالإنترنت».</p>"
        "<form method='post' action='{{ url_for(\"config_pack_push\") }}'>"
        "<label style='display:block;margin:6px 0'>معرّف جهاز العميل (Hardware ID) "
        "<input type='text' name='hardware_id' required style='width:340px;direction:ltr'></label>"
        "<label style='display:block;margin:6px 0'><input type='checkbox' name='g' value='settings' checked> الإعدادات والتصاميم</label>"
        "<label style='display:block;margin:6px 0'><input type='checkbox' name='g' value='lab_doctors' checked> أطباء المختبر وشهاداتهم والأختام والتواقيع</label>"
        "<label style='display:block;margin:6px 0'><input type='checkbox' name='g' value='catalog' checked> تصاميم التقارير لكل تحليل (على جهاز فيه زيارات تُدمج بالرمز بدون المساس بالتحاليل والأسعار)</label>"
        "<label style='display:block;margin:6px 0'><input type='checkbox' name='identity' value='1'> تضمين اسم المختبر والهاتف والعنوان</label>"
        "<label style='display:block;margin:6px 0'><input type='checkbox' name='files' value='1' checked> تضمين الصور (حتى 15MB إجمالًا)</label>"
        "<button class='btn' style='padding:8px 16px'>🚀 أرسل للعميل</button></form>"
        "<p style='margin-top:20px'><a href='{{ url_for(\"designer_panel\") }}'>رجوع للوحة المصمم</a></p></body>",
        groups=_CFG_GROUPS, msg=msg, fresh=_cfg_is_fresh(db))


def _cfg_collect(db, want, identity):
    """يبني حزمة الإعدادات (dict) بدون ملفات."""
    present = _cfg_tables_present(db)
    pack = {"format": "lis-config-pack", "version": 1, "created": datetime.now().isoformat(timespec="seconds"),
            "groups": sorted(want), "settings": {}, "tables": {}, "maps": {}}
    if "settings" in want:
        for r in db.execute("SELECT key, value FROM settings").fetchall():
            k = r["key"] or ""
            if _CFG_SKIP_KEYS.search(k):
                continue
            if _CFG_IDENTITY_KEYS.search(k) and not identity:
                continue
            pack["settings"][k] = r["value"]
    for key, _label, tables, _fresh in _CFG_GROUPS:
        if key not in want:
            continue
        for t in tables:
            if t not in present:
                continue
            q = "SELECT * FROM " + t
            if t == "report_layout_overrides":
                q += " WHERE COALESCE(scope,'') <> 'order_test'"
            try:
                cur = db.execute(q)
            except Exception:
                continue
            cols = [d[0] for d in cur.description]
            pack["tables"][t] = {"cols": cols, "rows": [list(r) for r in cur.fetchall()]}
    # خرائط رقم→رمز/اسم: تسمح بدمج التصاميم والأختام بجهاز عنده زيارات (الأرقام تختلف بين الأجهزة، الرموز لا)
    try:
        pack["maps"]["test_codes"] = {str(r[0]): r[1] for r in db.execute("SELECT id, code FROM test_definitions")}
        pack["maps"]["doctor_names"] = {str(r[0]): r[1] for r in db.execute("SELECT id, name FROM examining_doctors_list")}
    except Exception:
        pass
    return pack


def _cfg_collect_files(max_file=5 * 1024 * 1024, max_total=100 * 1024 * 1024):
    out, total = {}, 0
    if os.path.isdir(UPLOAD_DIR):
        for root, _d, files in os.walk(UPLOAD_DIR):
            for fn in files:
                fp = os.path.join(root, fn)
                try:
                    sz = os.path.getsize(fp)
                    if sz > max_file or total + sz > max_total:
                        continue
                    with open(fp, "rb") as fh:
                        out["uploads/" + os.path.relpath(fp, UPLOAD_DIR).replace(os.sep, "/")] = fh.read()
                    total += sz
                except OSError:
                    pass
    return out


def _cfg_apply(db, pack, files, want):
    """يطبّق حزمة على قاعدة هذا الجهاز. files: dict {"uploads/x.png": bytes}. يرجّع (done, skipped). بدون أي اعتماد على Flask."""
    done, skipped = [], []
    fresh = _cfg_is_fresh(db)
    present = _cfg_tables_present(db)
    if "settings" in want:
        n = 0
        for k, v in (pack.get("settings") or {}).items():
            if _CFG_SKIP_KEYS.search(k or ""):
                continue
            set_setting(db, k, v)
            n += 1
        done.append(f"الإعدادات ({n} مفتاح)")
    db.execute("PRAGMA foreign_keys=OFF")
    try:
        for key, label, tables, needs_fresh in _CFG_GROUPS:
            if key not in want or key == "settings":
                continue
            if needs_fresh and not fresh:
                if key == "lab_doctors":
                    blob = (pack.get("tables") or {}).get("examining_doctors_list")
                    n_m = 0
                    if blob and "examining_doctors_list" in present:
                        cols = blob["cols"]
                        for row in blob["rows"]:
                            rec = dict(zip(cols, row))
                            nm = (rec.get("name") or "").strip()
                            if not nm:
                                continue
                            fields = [c for c in ("title", "degree_ar", "degree_en", "sort_order", "show_on_letterhead") if c in rec]
                            ex = db.execute("SELECT id FROM examining_doctors_list WHERE name=?", (nm,)).fetchone()
                            if ex:
                                if fields:
                                    db.execute("UPDATE examining_doctors_list SET " + ",".join(f + "=?" for f in fields) + " WHERE id=?",
                                               [rec[f] for f in fields] + [ex[0]])
                            else:
                                ins = ["name"] + fields
                                db.execute("INSERT INTO examining_doctors_list (" + ",".join(ins) + ") VALUES (" + ",".join("?" * len(ins)) + ")",
                                           [nm] + [rec[f] for f in fields])
                            n_m += 1
                    # الأختام والتواقيع: دمج بالتسمية (label) وربط الطبيب بالاسم
                    n_st = 0
                    sblob = (pack.get("tables") or {}).get("digital_stamps")
                    dnames = (pack.get("maps") or {}).get("doctor_names") or {}
                    if sblob and "digital_stamps" in present:
                        tcols = {r[1] for r in db.execute("PRAGMA table_info(digital_stamps)").fetchall()}
                        skipc = {"id", "created_by", "linked_examining_doctor_id"}
                        for row in sblob["rows"]:
                            rec = dict(zip(sblob["cols"], row))
                            lab = (rec.get("label") or "").strip()
                            if not lab:
                                continue
                            link = None
                            dn = dnames.get(str(rec.get("linked_examining_doctor_id")))
                            if dn:
                                lr = db.execute("SELECT id FROM examining_doctors_list WHERE name=?", (dn,)).fetchone()
                                link = lr[0] if lr else None
                            use = [c for c in rec if c in tcols and c not in skipc]
                            ex = db.execute("SELECT id FROM digital_stamps WHERE label=?", (lab,)).fetchone()
                            if ex:
                                db.execute("UPDATE digital_stamps SET " + ",".join(c + "=?" for c in use) + ", linked_examining_doctor_id=? WHERE id=?",
                                           [rec[c] for c in use] + [link, ex[0]])
                            else:
                                cols2 = use + ["linked_examining_doctor_id"]
                                db.execute("INSERT INTO digital_stamps (" + ",".join(cols2) + ") VALUES (" + ",".join("?" * len(cols2)) + ")",
                                           [rec[c] for c in use] + [link])
                            n_st += 1
                    done.append(f"أطباء المختبر وشهاداتهم — دمج بالاسم ({n_m} طبيب) + الأختام والتواقيع ({n_st})")
                    continue
                if key == "catalog":
                    # تصاميم التقارير لكل تحليل: دمج بالمطابقة برمز التحليل (بدون المساس بالتحاليل والأسعار)
                    id2code = (pack.get("maps") or {}).get("test_codes") or {}
                    code2local = {r[1]: r[0] for r in db.execute("SELECT id, code FROM test_definitions")}
                    n_d = 0
                    nowx = datetime.now().isoformat(timespec="seconds")
                    tb = (pack.get("tables") or {}).get("report_templates")
                    if tb and "report_templates" in present:
                        for row in tb["rows"]:
                            rec = dict(zip(tb["cols"], row))
                            loc = code2local.get(id2code.get(str(rec.get("test_definition_id"))))
                            if not loc:
                                continue
                            ex = db.execute("SELECT id FROM report_templates WHERE test_definition_id=?", (loc,)).fetchone()
                            if ex:
                                db.execute("UPDATE report_templates SET heading=?, rows_json=?, source_docx_name=?, updated_at=? WHERE id=?",
                                           (rec.get("heading"), rec.get("rows_json"), rec.get("source_docx_name"), nowx, ex[0]))
                            else:
                                db.execute("INSERT INTO report_templates (test_definition_id, heading, rows_json, source_docx_name, created_at, updated_at) "
                                           "VALUES (?,?,?,?,?,?)", (loc, rec.get("heading"), rec.get("rows_json"), rec.get("source_docx_name"), nowx, nowx))
                            n_d += 1
                    lb = (pack.get("tables") or {}).get("report_layout_overrides")
                    if lb and "report_layout_overrides" in present:
                        for row in lb["rows"]:
                            rec = dict(zip(lb["cols"], row))
                            if rec.get("scope") != "test":
                                continue
                            loc = code2local.get(id2code.get(str(rec.get("scope_id"))))
                            if not loc:
                                continue
                            db.execute("INSERT INTO report_layout_overrides (scope, scope_id, layout_json, updated_at) VALUES ('test',?,?,?) "
                                       "ON CONFLICT(scope, scope_id) DO UPDATE SET layout_json=excluded.layout_json, updated_at=excluded.updated_at",
                                       (loc, rec.get("layout_json"), nowx))
                            n_d += 1
                    done.append(f"تصاميم التقارير لكل تحليل — دمج بالرمز ({n_d}؛ التحاليل والأسعار والمديات ما تتغير على نسخة فيها زيارات)")
                    continue
                skipped.append(label.split(" (")[0].split(" +")[0])
                continue
            cnt = 0
            for t in tables:
                blob = (pack.get("tables") or {}).get(t)
                if not blob or t not in present:
                    continue
                tcols = {r["name"] if hasattr(r, "keys") else r[1] for r in db.execute("PRAGMA table_info(" + t + ")").fetchall()}
                use = [c for c in blob["cols"] if c in tcols]
                if not use:
                    continue
                if t == "report_layout_overrides":
                    db.execute("DELETE FROM report_layout_overrides WHERE COALESCE(scope,'') <> 'order_test'")
                else:
                    db.execute("DELETE FROM " + t)
                idx = [blob["cols"].index(c) for c in use]
                sql = "INSERT OR REPLACE INTO " + t + " (" + ",".join(use) + ") VALUES (" + ",".join("?" * len(use)) + ")"
                for row in blob["rows"]:
                    db.execute(sql, [row[i] for i in idx])
                    cnt += 1
            done.append(f"{label.split(' (')[0].split(' +')[0]} ({cnt} سجل)")
        db.commit()
    finally:
        db.execute("PRAGMA foreign_keys=ON")
    nfiles = 0
    base = os.path.realpath(UPLOAD_DIR)
    for name, data in (files or {}).items():
        if not name.startswith("uploads/") or name.endswith("/"):
            continue
        dest = os.path.realpath(os.path.join(UPLOAD_DIR, name[len("uploads/"):]))
        if not dest.startswith(base + os.sep):
            continue
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "wb") as out:
            out.write(data)
        nfiles += 1
    if nfiles:
        done.append(f"الصور ({nfiles} ملف)")
    return done, skipped


@app.route("/designer/config-pack")
@designer_required
def config_pack_page():
    return _cfg_page(get_db())


@app.route("/designer/config-pack/export", methods=["POST"])
@designer_required
def config_pack_export():
    db = get_db()
    want = set(request.form.getlist("g"))
    pack = _cfg_collect(db, want, request.form.get("identity") == "1")
    files = _cfg_collect_files() if request.form.get("files") == "1" else {}
    buf = BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("config.json", json.dumps(pack, ensure_ascii=False, default=str))
        for name, data in files.items():
            z.writestr(name, data)
    buf.seek(0)
    log_action("ConfigPackExport", "settings", 0, ",".join(sorted(want)))
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name="lis_config_pack_" + datetime.now().strftime("%Y%m%d_%H%M") + ".zip")


@app.route("/designer/config-pack/import", methods=["POST"])
@designer_required
def config_pack_import():
    db = get_db()
    f = request.files.get("pack")
    if not f:
        return _cfg_page(db, "اختر ملف الحزمة أولاً.")
    want = set(request.form.getlist("g"))
    raw = f.read(150 * 1024 * 1024 + 1)
    if len(raw) > 150 * 1024 * 1024:
        return _cfg_page(db, "الملف كبير جدًا.")
    try:
        z = zipfile.ZipFile(BytesIO(raw))
        pack = json.loads(z.read("config.json").decode("utf-8"))
        assert pack.get("format") == "lis-config-pack"
    except Exception:
        return _cfg_page(db, "الملف ليس حزمة إعدادات صالحة.")
    files = {n: z.read(n) for n in z.namelist() if n.startswith("uploads/") and not n.endswith("/")}
    done, skipped = _cfg_apply(db, pack, files, want)
    log_action("ConfigPackImport", "settings", 0, ",".join(done)[:200])
    msg = "تم استيراد: " + "، ".join(done) if done else "ما تم استيراد شي."
    if skipped:
        msg += " — تم تخطي (النسخة فيها زيارات): " + "، ".join(skipped)
    return _cfg_page(db, msg)


# ---- إرسال الإعدادات لعميل عن بُعد (v65) ----
def _cfg_canon(payload):
    return json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def _cfg_signing_key_path(db):
    cands = [get_setting(db, "update_signing_key_path", "") or "", os.environ.get("LAB_UPDATE_SIGNING_KEY", ""),
             os.path.join(os.path.expanduser("~"), ".lab_update_signing_key.pem")]
    for c in cands:
        if c and os.path.isfile(c):
            return c
    return ""


def _cfg_sign(db, created, payload):
    import hashlib
    from cryptography.hazmat.primitives.serialization import load_pem_private_key
    kp = _cfg_signing_key_path(db)
    if not kp:
        raise RuntimeError("مفتاح توقيع التحديثات غير موجود (~/.lab_update_signing_key.pem). نفس المفتاح اللي تنشر فيه التحديثات.")
    with open(kp, "rb") as fh:
        key = load_pem_private_key(fh.read(), password=None)
    digest = hashlib.sha256(_cfg_canon(payload)).hexdigest()
    return base64.b64encode(key.sign(("%s|%s" % (created, digest)).encode("utf-8"))).decode("ascii")


@app.route("/designer/config-pack/push", methods=["POST"])
@designer_required
def config_pack_push():
    db = get_db()
    hw = (request.form.get("hardware_id") or "").strip().upper()
    want = set(request.form.getlist("g")) & {"settings", "lab_doctors", "catalog"}
    if not hw or not want:
        return _cfg_page(db, "أدخل معرّف الجهاز واختر مجموعة واحدة على الأقل.")
    try:
        pack = _cfg_collect(db, want, request.form.get("identity") == "1")
        files = _cfg_collect_files(max_file=2 * 1024 * 1024, max_total=15 * 1024 * 1024) if request.form.get("files") == "1" else {}
        payload = dict(pack)
        payload["files"] = {n: base64.b64encode(d).decode("ascii") for n, d in files.items()}
        created = pack["created"]
        envelope = {"created": created, "sig": _cfg_sign(db, created, payload), "payload": payload}
        auto_updater.push_config_pack(get_setting(db, "github_write_token", ""), hw, envelope)
        log_action("ConfigPackPush", "settings", 0, hw)
        return _cfg_page(db, f"تم إرسال الإعدادات لجهاز {hw} ({len(payload['files'])} صورة) — يطبّقها عند فحصه الدوري أو لما يضغط «تحقق من تحديث الآن».")
    except Exception as e:
        return _cfg_page(db, f"⚠️ تعذر الإرسال: {e}")


def _cfg_remote_apply(db, payload):
    """يُستدعى من auto_updater.check_config_pack بعد التحقق من التوقيع. يطبّق فقط الإعدادات وأطباء المختبر."""
    files = {}
    for n, b in (payload.get("files") or {}).items():
        try:
            files[n] = base64.b64decode(b)
        except Exception:
            pass
    want = set(payload.get("groups") or []) & {"settings", "lab_doctors", "catalog"}
    done, skipped = _cfg_apply(db, payload, files, want)
    return "تم تطبيق إعدادات من المصمم: " + "، ".join(done)


@app.route("/master/analyzer-ip-map", methods=["GET", "POST"])
@designer_required
def analyzer_ip_map():
    """ربط عنوان IP كل جهاز باسمه (لازم يطابق machine_name بصفحة Mapcodes) حتى يرجّع له الاستعلام تحاليله فقط."""
    db = get_db()
    if request.method == "POST":
        lines = []
        for ln in (request.form.get("map") or "").splitlines():
            if "=" in ln:
                k, v = ln.split("=", 1)
                if k.strip() and v.strip():
                    lines.append(k.strip() + "=" + v.strip())
        set_setting(db, "analyzer_ip_map", ";".join(lines))
        db.commit()
        flash("تم حفظ ربط الأجهزة")
        return redirect(url_for("analyzer_ip_map"))
    cur = (get_setting(db, "analyzer_ip_map", "") or "").replace(";", "\n")
    names = [r["machine_name"] for r in db.execute(
        "SELECT DISTINCT machine_name FROM mapcodes WHERE machine_name IS NOT NULL AND machine_name<>'' ORDER BY 1")]
    return render_template_string(
        "<!doctype html><meta charset='utf-8'><body dir='rtl' style='font-family:Tahoma;padding:20px;max-width:720px'>"
        "<h3>ربط الأجهزة بعناوين IP</h3>"
        "<p>سطر لكل جهاز بالشكل: <code>IP=اسم الجهاز</code> مثال:<br><code>192.168.1.21=cobas e 411</code><br>"
        "<code>192.168.1.22=cobas pure</code><br><code>192.168.1.23=DxH 520</code></p>"
        "<p>الأسماء الموجودة حاليًا بـMapcodes: <b>{{ names|join(' ، ') or 'لا يوجد' }}</b></p>"
        "<form method='post'><textarea name='map' rows='6' style='width:100%;direction:ltr'>{{ cur }}</textarea><br>"
        "<button>حفظ</button> <a href='{{ url_for(\"host_interface\") }}'>رجوع</a></form></body>",
        cur=cur, names=names)


@app.route("/master/host-interface", methods=["GET", "POST"])
@designer_required
def host_interface():
    db = get_db()
    if request.method == "POST":
        enabled = "1" if request.form.get("enabled") else "0"
        ip = request.form.get("ip", "0.0.0.0").strip() or "0.0.0.0"
        port = request.form.get("port", "5000").strip() or "5000"
        set_setting(db, "host_listener_enabled", enabled)
        set_setting(db, "host_listener_ip", ip)
        set_setting(db, "host_listener_port", port)
        set_setting(db, "host_auto_send_to_reception", "1" if request.form.get("auto_send_to_reception") else "0")
        db.commit()
        flash(t(session.get("lang", "en"), "host_settings_saved"))
        return redirect(url_for("host_interface"))

    enabled = get_setting(db, "host_listener_enabled", "0") == "1"
    ip = get_setting(db, "host_listener_ip", "0.0.0.0")
    port = get_setting(db, "host_listener_port", "5000")
    auto_send = get_setting(db, "host_auto_send_to_reception", "0") == "1"
    logs = db.execute(
        "SELECT * FROM host_interface_log ORDER BY id DESC LIMIT 100"
    ).fetchall()
    return render_template("master/host_interface.html", enabled=enabled, ip=ip, port=port, logs=logs,
                           auto_send=auto_send)


@app.route("/master/host-interface/clear-log", methods=["POST"])
@designer_required
def clear_host_interface_log():
    db = get_db()
    db.execute("DELETE FROM host_interface_log")
    db.commit()
    return redirect(url_for("host_interface"))


@app.route("/master/quick-add-items", methods=["GET", "POST"])
@roles_required("supervisor")
def quick_add_items():
    db = get_db()
    if request.method == "POST":
        test_id = request.form.get("test_definition_id")
        exists = db.execute("SELECT id FROM quick_add_items WHERE test_definition_id=?", (test_id,)).fetchone()
        if not exists:
            db.execute("INSERT INTO quick_add_items (test_definition_id) VALUES (?)", (test_id,))
            db.commit()
            flash("Added to Quick Add.")
        return redirect(url_for("quick_add_items"))

    rows = db.execute(
        "SELECT q.id, td.name as test_name, td.department FROM quick_add_items q "
        "JOIN test_definitions td ON td.id = q.test_definition_id WHERE q.is_active=1 ORDER BY q.display_order"
    ).fetchall()
    all_tests = db.execute("SELECT * FROM test_definitions WHERE is_active=1 ORDER BY name").fetchall()
    return render_template("master/quick_add_items.html", rows=rows, all_tests=all_tests)


@app.route("/master/quick-add-items/<int:item_id>/remove", methods=["POST"])
@roles_required("supervisor")
def quick_add_item_remove(item_id):
    db = get_db()
    db.execute("UPDATE quick_add_items SET is_active=0 WHERE id=?", (item_id,))
    db.commit()
    flash("Removed from Quick Add.")
    return redirect(url_for("quick_add_items"))



@app.route("/master/reference-ranges", methods=["GET", "POST"])
@roles_required("supervisor")
def reference_ranges():
    db = get_db()
    if request.method == "POST":
        param_id = request.form.get("test_parameter_id")
        gender = request.form.get("gender") or "Both"
        age_from = request.form.get("age_from") or 0
        age_from_unit = request.form.get("age_from_unit") or "Years"
        age_to = request.form.get("age_to") or 120
        age_to_unit = request.form.get("age_to_unit") or "Years"
        low = request.form.get("low") or None
        high = request.form.get("high") or None
        range_text = request.form.get("range_text") or None
        # scope_type="patient" (المطلوب 5): patient_id يقفل هذي النسبة على
        # مريض واحد بالذات (حالة خاصة/علاج) — تتفوّق تلقائيًا على أي نسبة
        # عامة لنفس الباراميتر (راجع find_reference_range بـdatabase.py).
        # range_label اختياري، عرض فقط (مثلاً "مرضى الكورتيزون").
        scope_type = request.form.get("scope_type") or "all"
        patient_id = request.form.get("patient_id") or None if scope_type == "patient" else None
        range_label = request.form.get("range_label") or None
        # analyzer (المطلوب 6): اسم جهاز حر — فاضي يعني نسبة عامة بغض النظر
        # عن الجهاز.
        analyzer = request.form.get("analyzer") or None
        db.execute(
            "INSERT INTO reference_ranges (test_parameter_id, gender, age_from, age_from_unit, age_to, age_to_unit, "
            "low, high, range_text, patient_id, range_label, analyzer) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (param_id, gender, age_from, age_from_unit, age_to, age_to_unit, low, high, range_text,
             patient_id, range_label, analyzer),
        )
        db.commit()
        flash("Reference range added.")
        return redirect(url_for("reference_ranges"))

    ranges = db.execute(
        "SELECT rr.*, tp.name as param_name, td.name as test_name, p.full_name as patient_name "
        "FROM reference_ranges rr "
        "JOIN test_parameters tp ON tp.id = rr.test_parameter_id "
        "JOIN test_definitions td ON td.id = tp.test_definition_id "
        "LEFT JOIN patients p ON p.id = rr.patient_id "
        "ORDER BY td.name LIMIT 200"
    ).fetchall()
    parameters = db.execute(
        "SELECT tp.id, tp.name, tp.highlight, tp.unit, tp.unit2, tp.unit2_factor, td.name as test_name "
        "FROM test_parameters tp "
        "JOIN test_definitions td ON td.id = tp.test_definition_id ORDER BY td.name"
    ).fetchall()
    # تجميع الصفوف حسب الباراميتر — كل باراميتر يطلع كارد لحاله، وكل تيير
    # (حالة/طور فسيولوجي) داخل range_text يطلع صف عرض مستقل قابل للتحرير
    # لحاله عبر tier-save، بدل جدول مسطّح وحدة لكل الفحوصات مع بعض.
    param_meta = {p["id"]: p for p in parameters}
    groups_by_param = {}
    order = []
    for r in ranges:
        pid = r["test_parameter_id"]
        if pid not in groups_by_param:
            meta = param_meta.get(pid)
            groups_by_param[pid] = {
                "id": pid, "name": r["param_name"], "test_name": r["test_name"],
                "unit": meta["unit"] if meta else "", "highlight": meta["highlight"] if meta else 0,
                "unit2": meta["unit2"] if meta else "", "unit2_factor": meta["unit2_factor"] if meta else "",
                "rows": [],
            }
            order.append(pid)
        for tier in reference_range_tiers(r):
            groups_by_param[pid]["rows"].append({
                "range_id": r["id"], "gender": r["gender"],
                "age_from": r["age_from"], "age_from_unit": r["age_from_unit"],
                "age_to": r["age_to"], "age_to_unit": r["age_to_unit"],
                "label": tier["label"], "low": tier["low"], "high": tier["high"], "raw": tier["raw"],
                "patient_id": r["patient_id"], "patient_name": r["patient_name"],
                "range_label": r["range_label"], "analyzer": r["analyzer"],
            })
    parameter_groups = [groups_by_param[pid] for pid in order]
    all_test_definitions = db.execute(
        "SELECT id, name, department FROM test_definitions WHERE is_active=1 ORDER BY name"
    ).fetchall()
    return render_template("master/reference_ranges.html", parameter_groups=parameter_groups,
                            parameters=parameters, known_analyzers=get_known_analyzers(db),
                            known_units=get_known_units(db), all_test_definitions=all_test_definitions)


@app.route("/master/reference-ranges/tier-save", methods=["POST"])
@roles_required("supervisor")
def save_reference_range_tier():
    """يحفظ حالة/طور واحد (تيير) من كارد باراميتر بصفحة Reference Ranges —
    إمّا يعدّل تيير موجود (original_label يحدّد أيّه)، يضيف تيير جديد لصف
    جنس/فئة عمرية موجود أصلاً بدل ما يسوي صف مكرر، أو يسوي صف جديد كليًا لو
    ما فيه صف مطابق أصلاً."""
    db = get_db()
    range_id = request.form.get("range_id") or None
    test_parameter_id = request.form.get("test_parameter_id")
    original_label = request.form.get("original_label") or ""
    gender = request.form.get("gender") or "Both"
    age_from = request.form.get("age_from") or 0
    age_from_unit = request.form.get("age_from_unit") or "Years"
    age_to = request.form.get("age_to") or 120
    age_to_unit = request.form.get("age_to_unit") or "Years"
    label = (request.form.get("label") or "").strip() or None
    low_raw = request.form.get("low")
    high_raw = request.form.get("high")
    low = float(low_raw) if low_raw not in (None, "") else None
    high = float(high_raw) if high_raw not in (None, "") else None
    raw_text = (request.form.get("raw_text") or "").strip() or None
    if raw_text:
        low = high = None
    scope_type = request.form.get("scope_type") or "all"
    patient_id = (request.form.get("patient_id") or None) if scope_type == "patient" else None
    range_label = request.form.get("range_label") or None
    analyzer = request.form.get("analyzer") or None

    row = db.execute("SELECT * FROM reference_ranges WHERE id=?", (range_id,)).fetchone() if range_id else None
    if not row:
        row = db.execute(
            "SELECT * FROM reference_ranges WHERE test_parameter_id=? AND gender=? AND age_from=? "
            "AND age_from_unit=? AND age_to=? AND age_to_unit=? AND patient_id IS ?",
            (test_parameter_id, gender, age_from, age_from_unit, age_to, age_to_unit, patient_id),
        ).fetchone()

    tiers = reference_range_tiers(row) if row else []
    new_tier = {"label": label, "low": low, "high": high, "raw": raw_text}
    for i, tier in enumerate(tiers):
        if (tier["label"] or "") == original_label:
            tiers[i] = new_tier
            break
    else:
        tiers.append(new_tier)

    range_text, base_low, base_high = serialize_range_tiers(tiers)

    if row:
        db.execute(
            "UPDATE reference_ranges SET gender=?, age_from=?, age_from_unit=?, age_to=?, age_to_unit=?, "
            "low=?, high=?, range_text=?, patient_id=?, range_label=?, analyzer=? WHERE id=?",
            (gender, age_from, age_from_unit, age_to, age_to_unit, base_low, base_high, range_text,
             patient_id, range_label, analyzer, row["id"]),
        )
    else:
        db.execute(
            "INSERT INTO reference_ranges (test_parameter_id, gender, age_from, age_from_unit, age_to, age_to_unit, "
            "low, high, range_text, patient_id, range_label, analyzer) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (test_parameter_id, gender, age_from, age_from_unit, age_to, age_to_unit, base_low, base_high,
             range_text, patient_id, range_label, analyzer),
        )
    db.commit()
    flash("تم حفظ النسبة الطبيعية.")
    return redirect(url_for("reference_ranges"))


@app.route("/master/reference-ranges/tier-delete", methods=["POST"])
@roles_required("supervisor")
def delete_reference_range_tier():
    """يحذف حالة/طور واحد بس من صف — لو كان آخر تيير بالصف، يحذف الصف كله
    (نفس /master/reference-ranges/<id>/delete القديم) بدل ما يخلّي صف فاضي."""
    db = get_db()
    range_id = request.form.get("range_id")
    label = request.form.get("label") or ""
    row = db.execute("SELECT * FROM reference_ranges WHERE id=?", (range_id,)).fetchone()
    if row:
        remaining = [t for t in reference_range_tiers(row) if (t["label"] or "") != label]
        if not remaining:
            db.execute("DELETE FROM reference_ranges WHERE id=?", (range_id,))
        else:
            range_text, base_low, base_high = serialize_range_tiers(remaining)
            db.execute("UPDATE reference_ranges SET low=?, high=?, range_text=? WHERE id=?",
                       (base_low, base_high, range_text, range_id))
        db.commit()
    flash("تم الحذف.")
    return redirect(url_for("reference_ranges"))


@app.route("/master/reference-ranges/<int:range_id>/edit", methods=["POST"])
@roles_required("supervisor")
def update_reference_range(range_id):
    db = get_db()
    gender = request.form.get("gender") or "Both"
    age_from = request.form.get("age_from") or 0
    age_from_unit = request.form.get("age_from_unit") or "Years"
    age_to = request.form.get("age_to") or 120
    age_to_unit = request.form.get("age_to_unit") or "Years"
    low = request.form.get("low") or None
    high = request.form.get("high") or None
    range_text = request.form.get("range_text") or None
    scope_type = request.form.get("scope_type") or "all"
    patient_id = request.form.get("patient_id") or None if scope_type == "patient" else None
    range_label = request.form.get("range_label") or None
    analyzer = request.form.get("analyzer") or None
    db.execute(
        "UPDATE reference_ranges SET gender=?, age_from=?, age_from_unit=?, age_to=?, age_to_unit=?, low=?, high=?, "
        "range_text=?, patient_id=?, range_label=?, analyzer=? WHERE id=?",
        (gender, age_from, age_from_unit, age_to, age_to_unit, low, high, range_text,
         patient_id, range_label, analyzer, range_id),
    )
    db.commit()
    flash(t(session.get("lang", "en"), "range_updated"))
    return redirect(url_for("reference_ranges"))


@app.route("/master/reference-ranges/<int:range_id>/delete", methods=["POST"])
@roles_required("supervisor")
def delete_reference_range(range_id):
    db = get_db()
    db.execute("DELETE FROM reference_ranges WHERE id=?", (range_id,))
    db.commit()
    flash(t(session.get("lang", "en"), "range_deleted"))
    return redirect(url_for("reference_ranges"))


@app.route("/master/test-catalog/<int:test_id>/rename", methods=["POST"])
@roles_required("supervisor")
def rename_test_definition(test_id):
    """يعيد تسمية تحليل موجود — يُستخدم بالقلم ✏️ الجديد جنب كل تحليل
    بشاشة "زيارة جديدة" (تعديل سريع من نفس الصفحة، بدون فتح كتالوج
    التحاليل). لا يغيّر أي بارامتر تابع لهذا التحليل، فقط اسم التحليل
    نفسه (test_definitions.name)."""
    db = get_db()
    body = request.get_json(silent=True) or request.form
    new_name = (body.get("name") or "").strip()
    if not new_name:
        return {"ok": False, "error": "الاسم لا يمكن أن يكون فارغًا"}, 400
    row = db.execute("SELECT id FROM test_definitions WHERE id=?", (test_id,)).fetchone()
    if not row:
        return {"ok": False, "error": "التحليل غير موجود"}, 404
    db.execute("UPDATE test_definitions SET name=? WHERE id=?", (new_name, test_id))
    db.commit()
    log_action("RenameTest", "test_definitions", test_id, new_name)
    return {"ok": True, "name": new_name}


@app.route("/master/test-catalog/<int:test_id>/price", methods=["POST"])
@roles_required("supervisor")
def update_test_price(test_id):
    db = get_db()
    try:
        price = float(request.form.get("price") or request.json.get("price"))
    except (TypeError, ValueError):
        return {"ok": False, "error": "invalid price"}, 400
    db.execute("UPDATE test_definitions SET price=? WHERE id=?", (price, test_id))
    db.commit()
    return {"ok": True, "price": price}


@app.route("/master/test-catalog/<int:test_id>/toggle-examining", methods=["POST"])
@roles_required("supervisor")
def toggle_examining_test(test_id):
    db = get_db()
    row = db.execute("SELECT is_examining_test FROM test_definitions WHERE id=?", (test_id,)).fetchone()
    if not row:
        return {"ok": False}, 404
    new_val = 0 if row["is_examining_test"] else 1
    db.execute("UPDATE test_definitions SET is_examining_test=? WHERE id=?", (new_val, test_id))
    db.commit()
    return {"ok": True, "is_examining_test": new_val}


# اسم "الريبورت المجمّع" (report_group) اللي يظهر عنوانًا فرعيًا للوحة
# الطباعة المجمّعة (print_combined_panel) — فاضي يرجّع التحليل يعتمد على
# اسم القسم (department) العام كالمعتاد بدل عنوان مخصص.
@app.route("/master/test-catalog/<int:test_id>/report-group", methods=["POST"])
@roles_required("supervisor")
def update_test_report_group(test_id):
    db = get_db()
    value = (request.form.get("report_group") or "").strip()
    row = db.execute("SELECT id FROM test_definitions WHERE id=?", (test_id,)).fetchone()
    if not row:
        return {"ok": False}, 404
    db.execute("UPDATE test_definitions SET report_group=? WHERE id=?", (value, test_id))
    db.commit()
    return {"ok": True, "report_group": value}


@app.route("/master/test-catalog/<int:test_id>/field", methods=["POST"])
@roles_required("supervisor")
def update_test_field(test_id):
    """تعديل مباشر لعمود code/name/department/sample_type من نفس صفحة
    كتالوج التحاليل — قائمة بيضاء صارمة بالأعمدة المسموحة (allowed_fields)
    حتى ما يقدر أي طلب يعدّل عمود ثاني غير مقصود بهذا المسار."""
    db = get_db()
    field = (request.form.get("field") or "").strip()
    value = (request.form.get("value") or "").strip()
    allowed_fields = {"code", "name", "short_name", "department", "sample_type"}
    if field not in allowed_fields:
        return {"ok": False, "error": "حقل غير مسموح بتعديله من هنا"}, 400
    row = db.execute("SELECT id FROM test_definitions WHERE id=?", (test_id,)).fetchone()
    if not row:
        return {"ok": False, "error": "التحليل غير موجود"}, 404
    if field in ("code", "name") and not value:
        return {"ok": False, "error": "هذا الحقل لا يمكن أن يكون فارغًا"}, 400
    try:
        db.execute(f"UPDATE test_definitions SET {field}=? WHERE id=?", (value, test_id))
        db.commit()
    except Exception as e:
        # الأرجح تعارض قيد UNIQUE على code (كود مستخدم أصلاً لتحليل آخر).
        return {"ok": False, "error": "تعذّر الحفظ — على الأغلب هذا الكود مستخدم أصلاً لتحليل آخر"}, 400
    log_action("UpdateTestField", "test_definitions", test_id, f"{field}={value}")
    return {"ok": True, "field": field, "value": value}


@app.route("/master/test-parameters/<int:param_id>/toggle-highlight", methods=["POST"])
@roles_required("supervisor")
def toggle_parameter_highlight(param_id):
    # Yellow-shading a result on the printed report is a manual, per-parameter
    # choice the admin makes here — nothing is highlighted automatically.
    db = get_db()
    row = db.execute("SELECT highlight FROM test_parameters WHERE id=?", (param_id,)).fetchone()
    if not row:
        return {"ok": False}, 404
    new_val = 0 if row["highlight"] else 1
    db.execute("UPDATE test_parameters SET highlight=? WHERE id=?", (new_val, param_id))
    db.commit()
    return {"ok": True, "highlight": new_val}


# ------------------------------------------------------------------------
# أداة "تعديل وحدة القياس" — تسمح للمشرف/الأدمن يغيّر وحدة أي معيار
# (test_parameter) مباشرة (مثل NRBC، أو أي معيار يحتاج تغيير وحدته لاحقًا)
# دون لمس قاعدة البيانات يدويًا. لو التغيير يمثّل تحويل قياس فعلي (مو مجرد
# إعادة تسمية)، تقدر تعطيها معامل تحويل (factor) واتجاه (ضرب/قسمة) فتتحول
# كل المدايات المرجعية (reference_ranges) المرتبطة بهذا المعيار تلقائيًا
# بنفس المعامل والاتجاه، حتى تبقى متوافقة مع الوحدة الجديدة. لإعادة تسمية
# بدون أي تغيير بالأرقام (مثل NRBC من "100/wbc" إلى "/100WBC")، اترك
# المعامل = 1.
# ------------------------------------------------------------------------
@app.route("/master/unit-converter", methods=["GET"])
@roles_required("supervisor")
def unit_converter():
    db = get_db()
    # شيلنا فلتر "result_type = 'Numeric'" — أي باراميتر بأي تحليل يظهر
    # هنا الحين، مو بس الرقمية، حتى تقدر تعدّل وحدة أي شي بالبرنامج من
    # نفس هذي الصفحة.
    parameters = db.execute(
        "SELECT tp.id, tp.name, tp.unit, tp.unit2, tp.unit2_factor, td.name as test_name, td.department "
        "FROM test_parameters tp JOIN test_definitions td ON td.id = tp.test_definition_id "
        "ORDER BY td.department, td.name, tp.name"
    ).fetchall()
    return render_template("master/unit_converter.html", parameters=parameters)


# ------------------------------------------------------------------------
# تعديل مباشر وبسيط للوحدة — تكتب النص وتضغط حفظ وخلاص، بدون أي معامل
# تحويل أو اتجاه (بعكس "تغيير/تحويل الوحدة الأساسية" تحت، اللي مصمم
# لعملية تحويل رقمية فعلية تلمس المديات المرجعية معها). هذا الخيار
# للحالة الشائعة: بس تبي تغيّر/تصلّح نص الوحدة نفسه (مثال: NRBC من
# "100/wbc" إلى "/100wbc") بدون لمس أي رقم ثاني إطلاقاً.
# ------------------------------------------------------------------------
# ------------------------------------------------------------------------
# تعبئة وحدات SI تلقائيًا: جدول تحويلات قياسية معروفة (غلوكوز mg/dL -> mmol/L، كرياتينين -> µmol/L ...).
# لا يغيّر الوحدة الأساسية ولا المديات، ولا يمسح/يبدّل أي وحدة ثانية موجودة أصلاً (يعبّي الفاضي فقط).
# تُطبَّق فقط لو اسم الباراميتر والوحدة الأساسية الحالية يطابقان الجدول حرفيًا (احتياطًا من تحويل خاطئ).
# بدون معامل: HbA1c (% -> mmol/mol) لأن تحويله معادلة (×10.929 − 23.5) وليس معامل ضرب فقط.
# ------------------------------------------------------------------------
_AUTO_SI_RULES = [
    # (regex لاسم الباراميتر, الوحدات الأساسية المقبولة (مطبَّعة), الوحدة الثانية, المعامل)
    (r"triglycerid|\btg\b|\btag\b", ("mg/dl",), "mmol/L", 0.01129),
    (r"cholesterol|\bhdl\b|\bldl\b|\bvldl\b", ("mg/dl",), "mmol/L", 0.02586),
    (r"glucose|\bfbs\b|\brbs\b|\bppbs\b|\b2hpp\b|blood sugar", ("mg/dl",), "mmol/L", 0.0555),
    (r"\bbun\b|urea nitrogen", ("mg/dl",), "mmol/L", 0.357),
    (r"\burea\b|blood urea", ("mg/dl",), "mmol/L", 0.1665),
    (r"creatinine", ("mg/dl",), "µmol/L", 88.4),
    (r"uric", ("mg/dl",), "µmol/L", 59.48),
    (r"bilirubin", ("mg/dl",), "µmol/L", 17.1),
    (r"calcium", ("mg/dl",), "mmol/L", 0.2495),
    (r"phosph", ("mg/dl",), "mmol/L", 0.3229),
    (r"magnesium", ("mg/dl",), "mmol/L", 0.4114),
    (r"albumin|total protein|globulin", ("g/dl",), "g/L", 10),
    (r"\biron\b|serum iron", ("ug/dl",), "µmol/L", 0.1791),
    (r"vitamin ?d|25.?oh", ("ng/ml",), "nmol/L", 2.496),
    (r"b ?12|cobalamin", ("pg/ml",), "pmol/L", 0.738),
    (r"folate|folic", ("ng/ml",), "nmol/L", 2.266),
    (r"cortisol", ("ug/dl",), "nmol/L", 27.59),
    (r"insulin", ("uiu/ml", "miu/l"), "pmol/L", 6.945),
]


def _norm_unit(u):
    return re.sub(r"\s+", "", str(u or "").lower().replace("µ", "u").replace("μ", "u"))


def _auto_si_candidates(db):
    rows = db.execute(
        "SELECT tp.id, tp.name, tp.unit, td.name AS test_name FROM test_parameters tp "
        "JOIN test_definitions td ON td.id = tp.test_definition_id "
        "WHERE (tp.unit2 IS NULL OR TRIM(tp.unit2) = '') AND tp.unit IS NOT NULL AND TRIM(tp.unit) <> '' "
        "ORDER BY td.department, td.name, tp.name"
    ).fetchall()
    out = []
    for r in rows:
        nm = (r["name"] or "").lower()
        un = _norm_unit(r["unit"])
        for rx, units, unit2, factor in _AUTO_SI_RULES:
            if re.search(rx, nm) and un in units:
                out.append({"id": r["id"], "test": r["test_name"], "name": r["name"], "unit": r["unit"],
                            "unit2": unit2, "factor": factor})
                break
    return out


@app.route("/master/unit-converter/auto-si", methods=["GET", "POST"])
@roles_required("supervisor")
def unit_converter_auto_si():
    db = get_db()
    cands = _auto_si_candidates(db)
    if request.method == "POST":
        picked = set(request.form.getlist("pid"))
        n = 0
        for c in cands:
            if str(c["id"]) in picked:
                db.execute("UPDATE test_parameters SET unit2=?, unit2_factor=? WHERE id=? AND (unit2 IS NULL OR TRIM(unit2)='')",
                           (c["unit2"], c["factor"], c["id"]))
                log_action("SetDualUnit", "test_parameter", c["id"], f"auto: {c['unit']} -> {c['unit2']} (x{c['factor']})")
                n += 1
        db.commit()
        flash(f"تمت تعبئة وحدة SI تلقائيًا لـ {n} باراميتر.")
        return redirect(url_for("unit_converter_auto_si"))
    from flask import render_template_string as _rts
    tpl = """{% extends "base.html" %}
{% block page_title %}وحدات SI تلقائية{% endblock %}
{% block content %}
<div class="card" dir="rtl">
  <h3>🌐 تعبئة وحدات SI تلقائيًا</h3>
  <p class="muted">التحاليل التالية لها تحويل SI قياسي معروف ولسا ما عندها وحدة ثانية. اختر ما تريد ثم "تطبيق" —
  لا يتغيّر شي من الوحدة الأساسية ولا المديات، ولا يُستبدل أي إعداد موجود. تقدر تعدّل أي معامل لاحقًا من صفحة تعديل الوحدات.
  راجع المعاملات قبل التطبيق. (HbA1c: تحويله لـ mmol/mol معادلة وليس معامل ضرب، فلا يدخل هنا.)</p>
  {% if cands %}
  <form method="POST">
    <table>
      <thead><tr><th><input type="checkbox" checked onclick="document.querySelectorAll('.pidchk').forEach(function(c){c.checked=this.checked}.bind(this))"></th>
        <th>التحليل</th><th>الباراميتر</th><th>الوحدة الحالية</th><th>وحدة SI</th><th>المعامل (×)</th><th>مثال</th></tr></thead>
      <tbody>
      {% for c in cands %}
      <tr><td><input class="pidchk" type="checkbox" name="pid" value="{{ c.id }}" checked></td>
        <td>{{ c.test }}</td><td>{{ c.name }}</td><td class="mono">{{ c.unit }}</td>
        <td class="mono">{{ c.unit2 }}</td><td class="mono">{{ c.factor }}</td>
        <td class="mono">100 {{ c.unit }} = {{ (100 * c.factor)|round(3) }} {{ c.unit2 }}</td></tr>
      {% endfor %}
      </tbody>
    </table>
    <button class="btn" type="submit" style="margin-top:10px;">✅ تطبيق على المحدد</button>
    <a class="btn secondary" href="{{ url_for('unit_converter') }}">رجوع</a>
  </form>
  {% else %}
  <p>لا يوجد تحاليل جديدة تنطبق عليها القائمة (إما مضبوطة مسبقًا أو وحدتها الحالية مختلفة).</p>
  <a class="btn secondary" href="{{ url_for('unit_converter') }}">رجوع</a>
  {% endif %}
</div>
{% endblock %}"""
    db.close()
    return _rts(tpl, cands=cands)


@app.route("/master/unit-converter/<int:param_id>/set-unit", methods=["POST"])
@roles_required("supervisor")
def unit_converter_set_unit(param_id):
    db = get_db()
    param = db.execute("SELECT * FROM test_parameters WHERE id=?", (param_id,)).fetchone()
    if not param:
        if request.form.get("ajax"):
            return {"ok": False, "error": "المعيار غير موجود."}, 404
        flash("المعيار غير موجود.")
        return redirect(url_for("unit_converter"))
    new_unit = request.form.get("unit", "").strip()
    db.execute("UPDATE test_parameters SET unit=? WHERE id=?", (new_unit, param_id))
    db.commit()
    # ajax=1: يُرسَل فقط من محرّر الوحدة المصغّر بصفحة النسب الطبيعية
    # (reference_ranges.html) — يرجّع JSON بدل صفحة كاملة، بدون أي تأثير
    # على استخدام صفحة "تعديل الوحدات" الأصلية (نموذج عادي، بلا ajax=1).
    if request.form.get("ajax"):
        return {"ok": True, "unit": new_unit}
    flash(f"تم تحديث وحدة {param['name']} إلى \"{new_unit}\"." if new_unit else f"تم إفراغ وحدة {param['name']}.")
    return redirect(url_for("unit_converter"))


# ------------------------------------------------------------------------
# الوحدة الثانية الدائمة لعرض النتيجة بوحدتين بنفس الوقت وقت الطباعة
# (مثلاً mg/dL و mmol/L لنفس الباراميتر) — بخلاف "تحويل الوحدة" أعلاه اللي
# يغيّر الوحدة الأساسية مرة وحدة ويحوّل المديات المرجعية معها، هذا الإعداد
# دائم ولا يلمس الوحدة الأساسية ولا المديات المرجعية إطلاقًا: فقط يضيف قيمة
# محسوبة تلقائيًا (value2 = value1 × factor) تُطبع جنب النتيجة الأصلية.
# اترك حقل "الوحدة الثانية" فاضي لإلغاء/تعطيل الوحدة الثانية لهذا الباراميتر.
# ------------------------------------------------------------------------
@app.route("/master/unit-converter/<int:param_id>/set-dual-unit", methods=["POST"])
@roles_required("supervisor")
def unit_converter_set_dual(param_id):
    db = get_db()
    param = db.execute("SELECT * FROM test_parameters WHERE id=?", (param_id,)).fetchone()
    is_ajax = bool(request.form.get("ajax"))
    if not param:
        if is_ajax:
            return {"ok": False, "error": "المعيار غير موجود."}, 404
        flash("المعيار غير موجود.")
        return redirect(url_for("unit_converter"))

    unit2 = (request.form.get("unit2") or "").strip()
    if not unit2:
        db.execute("UPDATE test_parameters SET unit2=NULL, unit2_factor=NULL WHERE id=?", (param_id,))
        db.commit()
        log_action("SetDualUnit", "test_parameter", param_id, "cleared")
        if is_ajax:
            return {"ok": True, "unit2": None, "unit2_factor": None}
        flash(f"تم إلغاء الوحدة الثانية لـ \"{param['name']}\".")
        return redirect(url_for("unit_converter"))

    factor_raw = (request.form.get("unit2_factor") or "").strip()
    try:
        factor = float(factor_raw)
        if factor <= 0:
            raise ValueError
    except ValueError:
        if is_ajax:
            return {"ok": False, "error": "معامل التحويل يجب أن يكون رقمًا أكبر من صفر."}, 400
        flash("معامل التحويل للوحدة الثانية يجب أن يكون رقمًا أكبر من صفر.")
        return redirect(url_for("unit_converter"))

    db.execute("UPDATE test_parameters SET unit2=?, unit2_factor=? WHERE id=?", (unit2, factor, param_id))
    db.commit()
    log_action("SetDualUnit", "test_parameter", param_id, f"{param['unit']} -> {unit2} (x{factor})")
    if is_ajax:
        return {"ok": True, "unit2": unit2, "unit2_factor": factor}
    flash(f"تم حفظ الوحدة الثانية لـ \"{param['name']}\": {unit2} (يُحسب تلقائيًا = القيمة × {factor}).")
    return redirect(url_for("unit_converter"))


@app.route("/master/unit-converter/<int:param_id>/apply", methods=["POST"])
@roles_required("supervisor")
def unit_converter_apply(param_id):
    db = get_db()
    param = db.execute("SELECT * FROM test_parameters WHERE id=?", (param_id,)).fetchone()
    if not param:
        flash("المعيار غير موجود.")
        return redirect(url_for("unit_converter"))

    new_unit = (request.form.get("new_unit") or "").strip()
    direction = request.form.get("direction", "multiply")
    try:
        factor = float(request.form.get("factor") or 1)
    except ValueError:
        factor = 1.0
    if factor <= 0:
        flash("معامل التحويل يجب أن يكون رقمًا أكبر من صفر.")
        return redirect(url_for("unit_converter"))

    old_unit = param["unit"]
    ranges = db.execute("SELECT id, low, high FROM reference_ranges WHERE test_parameter_id=?", (param_id,)).fetchall()
    for r in ranges:
        new_low = r["low"]
        new_high = r["high"]
        if direction == "divide":
            if new_low is not None:
                new_low = new_low / factor
            if new_high is not None:
                new_high = new_high / factor
        else:
            if new_low is not None:
                new_low = new_low * factor
            if new_high is not None:
                new_high = new_high * factor
        db.execute("UPDATE reference_ranges SET low=?, high=? WHERE id=?", (new_low, new_high, r["id"]))

    if new_unit:
        db.execute("UPDATE test_parameters SET unit=? WHERE id=?", (new_unit, param_id))

    db.commit()
    log_action(
        "UnitConvert", "test_parameter", param_id,
        f"{old_unit!r} -> {new_unit!r} ({direction} x{factor}, {len(ranges)} ranges updated)",
    )
    flash(f"تم تحديث وحدة \"{param['name']}\" وتحويل {len(ranges)} مدى مرجعي.")
    return redirect(url_for("unit_converter"))



# تصنيف تلقائي لحقل "الريبورت المجمّع" (report_group) — يطابق اسم كل
# تحليل مع كلمات مفتاحية شائعة تحدد أي من المجاميع الثابتة الخمس ينتمي
# لها، حتى تصير كل تحاليل "سكر/دهون/سكر تراكمي/وظائف كلى/وظائف كبد/
# كالسيوم/مغنيسيوم/إلكترولايت" تحت "Biochemistry Tests" مجتمعة، وهكذا
# لبقية المجاميع — بدل ما الأدمن يدخل كل تحليل لحاله يدويًا. لا تلمس أي
# تحليل مصنّف يدويًا من قبل (report_group غير فاضي) إطلاقًا، حتى لا تلغي
# أي تخصيص سابق.
FIXED_REPORT_GROUPS = [
    "Biochemistry Tests", "Hormones Tests", "Vitamins Tests",
    "Virology Screening", "Tumor Marker",
]

_REPORT_GROUP_KEYWORDS = [
    ("Tumor Marker", [
        "cea", "afp", "psa", "ca125", "ca 125", "ca19-9", "ca 19-9", "ca15-3",
        "ca 15-3", "beta-hcg", "b-hcg", "tumor marker", "tumour marker",
    ]),
    ("Virology Screening", [
        "hbsag", "hbsab", "anti-hbs", "anti-hcv", "hcv", "hiv", "hbcab",
        "rubella", "toxoplasma", "cmv", "ebv", "vdrl", "tpha", "hepatitis",
        "measles", "mumps", "varicella", "widal", "brucella",
    ]),
    ("Vitamins Tests", ["vitamin", "folate", "folic acid", "b12"]),
    ("Hormones Tests", [
        "tsh", " t3", " t4", "ft3", "ft4", "fsh", " lh", "prolactin",
        "cortisol", "testosterone", "estrogen", "estradiol", "progesterone",
        "insulin", "pth", "parathyroid", "growth hormone", " gh ", "acth", "dhea",
    ]),
    ("Biochemistry Tests", [
        "fbs", "glucose", "sugar", "rbs", "hba1c", "glycated", "lipid",
        "cholesterol", "triglyceride", "hdl", "ldl", "vldl", "urea",
        "creatinine", "uric acid", "bun", "kidney", "renal", " alt", " ast",
        " alp", "sgot", "sgpt", "bilirubin", "albumin", "total protein",
        "liver", "ggt", "calcium", "magnesium", "phosphorus", "phosphate",
        "sodium", "potassium", "chloride", "electrolyte", "amylase",
        "lipase", "ferritin", "tibc", "crp", "esr", "ldh",
    ]),
]


def _guess_report_group(test_name):
    name = f" {(test_name or '').strip().lower()} "
    for group, keywords in _REPORT_GROUP_KEYWORDS:
        for kw in keywords:
            if kw in name:
                return group
    return None


@app.route("/master/test-catalog/auto-assign-report-groups", methods=["POST"])
@roles_required("supervisor")
def auto_assign_report_groups():
    """يعبّي report_group تلقائيًا لكل تحليل ماله تصنيف بعد (لا يلمس أي
    تحليل مصنّف يدويًا من قبل) بمطابقة اسمه مع الكلمات المفتاحية فوق.
    يرجّع JSON بعدد التحاليل المصنَّفة، وأسماء أي تحاليل ما انطابقت مع أي
    كلمة (تحتاج تصنيف يدوي من الأدمن)."""
    db = get_db()
    tests = db.execute(
        "SELECT id, name FROM test_definitions WHERE report_group IS NULL OR TRIM(report_group)=''"
    ).fetchall()
    updated = 0
    unmatched = []
    for t in tests:
        group = _guess_report_group(t["name"])
        if group:
            db.execute("UPDATE test_definitions SET report_group=? WHERE id=?", (group, t["id"]))
            updated += 1
        else:
            unmatched.append(t["name"])
    db.commit()
    return jsonify({"ok": True, "updated": updated, "unmatched": unmatched})


@app.route("/master/test-catalog", methods=["GET", "POST"])
@roles_required("supervisor")
def test_catalog():
    db = get_db()
    if request.method == "POST":
        code = request.form.get("code", "").strip()
        name = request.form.get("name", "").strip()
        short_name = request.form.get("short_name", "").strip()
        department = request.form.get("department", "").strip()
        report_group = request.form.get("report_group", "").strip()
        sample_type = request.form.get("sample_type", "").strip()
        price = float(request.form.get("price") or 0)
        is_examining_test = 1 if request.form.get("is_examining_test") else 0
        params_raw = request.form.get("parameters", "").strip()

        cur = db.execute(
            "INSERT INTO test_definitions (code, name, short_name, department, report_group, sample_type, price, is_examining_test) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (code, name, short_name, department, report_group, sample_type, price, is_examining_test),
        )
        test_id = cur.lastrowid
        for chunk in params_raw.split(","):
            chunk = chunk.strip()
            if not chunk:
                continue
            if "unit:" in chunk:
                pname, unit = chunk.split("unit:")
                pname, unit = pname.strip(), unit.strip()
            else:
                pname, unit = chunk, ""
            db.execute(
                "INSERT INTO test_parameters (test_definition_id, name, unit, result_type) "
                "VALUES (?, ?, ?, 'Numeric')",
                (test_id, pname, unit),
            )
        db.commit()
        flash("Test added to catalog.")
        return redirect(url_for("test_catalog"))

    tests = db.execute("SELECT * FROM test_definitions ORDER BY department, name").fetchall()
    # أسماء "الريبورت المجمّع" المستخدمة أصلاً بأي تحليل — تُعرض كاقتراحات
    # بحقل الإدخال (datalist) حتى يعيد الأدمن استخدام نفس الاسم بالضبط بدل
    # ما يكتبه بصيغة مختلفة شوي فينفصل عن مجموعته بالخطأ (مثلاً "Viral
    # study" مرة و"Viral Study" مرة ثانية تصيران مجموعتين منفصلتين).
    report_groups = sorted(set(FIXED_REPORT_GROUPS) | {
        row["report_group"].strip() for row in tests if row["report_group"] and row["report_group"].strip()
    })
    return render_template("master/test_catalog.html", tests=tests, report_groups=report_groups)


# ------------------------------------------------------------ parameter order
# ترتيب باراميترات أي تحليل (بشاشة إدخال النتائج وبالتقرير المطبوع) —
# صفحة مستقلة عامة لأي تحليل (مو خاصة بس بتحاليل الـdifferential)، لأن
# ترتيب الباراميترات بقاعدة البيانات بيّن (test_parameters.sort_order)
# وما كان فيه شاشة تتحكم فيه سابقًا — كانت تعتمد على ترتيب id (الإدخال).
@app.route("/master/parameter-order", methods=["GET", "POST"])
@roles_required("supervisor")
def parameter_order():
    db = get_db()
    if request.method == "POST":
        test_id = request.form.get("test_id")
        param_ids = request.form.getlist("param_id")
        orders = request.form.getlist("order")
        for pid, order in zip(param_ids, orders):
            try:
                order_val = int(order)
            except (TypeError, ValueError):
                order_val = 0
            db.execute("UPDATE test_parameters SET sort_order=? WHERE id=?", (order_val, pid))
        db.commit()
        flash("تم حفظ ترتيب الباراميترات.")
        return redirect(url_for("parameter_order", test_id=test_id))

    tests = db.execute(
        "SELECT DISTINCT td.id, td.name, td.code FROM test_definitions td "
        "JOIN test_parameters tp ON tp.test_definition_id = td.id "
        "ORDER BY td.name"
    ).fetchall()

    selected_id = request.args.get("test_id", type=int)
    if not selected_id and tests:
        selected_id = tests[0]["id"]

    parameters = []
    if selected_id:
        parameters = db.execute(
            "SELECT * FROM test_parameters WHERE test_definition_id=? ORDER BY sort_order, id",
            (selected_id,),
        ).fetchall()

    return render_template("master/parameter_order.html", tests=tests, parameters=parameters, selected_id=selected_id)


def unique_test_code(db, name):
    """يولّد رمزًا فريدًا للتحليل من اسمه الإنكليزي عند الإضافة السريعة من
    قسم الطلبات (بدون الحاجة لإدخال رمز يدويًا)."""
    base = re.sub(r"[^A-Za-z0-9]+", "", name).upper()[:12] or "TEST"
    code = base
    n = 1
    while db.execute("SELECT 1 FROM test_definitions WHERE code=?", (code,)).fetchone():
        n += 1
        code = f"{base}{n}"
    return code


# إضافة/تعديل/إخفاء تحليل بسرعة من داخل نفس نافذة "قسم الطلبات" بشاشتي
# "زيارة جديدة" و"تعديل الزيارة" — دون مغادرة الصفحة أو فقدان بيانات الزيارة
# التي بدأ المستخدم بتعبئتها (لهذا الاستجابة JSON وليس إعادة توجيه صفحة).
@app.route("/api/tests/quick-add", methods=["POST"])
@roles_required("supervisor")
def api_quick_add_test():
    db = get_db()
    name = (request.form.get("name") or "").strip()
    department = (request.form.get("department") or "").strip()
    if not name:
        return jsonify({"error": "الاسم مطلوب"}), 400
    code = unique_test_code(db, name)
    cur = db.execute(
        "INSERT INTO test_definitions (code, name, department, sample_type, price, is_active, is_examining_test) "
        "VALUES (?, ?, ?, '', 0, 1, 0)",
        (code, name, department),
    )
    db.commit()
    log_action("QuickAddTest", "test_definition", cur.lastrowid, name)
    return jsonify({"id": cur.lastrowid, "name": name, "department": department, "code": code})

@app.route("/api/tests/quick-add-with-price", methods=["POST"])
@login_required
def api_quick_add_test_with_price():
    """يسمح لأي مستخدم مسجّل دخول (مو بس admin/supervisor) بإضافة تحليل غير
    موجود بالقائمة مباشرة أثناء إنشاء زيارة جديدة، مع تحديد سعره فورًا —
    يبقى هذا التحليل محفوظًا بالكتالوج بشكل دائم لأي زيارة قادمة. لو التحليل
    موجود مسبقًا بنفس الاسم، نرجع بياناته الحالية بدل ما ننشئ نسخة مكررة."""
    db = get_db()
    name = (request.form.get("name") or "").strip()
    try:
        price = float(request.form.get("price") or 0)
    except ValueError:
        price = 0
    if not name:
        return jsonify({"error": "اسم التحليل مطلوب"}), 400
    if price < 0:
        return jsonify({"error": "السعر يجب أن يكون رقمًا موجبًا"}), 400
    existing = db.execute(
        "SELECT id, price FROM test_definitions WHERE LOWER(TRIM(name))=LOWER(TRIM(?))", (name,)
    ).fetchone()
    if existing:
        return jsonify({"id": existing["id"], "name": name, "price": existing["price"], "existed": True})
    code = unique_test_code(db, name)
    cur = db.execute(
        "INSERT INTO test_definitions (code, name, department, sample_type, price, is_active, is_examining_test) "
        "VALUES (?, ?, '', '', ?, 1, 0)",
        (code, name, price),
    )
    db.commit()
    log_action("QuickAddTestWithPrice", "test_definition", cur.lastrowid, f"{name} ({price})")
    return jsonify({"id": cur.lastrowid, "name": name, "price": price, "existed": False})

# إضافة تحليل غير موجود بالقائمة مباشرة من قسم "الطلبات" بشاشة "زيارة
# جديدة" — متاحة لأي مستخدم مسجّل دخول (وليس فقط admin/supervisor مثل
# نافذة "إدارة التحاليل" وراوت /api/tests/quick-add أعلاه)، لأن موظف
# الاستقبال هو من يواجه هذا الموقف يوميًا (مريض طلب تحليل غير مُدرج بعد).
# يُطلب السعر إجباريًا هنا (بعكس /api/tests/quick-add اللي يحفظه 0 مؤقتًا
# بانتظار أن يعدّله المدير لاحقًا من كتالوج التحاليل) حتى يدخل التحليل
# فورًا بجدول الفاتورة/المجموع بسعره الصحيح دون انتظار أحد.
@app.route("/api/tests/quick-add-priced", methods=["POST"])
@login_required
def api_quick_add_test_priced():
    db = get_db()
    name = (request.form.get("name") or "").strip()
    price_raw = (request.form.get("price") or "").strip()
    if not name:
        return jsonify({"error": "الاسم مطلوب"}), 400
    try:
        price = float(price_raw)
        if price < 0:
            raise ValueError
    except ValueError:
        return jsonify({"error": "السعر يجب أن يكون رقمًا (0 أو أكثر)"}), 400
    code = unique_test_code(db, name)
    cur = db.execute(
        "INSERT INTO test_definitions (code, name, department, sample_type, price, is_active, is_examining_test) "
        "VALUES (?, ?, '', '', ?, 1, 0)",
        (code, name, price),
    )
    db.commit()
    log_action("QuickAddTestPriced", "test_definition", cur.lastrowid, f"{name} ({price})")
    return jsonify({"id": cur.lastrowid, "name": name, "price": price, "code": code})


# إضافة اسم طبيب فاحص جديد بسرعة من نفس شاشة "زيارة جديدة" (القائمتين
# "دكتور المختبر الفاحص" و"الدكتور الفاحص") — يُحفظ بنفس قائمة الإعدادات
# التي يديرها المدير من Management → Settings، فيظهر لاحقًا هناك أيضًا.
@app.route("/api/examining-doctors/quick-add", methods=["POST"])
@login_required
def api_quick_add_examining_doctor():
    db = get_db()
    name = (request.form.get("name") or "").strip()
    if not name:
        return jsonify({"error": "الاسم مطلوب"}), 400
    add_examining_doctor(db, name)
    log_action("QuickAddExaminingDoctor", "settings", 0, name)
    return jsonify({"name": name})


@app.route("/api/tests/<int:test_id>/quick-edit", methods=["POST"])
@roles_required("supervisor")
def api_quick_edit_test(test_id):
    db = get_db()
    name = (request.form.get("name") or "").strip()
    department = (request.form.get("department") or "").strip()
    if not name:
        return jsonify({"error": "الاسم مطلوب"}), 400
    test = db.execute("SELECT id FROM test_definitions WHERE id=?", (test_id,)).fetchone()
    if not test:
        return jsonify({"error": "not found"}), 404
    db.execute("UPDATE test_definitions SET name=?, department=? WHERE id=?", (name, department, test_id))
    db.commit()
    log_action("QuickEditTest", "test_definition", test_id, name)
    return jsonify({"id": test_id, "name": name, "department": department})


@app.route("/api/tests/<int:test_id>/quick-hide", methods=["POST"])
@roles_required("supervisor")
def api_quick_hide_test(test_id):
    db = get_db()
    test = db.execute("SELECT id, is_active FROM test_definitions WHERE id=?", (test_id,)).fetchone()
    if not test:
        return jsonify({"error": "not found"}), 404
    new_val = 0 if test["is_active"] else 1
    db.execute("UPDATE test_definitions SET is_active=? WHERE id=?", (new_val, test_id))
    db.commit()
    log_action("QuickToggleTestActive", "test_definition", test_id, str(new_val))
    return jsonify({"id": test_id, "is_active": new_val})


@app.route("/api/tests/active-list")
@roles_required("supervisor")
def api_tests_active_list():
    db = get_db()
    tests = db.execute(
        "SELECT id, name, department, is_active FROM test_definitions WHERE is_active=1 ORDER BY department, name"
    ).fetchall()
    return jsonify([dict(t) for t in tests])



# --------------------------------------------------------------- management
def _report_designs_context(db):
    """بيانات لوحة اختيار التصاميم (تخثر 1..4 + GUE/GSE/SFA 1..4) المدمجة داخل صفحة مصمم التقارير."""
    ids = {}
    for key, code in (("coag", "COAG"), ("gue", "GUE"), ("gse", "GSE"), ("sfa", "SFA")):
        r = db.execute("SELECT id FROM test_definitions WHERE code=?", (code,)).fetchone()
        ids[key] = r["id"] if r else None
    cur = {fam: get_setting(db, f"report_design_{fam}", "table" if fam == "coag" else "1") for fam in ("coag", "exam")}
    return {"design_ids": ids, "design_cur": cur}


@app.route("/management/report-designs", methods=["GET", "POST"])
@roles_required("admin")
def report_designs():
    """حفظ التصميم المختار (1..4) لطباعة التخثر ولتقارير GUE/GSE/SFA. اللوحة نفسها صارت داخل صفحة
    \"مصمم التقارير\" (بطاقة التصاميم)؛ هذا المسار يبقى لحفظ الاختيار ولا يفتح صفحة منفصلة."""
    db = get_db()
    if request.method == "POST":
        for fam in ("coag", "exam"):
            v = request.form.get(fam, "")
            if v in ("1", "2", "3", "4") or (fam == "coag" and v == "table"):
                set_setting(db, f"report_design_{fam}", v)
        if "exam_abnormal_present" in request.form:
            set_setting(db, "exam_abnormal_red", "1" if request.form.get("exam_abnormal_red") else "0")
        db.commit()
        flash("تم حفظ التصاميم المختارة.")
    return redirect(url_for("report_designer") + "#designs")


@app.route("/management/dashboard-look", methods=["GET", "POST"])
@roles_required("admin")
def dashboard_look():
    """مظهر الشاشة الرئيسية لكل واجهة على حدة (استقبال / مختبر / الاثنين معًا):
    صورة الخلفية، التعتيم، الضبابية، الموضع، الحجم، ولون الواجهة وخلفية الصفحات.
    أي حقل يُترك بدون قيمة لواجهة معيّنة يرث الإعداد العام من صفحة الإعدادات."""
    db = get_db()
    if request.method == "POST":
        iface = request.form.get("iface", "")
        if iface not in DASH_INTERFACES:
            flash("واجهة غير صالحة.")
            return redirect(url_for("dashboard_look"))
        def key(k):
            return f"{k}__{iface}"

        if request.form.get("action") == "reset":
            old_path = get_setting(db, key("dashboard_bg_path"), "")
            if old_path and old_path != "-":
                full = os.path.join(UPLOAD_DIR, os.path.basename(old_path))
                if os.path.exists(full):
                    os.remove(full)
            for k in DASH_LOOK_KEYS:
                set_setting(db, key(k), "")
            db.commit()
            flash(f"تمت إعادة واجهة {DASH_INTERFACE_LABELS[iface]} للإعدادات العامة.")
            return redirect(url_for("dashboard_look", tab=iface))

        # صورة الخلفية: رفع جديد / بدون صورة / وراثة العام
        img_mode = request.form.get("bg_mode", "keep")
        if img_mode == "inherit":
            old_path = get_setting(db, key("dashboard_bg_path"), "")
            if old_path and old_path != "-":
                full = os.path.join(UPLOAD_DIR, os.path.basename(old_path))
                if os.path.exists(full):
                    os.remove(full)
            set_setting(db, key("dashboard_bg_path"), "")
        elif img_mode == "none":
            set_setting(db, key("dashboard_bg_path"), "-")
        bg_file = request.files.get("bg_file")
        if bg_file and bg_file.filename:
            ext = bg_file.filename.rsplit(".", 1)[-1].lower() if "." in bg_file.filename else ""
            if ext in ALLOWED_DASHBOARD_BG_EXT:
                for old_ext in ALLOWED_DASHBOARD_BG_EXT:
                    old_f = os.path.join(UPLOAD_DIR, f"dashboard-bg-{iface}.{old_ext}")
                    if os.path.exists(old_f):
                        os.remove(old_f)
                fname = secure_filename(f"dashboard-bg-{iface}.{ext}")
                bg_file.save(os.path.join(UPLOAD_DIR, fname))
                set_setting(db, key("dashboard_bg_path"), f"uploads/{fname}")
            else:
                flash("صيغة الصورة غير مدعومة. استخدم PNG أو JPG أو WEBP.")

        def save_int(field, lo, hi):
            raw = request.form.get(field, "").strip()
            if raw == "":
                return
            try:
                set_setting(db, key(field), str(max(lo, min(hi, int(raw)))))
            except ValueError:
                pass
        save_int("dashboard_bg_overlay_opacity", 0, 100)
        save_int("dashboard_bg_blur", 0, 20)
        save_int("dashboard_bg_size_percent", 5, 400)
        save_int("dashboard_bg_brightness", 20, 200)
        pos = request.form.get("dashboard_bg_position", "")
        if pos in ("top", "center", "bottom"):
            set_setting(db, key("dashboard_bg_position"), pos)
        mode = request.form.get("dashboard_bg_size_mode", "")
        if mode in ("cover", "contain", "custom"):
            set_setting(db, key("dashboard_bg_size_mode"), mode)
        for cf in ("theme_primary_color", "theme_page_bg_color",
                   "dashboard_overlay_color", "dashboard_hero_text_color"):
            v = request.form.get(cf, "").strip()
            if request.form.get(cf + "_inherit") == "1":
                set_setting(db, key(cf), "")
            elif v and _HEX_COLOR_RE.match(v):
                set_setting(db, key(cf), v)
        db.commit()
        flash(f"تم حفظ مظهر واجهة {DASH_INTERFACE_LABELS[iface]}.")
        return redirect(url_for("dashboard_look", tab=iface))

    glob = {
        "dashboard_bg_path": get_setting(db, "dashboard_bg_path", ""),
        "dashboard_bg_overlay_opacity": get_setting(db, "dashboard_bg_overlay_opacity", "62"),
        "dashboard_bg_blur": get_setting(db, "dashboard_bg_blur", "2"),
        "dashboard_bg_position": get_setting(db, "dashboard_bg_position", "center"),
        "dashboard_bg_size_mode": get_setting(db, "dashboard_bg_size_mode", "cover"),
        "dashboard_bg_size_percent": get_setting(db, "dashboard_bg_size_percent", "100"),
        "theme_primary_color": get_setting(db, "theme_primary_color", "#205072"),
        "theme_page_bg_color": get_setting(db, "theme_page_bg_color", "#F3F6F8"),
        "dashboard_overlay_color": get_setting(db, "dashboard_overlay_color", DASH_LOOK_DEFAULTS["dashboard_overlay_color"]),
        "dashboard_bg_brightness": get_setting(db, "dashboard_bg_brightness", DASH_LOOK_DEFAULTS["dashboard_bg_brightness"]),
        "dashboard_hero_text_color": get_setting(db, "dashboard_hero_text_color", DASH_LOOK_DEFAULTS["dashboard_hero_text_color"]),
    }
    cards = []
    for iface in DASH_INTERFACES:
        own = {k: get_setting(db, f"{k}__{iface}", "") for k in DASH_LOOK_KEYS}
        eff = {k: (own[k] if own[k] != "" else glob[k]) for k in DASH_LOOK_KEYS}
        bg = eff["dashboard_bg_path"]
        cards.append({
            "iface": iface, "label": DASH_INTERFACE_LABELS[iface], "own": own, "eff": eff,
            "bg_url": (url_for("static", filename=bg) if bg and bg != "-" else None),
            "bg_state": ("none" if own["dashboard_bg_path"] == "-" else
                         "own" if own["dashboard_bg_path"] else "inherit"),
        })
    return render_template("management/dashboard_look.html", cards=cards,
                           active_tab=request.args.get("tab", "reception"))


@app.route("/management/settings", methods=["GET", "POST"])
@roles_required("admin")
def app_settings():
    db = get_db()
    if request.method == "POST":
        name_en = request.form.get("app_name", "").strip()
        name_ar = request.form.get("app_name_ar", "").strip()
        if name_en:
            set_setting(db, "app_name", name_en)
        if name_ar:
            set_setting(db, "app_name_ar", name_ar)

        lab_address_raw = request.form.get("lab_address", "").strip()
        if lab_address_raw:
            set_setting(db, "lab_address", lab_address_raw)
        lab_phone_raw = request.form.get("lab_phone", "").strip()
        if lab_phone_raw:
            set_setting(db, "lab_phone", lab_phone_raw)

        file = request.files.get("logo")
        if file and file.filename:
            ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
            if ext in ALLOWED_LOGO_EXT:
                filename = secure_filename(f"logo.{ext}")
                # remove any previously uploaded logo with a different extension
                for old_ext in ALLOWED_LOGO_EXT:
                    old_path = os.path.join(UPLOAD_DIR, f"logo.{old_ext}")
                    if os.path.exists(old_path):
                        os.remove(old_path)
                file.save(os.path.join(UPLOAD_DIR, filename))
                set_setting(db, "logo_path", f"uploads/{filename}")
            else:
                flash("Unsupported logo file type. Use PNG, JPG, GIF, SVG or WEBP.")

        # خلفية شاشة الترحيب (dashboard) — نفس منطق رفع الشعار أعلاه بالضبط:
        # نحذف أي نسخة قديمة (بأي امتداد) ثم نحفظ الجديدة باسم ثابت
        # dashboard-bg.<ext> حتى يبقى مسار واحد معروف. زر "إزالة الصورة"
        # منفصل (checkbox/hidden باسم remove_dashboard_bg) يمسحها بدون رفع بديل.
        if request.form.get("remove_dashboard_bg") == "1":
            old_bg_path = get_setting(db, "dashboard_bg_path", "")
            if old_bg_path:
                old_bg_full = os.path.join(UPLOAD_DIR, os.path.basename(old_bg_path))
                if os.path.exists(old_bg_full):
                    os.remove(old_bg_full)
            set_setting(db, "dashboard_bg_path", "")
        else:
            bg_file = request.files.get("dashboard_bg")
            if bg_file and bg_file.filename:
                bg_ext = bg_file.filename.rsplit(".", 1)[-1].lower() if "." in bg_file.filename else ""
                if bg_ext in ALLOWED_DASHBOARD_BG_EXT:
                    bg_filename = secure_filename(f"dashboard-bg.{bg_ext}")
                    for old_ext in ALLOWED_DASHBOARD_BG_EXT:
                        old_bg = os.path.join(UPLOAD_DIR, f"dashboard-bg.{old_ext}")
                        if os.path.exists(old_bg):
                            os.remove(old_bg)
                    bg_file.save(os.path.join(UPLOAD_DIR, bg_filename))
                    set_setting(db, "dashboard_bg_path", f"uploads/{bg_filename}")
                else:
                    flash("صيغة صورة غير مدعومة لخلفية شاشة الترحيب. استخدم PNG أو JPG أو WEBP.")

        # خصائص خلفية شاشة الترحيب (تعتيم/ضبابية الطبقة فوق الصورة أو
        # التدرّج) — قابلة للتحكم الكامل من هنا بدل قيمتين ثابتتين
        # بالكود (كانت .62 وblur(2px))، بنفس أسلوب report_row_pad
        # وبقية إعدادات التخصيص أعلاه. تُحقن عالمياً بـinject_globals
        # وتُستخدم مباشرة بـdashboard.html.
        bg_opacity = request.form.get("dashboard_bg_overlay_opacity", "").strip()
        if bg_opacity:
            try:
                bg_opacity_val = max(0, min(100, int(bg_opacity)))
                set_setting(db, "dashboard_bg_overlay_opacity", str(bg_opacity_val))
            except ValueError:
                pass
        bg_blur = request.form.get("dashboard_bg_blur", "").strip()
        if bg_blur:
            try:
                bg_blur_val = max(0, min(20, int(bg_blur)))
                set_setting(db, "dashboard_bg_blur", str(bg_blur_val))
            except ValueError:
                pass
        # موضع الصورة (top/center/bottom) -- أعدتها هنا (كانت موجودة قبل)
        # لحد ما يتأكد المستخدم إذا يريدها يبقى أو يشيلها نهائيًا.
        bg_position_raw = request.form.get("dashboard_bg_position", "").strip()
        if bg_position_raw in ("top", "center", "bottom"):
            set_setting(db, "dashboard_bg_position", bg_position_raw)
        # حجم الصورة: cover / contain / custom (نسبة % من عرض الشاشة، 5..400)
        bg_size_mode_raw = request.form.get("dashboard_bg_size_mode", "").strip()
        if bg_size_mode_raw in ("cover", "contain", "custom"):
            set_setting(db, "dashboard_bg_size_mode", bg_size_mode_raw)
        bg_size_pct_raw = request.form.get("dashboard_bg_size_percent", "").strip()
        if bg_size_pct_raw:
            try:
                set_setting(db, "dashboard_bg_size_percent", str(max(5, min(400, int(bg_size_pct_raw)))))
            except ValueError:
                pass

        # ألوان الواجهة العامة (المطلوب: تغيير ألوان الخلفية بكل صفحات
        # البرنامج، مو بس شاشة الترحيب) -- نفس أسلوب باقي إعدادات
        # التخصيص، فحص بسيط على صيغة hex صحيحة (#RRGGBB) قبل الحفظ.
        primary_color_raw = request.form.get("theme_primary_color", "").strip()
        if primary_color_raw and _HEX_COLOR_RE.match(primary_color_raw):
            set_setting(db, "theme_primary_color", primary_color_raw)
        page_bg_raw = request.form.get("theme_page_bg_color", "").strip()
        if page_bg_raw and _HEX_COLOR_RE.match(page_bg_raw):
            set_setting(db, "theme_page_bg_color", page_bg_raw)

        # ملاحظة: إدارة أسماء وشهادات دكاترة الفحص انتقلت لشاشة مستقلة
        # (management/examining_doctors.html عبر الرابط بهذي الصفحة) — ما عاد
        # فيها فورم هنا.

        # ارتفاع/عرض خلايا جدول نتائج التقرير — رقم صحيح بين 2 و30 بكسل فقط،
        # أي قيمة غير صالحة تُتجاهل ويبقى المحفوظ سابقًا كما هو.
        row_pad_raw = request.form.get("report_row_pad", "").strip()
        if row_pad_raw:
            try:
                row_pad = max(2, min(30, int(row_pad_raw)))
                set_setting(db, "report_row_pad", str(row_pad))
            except ValueError:
                pass
        col_pad_raw = request.form.get("report_col_pad", "").strip()
        if col_pad_raw:
            try:
                col_pad = max(2, min(40, int(col_pad_raw)))
                set_setting(db, "report_col_pad", str(col_pad))
            except ValueError:
                pass

        if request.form.get("sample_no_settings"):
            _r = request.form.get("sample_no_reset", "daily")
            set_setting(db, "sample_no_reset", _r if _r in ("daily", "monthly", "yearly", "never") else "daily")
            _d = request.form.get("sample_no_date_part", "none")
            set_setting(db, "sample_no_date_part", _d if _d in ("none", "yymmdd", "yymm", "yy") else "none")
            set_setting(db, "sample_no_prefix", (request.form.get("sample_no_prefix") or "").strip()[:10])
            _p = (request.form.get("sample_no_padding") or "3").strip()
            set_setting(db, "sample_no_padding", _p if _p.isdigit() and 1 <= int(_p) <= 8 else "3")

        if request.form.get("portal_settings"):
            set_setting(db, "portal_enabled", "1" if request.form.get("portal_enabled") else "0")
            set_setting(db, "portal_url", (request.form.get("portal_url") or "").strip().rstrip("/")[:200])
            _k = (request.form.get("portal_api_key") or "").strip()
            if _k:   # فاضي = أبقِ المفتاح القديم (ما نعرضه بالصفحة)
                set_setting(db, "portal_api_key", _k[:200])
            set_setting(db, "portal_default_hours", str(max(0, min(240, float(request.form.get("portal_default_hours") or 2)))))
            set_setting(db, "portal_tat_overrides", (request.form.get("portal_tat_overrides") or "")[:2000])
            _rw = request.form.get("portal_ready_when", "completed")
            set_setting(db, "portal_ready_when", _rw if _rw in ("completed", "verified") else "completed")
            set_setting(db, "portal_pdf_enabled", "1" if request.form.get("portal_pdf_enabled") else "0")
            _pm = request.form.get("portal_mode", "local")
            set_setting(db, "portal_mode", "remote" if _pm == "remote" else "local")
            try:
                set_setting(db, "portal_retention_days", str(max(1, min(365, int(float(request.form.get("portal_retention_days") or 30))))))
            except ValueError:
                set_setting(db, "portal_retention_days", "30")
            cloud_sync.trigger()

        pi_gap_raw = request.form.get("patient_info_top_gap", "").strip()
        if pi_gap_raw:
            try:
                pi_gap = max(-20, min(150, int(pi_gap_raw)))
                set_setting(db, "patient_info_top_gap", str(pi_gap))
            except ValueError:
                pass
        # المطلوب 2: توسيع نطاق مسافات معلومات المريض (فوق-تحت وبين
        # اليمين-اليسار) لأبعد بكثير من الحدود القديمة (كانت 0-30 للمسافة
        # العمودية و0-150 للمسافة الأفقية) — بطلب صريح من المستخدم إنه
        # يحتاج يصغّر أو يكبّر أكثر مما كان متاحاً بالإعدادات القديمة.
        # القيمة الافتراضية (لو الحقل فاضي) ما تغيّرت، فقط سقف/أرضية
        # القيم المسموحة اتوسّعت.
        pi_label_w_raw = request.form.get("patient_info_label_width", "").strip()
        if pi_label_w_raw:
            try:
                pi_label_w = max(20, min(400, int(pi_label_w_raw)))
                set_setting(db, "patient_info_label_width", str(pi_label_w))
            except ValueError:
                pass
        pi_row_gap_raw = request.form.get("patient_info_row_gap", "").strip()
        if pi_row_gap_raw:
            try:
                pi_row_gap = max(-10, min(80, int(pi_row_gap_raw)))
                set_setting(db, "patient_info_row_gap", str(pi_row_gap))
            except ValueError:
                pass
        pi_col_gap_raw = request.form.get("patient_info_col_gap", "").strip()
        if pi_col_gap_raw:
            try:
                pi_col_gap = max(0, min(400, int(pi_col_gap_raw)))
                set_setting(db, "patient_info_col_gap", str(pi_col_gap))
            except ValueError:
                pass
        underline_style_raw = request.form.get("report_underline_style")
        if underline_style_raw in ("solid", "dashed", "none"):
            set_setting(db, "report_underline_style", underline_style_raw)

        wa_code = request.form.get("whatsapp_country_code", "").strip()
        if wa_code:
            set_setting(db, "whatsapp_country_code", "".join(ch for ch in wa_code if ch.isdigit()))

        # حجم ونوع خط أسماء/شهادات الدكاترة بترويسة كل تقرير مطبوع (base_report.html)
        # — إعداد عام واحد ينطبق على الجميع دفعة وحدة، مو لكل شخص لحاله.
        lh_size_raw = request.form.get("letterhead_font_size", "").strip()
        if lh_size_raw:
            try:
                lh_size = max(8, min(30, int(lh_size_raw)))
                set_setting(db, "letterhead_font_size", str(lh_size))
            except ValueError:
                pass
        lh_family_raw = request.form.get("letterhead_font_family", "").strip()
        if lh_family_raw:
            set_setting(db, "letterhead_font_family", lh_family_raw)

        # موضع الشعار (يمين الافتراضي/وسط/يسار) وحجمه (عرضه بالبكسل) —
        # إعدادان عامان جديدان، نفس أسلوب باقي إعدادات التقرير.
        logo_pos_raw = request.form.get("logo_position", "").strip()
        if logo_pos_raw in ("right", "center", "left"):
            set_setting(db, "logo_position", logo_pos_raw)
        # v61: ستايل الترويسة (default = الحالية | h1..h4)، لونها، والسطر الإنجليزي تحت اسم المختبر
        _hs_raw = request.form.get("report_header_style", "").strip()
        if _hs_raw in ("default", "h1", "h2", "h3", "h4"):
            set_setting(db, "report_header_style", _hs_raw)
        _ha_raw = request.form.get("report_header_accent", "").strip()
        if re.fullmatch(r"#[0-9A-Fa-f]{6}", _ha_raw):
            set_setting(db, "report_header_accent", _ha_raw)
        if "report_header_subtitle" in request.form:
            set_setting(db, "report_header_subtitle", request.form.get("report_header_subtitle", "").strip()[:120])
        logo_width_raw = request.form.get("logo_width", "").strip()
        if logo_width_raw:
            try:
                logo_width = max(30, min(300, int(logo_width_raw)))
                set_setting(db, "logo_width", str(logo_width))
            except ValueError:
                pass

        # ترتيب أقسام اللوحة المجمّعة — سطر واحد لكل اسم قسم/ريبورت مجمّع
        # (report_group أو department)، بنفس الترتيب اللي يريده الأدمن
        # بالطباعة. حقل نصي فاضي بالكامل = رجوع للترتيب الأبجدي الافتراضي.
        panel_group_order_raw = request.form.get("combined_panel_group_order")
        if panel_group_order_raw is not None:
            set_setting(db, "combined_panel_group_order", panel_group_order_raw.strip())

        # ترتيب ثابت للتحاليل بشاشة "إدخال النتائج" (Results Entry) — سطر
        # لكل اسم تحليل بالضبط كما يظهر بالشاشة (مثلاً "HbA1c (BioChemstry)")،
        # بنفس الترتيب اللي يريده الأدمن، ثابت دائماً بغض النظر عن ترتيب
        # طلب التحاليل الفعلي بكل زيارة. فاضي بالكامل = رجوع لترتيب الطلب
        # الأصلي (ot.id) كالسابق.
        results_order_raw = request.form.get("results_entry_test_order")
        if results_order_raw is not None:
            set_setting(db, "results_entry_test_order", results_order_raw.strip())
        analyzers_raw = request.form.get("known_analyzers")
        if analyzers_raw is not None:
            set_setting(db, "known_analyzers", analyzers_raw.strip())
        # تصحيحات ترجمة الأسماء العربية للإنكليزي (المطلوب: ترجمة دقيقة —
        # القاموس الجاهز بالكود يغطي أسماء شائعة، وهذا الحقل يخلي المختبر
        # يصحّح أي اسم يطلع غلط بنفسه دون انتظار تحديث بالكود. سطر لكل
        # اسم بصيغة "عربي=إنكليزي"، مثال: سمر=Samar
        name_translit_raw = request.form.get("name_translit_overrides")
        if name_translit_raw is not None:
            set_setting(db, "name_translit_overrides", name_translit_raw.strip())
        # حجم خط اسم التحليل وحجم خط النتيجة بجدول/بطاقات النتائج بكل
        # التقارير المطبوعة — إعدادان عامان منفصلان عن بعض (وعن حجم خط
        # ترويسة الدكاترة letterhead_font_size أعلاه)، دفعة وحدة لكل
        # التقارير. أي قيمة غير صالحة تُتجاهل ويبقى المحفوظ سابقًا كما هو.
        tn_size_raw = request.form.get("test_name_font_size", "").strip()
        if tn_size_raw:
            try:
                tn_size = max(8, min(30, int(tn_size_raw)))
                set_setting(db, "test_name_font_size", str(tn_size))
            except ValueError:
                pass
        rv_size_raw = request.form.get("result_value_font_size", "").strip()
        if rv_size_raw:
            try:
                rv_size = max(8, min(30, int(rv_size_raw)))
                set_setting(db, "result_value_font_size", str(rv_size))
            except ValueError:
                pass

        # مجلد أرشفة الـPDF الدائم (نقطة #8) — يُضبط مرة وحدة هنا وقت
        # التنصيب/الإعداد الأولي، ويُعاد استخدامه تلقائيًا بعدها لكل زيارة
        # تكتمل نتائجها. لا نتحقق من وجوده هنا (os.makedirs لاحقًا وقت
        # الأرشفة الفعلية يكفي) حتى يقدر المدير يكتب مسار جهاز آخر بالشبكة.
        archive_dir_raw = request.form.get("pdf_archive_dir", "").strip()
        if archive_dir_raw:
            set_setting(db, "pdf_archive_dir", archive_dir_raw)

        # ألوان رموز الـ Conclusion (نجمة/أسهم/استفهام/تعجب) — كل رمز إله
        # حقل <input type=color> باسم marker_color_<key> بشاشة الإعدادات.
        # نحفظ فقط الألوان اللي وصلت وبصيغة hex صحيحة؛ أي حقل فاضي أو غير
        # صالح يبقى على قيمته المحفوظة سابقًا (أو الافتراضي إذا ما انحفظ شي).
        marker_colors = {}
        raw_existing = get_setting(db, "conclusion_marker_colors", "")
        if raw_existing:
            try:
                marker_colors = json.loads(raw_existing)
            except (ValueError, TypeError):
                marker_colors = {}
        for m in CONCLUSION_MARKERS:
            val = request.form.get("marker_color_" + m["key"], "").strip()
            if val and _HEX_COLOR_RE.match(val):
                marker_colors[m["key"]] = val
        if marker_colors:
            set_setting(db, "conclusion_marker_colors", json.dumps(marker_colors))

        # تلوين/أعلام النتائج (المطلوب 2 و3) — نفس مشكلة أي checkbox بفورم
        # منفصل عن باقي كروت الإعدادات: checkbox غير محدد ما يظهر إطلاقًا
        # بالفورم، فما نقدر نميّز "هذا الكرت انحفظ والخيار متروك فارغ" عن
        # "فورم كرت ثاني انحفظ وهذا الحقل أصلاً مو منه". لذلك نعتمد على
        # حقل hidden مميّز (flag_settings_form) موجود فقط بفورم هذا الكرت
        # تحديداً بـsettings.html — لا نلمس هذا الإعداد أبداً إلا لو
        # الفورم المُرسَل فعلاً هو فورم هذا الكرت.
        if request.form.get("flag_settings_form") is not None:
            set_setting(db, "auto_flag_color_enabled", "1" if request.form.get("auto_flag_color_enabled") else "0")
            set_setting(db, "show_result_flag", "1" if request.form.get("show_result_flag") else "0")
            flag_high = request.form.get("flag_color_high", "").strip()
            if flag_high and _HEX_COLOR_RE.match(flag_high):
                set_setting(db, "flag_color_high", flag_high)
            flag_low = request.form.get("flag_color_low", "").strip()
            if flag_low and _HEX_COLOR_RE.match(flag_low):
                set_setting(db, "flag_color_low", flag_low)

        # ------------------------------------------------------------
        # بطاقة "تحليل مجاني" — محمية بيوزر/باسوورد تعديل مخصص ومنفصل عن
        # كل نظام يوزرات البرنامج العادي. أول مرة (ما فيه يوزر/باسوورد
        # تعديل محفوظ بعد) نقبل أي يوزر/باسوورد جديدين يُكتبان بحقلي
        # "يوزر جديد/باسوورد جديد" كبذرة أولى؛ بعدها أي تعديل (حتى تغيير
        # اليوزر/الباسوورد نفسه) يحتاج تأكيد اليوزر/الباسوورد الحاليين أولاً.
        # ------------------------------------------------------------
        if request.form.get("fee_waiver_form") is not None:
            gate_user_input = request.form.get("gate_username", "").strip()
            gate_pass_input = request.form.get("gate_password", "")
            stored_gate_user = get_setting(db, "fee_waiver_gate_username", "")
            stored_gate_hash = get_setting(db, "fee_waiver_gate_password_hash", "")

            gate_ok = False
            if not stored_gate_user and not stored_gate_hash:
                new_gate_user_first = request.form.get("new_gate_username", "").strip()
                new_gate_pass_first = request.form.get("new_gate_password", "")
                if new_gate_user_first and new_gate_pass_first:
                    set_setting(db, "fee_waiver_gate_username", new_gate_user_first)
                    set_setting(db, "fee_waiver_gate_password_hash", hash_password(new_gate_pass_first))
                    gate_ok = True
                    flash("تم إنشاء يوزر/باسوورد التعديل الخاص بميزة \"تحليل مجاني\" لأول مرة.")
                else:
                    flash("لأول ضبط لهذه الميزة: اكتب يوزر وباسوورد جديدين بحقلي \"تغيير يوزر/باسوورد هذا التعديل\" بالأسفل.")
            elif gate_user_input and gate_user_input == stored_gate_user and hash_password(gate_pass_input) == stored_gate_hash:
                gate_ok = True
            else:
                flash("يوزر أو باسوورد التعديل غير صحيح — لم يتم حفظ أي تغيير على بطاقة \"تحليل مجاني\".")

            if gate_ok:
                waiver_name = request.form.get("waiver_authorized_name", "").strip()
                if waiver_name:
                    set_setting(db, "fee_waiver_authorized_name", waiver_name)
                waiver_pass = request.form.get("waiver_password", "")
                if waiver_pass:
                    set_setting(db, "fee_waiver_password_hash", hash_password(waiver_pass))
                new_gate_user = request.form.get("new_gate_username", "").strip()
                new_gate_pass = request.form.get("new_gate_password", "")
                if new_gate_user and new_gate_pass and (stored_gate_user or stored_gate_hash):
                    set_setting(db, "fee_waiver_gate_username", new_gate_user)
                    set_setting(db, "fee_waiver_gate_password_hash", hash_password(new_gate_pass))
                    flash("تم تغيير يوزر/باسوورد التعديل الخاص بميزة \"تحليل مجاني\".")
                db.commit()
                log_action("UpdateFeeWaiverSettings", "settings", 0)
                flash("تم حفظ إعدادات \"تحليل مجاني\".")
            return redirect(url_for("app_settings"))

        # ------------------------------------------------------------
        # كلمات مرور واجهتي "استقبال" و"مختبر" (المطلوب 3) -- كل وحدة
        # مستقلة، تُسأل بس وقت الدخول/تبديل الواجهة لتلك القيمة تحديدًا.
        # ترك الحقل فاضي = ما يغيّر كلمة المرور الحالية (يبقى نفس الشي
        # -- خله فاضي كل مرة إذا ما تريد تغييرها).
        # ------------------------------------------------------------
        if request.form.get("delete_password_form") is not None:
            cur_hash = get_setting(db, "delete_password_hash", "")
            if cur_hash and hash_password(request.form.get("current_delete_password", "")) != cur_hash:
                flash("كلمة مرور الحذف الحالية غير صحيحة — لم تتغيّر.")
            else:
                newp = request.form.get("new_delete_password", "")
                if not newp:
                    flash("اكتب كلمة المرور الجديدة.")
                else:
                    set_setting(db, "delete_password_hash", hash_password(newp))
                    db.commit()
                    log_action("UpdateDeletePassword", "settings", 0)
                    flash("تم حفظ كلمة مرور الحذف.")
            return redirect(url_for("app_settings"))

        if request.form.get("interface_passwords_form") is not None:
            recep_pass = request.form.get("interface_reception_password", "")
            if recep_pass:
                set_setting(db, "interface_reception_password_hash", hash_password(recep_pass))
            lab_pass = request.form.get("interface_lab_password", "")
            if lab_pass:
                set_setting(db, "interface_lab_password_hash", hash_password(lab_pass))
            db.commit()
            log_action("UpdateInterfacePasswords", "settings", 0)
            flash("تم حفظ كلمات مرور الواجهات.")
            return redirect(url_for("app_settings"))

        # ------------------------------------------------------------
        # الشاشة الرئيسية (المطلوب: العنوان + صور الخيارات الثلاث + لوني
        # التدرّج). نفس أسلوب رفع صورة خلفية شاشة الترحيب أعلاه بالضبط،
        # لكن لكل صورة من الثلاث خزّانها الخاص (landing_<key>_image_path)
        # حتى ما تتداخل ببعضها. حقل فاضي = يبقى نفس الشي الحالي.
        # ------------------------------------------------------------
        if request.form.get("landing_page_form") is not None:
            landing_title_raw = request.form.get("landing_title", "").strip()
            if landing_title_raw:
                set_setting(db, "landing_title", landing_title_raw)
            # عنوان فرعي بالانكليزي يظهر تحت العنوان العربي فوق خلفية الشاشة
            # الرئيسية -- اختياري، حقل فاضي = ما يظهر أي سطر انكليزي (نفس
            # سلوك landing_title القديم يبقى شغال بدون أي تغيير).
            landing_title_en_raw = request.form.get("landing_title_en", "")
            set_setting(db, "landing_title_en", landing_title_en_raw.strip())
            for gkey in ("landing_gradient_color1", "landing_gradient_color2"):
                gval = request.form.get(gkey, "").strip()
                if gval and _HEX_COLOR_RE.match(gval):
                    set_setting(db, gkey, gval)
            # المطلوب: التحكم بشكل صور البطاقات الثلاث (دائرية/مربعة/
            # مستطيلة)، وضوحها (0-100)، وموضعها بالنسبة للبطاقة (داخل
            # البطاقة بالأعلى -- الافتراضي، خلفية كاملة للبطاقة، أو جنب
            # النص). إعداد واحد موحّد يطبَّق على الثلاث بطاقات مع بعض.
            shape_raw = request.form.get("landing_image_shape", "").strip()
            if shape_raw in ("circle", "square", "rectangle"):
                set_setting(db, "landing_image_shape", shape_raw)
            position_raw = request.form.get("landing_image_position", "").strip()
            if position_raw in ("top", "background", "side"):
                set_setting(db, "landing_image_position", position_raw)
            opacity_raw = request.form.get("landing_image_opacity", "").strip()
            if opacity_raw:
                try:
                    opacity_val = max(10, min(100, int(opacity_raw)))
                    set_setting(db, "landing_image_opacity", str(opacity_val))
                except ValueError:
                    pass
            # وضوح طبقة التعتيم فوق صورة خلفية الشاشة الرئيسية (0-100) --
            # نفس فكرة dashboard_bg_overlay_opacity الموجودة أصلاً لشاشة
            # الداشبورد، لكن بإعداد منفصل خاص بهذي الشاشة فقط. الافتراضي 55
            # يخلي الصورة واضحة والنص/البطاقات مقروءة فوقها.
            bg_opacity_raw = request.form.get("landing_bg_overlay_opacity", "").strip()
            if bg_opacity_raw:
                try:
                    bg_opacity_val = max(0, min(100, int(bg_opacity_raw)))
                    set_setting(db, "landing_bg_overlay_opacity", str(bg_opacity_val))
                except ValueError:
                    pass
            # موضع صورة الخلفية: خلف البطاقات الثلاث كخلفية كاملة للشاشة
            # (الافتراضي -- نفس السلوك القديم)، أو فوق البطاقات كـ"بانر"
            # بحجم وشكل محدَّدين بدل تغطية الشاشة كلها.
            bg_position_raw = request.form.get("landing_bg_position", "").strip()
            if bg_position_raw in ("background", "banner"):
                set_setting(db, "landing_bg_position", bg_position_raw)
            bg_shape_raw = request.form.get("landing_bg_shape", "").strip()
            if bg_shape_raw in ("rectangle", "square", "circle"):
                set_setting(db, "landing_bg_shape", bg_shape_raw)
            banner_size_raw = request.form.get("landing_bg_banner_size", "").strip()
            if banner_size_raw:
                try:
                    banner_size_val = max(60, min(400, int(banner_size_raw)))
                    set_setting(db, "landing_bg_banner_size", str(banner_size_val))
                except ValueError:
                    pass
            # حجم شعار المختبر (لو انرفع) -- شعار المختبر مستقل تمامًا عن
            # صورة الخلفية/البانر ونص العنوان: يظهر فوق العنوان بغض النظر
            # عن باقي الإعدادات، ويُطبَّق/يُزال بشكل منفصل عن الصورة والنص.
            logo_size_raw = request.form.get("landing_bg_logo_size", "").strip()
            if logo_size_raw:
                try:
                    logo_size_val = max(30, min(300, int(logo_size_raw)))
                    set_setting(db, "landing_bg_logo_size", str(logo_size_val))
                except ValueError:
                    pass
            for img_key in ("reception", "lab", "together", "bg", "bglogo"):
                setting_key = f"landing_{img_key}_image_path"
                if request.form.get(f"remove_landing_{img_key}_image") == "1":
                    old_path = get_setting(db, setting_key, "")
                    if old_path:
                        old_full = os.path.join(UPLOAD_DIR, os.path.basename(old_path))
                        if os.path.exists(old_full):
                            os.remove(old_full)
                    set_setting(db, setting_key, "")
                    continue
                img_file = request.files.get(f"landing_{img_key}_image")
                if img_file and img_file.filename:
                    img_ext = img_file.filename.rsplit(".", 1)[-1].lower() if "." in img_file.filename else ""
                    if img_ext in ALLOWED_DASHBOARD_BG_EXT:
                        img_filename = secure_filename(f"landing-{img_key}.{img_ext}")
                        for old_ext in ALLOWED_DASHBOARD_BG_EXT:
                            old_img = os.path.join(UPLOAD_DIR, f"landing-{img_key}.{old_ext}")
                            if os.path.exists(old_img):
                                os.remove(old_img)
                        img_file.save(os.path.join(UPLOAD_DIR, img_filename))
                        set_setting(db, setting_key, f"uploads/{img_filename}")
                    else:
                        if img_key == "bg":
                            img_label = "خلفية الشاشة الرئيسية"
                        elif img_key == "bglogo":
                            img_label = "شعار المختبر"
                        else:
                            img_label = f"بطاقة {img_key}"
                        flash(f"صيغة صورة غير مدعومة لـ{img_label}. استخدم PNG أو JPG أو WEBP.")
            db.commit()
            log_action("UpdateLandingPage", "settings", 0)
            flash("تم حفظ إعدادات الشاشة الرئيسية.")
            return redirect(url_for("app_settings"))

        db.commit()
        log_action("UpdateSettings", "settings", 0)
        flash("Settings saved.")
        return redirect(url_for("app_settings"))

    current = {
        "app_name": get_setting(db, "app_name", ""),
        "app_name_ar": get_setting(db, "app_name_ar", ""),
        "lab_address": get_setting(db, "lab_address", ""),
        "lab_phone": get_setting(db, "lab_phone", ""),
        "logo_path": get_setting(db, "logo_path", ""),
        "dashboard_bg_path": get_setting(db, "dashboard_bg_path", ""),
        "dashboard_bg_overlay_opacity": get_setting(db, "dashboard_bg_overlay_opacity", "62"),
        "theme_primary_color": get_setting(db, "theme_primary_color", "#205072"),
        "theme_page_bg_color": get_setting(db, "theme_page_bg_color", "#F3F6F8"),
        "landing_title": get_setting(db, "landing_title", "نظام الإدارة المتكامل"),
        "landing_title_en": get_setting(db, "landing_title_en", ""),
        "landing_gradient_color1": get_setting(db, "landing_gradient_color1", "#0f172a"),
        "landing_gradient_color2": get_setting(db, "landing_gradient_color2", "#205072"),
        "landing_reception_image_path": get_setting(db, "landing_reception_image_path", ""),
        "landing_lab_image_path": get_setting(db, "landing_lab_image_path", ""),
        "landing_together_image_path": get_setting(db, "landing_together_image_path", ""),
        "landing_bg_image_path": get_setting(db, "landing_bg_image_path", ""),
        "landing_bg_overlay_opacity": get_setting(db, "landing_bg_overlay_opacity", "55"),
        "landing_bg_position": get_setting(db, "landing_bg_position", "background"),
        "landing_bg_shape": get_setting(db, "landing_bg_shape", "rectangle"),
        "landing_bg_banner_size": get_setting(db, "landing_bg_banner_size", "160"),
        "landing_bglogo_image_path": get_setting(db, "landing_bglogo_image_path", ""),
        "landing_bg_logo_size": get_setting(db, "landing_bg_logo_size", "90"),
        "landing_image_shape": get_setting(db, "landing_image_shape", "square"),
        "landing_image_position": get_setting(db, "landing_image_position", "top"),
        "landing_image_opacity": get_setting(db, "landing_image_opacity", "100"),
        "dashboard_bg_blur": get_setting(db, "dashboard_bg_blur", "2"),
        "dashboard_bg_position": get_setting(db, "dashboard_bg_position", "center"),
        "dashboard_bg_size_mode": get_setting(db, "dashboard_bg_size_mode", "cover"),
        "dashboard_bg_size_percent": get_setting(db, "dashboard_bg_size_percent", "100"),
        "report_row_pad": get_setting(db, "report_row_pad", "5"),
        "sample_no_reset": get_setting(db, "sample_no_reset", "daily"),
        "sample_no_date_part": get_setting(db, "sample_no_date_part", "none"),
        "sample_no_prefix": get_setting(db, "sample_no_prefix", ""),
        "sample_no_padding": get_setting(db, "sample_no_padding", "3"),
        "sample_no_next": peek_next_sample_no(db),
        "portal_enabled": get_setting(db, "portal_enabled", "0") == "1",
        "portal_url": get_setting(db, "portal_url", ""),
        "portal_key_set": bool(get_setting(db, "portal_api_key", "")),
        "portal_default_hours": get_setting(db, "portal_default_hours", "2"),
        "portal_tat_overrides": get_setting(db, "portal_tat_overrides", ""),
        "portal_ready_when": get_setting(db, "portal_ready_when", "completed"),
        "portal_pdf_enabled": get_setting(db, "portal_pdf_enabled", "1") == "1",
        "portal_mode": "remote" if get_setting(db, "portal_mode", "local") == "remote" else "local",
        "portal_retention_days": get_setting(db, "portal_retention_days", "30"),
        "patient_info_top_gap": get_setting(db, "patient_info_top_gap", "4"),
        "patient_info_label_width": get_setting(db, "patient_info_label_width", "108"),
        "patient_info_row_gap": get_setting(db, "patient_info_row_gap", "3"),
        "patient_info_col_gap": get_setting(db, "patient_info_col_gap", "36"),
        "report_underline_style": get_setting(db, "report_underline_style", "solid"),
        "report_col_pad": get_setting(db, "report_col_pad", "12"),
        "whatsapp_country_code": get_setting(db, "whatsapp_country_code", "964"),
        "pdf_archive_dir": get_setting(db, "pdf_archive_dir", ""),
        "letterhead_font_size": get_setting(db, "letterhead_font_size", "14"),
        "letterhead_font_family": get_setting(db, "letterhead_font_family", "Segoe UI, Tahoma, Arial, sans-serif"),
        "test_name_font_size": get_setting(db, "test_name_font_size", "16"),
        "result_value_font_size": get_setting(db, "result_value_font_size", "16"),
        "logo_position": get_setting(db, "logo_position", "right"),
        "report_header_style": get_setting(db, "report_header_style", "default"),
        "report_header_accent": get_setting(db, "report_header_accent", "") or "#4FB6E8",
        "report_header_subtitle": get_setting(db, "report_header_subtitle", ""),
        "logo_width": get_setting(db, "logo_width", "100"),
        "combined_panel_group_order": get_setting(db, "combined_panel_group_order", ""),
        "name_translit_overrides": get_setting(db, "name_translit_overrides", ""),
        "results_entry_test_order": get_setting(db, "results_entry_test_order", ""),
        "known_analyzers": get_setting(db, "known_analyzers", ""),
        "auto_flag_color_enabled": get_setting(db, "auto_flag_color_enabled", "0"),
        "show_result_flag": get_setting(db, "show_result_flag", "0"),
        "flag_color_high": get_setting(db, "flag_color_high", "#D40000"),
        "flag_color_low": get_setting(db, "flag_color_low", "#B58900"),
        "fee_waiver_authorized_name": get_setting(db, "fee_waiver_authorized_name", ""),
    }
    marker_colors_by_char = get_conclusion_marker_colors(db)
    conclusion_markers = [
        {**m, "color": marker_colors_by_char[m["char"]]} for m in CONCLUSION_MARKERS
    ]
    return render_template(
        "management/settings.html", current=current, conclusion_markers=conclusion_markers
    )


# ------------------------------------------------------------------------
# تبديل "التحديث التلقائي" بضغطة وحدة من شريط الأعلى (بجانب اسم المستخدم) —
# متاح لدخول الأدمن العادي، بعكس /designer/update/toggle اللي يحتاج جلسة
# "مصمم" منفصلة. الاثنين يكتبان لنفس المفتاح (auto_update_enabled) بجدول
# الإعدادات، فتفعيل/تعطيل أي وحدة منهم ينعكس على الثاني وعلى auto_updater
# نفسه فورًا. يرجّع المستخدم لنفس الصفحة اللي كان فيها (request.referrer).
# ------------------------------------------------------------------------
# ============================================================================
# نظام النسخ الاحتياطي / الاستعادة (Backup / Restore) على USB أو CD
# ============================================================================
# فكرة العمل: قاعدة بيانات البرنامج بالكامل عبارة عن ملف واحد (lis.db).
# "تصدير نسخة احتياطية" ينسخ هذا الملف بأمان (عبر sqlite backup API، حتى
# لو فيه استخدام لحظي) ويحزمه مع صفحة بحث بسيطة تعمل بدون تنصيب البرنامج
# (search_offline.html) داخل ملف ZIP واحد يُنزَّل من المتصفح -- والمستخدم
# نفسه يحفظه بعدها بمكان تخزينه (USB / قرص) ويقدر يحرقه على CD إذا يريد.
# "استيراد نسخة احتياطية" يرفع نفس ملف الـZIP ويستبدل قاعدة البيانات
# الحالية بعد أخذ نسخة احتياطية تلقائية من القديمة أولاً (تحسّبًا لأي خطأ).
#
# 🔒 حماية إضافية مطلوبة صراحة: العملية بالكامل (تصدير أو استيراد) لازم
# تمر عبر يوزر/باسوورد خاصين بهذا الغرض فقط (backup_gate_username /
# backup_gate_password_hash) -- منفصلين تمامًا عن يوزر دخولك العادي وعن
# يوزر ميزة "تحليل مجاني" -- بنفس أسلوب "أول مرة تُترك فاضية تُنشأ تلقائيًا،
# وبعدها أي تغيير يحتاج تأكيد اليوزر/الباسوورد الحاليين" المتّبع بكل أنظمة
# الحماية الحساسة بهذا البرنامج.
# ============================================================================

def _check_backup_gate(db, username, password):
    """يتحقق من يوزر/باسوورد النسخ الاحتياطي الخاصين. يرجّع (ok: bool,
    first_time: bool) -- لو ما فيه يوزر/باسوورد محفوظ بعد (أول استخدام)،
    يعتبرها "غير جاهزة" (ok=False) لكن يعلّم first_time=True حتى تظهر
    رسالة توجّه المستخدم لصفحة الإعدادات يضبطها أول مرة."""
    stored_user = get_setting(db, "backup_gate_username", "")
    stored_hash = get_setting(db, "backup_gate_password_hash", "")
    if not stored_user and not stored_hash:
        return False, True
    ok = bool(username) and username == stored_user and hash_password(password or "") == stored_hash
    return ok, False


@app.route("/management/backup", methods=["GET"])
@roles_required("admin")
def backup_center():
    db = get_db()
    gate_ready = bool(get_setting(db, "backup_gate_username", ""))
    return render_template(
        "management/backup.html",
        gate_ready=gate_ready,
        hardware_id=license_manager.get_hardware_id(),
        last_backup_at=get_setting(db, "last_backup_at", ""),
    )


@app.route("/management/backup/set-gate", methods=["POST"])
@roles_required("admin")
def backup_set_gate():
    # نفس منطق بطاقة "تحليل مجاني" بالإعدادات: أول مرة تُترك الحقول فاضية
    # (ما فيه يوزر/باسوورد محفوظ) يُقبل أي يوزر/باسوورد جديدين كبذرة أولى؛
    # بعدها أي تغيير يحتاج تأكيد اليوزر/الباسوورد الحاليين أولاً.
    db = get_db()
    stored_user = get_setting(db, "backup_gate_username", "")
    stored_hash = get_setting(db, "backup_gate_password_hash", "")
    current_user_input = request.form.get("current_username", "").strip()
    current_pass_input = request.form.get("current_password", "")
    new_user = request.form.get("new_username", "").strip()
    new_pass = request.form.get("new_password", "")

    if not stored_user and not stored_hash:
        if new_user and new_pass:
            set_setting(db, "backup_gate_username", new_user)
            set_setting(db, "backup_gate_password_hash", hash_password(new_pass))
            db.commit()
            log_action("SetBackupGate", "settings", 0)
            flash("تم إنشاء يوزر/باسوورد النسخ الاحتياطي لأول مرة.")
        else:
            flash("اكتب يوزر وباسوورد جديدين لإنشاء صلاحية النسخ الاحتياطي أول مرة.")
    elif current_user_input == stored_user and hash_password(current_pass_input) == stored_hash:
        if new_user and new_pass:
            set_setting(db, "backup_gate_username", new_user)
            set_setting(db, "backup_gate_password_hash", hash_password(new_pass))
            db.commit()
            log_action("ChangeBackupGate", "settings", 0)
            flash("تم تغيير يوزر/باسوورد النسخ الاحتياطي.")
        else:
            flash("اكتب يوزر وباسوورد جديدين بحقلي \"يوزر/باسوورد جديد\" لتغييرهما.")
    else:
        flash("يوزر أو باسوورد النسخ الاحتياطي الحالي غير صحيح -- لم يتم أي تغيير.")
    return redirect(url_for("backup_center"))


def _build_offline_export(db):
    """يبني كل مكونات البحث والتفاصيل الكاملة بدون تنصيب أو ترخيص:
    1) صفحة فهرس (search_offline.html) للبحث باسم المريض/رقم التسجيل/التاريخ.
    2) ملف HTML مستقل لكل زيارة فيها تحليل مكتمل واحد على الأقل، بنفس
       التصميم الحقيقي حرفيًا لتقرير المريض (نفس الدالة المستخدمة أصلاً
       لتوليد ملف PDF الموحّد للأرشفة/واتساب: _build_combined_designed_reports_html) —
       فتحه من نفس الـUSB أو الـCD بأي متصفح يعرض كل الأرقام والقيم
       المرجعية بالضبط متل لو طُبع من داخل البرنامج، بدون أي اتصال أو
       تنصيب. الزيارات اللي ما فيها أي تحليل مكتمل بعد تظهر بالفهرس بس
       بدون رابط تقرير (لأنه ما فيه نتيجة جاهزة أصلاً تُطبع).
    يرجّع (index_html: str, report_files: dict[اسم الملف -> محتوى HTML])."""
    rows = db.execute(
        "SELECT v.id, v.registration_number, p.full_name, v.gender, v.age, v.age_unit, "
        "v.created_at, d.full_name as doctor_name, v.examining_doctor "
        "FROM visits v "
        "JOIN patients p ON p.id = v.patient_id "
        "LEFT JOIN doctors d ON d.id = v.doctor_id "
        "ORDER BY v.created_at DESC"
    ).fetchall()
    records = []
    report_files = {}
    for v in rows:
        tests = db.execute(
            "SELECT td.name, ot.status, ot.fee_waived FROM order_tests ot "
            "JOIN test_definitions td ON td.id = ot.test_definition_id "
            "JOIN orders o ON o.id = ot.order_id "
            "WHERE o.visit_id=? AND (ot.hidden_from_log IS NULL OR ot.hidden_from_log=0)",
            (v["id"],),
        ).fetchall()
        report_file = None
        try:
            combined_html = _build_combined_designed_reports_html(v["id"])
        except Exception:
            # ما نوقّف التصدير كامل بسبب تقرير وحيد فشل توليده -- نتجاهله
            # ونكمّل الباقي (نفس أسلوب _build_combined_designed_reports_html
            # نفسها مع كل تحليل).
            combined_html = None
        if combined_html:
            safe_name = secure_filename(str(v["registration_number"] or v["id"])) or f"visit_{v['id']}"
            filename = f"{safe_name}.html"
            if filename in report_files:
                filename = f"{safe_name}_{v['id']}.html"
            report_files[filename] = combined_html
            report_file = f"reports/{filename}"
        records.append({
            "reg": v["registration_number"],
            "name": v["full_name"],
            "gender": v["gender"],
            "age": f"{v['age'] or ''} {v['age_unit'] or ''}".strip(),
            "date": v["created_at"],
            "referring_doctor": v["doctor_name"] or "",
            "examining_doctor": v["examining_doctor"] or "",
            "tests": [
                {"name": t["name"], "status": t["status"], "free": bool(t["fee_waived"])}
                for t in tests
            ],
            "report_file": report_file,
        })
    data_json = json.dumps(records, ensure_ascii=False)
    html = """<!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="UTF-8">
<title>بحث نسخة احتياطية -- سجل المرضى</title>
<style>
body{font-family:Tahoma,Arial,sans-serif;background:#f3f6f8;margin:0;padding:20px;}
h1{color:#205072;font-size:18px;}
input{padding:8px;width:100%;max-width:420px;border:1px solid #cbd5e1;border-radius:6px;font-size:14px;}
table{width:100%;border-collapse:collapse;background:#fff;margin-top:14px;}
th,td{border:1px solid #e2e8f0;padding:6px 10px;font-size:13px;text-align:right;}
th{background:#205072;color:#fff;}
.muted{color:#64748b;font-size:12px;}
.free{color:#0f766e;font-weight:bold;}
a.report-link{background:#205072;color:#fff;text-decoration:none;padding:4px 10px;border-radius:5px;font-size:12px;white-space:nowrap;}
span.no-report{color:#94a3b8;font-size:12px;}
</style></head><body>
<h1>🔎 بحث كامل بالنسخة الاحتياطية (بدون تنصيب أو ترخيص)</h1>
<p class="muted">اضغط "عرض التقرير الكامل" لأي مريض عنده نتيجة جاهزة لعرض كل الأرقام والقيم المرجعية بنفس تصميم التقرير المطبوع بالضبط -- كل هذا يفتح من نفس الملفات المحلية بدون أي اتصال انترنت.</p>
<input id="q" type="text" placeholder="اكتب اسم المريض أو رقم التسجيل أو التاريخ...">
<table id="tbl"><thead><tr><th>رقم التسجيل</th><th>الاسم</th><th>الجنس</th><th>العمر</th><th>التاريخ</th><th>التحاليل</th><th>التقرير</th></tr></thead>
<tbody></tbody></table>
<script>
const DATA = __DATA_JSON__;
const tbody = document.querySelector('#tbl tbody');
function render(list) {
  tbody.innerHTML = '';
  list.slice(0, 300).forEach(function(r) {
    const testsStr = r.tests.map(function(t){ return t.name + (t.free ? ' (مجاني)' : ''); }).join('، ');
    const reportCell = r.report_file
      ? '<a class="report-link" target="_blank" href="' + r.report_file + '">📄 عرض التقرير الكامل</a>'
      : '<span class="no-report">لا توجد نتيجة جاهزة بعد</span>';
    const tr = document.createElement('tr');
    tr.innerHTML = '<td>' + r.reg + '</td><td>' + r.name + '</td><td>' + r.gender + '</td><td>' + r.age +
      '</td><td>' + r.date + '</td><td>' + testsStr + '</td><td>' + reportCell + '</td>';
    tbody.appendChild(tr);
  });
}
document.getElementById('q').addEventListener('input', function(e) {
  const q = e.target.value.trim().toLowerCase();
  if (!q) { render(DATA); return; }
  render(DATA.filter(function(r) {
    return (r.reg + ' ' + r.name + ' ' + r.date).toLowerCase().indexOf(q) !== -1;
  }));
});
render(DATA);
</script>
</body></html>"""
    return html.replace("__DATA_JSON__", data_json), report_files


@app.route("/management/backup/export", methods=["POST"])
@roles_required("admin")
def backup_export():
    db = get_db()
    ok, first_time = _check_backup_gate(db, request.form.get("username", "").strip(), request.form.get("password", ""))
    if first_time:
        flash("لازم تضبط يوزر/باسوورد النسخ الاحتياطي أولاً من نفس هذه الصفحة.")
        return redirect(url_for("backup_center"))
    if not ok:
        flash("يوزر أو باسوورد النسخ الاحتياطي غير صحيح -- لم يتم تصدير أي شيء.")
        return redirect(url_for("backup_center"))

    from database import DB_PATH
    # نسخ آمن لملف قاعدة البيانات عبر sqlite backup API (يتعامل صح حتى لو
    # فيه اتصال ثاني يستخدم الملف بنفس اللحظة، بعكس نسخ الملف مباشرة).
    tmp_dir = tempfile.mkdtemp(prefix="lis_backup_")
    db_copy_path = os.path.join(tmp_dir, "lis.db")
    src_conn = sqlite3.connect(DB_PATH)
    dst_conn = sqlite3.connect(db_copy_path)
    with dst_conn:
        src_conn.backup(dst_conn)
    src_conn.close()
    dst_conn.close()

    offline_html, report_files = _build_offline_export(db)
    manifest = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "hardware_id": license_manager.get_hardware_id(),
        "app": get_setting(db, "app_name", "LIS"),
        "reports_included": len(report_files),
    }

    zip_buf = BytesIO()
    with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(db_copy_path, "lis.db")
        zf.writestr("search_offline.html", offline_html)
        zf.writestr("backup_info.json", json.dumps(manifest, ensure_ascii=False, indent=2))
        # كل زيارة عندها نتيجة مكتملة تحصل على ملف تقرير كامل مستقل بنفس
        # التصميم الحقيقي بالضبط -- راجع _build_offline_export أعلاه.
        for filename, content in report_files.items():
            zf.writestr(f"reports/{filename}", content)
    zip_buf.seek(0)
    shutil.rmtree(tmp_dir, ignore_errors=True)

    set_setting(db, "last_backup_at", manifest["created_at"])
    db.commit()
    log_action("ExportBackup", "settings", 0, f"by={request.form.get('username','').strip()}")

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return send_file(zip_buf, mimetype="application/zip", as_attachment=True,
                      download_name=f"lis_backup_{stamp}.zip")


@app.route("/management/backup/import", methods=["POST"])
@roles_required("admin")
def backup_import():
    db = get_db()
    ok, first_time = _check_backup_gate(db, request.form.get("username", "").strip(), request.form.get("password", ""))
    if first_time:
        flash("لازم تضبط يوزر/باسوورد النسخ الاحتياطي أولاً من نفس هذه الصفحة.")
        return redirect(url_for("backup_center"))
    if not ok:
        flash("يوزر أو باسوورد النسخ الاحتياطي غير صحيح -- لم يتم استيراد أي شيء.")
        return redirect(url_for("backup_center"))

    uploaded = request.files.get("backup_file")
    if not uploaded or not uploaded.filename:
        flash("اختر ملف النسخة الاحتياطية (ZIP) أولاً.")
        return redirect(url_for("backup_center"))

    from database import DB_PATH
    tmp_dir = tempfile.mkdtemp(prefix="lis_restore_")
    zip_path = os.path.join(tmp_dir, "upload.zip")
    uploaded.save(zip_path)
    try:
        with zipfile.ZipFile(zip_path) as zf:
            if "lis.db" not in zf.namelist():
                flash("هذا الملف ليس نسخة احتياطية صالحة (ما فيه lis.db بداخله).")
                return redirect(url_for("backup_center"))
            zf.extract("lis.db", tmp_dir)
    except zipfile.BadZipFile:
        flash("تعذّر فتح الملف -- تأكد إنه ملف ZIP صالح من نفس البرنامج.")
        return redirect(url_for("backup_center"))

    extracted_db = os.path.join(tmp_dir, "lis.db")
    # تحقق سلامة قبل الاستبدال -- ما نستبدل قاعدة بيانات تالفة أو ملف مو حتى sqlite
    try:
        check_conn = sqlite3.connect(extracted_db)
        result = check_conn.execute("PRAGMA integrity_check").fetchone()
        check_conn.close()
        if not result or result[0] != "ok":
            flash("ملف قاعدة البيانات بالنسخة الاحتياطية غير سليم -- تم إلغاء الاستيراد.")
            shutil.rmtree(tmp_dir, ignore_errors=True)
            return redirect(url_for("backup_center"))
    except Exception:
        flash("تعذّر التحقق من ملف قاعدة البيانات -- تم إلغاء الاستيراد.")
        shutil.rmtree(tmp_dir, ignore_errors=True)
        return redirect(url_for("backup_center"))

    # نسخة احتياطية تلقائية من القاعدة الحالية قبل الاستبدال -- تحسبًا لأي غلط
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safety_copy = os.path.join(os.path.dirname(DB_PATH), f"lis_before_restore_{stamp}.db")
    shutil.copy2(DB_PATH, safety_copy)

    shutil.copy2(extracted_db, DB_PATH)
    shutil.rmtree(tmp_dir, ignore_errors=True)
    log_action("ImportBackup", "settings", 0, f"by={request.form.get('username','').strip()}")
    flash("تم استيراد النسخة الاحتياطية بنجاح. أعد تشغيل البرنامج الآن حتى تظهر البيانات المستوردة بشكل صحيح "
          f"(نسخة القاعدة القديمة محفوظة احتياطًا باسم lis_before_restore_{stamp}.db بجانب البرنامج).")
    return redirect(url_for("backup_center"))



@roles_required("admin")
def toggle_auto_update():
    db = get_db()
    currently_on = get_setting(db, "auto_update_enabled", "1") == "1"
    set_setting(db, "auto_update_enabled", "0" if currently_on else "1")
    db.commit()
    log_action("ToggleAutoUpdate", "settings", 0, "off" if currently_on else "on")
    db.close()
    flash("تم إيقاف التحديث التلقائي." if currently_on else "تم تفعيل التحديث التلقائي.")
    return redirect(request.referrer or url_for("dashboard"))


# ------------------------------------------------------------------------
# إدارة قائمة (دكتور المختبر الفاحص) — اسم/لقب/شهادة عربي/شهادة انكليزي
# وترتيب يدوي (فوق/تحت)، بالإضافة لمفتاح "إظهار بترويسة التقرير" لكل واحد
# منهم. مفتوحة من بطاقة "دكتور المختبر الفاحص" بصفحة الإعدادات. الأسماء
# نفسها تبقى تُستخدم كنص بجداول أخرى (أجور الفحص، الزيارات) فتغيير الاسم
# هنا لا يحدّث تلقائيًا سجلات قديمة محفوظة بالاسم السابق.
# ------------------------------------------------------------------------
@app.route("/management/examining-doctors", methods=["GET"])
@roles_required("admin")
def examining_doctors_manage():
    db = get_db()
    doctors = get_examining_doctors_full(db)
    return render_template("management/examining_doctors.html", doctors=doctors)


@app.route("/management/examining-doctors/add", methods=["POST"])
@roles_required("admin")
def examining_doctor_add():
    db = get_db()
    name = request.form.get("name", "").strip()
    if not name:
        flash("اسم الدكتور مطلوب.")
        return redirect(url_for("examining_doctors_manage"))
    title = request.form.get("title", "الدكتور").strip()
    degree_ar = request.form.get("degree_ar", "").strip() or None
    degree_en = request.form.get("degree_en", "").strip() or None
    show_on_letterhead = bool(request.form.get("show_on_letterhead"))
    # حجم خط مخصص لهذا الدكتور تحديداً بالترويسة (اختياري) — يتجاوز الحجم
    # العام letterhead_font_size من الإعدادات لو تُرك فاضي يرث العام كالمعتاد.
    font_size_raw = request.form.get("font_size", "").strip()
    font_size = None
    if font_size_raw:
        try:
            font_size = max(8, min(30, int(font_size_raw)))
        except ValueError:
            font_size = None
    add_examining_doctor_full(db, name, title, degree_ar, degree_en, show_on_letterhead, font_size)
    log_action("AddExaminingDoctor", "examining_doctor", 0, name)
    flash(f"تمت إضافة \"{name}\".")
    return redirect(url_for("examining_doctors_manage"))


@app.route("/management/examining-doctors/<int:doctor_id>/update", methods=["POST"])
@roles_required("admin")
def examining_doctor_update(doctor_id):
    db = get_db()
    name = request.form.get("name", "").strip()
    if not name:
        flash("اسم الدكتور مطلوب.")
        return redirect(url_for("examining_doctors_manage"))
    title = request.form.get("title", "الدكتور").strip()
    degree_ar = request.form.get("degree_ar", "").strip() or None
    degree_en = request.form.get("degree_en", "").strip() or None
    show_on_letterhead = bool(request.form.get("show_on_letterhead"))
    font_size_raw = request.form.get("font_size", "").strip()
    font_size = None
    if font_size_raw:
        try:
            font_size = max(8, min(30, int(font_size_raw)))
        except ValueError:
            font_size = None
    update_examining_doctor(db, doctor_id, name, title, degree_ar, degree_en, show_on_letterhead, font_size)
    log_action("UpdateExaminingDoctor", "examining_doctor", doctor_id, name)
    flash(f"تم حفظ تعديلات \"{name}\".")
    return redirect(url_for("examining_doctors_manage"))


@app.route("/management/examining-doctors/<int:doctor_id>/delete", methods=["POST"])
@roles_required("admin")
def examining_doctor_delete(doctor_id):
    db = get_db()
    delete_examining_doctor(db, doctor_id)
    log_action("DeleteExaminingDoctor", "examining_doctor", doctor_id)
    flash("تم الحذف.")
    return redirect(url_for("examining_doctors_manage"))


@app.route("/management/examining-doctors/<int:doctor_id>/move", methods=["POST"])
@roles_required("admin")
def examining_doctor_move(doctor_id):
    db = get_db()
    direction = request.form.get("direction", "")
    if direction in ("up", "down"):
        move_examining_doctor(db, doctor_id, direction)
    return redirect(url_for("examining_doctors_manage"))


# ------------------------------------------------------------------------
# مكتبة الأختام والتواقيع الرقمية — أيقونة/صفحة إدارة واحدة تسمح بإضافة أي
# عدد من الأختام (ختم المختبر نفسه + ختم/توقيع كل دكتور فاحص على حدة، لأن
# كل واحد منهم مختلف عن الثاني) بدون أي حصر. كل صورة تُحفظ دائمًا بخلفية
# بيضاء صلبة (راجع _save_stamp_image_on_white_bg) حتى تظهر واضحة وكأنها
# ختم/توقيع حقيقي فوق التقرير المطبوع، وليست "نشازًا". من نفس الشاشة يقدر
# المدير يربط أي ختم باسم دكتور فاحص محدد من القائمة (اختياري) — هذا الربط
# بس اقتراح تلقائي لاحقًا، ولا يمنع اختيار أي ختم آخر يدويًا عند إتمام
# التقرير (راجع stamp_placement_* أدناه لآلية الإلصاق الفعلي فوق تقرير
# معيّن مع إمكانية سحبه لأي موضع).
# ------------------------------------------------------------------------
@app.route("/management/stamps", methods=["GET"])
@roles_required("admin")
def stamps_manage():
    db = get_db()
    stamps = get_digital_stamps(db, active_only=False)
    doctors = get_examining_doctors_full(db)
    return render_template("management/stamps.html", stamps=stamps, doctors=doctors)


@app.route("/management/stamps/add", methods=["POST"])
@roles_required("admin")
def stamp_add():
    db = get_db()
    label = (request.form.get("label") or "").strip()
    kind = request.form.get("kind") or "stamp"
    if kind not in ("stamp", "signature", "stamp_signature"):
        kind = "stamp"
    linked_doctor_raw = request.form.get("linked_examining_doctor_id") or ""
    linked_doctor_id = int(linked_doctor_raw) if linked_doctor_raw.isdigit() else None
    is_lab_default = bool(request.form.get("is_lab_default"))
    file = request.files.get("image")
    # signature_image: صورة توقيع منفصلة اختيارية — تُلصق فوق صورة الختم
    # مباشرة (ملاصقة بدون فراغ) وتتحرك معها كوحدة واحدة دائمًا (راجع
    # partials/stamp_picker.html). اتركها فاضية لو الصورة المرفوعة أعلاه
    # أصلاً تجمع الختم والتوقيع سوا بصورة واحدة.
    sig_file = request.files.get("signature_image")

    if not label:
        flash("اسم/تسمية الختم أو التوقيع مطلوبة (مثلاً: ختم د. خليل حمود).")
        return redirect(url_for("stamps_manage"))
    if not file or not file.filename:
        flash("لازم ترفع صورة الختم أو التوقيع.")
        return redirect(url_for("stamps_manage"))
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ext not in ALLOWED_STAMP_EXT:
        flash("صيغة الصورة غير مدعومة — استخدم PNG أو JPG أو WEBP.")
        return redirect(url_for("stamps_manage"))
    sig_ext = ""
    if sig_file and sig_file.filename:
        sig_ext = sig_file.filename.rsplit(".", 1)[-1].lower() if "." in sig_file.filename else ""
        if sig_ext not in ALLOWED_STAMP_EXT:
            flash("صيغة صورة التوقيع غير مدعومة — استخدم PNG أو JPG أو WEBP.")
            return redirect(url_for("stamps_manage"))

    # نحجز id أولاً بصف مؤقت (اسم ملف فاضي) حتى نقدر نسمّي ملفات الصور
    # stamp_<id>.png / stamp_<id>_sig.png بنفس رقم الصف مباشرة، ثم نحدّثه
    # بعد حفظ الصور فعليًا.
    new_id = add_digital_stamp(db, label, kind, image_filename="",
                                linked_examining_doctor_id=linked_doctor_id,
                                created_by=session.get("user_id"), is_lab_default=is_lab_default)
    try:
        filename = _save_stamp_image_on_white_bg(file, new_id)
        sig_filename = _save_stamp_image_on_white_bg(sig_file, new_id, suffix="_sig") if sig_ext else None
    except Exception:
        delete_digital_stamp(db, new_id)
        flash("تعذّر معالجة الصورة المرفوعة — تأكد إنها صورة صالحة، وإن مكتبة Pillow مثبّتة على الجهاز (pip install Pillow).")
        return redirect(url_for("stamps_manage"))
    db.execute("UPDATE digital_stamps SET image_filename=?, signature_filename=? WHERE id=?",
               (filename, sig_filename, new_id))
    db.commit()
    log_action("AddDigitalStamp", "digital_stamp", new_id, label)
    flash(f"تمت إضافة \"{label}\" لمكتبة الأختام والتواقيع.")
    return redirect(url_for("stamps_manage"))


@app.route("/management/stamps/<int:stamp_id>/update", methods=["POST"])
@roles_required("admin")
def stamp_update(stamp_id):
    db = get_db()
    label = (request.form.get("label") or "").strip()
    kind = request.form.get("kind") or "stamp"
    if kind not in ("stamp", "signature", "stamp_signature"):
        kind = "stamp"
    linked_doctor_raw = request.form.get("linked_examining_doctor_id") or ""
    linked_doctor_id = int(linked_doctor_raw) if linked_doctor_raw.isdigit() else None
    is_active = bool(request.form.get("is_active"))
    is_lab_default = bool(request.form.get("is_lab_default"))
    if not label:
        flash("اسم/تسمية الختم أو التوقيع مطلوبة.")
        return redirect(url_for("stamps_manage"))
    update_digital_stamp(db, stamp_id, label, kind, linked_doctor_id, is_active, is_lab_default)
    log_action("UpdateDigitalStamp", "digital_stamp", stamp_id, label)
    flash(f"تم حفظ تعديلات \"{label}\".")
    return redirect(url_for("stamps_manage"))


@app.route("/management/stamps/<int:stamp_id>/delete", methods=["POST"])
@roles_required("admin")
def stamp_delete(stamp_id):
    db = get_db()
    stamp = get_digital_stamp(db, stamp_id)
    if stamp:
        delete_digital_stamp(db, stamp_id)
        try:
            os.remove(os.path.join(STAMPS_UPLOAD_DIR, stamp["image_filename"]))
        except OSError:
            pass
        if stamp["signature_filename"]:
            try:
                os.remove(os.path.join(STAMPS_UPLOAD_DIR, stamp["signature_filename"]))
            except OSError:
                pass
        log_action("DeleteDigitalStamp", "digital_stamp", stamp_id, stamp["label"])
    flash("تم الحذف.")
    return redirect(url_for("stamps_manage"))


# API خفيف يرجّع قائمة الأختام/التواقيع الفعّالة (JSON) — يُستخدم بالقائمة
# المنسدلة "إضافة ختم/توقيع" بشاشة إتمام/طباعة أي تقرير (راجع
# partials/stamp_picker.html).
@app.route("/api/stamps/list")
@login_required
def api_stamps_list():
    db = get_db()
    kind = request.args.get("kind") or None
    stamps = get_digital_stamps(db, kind=kind, active_only=True)
    return jsonify([{
        "id": s["id"],
        "label": s["label"],
        "kind": s["kind"],
        "doctor_name": s["doctor_name"],
        "default_width": s["default_width"],
        "image_url": url_for("static", filename=f"uploads/stamps/{s['image_filename']}"),
    } for s in stamps])


# إلصاق/تحريك ختم فوق تقرير معيّن (target_type: 'visit' لتقرير موحّد لكل
# نتائج الزيارة، أو 'order_test' لتحليل مفرد) — تُستدعى بـfetch من جافاسكربت
# كل ما المستخدم يفلت الختم بمكان جديد بعد سحبه (drag&drop)، فتتحدّث فقط
# بدل ما تتكرر (راجع upsert_stamp_placement بقاعدة البيانات).
@app.route("/api/reports/<target_type>/<int:target_id>/stamps", methods=["GET"])
@login_required
def api_report_stamps_get(target_type, target_id):
    if target_type not in ("visit", "order_test"):
        return jsonify({"error": "target_type غير صحيح"}), 400
    db = get_db()
    placements = get_stamp_placements(db, target_type, target_id)
    return jsonify(_serialize_stamp_placements(placements))


@app.route("/api/reports/<target_type>/<int:target_id>/stamps", methods=["POST"])
@login_required
def api_report_stamps_place(target_type, target_id):
    if target_type not in ("visit", "order_test"):
        return jsonify({"error": "target_type غير صحيح"}), 400
    db = get_db()
    try:
        stamp_id = int(request.form.get("stamp_id"))
        pos_x = float(request.form.get("pos_x", 40))
        pos_y = float(request.form.get("pos_y", 40))
        width_raw = request.form.get("width")
        width = float(width_raw) if width_raw else None
    except (TypeError, ValueError):
        return jsonify({"error": "بيانات غير صالحة"}), 400
    placement_id = upsert_stamp_placement(db, target_type, target_id, stamp_id, pos_x, pos_y,
                                           width, placed_by=session.get("user_id"))
    log_action("PlaceStamp", target_type, target_id, f"stamp_id={stamp_id}")
    return jsonify({"ok": True, "placement_id": placement_id})


@app.route("/api/reports/stamps/<int:placement_id>/remove", methods=["POST"])
@login_required
def api_report_stamps_remove(placement_id):
    db = get_db()
    remove_stamp_placement(db, placement_id)
    log_action("RemoveStamp", "stamp_placement", placement_id)
    return jsonify({"ok": True})


def _parse_docx_rows(file_storage, parameters):
    """Read an admin-uploaded Word (.docx) reference report and pull out an
    ordered list of {"param_name", "label"} rows by matching each line/cell
    of text in the document against this test's existing parameter names.
    Returns (rows, matched_count, total_lines_found)."""
    try:
        import docx  # python-docx
    except ImportError:
        return None, 0, 0

    document = docx.Document(file_storage)
    param_by_lower = {p["name"].strip().lower(): p["name"] for p in parameters}

    def match_param(text):
        low = text.strip().lower()
        low = low.rstrip(":.").strip()
        if not low:
            return None
        if low in param_by_lower:
            return param_by_lower[low]
        for pname_low, pname in param_by_lower.items():
            if pname_low and (pname_low in low or low in pname_low):
                return pname
        return None

    raw_lines = []
    for table in document.tables:
        for trow in table.rows:
            cells = [c.text.strip() for c in trow.cells if c.text.strip()]
            if cells:
                raw_lines.append(cells[0])
    if not raw_lines:
        for para in document.paragraphs:
            text = para.text.strip()
            if text:
                raw_lines.append(text)

    rows = []
    matched = 0
    seen = set()
    for line in raw_lines:
        pname = match_param(line)
        if pname and pname in seen:
            continue
        if pname:
            seen.add(pname)
            matched += 1
        rows.append({"param_name": pname or "", "label": line})
    return rows, matched, len(raw_lines)


@app.route("/management/report-designer", methods=["GET", "POST"])
@roles_required("admin")
def report_designer():
    db = get_db()
    hardcoded_codes = set(REPORT_TEMPLATE_MAP.keys())

    if request.method == "POST":
        test_id = request.form.get("test_definition_id")
        test = db.execute("SELECT * FROM test_definitions WHERE id=?", (test_id,)).fetchone()
        if not test:
            flash("التحليل غير موجود.")
            return redirect(url_for("report_designer"))

        parameters = db.execute(
            "SELECT * FROM test_parameters WHERE test_definition_id=? ORDER BY sort_order, id", (test_id,)
        ).fetchall()
        mode = request.form.get("mode", "manual")
        source_docx_name = None
        existing_tpl = get_report_template(db, test_id)
        heading_align = request.form.get("heading_align") or (existing_tpl["heading_align"] if existing_tpl else None) or "center"
        rows_align = request.form.get("rows_align") or (existing_tpl["rows_align"] if existing_tpl else None) or "right"

        if mode == "print_options":
            # خيارات الختم والتوقيع + عمود كل باراميتر بالتقرير (مصمم التقارير).
            show_lab_stamp = 1 if request.form.get("show_lab_stamp") else 0
            show_doctor_stamp = 1 if request.form.get("show_doctor_stamp") else 0
            hide_signature_box = 1 if request.form.get("hide_signature_box") else 0
            sig_pos = request.form.get("signature_position", "")
            sig_pos = sig_pos if sig_pos in ("left", "center", "right") else None
            db.execute(
                "UPDATE test_definitions SET show_lab_stamp=?, show_doctor_stamp=?, "
                "hide_signature_box=?, signature_position=? WHERE id=?",
                (show_lab_stamp, show_doctor_stamp, hide_signature_box, sig_pos, test_id),
            )
            for p in parameters:
                col = request.form.get(f"report_column_{p['id']}", "")
                col = col if col in ("1", "2") else None
                db.execute("UPDATE test_parameters SET report_column=? WHERE id=?", (col, p["id"]))
            db.commit()
            log_action("UpdatePrintOptions", "test_definition", int(test_id), "print_options")
            flash("تم حفظ خيارات الختم والتوقيع وأعمدة الباراميترات.")
            return redirect(url_for("report_designer", test_definition_id=test_id))

        if mode == "stamp":
            # تفعيل/تعطيل صندوق "إضافة ختم / توقيع" التفاعلي لهذا التحليل —
            # عام لكل أنواع التقارير (جاهزة أو مخصصة)، منفصل تمامًا عن تصميم
            # الجدول نفسه. معطّل افتراضيًا (0) بكل التحاليل القديمة والجديدة.
            enable_stamp_widget = 1 if request.form.get("enable_stamp_widget") else 0
            db.execute("UPDATE test_definitions SET enable_stamp_widget=? WHERE id=?", (enable_stamp_widget, test_id))
            db.commit()
            log_action("UpdateStampWidgetSetting", "test_definition", int(test_id), str(enable_stamp_widget))
            flash("تم حفظ إعداد صندوق الختم/التوقيع.")
            return redirect(url_for("report_designer", test_definition_id=test_id))

        if mode == "done_by":
            # سطر "Done by ..." الاختياري لهذا التحليل تحديداً (المطلوب 7) —
            # فاضي = لا يظهر أبداً بـ.footer-block أي تقرير لهذا التحليل.
            done_by_note = request.form.get("done_by_note", "").strip() or None
            db.execute("UPDATE test_definitions SET done_by_note=? WHERE id=?", (done_by_note, test_id))
            db.commit()
            log_action("UpdateDoneByNote", "test_definition", int(test_id), done_by_note or "")
            flash("تم حفظ سطر Done by.")
            return redirect(url_for("report_designer", test_definition_id=test_id))

        if mode == "spacing":
            # المسافة بين صفوف الباراميترات (المطلوب 8) — تنطبق على exam
            # rows وcustom cards وCBC وcombined panel لنفس هذا التحليل.
            # فاضي = رجوع للتباعد الافتراضي القديم (بدون أي تغيير). راجع
            # row_spacing_px أعلى الملف لكيفية تفسير القيمة المحفوظة.
            spacing_choice = request.form.get("row_spacing_preset", "").strip()
            spacing_custom = request.form.get("row_spacing_custom", "").strip()
            row_spacing_value = spacing_custom if spacing_choice == "custom" and spacing_custom else (spacing_choice or None)
            db.execute("UPDATE test_definitions SET row_spacing=? WHERE id=?", (row_spacing_value, test_id))
            db.commit()
            log_action("UpdateRowSpacing", "test_definition", int(test_id), row_spacing_value or "")
            flash("تم حفظ إعداد التباعد بين الصفوف.")
            return redirect(url_for("report_designer", test_definition_id=test_id))

        if mode == "param_overrides":
            # تسمية عرض بديلة + محاذاة رقم النتيجة لكل باراميتر (المطلوب 9ب
            # و11) — فورم واحد يرسل صفوف كل باراميترات هذا التحليل سوا
            # (label_<param_id> و align_<param_id>). فاضي/"" = رجوع للاسم
            # الأصلي أو المحاذاة الافتراضية القديمة (بدون أي تغيير).
            for p in parameters:
                label_val = request.form.get(f"label_{p['id']}", "").strip() or None
                align_val = request.form.get(f"align_{p['id']}", "").strip() or None
                if align_val not in ("near_name", "center", "near_unit"):
                    align_val = None
                db.execute(
                    "UPDATE test_parameters SET display_label=?, value_align=? WHERE id=?",
                    (label_val, align_val, p["id"]),
                )
            db.commit()
            log_action("UpdateParamOverrides", "test_definition", int(test_id), "")
            flash("تم حفظ تسميات ومحاذاة الباراميترات.")
            return redirect(url_for("report_designer", test_definition_id=test_id))

        if mode == "docx":
            file = request.files.get("docx_file")
            if not file or not file.filename:
                flash("لم تختر ملف Word.")
                return redirect(url_for("report_designer", test_definition_id=test_id))
            ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
            if ext not in ALLOWED_DOCX_EXT:
                flash("صيغة الملف يجب أن تكون .docx")
                return redirect(url_for("report_designer", test_definition_id=test_id))
            rows, matched, total = _parse_docx_rows(file, parameters)
            if rows is None:
                flash("مكتبة قراءة ملفات Word (python-docx) غير مثبتة بعد. شغّل تشغيل البرنامج.vbs مرة واحدة وأنت متصل بالإنترنت ليتم تثبيتها تلقائيًا، ثم أعد المحاولة.")
                return redirect(url_for("report_designer", test_definition_id=test_id))
            if not rows:
                flash("لم أجد أي صفوف أو نصوص داخل ملف Word هذا.")
                return redirect(url_for("report_designer", test_definition_id=test_id))
            rows_json = json.dumps(rows, ensure_ascii=False)
            source_docx_name = secure_filename(file.filename)
            save_report_template(db, test_id, test["name"], rows_json, source_docx_name, session.get("user_id"),
                                  heading_align=heading_align, rows_align=rows_align)
            log_action("SaveReportTemplate", "test_definition", int(test_id), f"docx:{source_docx_name}")
            flash(f"تم استيراد التصميم من Word: {matched} من {total} سطر تم ربطها تلقائيًا بنتائج التحليل. "
                  f"الشعار وترويسة الأطباء وذيل الصفحة ستُضاف تلقائيًا عند الطباعة — راجع الصفوف غير المرتبطة (إن وجدت) وعدّلها يدويًا أدناه.")
            return redirect(url_for("report_designer", test_definition_id=test_id))

        if mode == "panel":
            # إعدادات "اللوحة المجمّعة" — مستويان: (أ) التحليل كامل، تنطبق
            # على كل باراميتراته كسلوك احتياطي؛ (ب) كل باراميتر لحاله
            # (panel_color_<pid>/panel_page_break_<pid>) تكتسح مستوى التحليل
            # لنفس الباراميتر لو ضُبطت — تسمح بتلوين/فصل باراميتر وحدة بس
            # (زي NRBC) داخل تحليل متعدد الباراميترات دون التأثير على الباقي.
            panel_color = request.form.get("panel_color", "").strip()
            enable_panel_color = bool(request.form.get("enable_panel_color"))
            panel_color_val = panel_color if (enable_panel_color and panel_color and _HEX_COLOR_RE.match(panel_color)) else None
            panel_page_break = 1 if request.form.get("panel_page_break") else 0
            db.execute(
                "UPDATE test_definitions SET panel_color=?, panel_page_break=? WHERE id=?",
                (panel_color_val, panel_page_break, test_id),
            )
            for p in parameters:
                pid = p["id"]
                p_color = request.form.get(f"param_panel_color_{pid}", "").strip()
                p_enable = bool(request.form.get(f"enable_param_panel_color_{pid}"))
                p_color_val = p_color if (p_enable and p_color and _HEX_COLOR_RE.match(p_color)) else None
                p_page_break = 1 if request.form.get(f"param_panel_page_break_{pid}") else 0
                db.execute(
                    "UPDATE test_parameters SET panel_color=?, panel_page_break=? WHERE id=?",
                    (p_color_val, p_page_break, pid),
                )
            db.commit()
            log_action("UpdatePanelSettings", "test_definition", int(test_id), "panel")
            flash("تم حفظ إعدادات اللوحة المجمّعة.")
            return redirect(url_for("report_designer", test_definition_id=test_id))

        # mode == manual: rebuild the row order from the submitted list of
        # parameter ids (checked + reordered by the admin in the form).
        heading = request.form.get("heading", "").strip() or test["name"]
        ordered_param_ids = request.form.getlist("param_order")
        rows = []
        params_by_id = {str(p["id"]): p for p in parameters}
        for pid in ordered_param_ids:
            p = params_by_id.get(pid)
            if p:
                row = {"param_name": p["name"], "label": p["name"]}
                # حرية تحريك الحقول لكل صف — تُقرأ فقط لو مصمم التقرير
                # (report_designer.html) يرسلها فعليًا كحقول name_side_<id>/
                # range_position_<id> (زر أو قائمة اختيار جنب كل صف)؛ إذا ما
                # أُرسلت (كل الحالات الحالية) تبقى القيم الافتراضية كما هي
                # ولا يتغيّر أي تصميم محفوظ سابقًا.
                name_side = request.form.get(f"name_side_{pid}")
                if name_side in ("left", "right"):
                    row["name_side"] = name_side
                range_position = request.form.get(f"range_position_{pid}")
                if range_position in ("inline", "below"):
                    row["range_position"] = range_position
                # لون مخصص لهذا التحليل (اسمه ونتيجته) — اختياري، فاضي يعني
                # يبقى باللون الافتراضي بكل التقرير. وفاصل صفحة: لو مفعّل،
                # هذا التحليل يبدأ دائمًا بأعلى صفحة جديدة عند الطباعة (يُقرأ
                # بـ custom.html كـ page-break-before قبل بطاقة هذا الصف).
                row_color = request.form.get(f"row_color_{pid}", "").strip()
                if request.form.get(f"enable_color_{pid}") and row_color and _HEX_COLOR_RE.match(row_color):
                    row["color"] = row_color
                if request.form.get(f"page_break_{pid}"):
                    row["page_break_before"] = True
                rows.append(row)
        if not rows:
            flash("اختر باراميتر واحد على الأقل لتصميم التقرير.")
            return redirect(url_for("report_designer", test_definition_id=test_id))
        rows_json = json.dumps(rows, ensure_ascii=False)
        # unit_column ثابتة 1 دائمًا الآن (المطلوب: عمود نتيجة وعمود وحدة
        # مستقلّين بكل تقرير، بلا استثناء) — عمود report_templates.unit_column
        # نفسه يبقى بقاعدة البيانات (بدون DROP) لعدم فقدان بيانات قديمة، بس
        # ما عاد يُقرأ من فورم ولا يُقرأ شرطيًا بالقوالب (custom.html صارت
        # تطبع بهذا التخطيط دائمًا بغض النظر عن قيمته).
        save_report_template(db, test_id, heading, rows_json, None, session.get("user_id"),
                              heading_align=heading_align, rows_align=rows_align, unit_column=1)
        log_action("SaveReportTemplate", "test_definition", int(test_id), "manual")
        flash("تم حفظ تصميم التقرير. الشعار سيُضاف تلقائيًا عند الطباعة.")
        return redirect(url_for("report_designer", test_definition_id=test_id))

    all_tests = db.execute(
        "SELECT * FROM test_definitions WHERE is_active=1 ORDER BY department, name"
    ).fetchall()
    tests_status = []
    for test in all_tests:
        has_builtin = test["code"] in hardcoded_codes
        custom = get_report_template(db, test["id"])
        tests_status.append({
            "test": test,
            "has_builtin": has_builtin,
            "has_custom": bool(custom),
            "needs_design": False,
            "auto_ok": (not has_builtin and not custom and bool(db.execute(
                "SELECT 1 FROM test_parameters WHERE test_definition_id=? LIMIT 1", (test["id"],)).fetchone())),
        })
        tests_status[-1]["needs_design"] = not has_builtin and not custom and not tests_status[-1]["auto_ok"]

    selected_id = request.args.get("test_definition_id", type=int)
    selected_test = None
    selected_parameters = []
    selected_template = None
    selected_rows_by_param = {}
    if selected_id:
        selected_test = db.execute("SELECT * FROM test_definitions WHERE id=?", (selected_id,)).fetchone()
        if selected_test:
            selected_parameters = db.execute(
                "SELECT * FROM test_parameters WHERE test_definition_id=? ORDER BY sort_order, id", (selected_id,)
            ).fetchall()
            selected_template = get_report_template(db, selected_id)
            if selected_template:
                for r in json.loads(selected_template["rows_json"] or "[]"):
                    selected_rows_by_param[r.get("param_name", "")] = r

    # ترتيب عرض الباراميترات بشاشة التصميم يدويًا: لو فيه تصميم محفوظ سابقًا،
    # نعرضهم بنفس ترتيب rows_json المحفوظ (نفس ترتيب الطباعة فعليًا) أولاً،
    # وأي باراميتر جديد أُضيف للتحليل لاحقًا (بعد آخر حفظ) يُلحق بالنهاية غير
    # مؤشر عليه — هذا يخلي "إضافة تحليل/باراميتر جديد لاحقًا" يظهر تلقائيًا
    # هنا جاهز للتأشير عليه دون أي خطوة إضافية. بدون تصميم سابق، الترتيب
    # الافتراضي هو ترتيب الإدخال بقاعدة البيانات كالمعتاد.
    ordered_selected_params = list(selected_parameters)
    if selected_template:
        params_by_name = {p["name"]: p for p in selected_parameters}
        saved_order = [r.get("param_name", "") for r in json.loads(selected_template["rows_json"] or "[]")]
        seen = set()
        ordered = []
        for name in saved_order:
            p = params_by_name.get(name)
            if p and name not in seen:
                ordered.append(p)
                seen.add(name)
        for p in selected_parameters:
            if p["name"] not in seen:
                ordered.append(p)
                seen.add(p["name"])
        ordered_selected_params = ordered

    return render_template(
        "management/report_designer.html",
        tests_status=tests_status, selected_test=selected_test,
        selected_parameters=ordered_selected_params, selected_template=selected_template,
        selected_rows_by_param=selected_rows_by_param,
        result_layout=get_result_layout(db), result_label_defaults=RESULT_LABEL_DEFAULTS,
        merged_exclude_default=", ".join(MERGED_EXCLUDE_DEFAULT),
        result_extra_values=get_extra_col_values(db),
        heading_dept_names=[r[0] for r in db.execute(
            "SELECT DISTINCT COALESCE(NULLIF(TRIM(report_group), ''), department) AS n FROM test_definitions "
            "WHERE COALESCE(NULLIF(TRIM(report_group), ''), department) IS NOT NULL "
            "AND TRIM(COALESCE(NULLIF(TRIM(report_group), ''), department)) <> '' ORDER BY n").fetchall()],
        text_style_fonts=list(TEXT_STYLE_FONTS.keys()),
        **_report_designs_context(db),
    )


@app.route("/management/report-designer/preview/<int:test_definition_id>")
@roles_required("admin")
def preview_report_design(test_definition_id):
    try:
        return _preview_report_design_impl(test_definition_id)
    except Exception:
        import traceback
        tb_text = traceback.format_exc()
        try:
            log_path = os.path.join(os.path.dirname(__file__), "error_log.txt")
            with open(log_path, "a", encoding="utf-8") as f:
                f.write("\n" + "=" * 80 + "\n")
                f.write(datetime.now().isoformat(timespec="seconds") + f"  preview test_definition_id={test_definition_id}\n")
                f.write(tb_text)
        except Exception:
            pass
        return (
            "<h1>خطأ أثناء معاينة التصميم — test_definition_id="
            + str(test_definition_id)
            + "</h1><p>صوّر هذا النص كامل وأرسله:</p>"
            + "<pre style='direction:ltr; text-align:left; white-space:pre-wrap; "
            + "background:#f5f5f5; border:1px solid #ccc; padding:12px;'>"
            + escape(tb_text)
            + "</pre>"
        ), 500


# قيم نموذجية لمعاينة تقارير الفحص (نفس القيم الظاهرة بالمعاينة المعتمدة preview_3)
EXAM_PREVIEW_SAMPLES = {
    "GUE": {"Color": "Yellow", "Specific Gravity": "1.020", "Reaction (pH)": "6.0", "Glucose": "Negative",
            "Protein": "Negative", "Ketone": "Negative", "Bile Pigment": "Negative", "Urobilinogen": "0.2",
            "Nitrite": "Negative", "RBCs": "1-2", "PUS": "2-3", "PUS (WBCs)": "2-3", "Casts": "Nil",
            "Epithelial Cells": "Few", "Amorphous": "Nil", "Mucus": "Nil", "Crystals": "Nil",
            "Parasites": "Nil", "Parasites / Others": "Nil"},
    "GSE": {"Color": "Brown", "Consistency": "Formed", "Mucus": "Nil", "Blood": "Nil", "Worms / Helminths": "Nil",
            "Pus Cells": "0-1", "RBCs": "Nil", "Amoeba (E. histolytica)": "Not seen", "Giardia lamblia": "Not seen",
            "Helminthes Ova": "Not seen", "Undigested Food Particles": "Nil", "Fungi / Yeast": "Nil"},
    "SFA": {"Volume": "3.2", "Color / Appearance": "Grey-white", "Liquefaction Time": "25", "Viscosity": "Normal",
            "pH": "7.9", "Sperm Count": "42", "Total Sperm Count": "134", "Active (Progressive)": "48",
            "Sluggish (Non-progressive)": "22", "Immotile": "30", "Normal Forms": "6", "Abnormal Forms": "94",
            "Pus Cells": "1-2", "RBCs": "Nil", "Agglutination": "Nil"},
}


def _preview_report_design_impl(test_definition_id):
    # Renders the exact same report template print_report() uses, but with
    # clearly-labeled sample data instead of a real order/patient — so the
    # admin can actually SEE a built-in or custom design (logo, headings,
    # row layout) from the report-designer page without needing to create a
    # real visit/result first. Reads test_definitions/test_parameters only;
    # never touches patient, visit, or result data.
    db = get_db()
    test = db.execute("SELECT * FROM test_definitions WHERE id=?", (test_definition_id,)).fetchone()
    if not test:
        return "Not found", 404

    template_name = REPORT_TEMPLATE_MAP.get(test["code"])
    _coag_table = (test["code"] == "COAG" and _coag_table_mode(db))
    if _coag_table:
        template_name = None
    custom_template = None
    if not template_name and test["report_style"] == "generic_exam":
        template_name = "reports/generic_exam.html"
    if not template_name:
        custom_template = get_report_template(db, test_definition_id)
        if not custom_template:
            # بلا قالب محفوظ: نعاين التصميم التلقائي (نفس ما ستطبعه الطباعة الفعلية بأسلوب جدول النتائج)
            custom_template = _auto_report_template(db, test_definition_id, test["name"])
        if not custom_template:
            flash("لا يوجد تصميم لهذا التحليل بعد لتتم معاينته. صممه أولاً بالأسفل.")
            return redirect(url_for("report_designer", test_definition_id=test_definition_id))
        if uses_order_style_report(test["department"], test["report_style"]):
            template_name = "reports/custom_v2.html"
        else:
            template_name = "reports/custom.html"

    parameters = db.execute(
        "SELECT * FROM test_parameters WHERE test_definition_id=? ORDER BY sort_order, id", (test_definition_id,)
    ).fetchall()
    units_by_name = {p["name"]: p["unit"] for p in parameters}
    highlight_by_name = {p["name"]: bool(p["highlight"]) for p in parameters}
    params_by_name_row = {p["name"]: p for p in parameters}
    row_spacing_px_value = row_spacing_px(test["row_spacing"] if "row_spacing" in test.keys() else None)
    # show_prev_values يبقى False دائمًا بالمعاينة (بلا استثناء) — هذي معاينة
    # تصميم بدون مريض حقيقي، فمافيه "نتيجة سابقة" فعلية أصلاً لأي تحليل. كان
    # يُحسب سابقًا من department_shows_previous_values(department) فقط، فيطلع
    # "Previous Result — X: — mg/dL" فاضي بكل تحليل قسمه يدعم النتيجة
    # السابقة، حتى لو ما فيه مريض إطلاقًا. النتيجة السابقة الحقيقية تُحسب
    # وتُعرض فقط بالطباعة الفعلية (_print_report_impl) لما تكون موجودة
    # وموثّقة لنفس المريض تحديداً.
    show_prev_values = False
    logo_path = get_setting(db, "logo_path", "")
    logo_url = url_for("static", filename=logo_path) if logo_path else None

    cbc_groups = None
    if test["code"] == "CBC":
        cbc_groups = []
        for group in CBC_ROW_GROUPS:
            rows = [{"name": resolve_label(params_by_name_row.get(name)), "result": "—", "unit": units_by_name.get(name, ""),
                     "low": "", "high": "", "highlight": highlight_by_name.get(name, False),
                     "previous": "—" if show_prev_values else "", "flag": None,
                     "value_align": resolve_value_align(params_by_name_row.get(name))}
                    for name in group]
            cbc_groups.append(rows)

    custom_rows = None
    custom_heading = None
    custom_heading_align = "center"
    custom_rows_align = "right"
    if custom_template:
        custom_heading = custom_template["heading"] or test["name"]
        custom_heading_align = custom_template["heading_align"] or "center"
        custom_rows_align = custom_template["rows_align"] or "right"
        row_defs = json.loads(custom_template["rows_json"] or "[]")
        custom_rows = [{
            "param_name": rd.get("param_name", ""),
            "name": resolve_label(params_by_name_row.get(rd.get("param_name", "")), rd.get("label")),
            "history": [], "extras": {}, "note": None, "note_key": None, "show_blank": True,
            "value2": None, "range2": None,
            "label": resolve_label(params_by_name_row.get(rd.get("param_name", "")), rd.get("label")),
            "result": "—", "unit": units_by_name.get(rd.get("param_name", ""), ""),
            "normal_range": "—", "range_tiers": [{"label": None, "value": "—"}],
            "normal_range2": None, "result2": None, "unit2": "",
            "previous": "—" if show_prev_values else "",
            "name_side": rd.get("name_side") or "left",
            "range_position": rd.get("range_position") or "inline",
            "name_align": rd.get("name_align"),
            "color": rd.get("color"),
            "value_align": resolve_value_align(params_by_name_row.get(rd.get("param_name", ""))),
            "flag": None,
            "page_break_before": rd.get("page_break_before", False),
        } for rd in row_defs]

    params = {p["name"]: "—" for p in parameters}
    # تعديل: كانت ranges={} وresults_by_name={} فاضيتين تمامًا بهذي المعاينة
    # -- بالنسبة لقوالب exam_report_shared.html (فحص عام/custom_v2، وهذا
    # يشمل قسم "Other Results" اللي فيه أي باراميتر حر مثل d.dimer أو
    # fibrinogen)، عمود النتيجة (rval) وعمود المدى الطبيعي (rnorm) يعتمدون
    # حصرًا على results_by_name/ranges -- فكانا يطلعان فاضيين بالكامل بهذي
    # المعاينة تحديدًا، فما تقدر أصلاً تشوف شكل/موضع "النتيجة" أو "Normal
    # Range" وأنت تصمم، حتى لو التخطيط نفسه (اسم / نتيجة / مدى طبيعي) كان
    # صحيح أصلاً بالكود. صارت تُملأ بقيم وهمية واضحة (— للقيمة، ومدى نصي
    # وهمي) لكل باراميتر، بما فيها باراميترات "Other Results" الحرة.
    ranges = {p["name"]: {"range_text": "— إلى —", "low": None, "high": None} for p in parameters}
    results_by_name = {p["name"]: {"value_text": "—", "value_numeric": None, "flag": None} for p in parameters}
    if test["code"] == "COAG":
        # التخثر: المعاينة تعرض المدى الحقيقي المحفوظ (مريض افتراضي ذكر 30 سنة) بدل "— إلى —"
        ranges = {p["name"]: find_reference_range(db, p["id"], "Male", 30, "Years") for p in parameters}
        if _coag_table and custom_rows is not None:
            # أسلوب الجدول: قيم نموذجية + المدى الحقيقي + Control مدموج مع PT/PTT (بيانات وهمية للتوضيح)
            _coag_samples = {"PT": "13.2", "PT Control": "12.8", "INR": "1.05", "PTT": "31", "PTT Control": "30",
                             "Bleeding time": "3", "Plasma fibrinogen con": "320", "D. dimer": "250"}
            for _r in custom_rows:
                _pn = _r["param_name"]
                _r["result"] = _coag_samples.get(_pn, "—")
                _rg = ranges.get(_pn)
                _txt = ""
                if _rg:
                    if _rg["range_text"]:
                        _txt = _rg["range_text"]
                    elif _rg["low"] is not None and _rg["high"] is not None:
                        _txt = f"{_rg['low']} - {_rg['high']}"
                    elif _rg["low"] is not None:
                        _txt = f"> {_rg['low']}"
                    elif _rg["high"] is not None:
                        _txt = f"< {_rg['high']}"
                _r["normal_range"] = _txt
                _r["range_tiers"] = parse_range_tiers(_rg["range_text"]) if (_rg and _rg["range_text"]) else ([{"label": None, "value": _txt}] if _txt else [])
            custom_rows = _coag_fold_control(custom_rows)

    # تقارير الفحص GUE/GSE/SFA: المعاينة بنفس شكل المعاينة المعتمدة (preview_3) —
    # قيم نموذجية واقعية + المدى الطبيعي الحقيقي المحفوظ (مريض نموذجي ذكر 34 سنة)
    # بدل "—" و"— إلى —"، وبيانات مريض نموذجية بدل الشرطات. بيانات وهمية للتوضيح فقط.
    _exam_preview_patient = {}
    if test["code"] in EXAM_PREVIEW_SAMPLES:
        _samples = EXAM_PREVIEW_SAMPLES[test["code"]]
        ranges = {p["name"]: find_reference_range(db, p["id"], "Male", 34, "Years") for p in parameters}
        results_by_name = {
            p["name"]: {"value_text": _samples.get(p["name"], ""), "value_numeric": None, "flag": None}
            for p in parameters
        }
        _exam_preview_patient = {
            "patient_name": "أحمد محمد علي", "patient_name_en": "Ahmed Mohammed Ali",
            "age": "34 Year(s)", "sex": "Male", "referring_doctor_name": "Dr. Sarah Hussein",
            "sample_no": "IQ26/0055901", "patient_id": "26/0025990",
            "sample_time": "10:15 AM", "number_of": "1",
        }

    # نفس منطق _print_report_impl بالضبط (راجع التعليق هناك) — القوالب
    # الجاهزة الحديثة (GUE/GSE/SFA وأي قالب مستقبلي بنفس نمط
    # exam_report_shared.html) تتوقع هذي المتغيرات دائمًا، وهذي المعاينة
    # كانت ما تمررها إطلاقًا فتنهار بـ UndefinedError فورًا. بما إنها معاينة
    # بلا مريض/طلب حقيقي، القيم فاضية/رمزية بدل بيانات فعلية — عدا
    # report_layout اللي نجيبها فعليًا (مستوى التحليل فقط، order_test_id=0
    # ما يطابق أي استثناء مريض حقيقي) حتى يشوف الأدمن نفس التخصيص المحفوظ.
    report_layout, report_layout_has_patient_override = get_report_layout(db, test_definition_id, 0)
    macro_params, micro_params = _build_exam_sections(test["code"], parameters, report_layout)

    auto_flag_color_enabled, show_result_flag, flag_color_map = get_report_flag_settings(db)
    return render_template(
        template_name,
        ot={"test_name": test["name"], "test_code": test["code"]}, params=params, ranges=ranges, units=units_by_name, cbc_groups=cbc_groups,
        custom_rows=custom_rows, custom_heading=custom_heading,
        custom_heading_align=custom_heading_align, custom_rows_align=custom_rows_align,
        layout_view=_coag_view(build_layout_view(db, style_override=request.args.get("style")), _coag_table), note_visit_id=None,
        show_prev_values=show_prev_values, previous_visit_date=None, previous_values={},
        repeat_header_on_print=department_shows_previous_values(test["department"]),
        logo_url=logo_url, from_other_lab=False, font_size=14 if test["code"] == "CBC" else 16,
        show_exam_signature=False,
        # نفس تفعيل/تعطيل صندوق الختم المحفوظ فعليًا لهذا التحليل، حتى تشوف
        # بالمعاينة بالضبط نفس اللي رح يطلع بالطباعة الحقيقية.
        enable_stamp_widget=bool(test["enable_stamp_widget"]) if "enable_stamp_widget" in test.keys() else False,
        stamp_target_type="test_definition", stamp_target_id=test_definition_id,
        digital_stamps=[], stamp_placements=[],
        visit_date=f"{datetime.now().day}/{datetime.now().month}/{datetime.now().year}",
        is_design_preview=True, preview_test_id=test_definition_id,
        test_definition_id=test_definition_id,
        **{**dict(sex="—", age="—", patient_name="اسم المريض — معاينة تصميم فقط", patient_id="0000",
                  referring_doctor_name="—", sample_no="—", sample_time="—", number_of="—",
                  patient_name_en=""), **_exam_preview_patient},
        order_test_id=0, results_by_name=results_by_name, param_notes={},
        auto_flag_color_enabled=auto_flag_color_enabled, show_result_flag=show_result_flag, AUTO_FLAG_COLORS=flag_color_map,
        row_spacing_px=row_spacing_px_value,
        done_by_note=(test["done_by_note"] or "") if "done_by_note" in test.keys() else "",
        report_layout=report_layout, report_layout_has_patient_override=report_layout_has_patient_override,
        macro_params=macro_params, micro_params=micro_params,
        params_list=parameters,
    )


# ============== أسلوب جدول النتائج: حفظ الإعدادات + معاينة حيّة + ملاحظات الصفوف ==============
@app.route("/reports/row-note", methods=["POST"])
@login_required
def save_report_row_note():
    """يحفظ/يحذف ملاحظة (أو تعليق) تحت تحليل بتقرير زيارة معيّنة. تظهر بالطباعة
    فقط لو show=true. العنوان (label) اختياري: فاضي = بدون عنوان."""
    data = request.get_json(silent=True) or {}
    try:
        visit_id = int(data.get("visit_id"))
    except (TypeError, ValueError):
        return {"ok": False, "error": "رقم الزيارة غير صالح"}, 400
    key = str(data.get("key") or "").strip()
    if "|" not in key or len(key) > 300:
        return {"ok": False, "error": "مفتاح الصف غير صالح"}, 400
    db = get_db()
    if not db.execute("SELECT id FROM visits WHERE id=?", (visit_id,)).fetchone():
        return {"ok": False, "error": "الزيارة غير موجودة"}, 404
    text = str(data.get("text") or "")[:2000]
    label = str(data.get("label") or "")[:60]
    save_row_note(db, visit_id, key, text, label, bool(data.get("show")))
    log_action("SaveReportRowNote", "visit", visit_id, key)
    return {"ok": True}


@app.route("/management/report-designer/result-style", methods=["POST"])
@roles_required("admin")
def save_result_style_settings():
    db = get_db()
    if request.form.get("reset"):
        set_setting(db, "result_layout_json", "")
        db.commit()
        flash("رجعت إعدادات أسلوب جدول النتائج للافتراضي (Style B — matching image 1).")
        return redirect(url_for("report_designer"))
    cfg = get_result_layout(db)
    style = request.form.get("style", cfg["style"])
    cfg["style"] = style if style in RESULT_STYLES else cfg["style"]

    labels = {}
    for st, defaults in RESULT_LABEL_DEFAULTS.items():
        row = {}
        for k, dv in defaults.items():
            v = (request.form.get(f"label_{st}_{k}") or "").strip()
            if v and v != dv:
                row[k] = v[:60]
        if row:
            labels[st] = row
    cfg["labels"] = labels

    extra_cols = []
    try:
        n = int(request.form.get("xc_count", "0"))
    except ValueError:
        n = 0
    for i in range(n):
        if request.form.get(f"xc_del_{i}"):
            continue
        eid = (request.form.get(f"xc_id_{i}") or "").strip()
        title = (request.form.get(f"xc_title_{i}") or "").strip()
        if not eid or not title:
            continue
        after = request.form.get(f"xc_after_{i}", "test")
        extra_cols.append({"id": eid, "title": title[:40],
                           "after": after if after in ("test", "result", "unit", "range") else "test",
                           "show": 1 if request.form.get(f"xc_show_{i}") else 0})
    new_title = (request.form.get("xc_new_title") or "").strip()
    if new_title:
        after = request.form.get("xc_new_after", "test")
        extra_cols.append({"id": "x" + str(int(datetime.now().timestamp() * 1000))[-9:], "title": new_title[:40],
                           "after": after if after in ("test", "result", "unit", "range") else "test", "show": 1})
    cfg["extra_cols"] = extra_cols

    colors = {k: "" for k in cfg["colors"]}
    if request.form.get("colors_enabled"):
        for k in colors:
            v = (request.form.get(f"color_{k}") or "").strip()
            if re.fullmatch(r"#[0-9A-Fa-f]{6}", v):
                colors[k] = v
    cfg["colors"] = colors

    try:
        cfg["prev_count"] = max(0, min(20, int(request.form.get("prev_count", cfg["prev_count"]))))
    except ValueError:
        pass
    cfg["prev_default_show"] = 1 if request.form.get("prev_default_show") else 0
    try:
        cfg["unit_gap"] = max(0, min(40, int(request.form.get("unit_gap", cfg.get("unit_gap", 6)))))
    except (TypeError, ValueError):
        pass
    for _gk, _gd, _gmax in (("row_gap", 8, 40), ("line_gap", 2, 20)):
        try:
            cfg[_gk] = max(0, min(_gmax, int(request.form.get(_gk, cfg.get(_gk, _gd)))))
        except (TypeError, ValueError):
            pass
    _th = request.form.get("theme", cfg["theme"])
    cfg["theme"] = _th if _th in ("default", "green", "custom") else "default"
    _po = request.form.get("prev_order", cfg["prev_order"])
    cfg["prev_order"] = _po if _po in ("asc", "desc") else "desc"
    _dh = request.form.get("dept_headings", cfg["dept_headings"])
    cfg["dept_headings"] = _dh if _dh in ("auto", "show", "hide") else "auto"
    cfg["merged_title"] = (request.form.get("merged_title") or "").strip()[:120]
    cfg["title_style"] = _form_text_style("title")
    cfg["head_style"] = _form_text_style("head")
    _ds = {}
    for _k in list(request.form.keys()):
        _m = re.fullmatch(r"ds_(\d+)_name", _k)
        if _m:
            _nm = (request.form.get(_k) or "").strip()[:80]
            _st = _form_text_style(f"ds_{_m.group(1)}")
            if _nm and _st:
                _ds[_nm] = _st
    cfg["dept_styles"] = _ds
    cfg["merged_exclude"] = (request.form.get("merged_exclude") or "").strip()[:2000]
    cfg["show_prev_visit_line"] = 1 if request.form.get("show_prev_visit_line") else 0
    save_result_layout(db, cfg)
    log_action("SaveResultStyle", "settings", 0, cfg["style"])
    flash("تم حفظ أسلوب جدول النتائج (يُطبّق على كل التقارير).")
    return redirect(url_for("report_designer"))


@app.route("/management/report-designer/extra-values", methods=["POST"])
@roles_required("admin")
def save_result_extra_values():
    """قيم الأعمدة الإضافية لباراميترات تحليل معيّن (نص حر لكل باراميتر)."""
    db = get_db()
    try:
        test_id = int(request.form.get("test_definition_id"))
    except (TypeError, ValueError):
        return redirect(url_for("report_designer"))
    params = db.execute("SELECT id, name FROM test_parameters WHERE test_definition_id=?", (test_id,)).fetchall()
    cfg = get_result_layout(db)
    data = get_extra_col_values(db)
    for c in cfg["extra_cols"]:
        mp = dict(data.get(c["id"], {}))
        for p in params:
            key = f"{test_id}|{p['name']}"
            v = (request.form.get(f"ev_{c['id']}_{p['id']}") or "").strip()
            if v:
                mp[key] = v[:120]
            else:
                mp.pop(key, None)
        data[c["id"]] = mp
    save_extra_col_values(db, data)
    log_action("SaveResultExtraValues", "test_definition", test_id, "extra_cols")
    flash("تم حفظ قيم الأعمدة الإضافية لهذا التحليل.")
    return redirect(url_for("report_designer", test_definition_id=test_id))


def _sample_panel_groups(style, prev_count, show_prev, prev_order="desc"):
    """بيانات المعاينة — نفس البيانات الظاهرة بالصور المرجعية للأساليب الأربعة."""
    def hist(pairs):
        pairs = list(pairs)[:prev_count] if show_prev else []
        if prev_order == "asc":
            pairs = list(reversed(pairs))
        return [{"date": d, "value": v, "value2": v2} for d, v, v2 in pairs]

    def row(name, res, unit, rng, v2=None, u2=None, r2=None, h=(), tier=None, flag=None, key=None):
        return {"name": name, "result": res, "unit": unit, "range_display": rng,
                "range_tiers": tier or [{"label": None, "value": rng}], "flag": flag, "value2": v2, "unit2": u2,
                "range2_display": r2, "range2": r2, "color": None, "history": hist(h),
                "extras": {}, "note": None, "note_key": key}

    def grp(title, rows):
        return {"department": title, "rows": rows, "name_header": "Test Name", "range_header": "Normal Range"}

    if style in ("a1", "a2", "r2", "r3"):
        return [
            grp("Biochemistry Tests", [
                row("FBS", "1122.0", "mg/dL", "70.0 - 100.0", h=[("10/05/2026", "105.0", None)], flag="High", key="s|fbs"),
                row("S. Creatinine", "1.10", "mg/dL", "0.70 - 1.30", key="s|cr")]),
            grp("Hormones Tests", [row("TSH", "2.45", "µIU/mL", "0.27 - 4.20", h=[("14/01/2026", "3.10", None)], key="s|tsh")]),
            grp("Vitamins Tests", [row("Vitamin D3 (25-OH)", "18.50", "ng/mL", "30.0 - 100.0", flag="Low", key="s|vd")]),
            grp("Virology Screening", [row("HBsAg", "Non-Reactive", "Index (0.15)", "Non-Reactive (< 1.0)", key="s|hbs")]),
            grp("Tumor Markers", [row("CEA", "1.57", "ng/mL", "Nonsmoker < 3.00 / Smoker < 6.20",
                                      h=[("14/02/2026", "1.65", None), ("09/08/2025", "1.49", None)], key="s|cea")]),
            grp("Coagulation Profile", [
                row("PT", "13.2", "sec", "11.0 - 14.0", h=[("01/03/2026", "12.8", None)], key="s|pt"),
                row("INR", "1.02", "", "0.9 - 1.1", key="s|inr")]),
        ]
    if style in ("b_grid", "r1"):
        rows = [
            row("Bilirubin Total, Serum", "0.45", "mg/dL", "<1.00", "7.65", "umol/L", "<17.00",
                [("14/02/2026", "0.31", "5.27"), ("09/08/2025", "0.30", "5.10")], key="s|bt"),
            row("Bilirubin Direct, Serum", "0.17", "mg/dL", "0.00 - 0.30", "2.89", "umol/L", "0.00 - 5.10",
                [("14/02/2026", "0.14", "2.38"), ("09/08/2025", "0.10", "1.70")], key="s|bd"),
            row("Ferritin, Serum", "127", "ng/mL", "30.0 - 400.0",
                h=[("14/02/2026", "115", None), ("09/08/2025", "100", None)], key="s|fe"),
            row("Vitamin B12, Serum", "607", "pg/mL", "178 - 870", "448", "pmol/L", "131 - 642",
                [("14/02/2026", "581", "429"), ("09/08/2025", "527", "389")], key="s|b12"),
        ]
        return [grp("Biochemistry", rows)]
    rows = [
        row("Bilirubin Total, Serum", "0.45", "mg/dL", "<1.00", "7.65", "umol/L", "<17.00",
            [("14/02/2026", "0.31", "5.27"), ("09/08/2025", "0.30", "5.10")], key="s|bt"),
        row("Ferritin, Serum", "127", "ng/mL", "30.0 - 400.0",
            h=[("14/02/2026", "115", None), ("09/08/2025", "100", None)], key="s|fe"),
        row("TSH, Serum", "1.22", "uIU/mL", "0.27 - 4.20",
            h=[("14/02/2026", "1.49", None), ("09/08/2025", "1.95", None)], key="s|tsh"),
        row("Vitamin D, Serum", "32", "ng/mL", "", "77", "nmol/L", None,
            [("14/02/2026", "54", "130"), ("09/08/2025", "34", "82")],
            tier=[{"label": "Optimal", "value": "20.00-50.00"}, {"label": "Optimal", "value": "50.00-125.00"}], key="s|vd"),
        row("HBsAg, Serum", "Negative", "", "Negative", h=[("14/02/2026", "Negative", None)], key="s|hbs"),
    ]
    return [grp("Biochemistry", rows)]


@app.route("/management/report-designer/style-preview")
@roles_required("admin")
def result_style_preview():
    """معاينة حيّة لأسلوب جدول النتائج (iframe بصفحة تصميم التقارير) — نفس combined_panel.html
    ونفس القالب المشترك بالضبط. ?style= ?theme= للمعاينة بدون حفظ، ?prev=0 لإخفاء السابقة."""
    try:
        db = get_db()
        cfg = get_result_layout(db)
        view = build_layout_view(db, style_override=request.args.get("style"), cfg=cfg,
                                 theme_override=request.args.get("theme"))
        show_prev = request.args.get("prev", "1") != "0" and cfg["prev_count"] > 0
        groups = _sample_panel_groups(view["style"], cfg["prev_count"], show_prev, cfg["prev_order"])
        for g in groups:
            for r in g["rows"]:
                for c in cfg["extra_cols"]:
                    r["extras"][c["id"]] = "—" if c.get("show") else ""
        # في المعاينة نفعّل تلوين الـHigh/Low حتى يظهر مثل الصور المرجعية
        flag_red = "#DC2626" if view["theme"] == "green" else "#B91C1C"
        show_headings = cfg["dept_headings"] == "show" or (cfg["dept_headings"] == "auto" and view["style"] in ("a1", "a2", "r3"))
        _, show_result_flag, _ = get_report_flag_settings(db)
        logo_path = get_setting(db, "logo_path", "")
        logo_url = url_for("static", filename=logo_path) if logo_path else None
        return render_template(
            "reports/combined_panel.html",
            panel_groups=groups, all_rows=[r for g in groups for r in g["rows"]], show_dept_headings=show_headings,
            merged_title=cfg["merged_title"], logo_url=logo_url, from_other_lab=False,
            **_heading_css_ctx(cfg, [g["department"] for g in groups]),
            layout_view=view, note_visit_id=None, prev_toggle_available=False, show_prev_values=show_prev,
            report_layout={}, report_layout_has_patient_override=False,
            visit_date="28/9/2026", sex="Male", age="45 Year",
            patient_name="أحمد كريم جاسم", patient_name_en="Ahmed Kareem Jasim", patient_id="19010",
            sample_no="19010023", sample_time="09:12", number_of="1", referring_doctor_name="د. سالم راضي",
            show_exam_signature=False, is_design_preview=True, preview_test_id=None,
            auto_flag_color_enabled=True, show_result_flag=show_result_flag,
            AUTO_FLAG_COLORS={"High": flag_red, "Low": flag_red, "Critical": flag_red},
            row_spacing_px=None, done_by_notes=[],
            ot={"test_name": "Report"}, stamp_target_type="visit", stamp_target_id=0, digital_stamps=[], stamp_placements=[],
        )
    except Exception:  # noqa: BLE001 — المعاينة صفحة مدير فقط: نعرض سبب الخطأ بدل صفحة 500 فاضية
        import traceback
        tb = traceback.format_exc()
        app.logger.error("result_style_preview failed:\n%s", tb)
        return ("<meta charset='utf-8'><body style='font-family:Segoe UI,Tahoma;padding:14px;direction:rtl'>"
                "<h3 style='color:#B91C1C'>تعذر عرض المعاينة</h3>"
                "<p>صوّر هذا النص وابعثه للمطوّر:</p>"
                "<pre dir='ltr' style='white-space:pre-wrap;background:#F8FAFC;border:1px solid #E2E8F0;padding:10px;font-size:12px'>"
                + _html_escape(tb) + "</pre></body>"), 500


@app.route("/management/report-designer/<int:test_definition_id>/start-generic-exam", methods=["GET", "POST"])
@roles_required("admin")
def start_generic_exam_report(test_definition_id):
    """يفعّل مسار reports/generic_exam.html لهذا التحليل بدل مسار "مصمم
    التقارير" العام — يبني تقرير فحص كامل (أقسام Macroscopic/Microscopic
    قابلة للتسمية، وباراميترات تُسحب بينها) من نفس صفحة معاينة الطباعة،
    بدون كتابة أي قالب HTML يدوي. لصق زر/رابط لهذا المسار بصفحة "مصمم
    التقارير" (management/report_designer.html) يفعّله لأي تحليل تختاره:
      <a href="/management/report-designer/{{ test.id }}/start-generic-exam">
        🧪 ابدأ تصميم فحص من الصفر (Macroscopic/Microscopic)
      </a>
    """
    db = get_db()
    test = db.execute("SELECT id, name, code FROM test_definitions WHERE id=?", (test_definition_id,)).fetchone()
    if not test:
        flash("التحليل غير موجود.")
        return redirect(url_for("report_designer"))
    db.execute("UPDATE test_definitions SET report_style='generic_exam' WHERE id=?", (test_definition_id,))
    db.commit()
    log_action("StartGenericExamReport", "test_definition", test_definition_id, test["name"])
    flash(
        f"تم تفعيل تصميم فحص من الصفر لـ \"{test['name']}\" ({test['code']}). "
        "اطبع أي نتيجة لهذا التحليل الآن (Results/Orders) — يطلع بقسم واحد "
        "افتراضي (Other Results) فيه كل الباراميترات، وتقدر تسمّي الأقسام "
        "وتسحب الباراميترات بينها وتلوّنها من زر ✏️ تعديل التصميم بأعلى المعاينة."
    )
    return redirect(url_for("report_designer", test_definition_id=test_definition_id))


@app.route("/master/test-catalog/<int:test_id>/report-header-style", methods=["POST"])
@roles_required("supervisor")
def set_test_report_header_style(test_id):
    """يفرض/يلغي التصميم الجديد (جدول Conventional/SI Units) لتحليل معيّن
    يدويًا، بغض النظر عن اسم قسمه (Department) — يُستخدم فقط لو الكشف
    التلقائي (uses_order_style_report أعلى الملف) ما انطبق صح على تحليل
    معيّن. value يوصل 'custom_v2' (فرض التفعيل) أو 'classic' (فرض
    الإلغاء) أو فاضي (رجوع للكشف التلقائي حسب القسم)."""
    db = get_db()
    test = db.execute("SELECT id, name FROM test_definitions WHERE id=?", (test_id,)).fetchone()
    if not test:
        return {"ok": False, "error": "التحليل غير موجود"}, 404
    value = (request.form.get("value") or "").strip()
    if value not in ("custom_v2", "classic", ""):
        return {"ok": False, "error": "قيمة غير صالحة"}, 400
    db.execute("UPDATE test_definitions SET report_style=? WHERE id=?", (value or None, test_id))
    db.commit()
    log_action("SetReportHeaderStyle", "test_definition", test_id, value or "auto")
    return {"ok": True, "value": value}


# ============== بوابة النتائج السحابية (QR للمريض) ==============
def _portal_collect(db, visit_id):
    """يجمع بيانات الزيارة لبوابة المريض، بنفس دالة بناء صفوف التقارير (أرقام/وحدات/مدى طبيعي متطابقة)."""
    visit = db.execute(
        "SELECT v.*, p.full_name as patient_name, p.age, p.age_unit, p.gender "
        "FROM visits v JOIN patients p ON p.id = v.patient_id WHERE v.id=?", (visit_id,)).fetchone()
    if not visit:
        return None
    ots = db.execute(
        "SELECT ot.*, td.code as test_code, td.name as test_name, td.department as department, "
        "td.report_group as report_group, td.panel_color as panel_color, td.panel_page_break as panel_page_break "
        "FROM order_tests ot JOIN test_definitions td ON td.id = ot.test_definition_id "
        "JOIN orders o ON o.id = ot.order_id WHERE o.visit_id=? ORDER BY ot.id", (visit_id,)).fetchall()
    tests = []
    for ot in ots:
        if ot["status"] in ("Cancelled", "Canceled", "Rejected"):
            continue
        rows = []
        if ot["status"] in ("Completed", "Verified"):
            rows = _build_panel_rows_for_ot(db, ot, visit, {}, {})
        _grp = (ot["report_group"] or "").strip() or ot["department"] or "Other"
        tests.append({"td_id": ot["test_definition_id"], "code": ot["test_code"], "name": ot["test_name"],
                      "status": ot["status"], "rows": rows, "group": _grp, "color": ot["panel_color"]})
    # نفس ترتيب أقسام اللوحة المجمّعة: المخصص من الإعدادات أولاً ثم الباقي أبجديًا
    _order = sorted({t["group"] for t in tests})
    _pref = [ln.strip() for ln in (get_setting(db, "combined_panel_group_order", "") or "").splitlines() if ln.strip()]
    if _pref:
        _order = [g for g in _pref if g in _order] + [g for g in _order if g not in _pref]
    return {"patient_name": visit["patient_name"], "created_at": visit["created_at"], "tests": tests,
            "group_order": _order,
            "expected_ready_at": (visit["expected_ready_at"] if "expected_ready_at" in visit.keys() else None),
            "expected_ready_text": (visit["expected_ready_text"] if "expected_ready_text" in visit.keys() else None)}


cloud_sync.set_collector(_portal_collect)


def _portal_make_pdf(visit_id):
    """نسخة PDF للمريض = نفس تقارير المختبر المصممة بالضبط (نفس مولّد الأرشفة _build_combined_designed_reports_html
    + pdf_export.html_to_pdf الموجود عندك أصلاً). تُستدعى من خيط المزامنة الخلفي، لذلك نفتح سياق طلب داخلي.
    لا تعلّم التحاليل كـ"مطبوعة" (نرجّع printed_at كما كانت). ترجع bytes أو None."""
    import pdf_export
    base = f"http://127.0.0.1:{os.environ.get('LIS_PORT', '9090')}/"
    # v70: سياق طلب واحد فقط (بدون تداخل). السياق الداخلي القديم كان عند خروجه يغلق اتصال القاعدة الخارجي
    # فيظهر "Cannot operate on a closed database" ولا يُولَّد الـPDF.
    with app.test_request_context("/?headings=1", base_url=base):
        session["interface"] = "both"
        db = get_db()
        prev = {r["id"]: r["printed_at"] for r in db.execute(
            "SELECT ot.id, ot.printed_at FROM order_tests ot JOIN orders o ON o.id = ot.order_id WHERE o.visit_id=?",
            (visit_id,)).fetchall()}
        try:
            # v65: نسخة المريض = نفس "اللوحة المجمّعة" (جدول واحد مرتب حسب الأقسام + التقارير المستقلة بعدها)
            # بدل ما تكون صفحة منفصلة لكل تحليل. لو فشلت لأي سبب نرجع للطريقة القديمة.
            html_content = None
            try:
                _h = print_combined_panel(visit_id)
                if isinstance(_h, str) and len(_h) > 500:
                    html_content = _h
            except Exception:
                html_content = None
            if not html_content:
                html_content = _build_combined_designed_reports_html(visit_id)
        finally:
            _db2 = get_db()  # اتصال جديد مضمون الفتح
            for otid, pa in prev.items():
                _db2.execute("UPDATE order_tests SET printed_at=? WHERE id=?", (pa, otid))
            _db2.commit()
        if not html_content:
            return None
        pdf_path = pdf_export.make_temp_pdf_path(f"portal{visit_id}")
        try:
            pdf_export.html_to_pdf(html_content, request.url_root, pdf_path)
            with open(pdf_path, "rb") as fh:
                return fh.read()
        finally:
            try:
                os.remove(pdf_path)
            except OSError:
                pass


cloud_sync.set_pdf_maker(_portal_make_pdf)


@app.route("/front-desk/visits/<int:visit_id>/portal-qr.png")
@login_required
def visit_portal_qr(visit_id):
    db = get_db()
    cfg = cloud_sync.get_cfg(db)
    if not cfg["url"]:
        return "Portal URL not configured", 400
    token = cloud_sync.ensure_token(db, visit_id)
    if not token:
        return "Not found", 404
    img = generate_qr(cloud_sync.portal_link(cfg, token))
    buf = BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")


@app.route("/front-desk/visits/<int:visit_id>/print/portal-qr")
@login_required
def print_visit_portal_qr(visit_id):
    """ورقة QR صغيرة للمريض (غير باركود القناني). تفتح نافذة طباعة جاهزة."""
    db = get_db()
    cfg = cloud_sync.get_cfg(db)
    visit = db.execute(
        "SELECT v.*, p.full_name as patient_name FROM visits v JOIN patients p ON p.id = v.patient_id WHERE v.id=?",
        (visit_id,)).fetchone()
    if not visit:
        return "Not found", 404
    if not cfg["url"]:
        # v77: حساب الاستقبال ما يفتح صفحة الإعدادات -> لا تحوّله لها (كان يطلع رسالتين ويرجع للوحة). ارجع للصفحة السابقة برسالة واضحة.
        flash("بوابة النتائج غير مفعّلة بهذا الجهاز (رابط البوابة/مفتاحها غير مضبوطين). اطلب من مسؤول النظام أو المصمم ضبطها، ثم أعد المحاولة.")
        return redirect(request.referrer or url_for("new_visit"))
    token = cloud_sync.ensure_token(db, visit_id)
    data = _portal_collect(db, visit_id) or {"tests": [], "created_at": visit["created_at"]}
    cloud_sync.trigger()
    return render_template("front_desk/print_portal_qr.html", visit=visit, link=cloud_sync.portal_link(cfg, token),
                           eta=cloud_sync._eta_text(cfg, data) if data["tests"] else "",
                           lab_name=get_setting(db, "lab_name", ""), enabled=cfg["enabled"])


@app.route("/api/visits/<int:visit_id>/portal-sync", methods=["POST"])
@login_required
def api_portal_sync(visit_id):
    db = get_db()
    try:
        cloud_sync.ensure_token(db, visit_id)
        ok, msg = cloud_sync.sync_visit(db, visit_id, force=True)
    except Exception as e:  # noqa: BLE001  v68: أظهر السبب الحقيقي بدل "فشل الاتصال"
        import traceback
        traceback.print_exc()
        return {"ok": False, "message": f"{type(e).__name__}: {e}"[:400]}, 502
    return {"ok": ok, "message": msg}, (200 if ok else 502)


@app.route("/api/visits/<int:visit_id>/portal-diagnose")
@login_required
def api_portal_diagnose(visit_id):
    """فحص سلسلة الـQR (رابط عام، بوابة محلية، رمز الزيارة، اكتمال التحاليل) — يُعرض بورقة الـQR."""
    db = get_db()
    return jsonify({"items": [{"level": l, "text": t} for l, t in cloud_sync.diagnose(db, visit_id, net=request.args.get("net") == "1")],
                    "link": cloud_sync.portal_link(cloud_sync.get_cfg(db),
                                                   (db.execute("SELECT portal_token FROM visits WHERE id=?", (visit_id,)).fetchone() or {"portal_token": None})["portal_token"])})


@app.route("/api/visits/<int:visit_id>/portal-revoke", methods=["POST"])
@login_required
def api_portal_revoke(visit_id):
    db = get_db()
    ok, msg = cloud_sync.revoke(db, visit_id)
    log_action("PortalRevoke", "visit", visit_id, msg)
    return {"ok": ok, "message": msg}


@app.route("/api/portal/test", methods=["POST"])
@roles_required("admin")
def api_portal_test():
    ok, msg = cloud_sync.test_connection(cloud_sync.get_cfg(get_db()))
    return {"ok": ok, "message": msg}
# --- v58: صفحة المصمم "تجهيز ملف تنصيب العميل" (client_builder.py): حقول + زر واحد يبني LabSystem_Setup.exe ---
try:
    import client_builder
    client_builder.register(app, designer_required, get_db, get_setting, set_setting)
except Exception as _cb_err:   # أي مشكلة بهالميزة ما توقف البرنامج
    print("client_builder not loaded:", _cb_err)
# --- v59: التحديث الداخلي (شريط "يتوفر تحديث") + نسخ احتياطي يومي لقاعدة البيانات خارج مجلد البرنامج ---
try:
    import lab_updater
    lab_updater.register(app, get_db, get_setting, set_setting, login_required)
except Exception as _lu_err:
    print("lab_updater not loaded:", _lu_err)
# --- v60: صفحة المصمم "نشر تحديث للعملاء" (update_publisher.py): إعداد المفتاح/الرابط + زر بناء وتوقيع ونشر ---
try:
    import update_publisher
    update_publisher.register(app, designer_required, get_db, get_setting, set_setting)

    @app.after_request
    def _designer_panel_publish_links(resp):
        """يضيف شريط أزرار صغير بلوحة المصمم يوصل لصفحتي «نشر تحديث» و«تجهيز Setup» (بدون تعديل قالب اللوحة)."""
        try:
            if request.path.rstrip("/") == "/designer" and resp.mimetype == "text/html" and resp.status_code == 200 \
                    and not getattr(sys, "frozen", False):
                body = resp.get_data(as_text=True)
                if "lisPubLinks" not in body and "</body>" in body:
                    bar = ('<div id="lisPubLinks" style="position:fixed;bottom:14px;left:14px;z-index:9999;display:flex;gap:8px;'
                           'direction:rtl;font:700 13px Tahoma,Arial,sans-serif;">'
                           '<a href="/designer/publish-update" style="background:#205072;color:#fff;padding:9px 14px;border-radius:9px;'
                           'text-decoration:none;box-shadow:0 3px 12px rgba(0,0,0,.3);">📦 نشر تحديث للعملاء</a>'
                           '<a href="/designer/client-builder" style="background:#fff;color:#205072;padding:9px 14px;border-radius:9px;'
                           'text-decoration:none;border:1px solid #205072;box-shadow:0 3px 12px rgba(0,0,0,.2);">🏗 تجهيز Setup العميل</a>'
                           '<a href="/designer/config-pack" style="background:#fff;color:#205072;padding:9px 14px;border-radius:9px;'
                           'text-decoration:none;border:1px solid #205072;box-shadow:0 3px 12px rgba(0,0,0,.2);">📦 حزمة الإعدادات</a></div>')
                    resp.set_data(body.replace("</body>", bar + "</body>", 1))
        except Exception:
            pass
        return resp
except Exception as _up_err:
    print("update_publisher not loaded:", _up_err)
# --- v75: بطاقة المريض (نافذة مستقلة بلا مسطرة جانبية) ---
def _pc_recalc_invoice(db, visit_id):
    inv = db.execute("SELECT id, extra_charges FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()
    if not inv:
        return
    tot = db.execute("SELECT COALESCE(SUM(ot.price),0) AS t FROM order_tests ot JOIN orders o ON o.id=ot.order_id WHERE o.visit_id=?", (visit_id,)).fetchone()["t"]
    fee = db.execute("SELECT COALESCE(home_visit_fee,0) AS f FROM visits WHERE id=?", (visit_id,)).fetchone()["f"]
    db.execute("UPDATE invoices SET total_amount=? WHERE id=?", (float(tot or 0) + float(fee or 0) + float(inv["extra_charges"] or 0), inv["id"]))


def _pc_visit(db, visit_id):
    return db.execute(
        "SELECT v.*, p.full_name, p.gender, p.age, p.age_unit, p.phone, p.title, p.email, p.address, p.national_id, p.passport_number, p.travel_certificate_number, p.lab_card_number, d.full_name AS doctor_name, rc.name AS center_name "
        "FROM visits v JOIN patients p ON p.id = v.patient_id LEFT JOIN doctors d ON d.id = v.doctor_id "
        "LEFT JOIN referral_centers rc ON rc.id = v.referral_center_id WHERE v.id=?", (visit_id,)).fetchone()


@app.route("/patient-card/<int:visit_id>")
@login_required
def patient_card(visit_id):
    db = get_db()
    v = _pc_visit(db, visit_id)
    if not v:
        return "Not found", 404
    tests = [dict(r) for r in db.execute(
        "SELECT ot.id, ot.test_definition_id, ot.status, COALESCE(ot.price,0) AS price, COALESCE(ot.forwarded_lab_name,'') AS fwd_lab, "
        "COALESCE(ot.forwarded_cost,0) AS fwd_cost, td.name, td.department, td.sample_type "
        "FROM order_tests ot JOIN orders o ON o.id = ot.order_id JOIN test_definitions td ON td.id = ot.test_definition_id "
        "WHERE o.visit_id=? ORDER BY ot.id", (visit_id,)).fetchall()]
    groups = {}
    for t in tests:
        k = (globals().get("_tube_type_of") or (lambda s, d, n: s or ""))(t["sample_type"], t["department"], t["name"]) or ""
        if k:
            g = groups.setdefault(k, {"label": k, "ids": [], "n": 0})
            g["ids"].append(str(t["id"])); g["n"] += 1
    tube_groups = [{"label": g["label"], "ids": ",".join(g["ids"]), "n": g["n"]} for g in groups.values()]
    fwd_ids = ",".join(str(t["id"]) for t in tests if t["fwd_lab"])
    try:
        catalog = [dict(r) for r in db.execute("SELECT id, name, department FROM test_definitions ORDER BY department, name").fetchall()]
    except Exception:
        catalog = []
    exam = [r[0] for r in db.execute("SELECT name FROM examining_doctors_list ORDER BY sort_order, name").fetchall()]
    refd = [r[0] for r in db.execute("SELECT full_name FROM doctors ORDER BY full_name LIMIT 300").fetchall()]
    fwd_labs = [r[0] for r in db.execute("SELECT DISTINCT forwarded_lab_name FROM order_tests WHERE forwarded_lab_name IS NOT NULL AND forwarded_lab_name<>''").fetchall()]
    return render_template("patient_card.html", v=v, tests=tests, bal=type("B", (), _visit_balance(db, visit_id)),
                           tube_groups=tube_groups, fwd_ids=fwd_ids, catalog=catalog, exam_doctors=exam, ref_doctors=refd, fwd_labs=fwd_labs,
                           pc_prices=_pc_partner_prices(db))


@app.route("/api/patient-card/<int:visit_id>/info", methods=["POST"])
@login_required
def api_pc_info(visit_id):
    db = get_db()
    v = _pc_visit(db, visit_id)
    if not v:
        return jsonify(ok=False, error="الزيارة غير موجودة"), 404
    inv = db.execute("SELECT * FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()
    if inv and inv["is_locked"]:
        return jsonify(ok=False, error="الفاتورة مقفلة — لا يمكن التعديل."), 400
    p = request.get_json(silent=True) or {}
    name = (p.get("patient_name") or "").strip()
    if not name:
        return jsonify(ok=False, error="اسم المريض مطلوب"), 400
    db.execute("UPDATE patients SET full_name=?, full_name_en=COALESCE(?, full_name_en), gender=?, age=?, age_unit=?, phone=?, title=?, email=? WHERE id=?",
               (name, transliterate_arabic_name(name) if name != v["full_name"] else None, p.get("gender") or v["gender"],
                p.get("age") or None, p.get("age_unit") or "Years", (p.get("phone") or "").strip(), p.get("title") or "Mr.",
                (p.get("email") or "").strip(), v["patient_id"]))
    doc_id = find_or_create_doctor(db, p.get("doctor_name", ""))
    center_id = find_or_create_referral_center(db, p.get("referral_lab_name", ""))
    exam = (p.get("examining_doctor") or "").strip()
    db.execute("UPDATE visits SET doctor_id=?, referral_center_id=?, fasting=?, notes=?, examining_doctor=?, attending_doctor=? WHERE id=?",
               (doc_id, center_id, p.get("fasting") or "Undefined", p.get("notes") or "", exam, exam, visit_id))
    if (doc_id or None) != (v["doctor_id"] or None) or (center_id or None) != (v["referral_center_id"] or None):
        for row in db.execute("SELECT ot.id, ot.test_definition_id FROM order_tests ot JOIN orders o ON o.id=ot.order_id WHERE o.visit_id=?", (visit_id,)).fetchall():
            pr = get_test_price(db, row["test_definition_id"], doc_id, center_id)
            db.execute("UPDATE order_tests SET price=?, doctor_id=?, price_missing=? WHERE id=?",
                       (pr if pr is not None else 0, doc_id, 1 if pr is None else 0, row["id"]))
    try:
        recompute_examining_doctor_fee(db, visit_id)
    except Exception:
        pass
    _pc_recalc_invoice(db, visit_id)
    db.commit()
    log_action("Update", "visit", visit_id, "patient-card")
    return jsonify(ok=True)


@app.route("/api/patient-card/<int:visit_id>/test/<int:ot_id>", methods=["POST"])
@login_required
def api_pc_test(visit_id, ot_id):
    db = get_db()
    row = db.execute("SELECT ot.id FROM order_tests ot JOIN orders o ON o.id=ot.order_id WHERE ot.id=? AND o.visit_id=?", (ot_id, visit_id)).fetchone()
    if not row:
        return jsonify(ok=False, error="غير موجود"), 404
    inv = db.execute("SELECT is_locked FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()
    p = request.get_json(silent=True) or {}
    try:
        price = float(p.get("price")) if str(p.get("price", "")).strip() != "" else None
        cost = float(p.get("fwd_cost") or 0)
    except ValueError:
        return jsonify(ok=False, error="رقم غير صحيح"), 400
    lab = (p.get("fwd_lab") or "").strip() or None
    if price is not None:
        if inv and inv["is_locked"]:
            return jsonify(ok=False, error="الفاتورة مقفلة — لا يمكن تعديل السعر."), 400
        db.execute("UPDATE order_tests SET price=?, price_missing=0 WHERE id=?", (price, ot_id))
        _pc_recalc_invoice(db, visit_id)
    db.execute("UPDATE order_tests SET forwarded_lab_name=?, forwarded_cost=? WHERE id=?", (lab, cost if lab else 0, ot_id))
    db.commit()
    log_action("ForwardTest", "order_tests", ot_id, "patient-card lab=%s cost=%s" % (lab, cost))
    return jsonify(ok=True)


@app.route("/api/patient-card/<int:visit_id>/add-test", methods=["POST"])
@login_required
def api_pc_add_test(visit_id):
    db = get_db()
    v = _pc_visit(db, visit_id)
    order = db.execute("SELECT * FROM orders WHERE visit_id=?", (visit_id,)).fetchone()
    inv = db.execute("SELECT is_locked FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()
    if not v or not order:
        return jsonify(ok=False, error="الزيارة غير موجودة"), 404
    if inv and inv["is_locked"]:
        return jsonify(ok=False, error="الفاتورة مقفلة — لا يمكن إضافة تحاليل."), 400
    tid = str((request.get_json(silent=True) or {}).get("test_id") or "")
    if not tid.isdigit() or not db.execute("SELECT id FROM test_definitions WHERE id=?", (tid,)).fetchone():
        return jsonify(ok=False, error="تحليل غير صحيح"), 400
    have = {str(r["test_definition_id"]) for r in db.execute("SELECT test_definition_id FROM order_tests WHERE order_id=?", (order["id"],)).fetchall()}
    if tid in have:
        return jsonify(ok=False, error="هذا التحليل موجود أصلًا بالزيارة."), 400
    reg = v["registration_number"]
    for t in [tid] + [x for x in expand_required_tests(db, [tid])[1:] if x not in have]:
        pr = get_test_price(db, t, v["doctor_id"], v["referral_center_id"])
        db.execute("INSERT INTO order_tests (order_id, test_definition_id, status, barcode, price, doctor_id, created_at, price_missing) "
                   "VALUES (?, ?, 'Accepted', ?, ?, ?, ?, ?)",
                   (order["id"], t, f"{reg}{str(t).zfill(3)}", pr if pr is not None else 0, v["doctor_id"],
                    datetime.now().isoformat(timespec="seconds"), 1 if pr is None else 0))
    try:
        recompute_examining_doctor_fee(db, visit_id)
    except Exception:
        pass
    _pc_recalc_invoice(db, visit_id)
    db.commit()
    log_action("AddTest", "visit", visit_id, "patient-card test=%s" % tid)
    return jsonify(ok=True)



# ============================== v81: بطاقة المريض (بحث فوري + نافذة بلا مسطرة) ==============================
_V81_PC_JS = ("<script id=\"lis-pc-js\">" + '(function(){\n if(window.__lisPcInit)return; window.__lisPcInit=1;\n var ov=null, fr=null, dd=null, inp=null, seq=0, timer=null, items=[], hi=-1;\n function build(){\n  if(ov)return;\n  ov=document.createElement("div"); ov.id="lisPcOv";\n  ov.style.cssText="position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:100000;display:none;align-items:center;justify-content:center;padding:14px;";\n  var box=document.createElement("div");\n  box.style.cssText="width:min(1320px,98vw);height:min(880px,96vh);border-radius:13px;overflow:hidden;background:#fff;box-shadow:0 24px 70px rgba(0,0,0,.45);";\n  fr=document.createElement("iframe"); fr.style.cssText="border:0;width:100%;height:100%;display:block;background:#F1F5F9;";\n  box.appendChild(fr); ov.appendChild(box); document.body.appendChild(ov);\n  ov.addEventListener("mousedown",function(e){ if(e.target===ov) closeCard(); });\n }\n function openCard(id){ build(); fr.src="/patient-card/"+id+"?modal=1"; ov.style.display="flex"; hideDd(); }\n function closeCard(){ if(!ov)return; ov.style.display="none"; fr.src="about:blank"; if(inp){inp.focus();} }\n window.lisOpenPatientCard=openCard;\n window.addEventListener("message",function(e){ if(e.data&&e.data.lisCard==="close") closeCard(); });\n document.addEventListener("keydown",function(e){ if(e.key==="Escape"&&ov&&ov.style.display==="flex") closeCard(); },true);\n function findInput(){\n  var byId=document.getElementById("lisQuickSearchInput"); if(byId) return byId; var a=document.querySelectorAll("input");\n  for(var i=0;i<a.length;i++){ var p=a[i].placeholder||""; if(p.indexOf("باركود")>=0&&p.indexOf("اسم")>=0){ var r=a[i].getBoundingClientRect(); if(r.top<150&&r.width>60) return a[i]; } }\n  return null;\n }\n function hideDd(){ if(dd){dd.style.display="none";} items=[]; hi=-1; }\n function esc(s){ return String(s==null?"":s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;","\\"":"&quot;"}[c];}); }\n function paint(){\n  if(!dd){ dd=document.createElement("div"); dd.id="lisPcDd"; document.body.appendChild(dd); }\n  var r=inp.getBoundingClientRect(), w=Math.max(r.width,440);\n  dd.style.cssText="position:fixed;top:"+(r.bottom+4)+"px;left:"+Math.max(8,Math.min(r.left,window.innerWidth-w-8))+"px;width:"+w+"px;max-height:62vh;overflow:auto;background:#fff;border:1px solid #94A3B8;border-radius:11px;box-shadow:0 12px 36px rgba(0,0,0,.28);z-index:99999;direction:rtl;font:13px Tahoma,Arial,sans-serif;display:block;";\n  if(!items.length){ dd.innerHTML="<div style=\\"padding:12px;color:#64748B\\">ما لكيت مريض بهذا الاسم/الرقم</div>"; return; }\n  dd.innerHTML=items.map(function(x,i){\n   return "<div data-i=\\""+i+"\\" style=\\"padding:8px 12px;cursor:pointer;border-bottom:1px solid #EEF2F6;"+(i===hi?"background:#E0F2FE;":"")+"\\"><b style=\\"color:#205072\\">"+esc(x.name)+"</b> <span style=\\"color:#475569\\">#"+esc(x.reg)+" · "+esc(x.age||"")+" "+esc(x.unit||"")+" · "+esc(x.date)+"</span>"+(x.tests?"<div style=\\"font-size:11.5px;color:#64748B;margin-top:2px\\">"+esc(x.tests)+"</div>":"")+"</div>";\n  }).join("");\n  Array.prototype.forEach.call(dd.children,function(el){ el.onmousedown=function(e){ e.preventDefault(); openCard(items[+el.dataset.i].visit_id); }; });\n }\n function search(q){\n  var my=++seq;\n  fetch("/api/pc/search?q="+encodeURIComponent(q)).then(function(r){return r.json();}).then(function(d){ if(my!==seq)return; items=d.items||[]; hi=items.length?0:-1; paint(); }).catch(function(){ if(my!==seq)return; items=[]; paint(); if(dd){ dd.innerHTML="<div style=padding:12px;color:#B91C1C>تعذّر البحث — أعد المحاولة، وإذا تكرر راجع error_log.txt</div>"; } });\n }\n function attach(){\n  inp=findInput(); if(!inp){ if((window.__lisPcTry=(window.__lisPcTry||0)+1)<20) setTimeout(attach,500); return; }\n  ["input","keyup"].forEach(function(ev){\n   document.addEventListener(ev,function(e){\n    if(e.target!==inp) return;\n    e.stopImmediatePropagation();\n    if(ev==="keyup"&&(e.key==="Enter"||e.key==="ArrowDown"||e.key==="ArrowUp"||e.key==="Escape")) return;\n    var q=inp.value.trim();\n    clearTimeout(timer);\n    if(q.length<2){ hideDd(); return; }\n    timer=setTimeout(function(){ search(q); },170);\n   },true);\n  });\n  document.addEventListener("keydown",function(e){\n   if(e.target!==inp) return;\n   if(e.key==="Enter"){ e.preventDefault(); e.stopImmediatePropagation(); if(items.length) openCard(items[Math.max(hi,0)].visit_id); else if(inp.value.trim().length>=2) search(inp.value.trim()); }\n   else if(e.key==="ArrowDown"||e.key==="ArrowUp"){ if(!items.length) return; e.preventDefault(); e.stopImmediatePropagation(); hi=(hi+(e.key==="ArrowDown"?1:-1)+items.length)%items.length; paint(); }\n   else if(e.key==="Escape"){ hideDd(); }\n   else { e.stopImmediatePropagation(); }\n  },true);\n  document.addEventListener("mousedown",function(e){ if(dd&&e.target!==inp&&!dd.contains(e.target)) hideDd(); });\n  inp.setAttribute("title","اكتب اسم المريض أو رقمه أو الباركود — تظهر بطاقة المريض فورًا");\n }\n if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",attach); else attach();\n})();' + "</script>")


def _pc_partner_prices(db):
    """{اسم المختبر: {test_definition_id: الكلفة}} لتعبئة كلفة الإرسال تلقائيًا."""
    try:
        labs, prices = _partner_context(db)
        return {l["name"]: dict(prices.get(str(l["id"]), {})) for l in labs}
    except Exception:
        return {}


def _pc_state(db, visit_id):
    b = _visit_balance(db, visit_id)
    return {"total": b["total"], "paid": b["paid"], "remaining": b["remaining"]}


def _pc_locked(db, visit_id):
    inv = db.execute("SELECT is_locked FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()
    return bool(inv and inv["is_locked"])


@app.route("/api/pc/search")
@login_required
def api_pc_search():
    q = (request.args.get("q") or "").strip()
    if len(q) < 2:
        return jsonify({"items": []})
    db = get_db()
    seq = _visit_seq_clause(q)
    rows = db.execute(
        "SELECT v.id, v.registration_number, v.created_at, p.full_name, p.age, p.age_unit, "
        "(SELECT GROUP_CONCAT(COALESCE(NULLIF(td.short_name,''), td.name), ', ') FROM order_tests ot "
        " JOIN orders o ON o.id = ot.order_id JOIN test_definitions td ON td.id = ot.test_definition_id "
        " WHERE o.visit_id = v.id) AS tests "
        "FROM visits v JOIN patients p ON p.id = v.patient_id "
        "WHERE p.full_name LIKE ? OR CAST(v.registration_number AS TEXT) LIKE ? OR p.phone LIKE ? "
        "OR EXISTS (SELECT 1 FROM order_tests ot JOIN orders o ON o.id = ot.order_id WHERE o.visit_id = v.id AND ot.barcode LIKE ?)"
        + (" OR " + seq[0] if seq else "") + " ORDER BY v.id DESC LIMIT 20",
        (f"%{q}%", _scan_like(q), f"%{q}%", f"%{q}%") + tuple(seq[1] if seq else ())).fetchall()
    return jsonify({"items": [{"visit_id": r["id"], "reg": r["registration_number"], "name": r["full_name"],
                               "age": r["age"], "unit": r["age_unit"], "tests": r["tests"] or "",
                               "date": (r["created_at"] or "")[:16].replace("T", " ")} for r in rows]})


@app.route("/api/patient-card/<int:visit_id>/state")
@login_required
def api_pc_state(visit_id):
    return jsonify(ok=True, **_pc_state(get_db(), visit_id))


@app.route("/api/patient-card/<int:visit_id>/extra", methods=["POST"])
@login_required
def api_pc_extra(visit_id):
    db = get_db()
    v = _pc_visit(db, visit_id)
    if not v:
        return jsonify(ok=False, error="الزيارة غير موجودة"), 404
    if _pc_locked(db, visit_id):
        return jsonify(ok=False, error="الفاتورة مقفلة — لا يمكن التعديل."), 400
    p = request.get_json(silent=True) or {}
    s = lambda k: (str(p.get(k) or "")).strip()
    db.execute("UPDATE patients SET address=?, national_id=?, passport_number=?, travel_certificate_number=?, lab_card_number=? WHERE id=?",
               (s("address"), s("national_id"), s("passport_number"), s("travel_certificate_number"), s("lab_card_number"), v["patient_id"]))
    home = 1 if s("is_home_visit") in ("1", "true", "True") else 0
    try:
        fee = float(s("home_visit_fee") or 0) if home else 0.0
    except ValueError:
        fee = 0.0
    db.execute("UPDATE visits SET weight=?, height=?, symptoms=?, disease=?, therapy=?, is_home_visit=?, home_visit_address=?, home_visit_fee=? WHERE id=?",
               (s("weight") or None, s("height") or None, s("symptoms"), s("disease"), s("therapy"),
                home, s("home_visit_address") if home else "", fee, visit_id))
    _pc_recalc_invoice(db, visit_id)
    db.commit()
    log_action("Update", "visit", visit_id, "patient-card extra")
    return jsonify(ok=True)


@app.route("/api/patient-card/<int:visit_id>/forward", methods=["POST"])
@login_required
def api_pc_forward(visit_id):
    """إرسال تحاليل محددة لمختبر آخر دفعة وحدة (الكلفة من قائمة أسعار المختبر إن وُجدت) — مختبر فارغ = إلغاء الإرسال."""
    db = get_db()
    p = request.get_json(silent=True) or {}
    ids = [int(x) for x in (p.get("ot_ids") or []) if str(x).isdigit()]
    lab = (p.get("lab") or "").strip() or None
    if not ids:
        return jsonify(ok=False, error="حدّد تحليلًا واحدًا على الأقل"), 400
    _ensure_partner_labs(db)
    pl = db.execute("SELECT id FROM partner_labs WHERE name=?", (lab,)).fetchone() if lab else None
    n = 0
    for oid in ids:
        ot = db.execute("SELECT ot.id, ot.test_definition_id FROM order_tests ot JOIN orders o ON o.id=ot.order_id WHERE ot.id=? AND o.visit_id=?",
                        (oid, visit_id)).fetchone()
        if not ot:
            continue
        cost = 0.0
        if lab and pl:
            pr = db.execute("SELECT cost FROM partner_lab_prices WHERE lab_id=? AND test_definition_id=?", (pl["id"], ot["test_definition_id"])).fetchone()
            cost = float(pr["cost"] or 0) if pr else 0.0
        db.execute("UPDATE order_tests SET forwarded_lab_name=?, forwarded_cost=? WHERE id=?", (lab, cost if lab else 0, oid))
        n += 1
    db.commit()
    log_action("ForwardTest", "visit", visit_id, ("patient-card lab=%s n=%d" % (lab, n)) if lab else "patient-card cleared n=%d" % n)
    return jsonify(ok=True, n=n)


@app.route("/api/patient-card/<int:visit_id>/remove/<int:ot_id>", methods=["POST"])
@login_required
def api_pc_remove(visit_id, ot_id):
    db = get_db()
    ot = db.execute("SELECT ot.id, ot.status FROM order_tests ot JOIN orders o ON o.id=ot.order_id WHERE ot.id=? AND o.visit_id=?", (ot_id, visit_id)).fetchone()
    if not ot:
        return jsonify(ok=False, error="التحليل غير موجود"), 404
    if _pc_locked(db, visit_id):
        return jsonify(ok=False, error="الفاتورة مقفلة — لا يمكن الحذف."), 400
    if ot["status"] in ("Completed", "Verified"):
        return jsonify(ok=False, error="هذا التحليل مكتمل ونتيجته محفوظة — احذفه من «التعديل الكامل» (محمي بكلمة مرور)."), 403
    visit_remove_test(visit_id, ot_id)      # نفس دالة صفحة التعديل (تحفظ نسخة للتراجع وتحدّث أجر الفاحص)
    try:
        get_flashed_messages()              # نمسح رسالة flash حتى ما تطلع بصفحة ثانية
    except Exception:
        pass
    try:
        recompute_examining_doctor_fee(db, visit_id)
    except Exception:
        pass
    _pc_recalc_invoice(db, visit_id)
    db.commit()
    return jsonify(ok=True, **_pc_state(db, visit_id))


@app.route("/api/patient-card/<int:visit_id>/pay", methods=["POST"])
@login_required
def api_pc_pay(visit_id):
    db = get_db()
    inv = db.execute("SELECT * FROM invoices WHERE visit_id=?", (visit_id,)).fetchone()
    if not inv:
        return jsonify(ok=False, error="ما توجد فاتورة لهذي الزيارة"), 404
    if inv["is_locked"]:
        return jsonify(ok=False, error="الفاتورة مقفلة"), 400
    try:
        amount = float(str((request.get_json(silent=True) or {}).get("amount") or "0").replace(",", "").strip())
    except ValueError:
        return jsonify(ok=False, error="المبلغ غير صالح"), 400
    if amount <= 0:
        return jsonify(ok=False, error="أدخل مبلغًا أكبر من صفر"), 400
    now = datetime.now().isoformat(timespec="seconds")
    new_paid = float(inv["paid_amount"] or 0) + amount
    status = "Paid" if new_paid >= float(inv["total_amount"] or 0) else "Partial"
    db.execute("INSERT INTO payments (invoice_id, amount, method, user_id, paid_at) VALUES (?, ?, 'Cash', ?, ?)",
               (inv["id"], amount, session.get("user_id"), now))
    db.execute("UPDATE invoices SET paid_amount=?, status=? WHERE id=?", (new_paid, status, inv["id"]))
    db.commit()
    log_action("Payment", "invoice", inv["id"], "amount=%s (patient-card)" % amount)
    return jsonify(ok=True, **_pc_state(db, visit_id))


@app.after_request
def _pc_inject_search_popup(resp):
    """يحقن سكربت بحث البطاقة بكل صفحات البرنامج (اللي ترث base.html): مربع البحث العلوي يعرض مرضى فورًا ويفتح البطاقة."""
    try:
        if resp.status_code != 200 or resp.mimetype != "text/html" or resp.direct_passthrough:
            return resp
        data = resp.get_data()
        if b"lis-sidebar-hidden" not in data or b'id="lis-pc-js"' in data or b"</body>" not in data:
            return resp
        head, _, tail = data.rpartition(b"</body>")
        resp.set_data(head + _V81_PC_JS.encode("utf-8") + b"</body>" + tail)
    except Exception:
        pass
    return resp


@app.after_request
def _pc_inject_search_buttons(resp):
    """بصفحة نتائج البحث: زر 🪟 بجانب كل نتيجة (وزر عائم لو نتيجة واحدة) يفتح بطاقة المريض بنافذة مستقلة."""
    try:
        if request.path == "/search" and resp.mimetype == "text/html" and resp.status_code == 200:
            body = resp.get_data(as_text=True)
            if "lisPcBtns" not in body and "</body>" in body:
                js = ("<script id='lisPcBtns'>(function(){var seen={},first=null;document.querySelectorAll('a[href*=\"/visits/\"]').forEach(function(a){"
                      "var m=(a.getAttribute('href')||'').match(/\\/visits\\/(\\d+)/);if(!m)return;var id=m[1];first=first||id;seen[id]=1;"
                      "if(a.dataset.pcDone)return;a.dataset.pcDone=1;var b=document.createElement('a');b.href='#';b.textContent='🪟 بطاقة';b.title='بطاقة المريض';"
                      "b.style.cssText='margin:0 6px;background:#205072;color:#fff;border-radius:7px;padding:3px 9px;font-size:12px;text-decoration:none;white-space:nowrap';"
                      "b.onclick=function(e){e.preventDefault();window.open('/patient-card/'+id,'lisCard'+id,'width=1180,height=820,resizable=yes,scrollbars=yes');};"
                      "a.parentNode.insertBefore(b,a.nextSibling);});"
                      "var ids=Object.keys(seen);if(ids.length===1){var f=document.createElement('a');f.href='#';f.textContent='🪟 فتح بطاقة المريض';"
                      "f.style.cssText='position:fixed;bottom:16px;left:16px;z-index:9999;background:#15803D;color:#fff;border-radius:10px;padding:10px 16px;font:700 14px Tahoma;text-decoration:none;box-shadow:0 3px 12px rgba(0,0,0,.3)';"
                      "f.onclick=function(e){e.preventDefault();window.open('/patient-card/'+ids[0],'lisCard','width=1180,height=820,resizable=yes,scrollbars=yes');};document.body.appendChild(f);}})();</script>")
                resp.set_data(body.replace("</body>", js + "</body>", 1))
    except Exception:
        pass
    return resp


# v79: لو للمريض CBC بنفس الزيارة => حقل HCT بتحليل Retic يختفي من شاشة الإدخال (القيمة تُسحب تلقائيًا من CBC).
# لو ما عنده CBC يبقى الحقل ظاهر للكتابة (ويُستخدم للحساب فقط، ولا يُطبع بتقرير Retic).
_V79_HIDE_RETIC_HCT_JS = """<script>
(function(){
  function first(tr){var c=tr.querySelector('td,th');return c?c.textContent.replace(/\\s+/g,' ').trim():'';}
  function rowsOf(el){return Array.prototype.slice.call(el.querySelectorAll('tr'));}
  var all=rowsOf(document);
  all.forEach(function(tr){
    if(first(tr)!=='HCT') return;
    var p=tr.parentElement,card=null;
    for(var i=0;i<10&&p;i++,p=p.parentElement){
      var rs=rowsOf(p).map(first);
      if(rs.indexOf('Reticulocyte count')>=0){ if(rs.indexOf('WBCs')<0&&rs.indexOf('RBC')<0) card=p; break; }
    }
    if(card){ tr.style.display='none'; tr.setAttribute('data-lis-hct-hidden','1'); }
  });
})();
</script>"""


@app.after_request
def _v79_hide_retic_hct(resp):
    try:
        if request.endpoint not in ("visit_results_entry", "result_entry") or resp.status_code != 200 \
                or resp.mimetype != "text/html" or resp.direct_passthrough:
            return resp
        _va = request.view_args or {}
        db = get_db()
        if "visit_id" in _va:
            vid = _va["visit_id"]
        else:
            _r = db.execute("SELECT o.visit_id FROM order_tests ot JOIN orders o ON o.id=ot.order_id WHERE ot.id=?",
                            (_va.get("order_test_id"),)).fetchone()
            vid = _r["visit_id"] if _r else None
        if vid is None:
            return resp
        has_cbc = db.execute(
            "SELECT 1 FROM order_tests ot JOIN orders o ON o.id=ot.order_id JOIN test_definitions td ON td.id=ot.test_definition_id "
            "WHERE o.visit_id=? AND td.code='CBC'", (vid,)).fetchone()
        if not has_cbc:
            return resp
        data = resp.get_data()
        if b"</body>" in data and b"data-lis-hct-hidden" not in data:
            resp.set_data(data.replace(b"</body>", _V79_HIDE_RETIC_HCT_JS.encode("utf-8") + b"</body>", 1))
    except Exception:
        pass
    return resp


# ============================== v80: ESR تحت CBC + Retic داخل BF ==============================
_V80_ESR_DOTS = False      # True = خطوط منقّطة بين الاسم والنتيجة والمدى (الافتراضي: بدون خطوط حسب الطلب)
_V80_RETIC_NAMES = ("Reticulocyte count", "Corrected Retic count")


def _v80_is_esr(code, name):
    c = (code or "").strip().upper()
    n = (name or "").strip().lower()
    return c == "ESR" or n == "esr" or n.startswith("esr ") or n.startswith("esr(") or "erythrocyte sedimentation" in n


def _v80_esr_html(db, cbc_ot_id):
    """سطر ESR الجاهز (HTML) لتقرير CBC، أو None لو ما عنده ESR/ما عنده نتيجة."""
    cbc = db.execute(
        "SELECT ot.order_id, p.id AS patient_id, p.gender, p.age, p.age_unit FROM order_tests ot "
        "JOIN orders o ON o.id = ot.order_id JOIN visits v ON v.id = o.visit_id JOIN patients p ON p.id = v.patient_id "
        "JOIN test_definitions td ON td.id = ot.test_definition_id WHERE ot.id=? AND td.code='CBC'", (cbc_ot_id,)).fetchone()
    if not cbc:
        return None
    esr_ots = [r for r in db.execute(
        "SELECT ot.id, ot.analyzer, td.code AS code, td.name AS name FROM order_tests ot "
        "JOIN test_definitions td ON td.id = ot.test_definition_id WHERE ot.order_id=? ORDER BY ot.id",
        (cbc["order_id"],)).fetchall() if _v80_is_esr(r["code"], r["name"])]
    lines = []
    for eo in esr_ots:
        for r in db.execute(
                "SELECT r.value_numeric, r.value_text, r.flag, tp.id AS pid, tp.name AS pname, tp.unit AS unit "
                "FROM results r JOIN test_parameters tp ON tp.id = r.test_parameter_id "
                "WHERE r.order_test_id=? ORDER BY tp.sort_order, tp.id", (eo["id"],)).fetchall():
            num, txt = r["value_numeric"], (r["value_text"] or "").strip()
            if num is None and not txt:
                continue
            if num is not None:
                val = str(int(num)) if float(num) == int(num) else str(num)
            else:
                val = txt
            rng = None
            try:
                rng = find_reference_range(db, r["pid"], cbc["gender"], cbc["age"], cbc["age_unit"],
                                           patient_id=cbc["patient_id"], analyzer=eo["analyzer"])
            except Exception:
                rng = None
            rtxt, low, high = "", None, None
            if rng is not None:
                try:
                    low, high = rng["low"], rng["high"]
                except (KeyError, IndexError, TypeError):
                    low = high = None
                try:
                    rtxt = (rng["range_text"] or "").strip()
                except (KeyError, IndexError, TypeError):
                    rtxt = ""
                if not rtxt and (low is not None or high is not None):
                    def _n(x):
                        return str(int(x)) if float(x) == int(x) else str(x)
                    rtxt = (_n(low) + " - " + _n(high)) if (low is not None and high is not None) else \
                           (("> " + _n(low)) if low is not None else ("< " + _n(high)))
            bad = (r["flag"] or "") in ("Low", "High", "Critical")
            if num is not None:
                if low is not None and num < low:
                    bad = True
                if high is not None and num > high:
                    bad = True
            lines.append((r["pname"] or "ESR", val, (r["unit"] or "").strip(), rtxt, bad))
    if not lines:
        return None
    dots = "border-bottom:2px dotted #666;transform:translateY(-3px);" if _V80_ESR_DOTS else ""
    out = ['<div class="lis-esr" dir="ltr" style="direction:ltr;margin:12px 0 0;padding-top:9px;border-top:1.5px solid #222;'
           'font-family:\'Times New Roman\',Georgia,serif;color:#111;">']
    for nm, val, unit, rtxt, bad in lines:
        col = "color:#c00;" if bad else ""
        out.append(
            '<div style="display:flex;align-items:baseline;gap:6px;font-size:13.5px;line-height:1.6;">'
            '<span style="font-weight:700;white-space:nowrap;">%s</span>'
            '<span style="flex:1;min-width:20px;%s"></span>'
            '<span style="font-weight:700;white-space:nowrap;text-align:center;min-width:90px;%s">%s</span>'
            '<span style="flex:1;min-width:20px;%s"></span>'
            '<span style="white-space:nowrap;min-width:120px;text-align:right;color:#333;">%s</span></div>'
            % (_html_escape(nm), dots, col, _html_escape((val + " " + unit).strip()), dots,
               _html_escape(("Normal: " + rtxt) if rtxt else "")))
    out.append("</div>")
    return "".join(out)


def _v80_insert_after_cbc_table(html, block):
    if 'class="lis-esr"' in html:
        return html
    pos = html.find('class="data-table"')   # v81: جدول CBC الحقيقي (قالب cbc.html)
    if pos < 0:
        pos = html.rfind("PLT")
    if pos < 0:
        pos = html.rfind("HGB")
    end = html.find("</table>", pos) if pos >= 0 else -1
    if end < 0:
        end = html.rfind("</table>")
    if end >= 0:
        end += len("</table>")
        return html[:end] + block + html[end:]
    i = html.rfind("</body>")
    return (html[:i] + block + html[i:]) if i >= 0 else (html + block)


def _print_report_impl(order_test_id):
    """v80: نفس تقرير v79 + سطر ESR أسفل جدول CBC لو عند المريض ESR بنفس الزيارة."""
    res = _print_report_impl_v79(order_test_id)
    try:
        if isinstance(res, str):
            db = get_db()
            block = _v80_esr_html(db, order_test_id)
            if block:
                return _v80_insert_after_cbc_table(res, block)
    except Exception:
        _v74_log_exc("v80 ESR under CBC failed (order_test %s)" % order_test_id)
    return res


def _v80_retic_row(db, order_id):
    return db.execute(
        "SELECT ot2.*, td2.code AS test_code, v.id AS visit_id, p.gender, p.age, p.age_unit "
        "FROM order_tests ot2 JOIN test_definitions td2 ON td2.id = ot2.test_definition_id "
        "JOIN orders o2 ON o2.id = ot2.order_id JOIN visits v ON v.id = o2.visit_id JOIN patients p ON p.id = v.patient_id "
        "WHERE ot2.order_id=? AND td2.code='RETIC'", (order_id,)).fetchone()


def _v80_sync_bf_to_retic(db, ot, parameters, user_id, now, patient_id):
    """عند حفظ BF: ينسخ Reticulocyte count / Corrected Retic count لتحليل Retic بنفس الزيارة ويكمّله."""
    try:
        if "test_code" not in ot.keys() or ot["test_code"] != "BF":
            return
        bf_params = {p["name"]: p for p in parameters if p["name"] in _V80_RETIC_NAMES}
        if "Reticulocyte count" not in bf_params:
            return
        rt = _v80_retic_row(db, ot["order_id"])
        if not rt:
            return
        rparams = db.execute("SELECT * FROM test_parameters WHERE test_definition_id=?", (rt["test_definition_id"],)).fetchall()
        rby = {p["name"]: p for p in rparams}

        def _has(r):
            return r is not None and (r["value_numeric"] is not None or (r["value_text"] or "") != "")
        copied = False
        for nm, bp in bf_params.items():
            rp = rby.get(nm)
            if not rp:
                continue
            src = db.execute("SELECT * FROM results WHERE order_test_id=? AND test_parameter_id=?", (ot["id"], bp["id"])).fetchone()
            if not _has(src):
                continue
            note = src["note"] if "note" in src.keys() else None
            dst = db.execute("SELECT * FROM results WHERE order_test_id=? AND test_parameter_id=?", (rt["id"], rp["id"])).fetchone()
            if dst:
                if dst["value_numeric"] != src["value_numeric"] or dst["value_text"] != src["value_text"]:
                    db.execute(
                        "INSERT INTO result_history (result_id, order_test_id, test_parameter_id, prev_value_numeric, "
                        "prev_value_text, prev_flag, changed_by, changed_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                        (dst["id"], rt["id"], rp["id"], dst["value_numeric"], dst["value_text"], dst["flag"], user_id, now))
                db.execute("UPDATE results SET value_numeric=?, value_text=?, flag=?, note=?, entered_by=?, entered_at=? WHERE id=?",
                           (src["value_numeric"], src["value_text"], src["flag"], note, user_id, now, dst["id"]))
            else:
                db.execute("INSERT INTO results (order_test_id, test_parameter_id, value_numeric, value_text, flag, note, "
                           "entered_by, entered_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                           (rt["id"], rp["id"], src["value_numeric"], src["value_text"], src["flag"], note, user_id, now))
            copied = True
        if copied and rt["status"] != "Verified":
            db.execute("UPDATE order_tests SET status='Completed' WHERE id=?", (rt["id"],))
        # Corrected لو ما انكتب ببطاقة BF: يُحسب (من HCT الـCBC) ثم يُنسخ لبطاقة BF حتى يظهر هناك
        cbp = bf_params.get("Corrected Retic count")
        crp = rby.get("Corrected Retic count")
        if copied and cbp and crp:
            bsrc = db.execute("SELECT * FROM results WHERE order_test_id=? AND test_parameter_id=?", (ot["id"], cbp["id"])).fetchone()
            if not _has(bsrc):
                _apply_retic_correction(db, rt, rparams, {}, "", user_id, now, patient_id)
                rc = db.execute("SELECT * FROM results WHERE order_test_id=? AND test_parameter_id=?", (rt["id"], crp["id"])).fetchone()
                if _has(rc):
                    if bsrc:
                        db.execute("UPDATE results SET value_numeric=?, value_text=?, flag=?, note=?, entered_by=?, entered_at=? WHERE id=?",
                                   (rc["value_numeric"], rc["value_text"], rc["flag"], rc["note"], user_id, now, bsrc["id"]))
                    else:
                        db.execute("INSERT INTO results (order_test_id, test_parameter_id, value_numeric, value_text, flag, note, "
                                   "entered_by, entered_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                                   (ot["id"], cbp["id"], rc["value_numeric"], rc["value_text"], rc["flag"], rc["note"], user_id, now))
    except Exception:
        _v74_log_exc("v80 BF->RETIC sync failed")


def _v80_retic_sibling_id(db, ot):
    try:
        if "test_code" in ot.keys() and ot["test_code"] == "BF":
            rt = _v80_retic_row(db, ot["order_id"])
            return rt["id"] if rt else None
    except Exception:
        pass
    return None


def _v80_adjust_entry_boxes(db, visit_id, boxes):
    """شاشة إدخال نتائج الزيارة: BF+Retic => بطاقة Retic تختفي (حقولها ببطاقة BF). BF بدون Retic => ينلغي حقلا Retic من BF."""
    try:
        codes = {r["c"] for r in db.execute(
            "SELECT td.code AS c FROM order_tests ot JOIN orders o ON o.id = ot.order_id "
            "JOIN test_definitions td ON td.id = ot.test_definition_id WHERE o.visit_id=?", (visit_id,)).fetchall()}
        bf = [b for b in boxes if b["ot"]["test_code"] == "BF"]
        if not bf:
            return boxes
        if "RETIC" in codes:
            if "Reticulocyte count" in {p["name"] for p in bf[0]["parameters"]}:
                return [b for b in boxes if b["ot"]["test_code"] != "RETIC"]
            return boxes
        for b in bf:
            b["parameters"] = [p for p in b["parameters"] if p["name"] not in _V80_RETIC_NAMES]
    except Exception:
        _v74_log_exc("v80 entry boxes adjust failed")
    return boxes


if __name__ == "__main__":
    init_db()
    write_pending_preset_logo(UPLOAD_DIR)   # شعار العميل القادم من portal_preset.json (إن وُجد)
    cloud_sync.start_worker()
    astm_host.start_listener_if_enabled()


    import threading
    threading.Thread(target=whatsapp_background_worker, daemon=True).start()
    threading.Thread(target=_hang_watchdog, daemon=True).start()
    # يحمّل توكن قراءة GitHub من الإعدادات المحلية (settings.github_read_token)
    # إلى الذاكرة قبل تشغيل خيط التحديث — التوكن نفسه ما يُكتب أبداً بكود
    # auto_updater.py حتى ما يترفع مع git push ويُلغى تلقائياً من GitHub
    # (راجع الشرح المفصّل بأعلى auto_updater.py).
    _startup_db = get_db()
    auto_updater.load_token_from_db(_startup_db)
    _startup_db.close()
    # خيط فحص التحديث التلقائي — يشتغل دائماً بالخلفية، لكن ما يتحقق فعلياً
    # من GitHub إلا إذا كان هذا الجهاز "مربوط بالإنترنت" من لوحة المصمم
    # (settings.auto_update_enabled = 1). راجع auto_updater.py.
    try:
        auto_updater.set_config_applier(_cfg_remote_apply)
    except Exception:
        pass
    threading.Thread(target=auto_updater.background_loop, args=(get_db,), daemon=True).start()

    if getattr(sys, "frozen", False):
        import logging
        logging.getLogger("werkzeug").setLevel(logging.WARNING)   # ما نسجّل كل طلب GET بالملف
    app.run(host="0.0.0.0", port=9090, debug=False, threaded=True)
