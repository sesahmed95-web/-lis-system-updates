"""
نظام التحديث التلقائي عبر الإنترنت (Auto-Update over the Internet)
====================================================================
هذا النظام منفصل تماماً عن نظام الترخيص (license_manager.py). وظيفته
الوحيدة: يخلي برنامج العميل يتحقق دورياً (أو عند الطلب من لوحة المصمم)
هل صدر إصدار أحدث من البرنامج، وإذا نعم ينزّله ويثبّته تلقائياً فوق نفس
مكان التثبيت (%LOCALAPPDATA%\\HematologistLIS) بدون ما يحتاج العميل يسوي
أي شيء يدوياً.

آلية العمل باختصار
-------------------
1. أنت (المصمم) تسوي مستودع GitHub **خاص (Private)** واحد لمشروع البرنامج.
   خاص عشان الكود ما يصير ظاهر للعموم.
2. كل مرة تسوي تحديث: تحدّث ملف VERSION برقم إصدار أكبر من السابق، وتسوي
   git push عادي لفرع main. **هذا كل شي** — ما تحتاج تسوي "Release" ولا
   ترفع ملف zip يدوياً؛ البرنامج يقرأ مباشرة آخر نسخة من فرع main.
3. برنامج كل عميل (بعد ما "يرتبط بالإنترنت" من لوحة المصمم الخاصة بجهازه)
   يتحقق دورياً من محتوى ملف VERSION على فرع main بمستودعك، يقارنه
   بالرقم المثبّت عنده محلياً، وإذا لقى رقم أحدث ينزّل نسخة كاملة من فرع
   main (zipball) ويشغّل update.ps1 تلقائياً بالخلفية (نفس السكربت
   المستخدم للتحديث اليدوي، فقط بمصدر= الملف المنزّل بدل مجلد جنب البرنامج).

⚠️ مهم جداً قبل تسليم البرنامج لأي عميل — عبّي القيم تحت:
   - GITHUB_OWNER: اسم حسابك/منظمتك على GitHub.
   - GITHUB_REPO: اسم المستودع (الخاص) اللي فيه الإصدارات.
   - GITHUB_BRANCH: اسم الفرع اللي تدفع (push) عليه تحديثاتك — افتراضياً main.

🔒 توكن القراءة (GITHUB_TOKEN) — لا يُكتب هنا أبداً بعد اليوم
   ------------------------------------------------------------
   قديماً كان هذا التوكن مكتوب صراحة بهذا الملف. المشكلة: هذا الملف نفسه
   جزء من المستودع اللي يترفع (git push) مع كل تحديث — يعني أي توكن
   تكتبه هنا يترفع لـ GitHub مكشوفاً، وGitHub يكتشف تلقائياً أي توكن من
   صيغته (github_pat_...) بأي مستودع (خاص أو عام) ويُلغيه فوراً كحماية —
   ولذلك كان يموت التوكن بشكل متكرر بغض النظر كم مرة تجدده.
   الحل: التوكن الحين يُخزَّن فقط محلياً بجدول settings (بقاعدة بيانات
   كل جهاز)، ويُدخَل من لوحة المصمم (قسم "توكن القراءة" بجانب "توكن
   الكتابة" الموجود أصلاً) — أبداً لا يُكتب هنا بالكود ولا يدخل أي
   git commit. راجع configure_token()/_get_token() تحت.
"""
import json
import os
import re
import subprocess
import sys
import tempfile
import time
import base64
import urllib.request
import urllib.error
import zipfile
from datetime import datetime

# ============================ إعدادات المصمم (عبّيها قبل التسليم) =========
GITHUB_OWNER = "sesahmed95-web"     # 🔒 غيّرها
GITHUB_REPO = "-lis-system-updates"    # 🔒 غيّرها
GITHUB_BRANCH = "main"                 # 🔒 اسم الفرع اللي تدفع عليه تحديثاتك
# مسار ملف VERSION داخل المستودع (لو حاطه بمجلد فرعي غيّر هذا المسار،
# مثلاً "lis_system/VERSION"). اتركه "VERSION" لو بجذر المستودع مباشرة.
VERSION_FILE_PATH_IN_REPO = "VERSION"
# كل قد ايش ساعة يتحقق البرنامج تلقائياً من وجود تحديث جديد (فقط إذا
# كان هذا الجهاز "مربوط بالإنترنت" من لوحة المصمم).
CHECK_INTERVAL_HOURS = 6
# ===========================================================================

# نسخة exe المثبّتة (PyInstaller): ملف VERSION يوضع بجانب LabSystem.exe (نفس منطق database.py)
if getattr(sys, "frozen", False):
    APP_DIR = os.path.dirname(sys.executable)
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))
VERSION_FILE = os.path.join(APP_DIR, "VERSION")
API_BASE = "https://api.github.com"

# ------------------------------------------------------- توكن القراءة -----
# يُخزَّن فقط بالذاكرة أثناء تشغيل البرنامج + بجدول settings المحلي —
# أبداً لا يُكتب هنا بالكود المصدري (راجع الشرح بأعلى الملف عن سبب هذا
# التغيير). load_token_from_db() تُستدعى مرة وحدة عند إقلاع البرنامج
# (app.py)، وconfigure_token() تُستدعى فوراً كل مرة يغيّره المصمم من
# لوحته بدون الحاجة لإعادة تشغيل البرنامج.
_runtime_token = None


def configure_token(token):
    """يضبط توكن القراءة بذاكرة هذا التشغيل فقط. يُستدعى عند الإقلاع
    (بعد قراءته من settings) وأيضاً فوراً بعد أي حفظ جديد له من لوحة
    المصمم، حتى يسري أثره فوراً بدون إعادة تشغيل."""
    global _runtime_token
    _runtime_token = (token or "").strip() or None


def load_token_from_db(db):
    """يقرأ توكن القراءة المحفوظ بجدول settings (المفتاح github_read_token)
    ويحمّله بالذاكرة. تُستدعى مرة وحدة عند إقلاع البرنامج."""
    from database import get_setting
    configure_token(get_setting(db, "github_read_token", ""))


def _get_token():
    return _runtime_token


def is_configured():
    """يرجع False لو المصمم نسى يعبّي القيم أعلاه، أو لو توكن القراءة
    لسا ما انضبط من لوحة المصمم (settings.github_read_token) — يمنع أي
    محاولة اتصال عبثية بدون بيانات كاملة."""
    return (
        GITHUB_OWNER and "YOUR-" not in GITHUB_OWNER
        and GITHUB_REPO and "YOUR-" not in GITHUB_REPO
        and bool(_get_token())
    )


def get_local_version():
    try:
        with open(VERSION_FILE, "r", encoding="utf-8") as f:
            return f.read().strip() or "0"
    except Exception:
        return "0"


def _version_key(v):
    """يحوّل نص الإصدار إلى رقم للمقارنة (v16 -> 16، 2026.08.06 -> يقارن
    كنص لو ما قدر يحوّله رقم)."""
    digits = re.sub(r"[^0-9]", "", v or "")
    return int(digits) if digits else -1


def is_newer(remote_version, local_version):
    rk, lk = _version_key(remote_version), _version_key(local_version)
    if rk != -1 and lk != -1:
        return rk > lk
    return (remote_version or "") != (local_version or "") and bool(remote_version)


def get_update_branch(db=None):
    """يرجّع اسم الفرع اللي هذا الجهاز بالذات يتحقق منه. الافتراضي
    GITHUB_BRANCH (نفس الفرع لكل العملاء). لو تم ضبط update_channel
    بجدول settings (من لوحة المصمم) يستخدمه بدلها — هذا يخلي تحديث معيّن
    يوصل لعميل واحد فقط بدل كل العملاء: انشئ فرع خاص بهذا العميل
    بمستودعك، ادفع (push) التعديل عليه هو فقط، وحط اسم الفرع هذا كـ
    'قناة التحديث' لهذا العميل من لوحة المصمم عنده. باقي العملاء الباقين
    على 'main' ما يتأثرون. لاحقاً لو تبي التعديل يوصل للكل: اعمل merge
    للفرع داخل main."""
    if db is not None:
        try:
            from database import get_setting
            channel = (get_setting(db, "update_channel", "") or "").strip()
            if channel:
                return channel
        except Exception:
            pass
    return GITHUB_BRANCH


def _api_request(path, accept="application/vnd.github+json"):
    req = urllib.request.Request(f"{API_BASE}{path}")
    req.add_header("Authorization", f"Bearer {_get_token()}")
    req.add_header("Accept", accept)
    req.add_header("X-GitHub-Api-Version", "2022-11-28")
    req.add_header("User-Agent", "LIS-Auto-Updater")
    return urllib.request.urlopen(req, timeout=20)


def fetch_remote_version(branch=None):
    """يقرأ محتوى ملف VERSION مباشرة من الفرع المطلوب (افتراضياً
    GITHUB_BRANCH، أو الفرع الخاص بهذا الجهاز عبر get_update_branch) —
    بدون أي حاجة لعمل GitHub Release. أي git push عادي لهذا الفرع (بملف
    VERSION محدّث) كافي حتى تلتقطه نسخ العملاء المتابعة له."""
    branch = branch or GITHUB_BRANCH
    if not is_configured():
        raise RuntimeError("لم يتم إعداد بيانات GitHub بعد (auto_updater.py) — راجع المصمم")
    path = f"/repos/{GITHUB_OWNER}/{GITHUB_REPO}/contents/{VERSION_FILE_PATH_IN_REPO}?ref={branch}"
    with _api_request(path) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    content_b64 = base64.b64decode(data["content"]).decode("utf-8")
    return content_b64.strip()


def _download_branch_zip(dest_path, branch=None):
    """ينزّل نسخة كاملة من فرع GITHUB_BRANCH (zipball) — نفس أسلوب تنزيل
    ملف من مستودع خاص عبر GitHub API: أول طلب بتوكن يرجع تحويل (302)
    لرابط مؤقت موقّع، وهذا الرابط الثاني ما لازم نرسل معه توكن GitHub
    إطلاقاً (يرفضه)، فنطفي المتابعة التلقائية للتحويل ونسوي الطلب الثاني
    يدوياً بدون هيدر Authorization."""
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k):
            return None

    zipball_url = f"{API_BASE}/repos/{GITHUB_OWNER}/{GITHUB_REPO}/zipball/{branch or GITHUB_BRANCH}"
    opener = urllib.request.build_opener(NoRedirect)
    req = urllib.request.Request(zipball_url)
    req.add_header("Authorization", f"Bearer {_get_token()}")
    req.add_header("User-Agent", "LIS-Auto-Updater")
    try:
        resp = opener.open(req, timeout=30)
        with open(dest_path, "wb") as f:
            f.write(resp.read())
        return
    except urllib.error.HTTPError as e:
        if e.code not in (301, 302, 303, 307, 308):
            raise
        redirect_url = e.headers.get("Location")
    if not redirect_url:
        raise RuntimeError("تعذر الحصول على رابط تنزيل نسخة التحديث")
    req2 = urllib.request.Request(redirect_url)
    req2.add_header("User-Agent", "LIS-Auto-Updater")
    with urllib.request.urlopen(req2, timeout=120) as resp2, open(dest_path, "wb") as f:
        f.write(resp2.read())


def _extract_zip(zip_path, extract_dir):
    with zipfile.ZipFile(zip_path) as z:
        z.extractall(extract_dir)
    # لو الملف المضغوط فيه مجلد واحد فرعي (lis_system/...) رجّع مساره،
    # وإلا رجّع نفس مجلد الفك مباشرة.
    entries = [e for e in os.listdir(extract_dir) if not e.startswith("__MACOSX")]
    if len(entries) == 1 and os.path.isdir(os.path.join(extract_dir, entries[0])):
        return os.path.join(extract_dir, entries[0])
    return extract_dir


def apply_update(silent=True, branch=None):
    """ينزّل نسخة الفرع المطلوب (افتراضياً GITHUB_BRANCH، أو فرع هذا
    الجهاز الخاص لو تم تمريره)، يفكّها، ويشغّل update.ps1 (نفس سكربت
    التحديث اليدوي الموجود أصلاً) بمصدر = الملف المنزّل. update.ps1 هو
    اللي يوقف السيرفر الحالي وينسخ الملفات الجديدة ويعيد التشغيل — فما
    نحتاج نعيد كتابة هذا المنطق من الصفر."""
    if sys.platform != "win32":
        raise RuntimeError("التحديث التلقائي مدعوم فقط على Windows حالياً")
    if getattr(sys, "frozen", False):
        # نسخة Setup/exe: ملفات .py صارت داخل الـexe فما يكدر update.ps1 يحدّثها.
        raise RuntimeError("النسخة المثبّتة (Setup) تتحدّث بتثبيت ملف Setup جديد من المصمم، مو تلقائياً")

    tmp_dir = tempfile.mkdtemp(prefix="lis_update_")
    zip_path = os.path.join(tmp_dir, "update.zip")
    _download_branch_zip(zip_path, branch=branch)
    source_dir = _extract_zip(zip_path, os.path.join(tmp_dir, "extracted"))

    update_script = os.path.join(APP_DIR, "update.ps1")
    if not os.path.exists(update_script):
        raise RuntimeError("update.ps1 غير موجود بمجلد البرنامج")

    args = [
        "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass",
        "-File", update_script, "-Source", source_dir,
    ]
    if silent:
        args.append("-Silent")

    creationflags = 0x08000000  # CREATE_NO_WINDOW
    subprocess.Popen(args, creationflags=creationflags, cwd=APP_DIR)


def check_and_apply(db, force_apply=True):
    """يتحقق من وجود إصدار أحدث (مباشرة من ملف VERSION على فرع
    التحديث الخاص بهذا الجهاز — راجع get_update_branch — بدون أي حاجة
    لـ GitHub Release). لو موجود ينزّله ويطبّقه (البرنامج راح يعيد تشغيل
    نفسه تلقائياً خلال ثوان). يرجع dict فيه النتيجة ويسجّلها بجدول
    settings حتى تنعرض بلوحة المصمم."""
    from database import set_setting
    now = datetime.now().isoformat(timespec="seconds")
    branch = get_update_branch(db)
    try:
        local_version = get_local_version()
        remote_version = fetch_remote_version(branch=branch)
        if is_newer(remote_version, local_version):
            if getattr(sys, "frozen", False):
                status = f"🆕 يتوفر إصدار جديد ({remote_version}) — اطلب ملف Setup الجديد من المصمم"
                set_setting(db, "auto_update_last_check", now)
                set_setting(db, "auto_update_last_status", status)
                db.commit()
                return {"ok": True, "updated": False, "remote_version": remote_version,
                        "local_version": local_version, "message": status}
            status = f"🆕 تم العثور على إصدار جديد ({remote_version}) — جاري التحديث الآن..."
            set_setting(db, "auto_update_last_check", now)
            set_setting(db, "auto_update_last_status", status)
            # يُقرأ هذا بعد إعادة التشغيل ويُعرض كرسالة لأول مستخدم يفتح
            # البرنامج (راجع enforce_license بملف app.py) — ثم يُمسح فوراً
            # حتى ما يتكرر بكل صفحة.
            set_setting(db, "auto_update_pending_banner", remote_version)
            db.commit()
            if force_apply:
                apply_update(silent=True, branch=branch)
            return {"ok": True, "updated": True, "remote_version": remote_version,
                    "local_version": local_version, "message": status}
        else:
            status = f"✅ البرنامج على آخر إصدار ({local_version})"
            set_setting(db, "auto_update_last_check", now)
            set_setting(db, "auto_update_last_status", status)
            db.commit()
            return {"ok": True, "updated": False, "remote_version": remote_version,
                    "local_version": local_version, "message": status}
    except Exception as e:
        status = f"⚠️ تعذر التحقق من التحديث: {e}"
        set_setting(db, "auto_update_last_check", now)
        set_setting(db, "auto_update_last_status", status)
        db.commit()
        return {"ok": False, "updated": False, "message": status}


def background_loop(get_db_func):
    """خيط خلفية دائم — ينام ثم يتحقق كل CHECK_INTERVAL_HOURS. ملاحظة مهمة:
    check_revocation و check_update_signal يفحصان دائمًا طالما فيه توكن
    قراءة صالح (is_configured())، بغض النظر عن auto_update_enabled —
    هذا الأخير يتحكم فقط بتحديثات النسخة العادية (check_and_apply) وهو
    الزر اللي يقدر العميل نفسه يبدّله من شريط الأعلى بالبرنامج (بعكس
    الإلغاء عن بُعد أو أمر التحديث الفوري، اللي لازم يضلّان تحت سيطرة
    المصمم دائمًا حتى لو العميل عطّل التحديث التلقائي عنده)."""
    from database import get_setting
    # فحص أول بعد 30 ثانية من الإقلاع (مو فوري حتى ما يبطّئ الإقلاع)
    time.sleep(30)
    while True:
        try:
            db = get_db_func()
            if is_configured():
                enabled = get_setting(db, "auto_update_enabled", "1") == "1"
                if enabled:
                    check_and_apply(db, force_apply=True)
                # هذولا يفحصان دائمًا — لا يتأثران بزر العميل إطلاقًا.
                check_revocation(db)
                check_update_signal(db)
                check_config_pack(db)
            db.close()
        except Exception:
            pass
        time.sleep(CHECK_INTERVAL_HOURS * 3600)


# ==================================================== إلغاء ترخيص عن بُعد ==
# آلية مستقلة عن التفعيل نفسه (license_manager.py) لكنها تستخدم نفس مستودع
# GitHub الخاص المُعدّ أعلاه. تخزّن قائمة أجهزة العملاء الملغاة كملف JSON
# واحد داخل المستودع (REVOCATION_FILE_PATH)، وكل جهاز عميل "مربوط
# بالإنترنت" يفحصها بنفس دورة فحص التحديثات (وبنفس توكن القراءة أعلاه —
# لا حاجة لصلاحية كتابة لقراءتها).
#
# النشر (كتابة الملف على GitHub) يحتاج توكن مختلف بصلاحية كتابة، ولا
# يُخزَّن هذا التوكن أبداً داخل هذا الملف ولا يُشحَن مع نسخة أي عميل —
# المصمم يدخله بنفسه من لوحة المصمم (يُحفَظ محلياً بجهازه فقط، بجدول
# settings)، فيبقى توكن القراءة (المضبوط بنفس الطريقة عبر settings —
# راجع configure_token أعلى الملف) بصلاحية قراءة فقط دائماً — حتى لو
# استخرجه أي عميل من نسخته ما يقدر يعدّل شي بمستودعك.
REVOCATION_FILE_PATH = "revoked_licenses.json"


def _contents_url(path):
    return f"/repos/{GITHUB_OWNER}/{GITHUB_REPO}/contents/{path}"


def fetch_revocation_list():
    """يرجع dict {hardware_id: {reason, revoked_at}}. يرجع {} بهدوء لو
    الملف غير موجود بعد بالمستودع (يعني ماكو أي إلغاء لحد الآن) — هذا
    ليس خطأ. يرفع Exception فقط لو صار خطأ اتصال/صلاحيات حقيقي."""
    if not is_configured():
        raise RuntimeError("لم يتم إعداد بيانات GitHub بعد (auto_updater.py) — راجع المصمم")
    try:
        with _api_request(_contents_url(REVOCATION_FILE_PATH)) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return {}
        raise
    content_b64 = data.get("content", "")
    raw = base64.b64decode(content_b64.replace("\n", "")).decode("utf-8")
    parsed = json.loads(raw) if raw.strip() else {}
    return parsed if isinstance(parsed, dict) else {}


def push_revocation(write_token, hardware_id, reason, revoke=True):
    """ينشر/يسحب إلغاء ترخيص جهاز عميل على مستودع GitHub. write_token
    يُمرَّر من المتصل (لوحة المصمم) — يُقرأ من settings لحظياً، لا يُخزَّن
    بهذا الملف. revoke=False تعني رفع الإلغاء (استعادة الجهاز) بدل
    فرضه، بحذف معرّف الجهاز من القائمة بدل إضافته."""
    if not is_configured():
        raise RuntimeError("لم يتم إعداد بيانات GitHub بعد (auto_updater.py) — راجع المصمم")
    if not write_token:
        raise RuntimeError("أدخل توكن GitHub بصلاحية كتابة أولاً (قسم الإعدادات أسفل هذا القسم)")

    hardware_id = hardware_id.strip().upper()
    sha = None
    current = {}
    try:
        with _api_request(_contents_url(REVOCATION_FILE_PATH)) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        sha = data.get("sha")
        raw = base64.b64decode(data.get("content", "").replace("\n", "")).decode("utf-8")
        current = json.loads(raw) if raw.strip() else {}
        if not isinstance(current, dict):
            current = {}
    except urllib.error.HTTPError as e:
        if e.code != 404:
            raise
        # الملف غير موجود بعد — أول عملية إلغاء تنشئه

    if revoke:
        current[hardware_id] = {
            "reason": reason or "",
            "revoked_at": datetime.now().isoformat(timespec="seconds"),
        }
        commit_msg = f"Revoke license: {hardware_id}"
    else:
        current.pop(hardware_id, None)
        commit_msg = f"Restore license: {hardware_id}"

    new_content_b64 = base64.b64encode(json.dumps(current, ensure_ascii=False, indent=2).encode("utf-8")).decode("ascii")
    body = {"message": commit_msg, "content": new_content_b64}
    if sha:
        body["sha"] = sha

    req = urllib.request.Request(
        f"{API_BASE}{_contents_url(REVOCATION_FILE_PATH)}",
        data=json.dumps(body).encode("utf-8"), method="PUT",
    )
    req.add_header("Authorization", f"Bearer {write_token}")
    req.add_header("Accept", "application/vnd.github+json")
    req.add_header("X-GitHub-Api-Version", "2022-11-28")
    req.add_header("User-Agent", "LIS-Auto-Updater")
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=20):
        pass


def check_revocation(db):
    """يُستدعى بنفس دورة فحص التحديثات (تلقائياً كل CHECK_INTERVAL_HOURS
    أو يدوياً بزر 'تحقق من تحديث الآن'). يقارن معرّف جهاز هذا التنصيب
    بقائمة الإلغاء البعيدة، ولو موجود يقفل الترخيص محلياً فوراً (نفس أثر
    انتهاء الصلاحية، لكن بسبب مختلف يظهر للمستخدم)."""
    import license_manager
    try:
        revoked_map = fetch_revocation_list()
    except Exception:
        return  # فشل الاتصال بالإلغاء البعيد لا يوقف بقية الفحص أبداً
    hw = license_manager.get_hardware_id()
    entry = revoked_map.get(hw)
    if entry:
        license_manager.mark_revoked(db, entry.get("reason", ""))


# ================================================ إرسال تحديث فوري لعميل ==
# آلية مستقلة عن قناة التحديث (update_channel/branch) وعن الإلغاء — تخلي
# المصمم "يدفع" تحديثاً فورياً لجهاز عميل واحد بالذات دون انتظار دورة
# الفحص الدورية (قد تصل CHECK_INTERVAL_HOURS ساعات) ودون التأثير على بقية
# العملاء. تستخدم نفس أسلوب ملف JSON على GitHub المستخدَم بقائمة الإلغاء
# أعلاه (نفس توكن القراءة للفحص، وتوكن الكتابة الذي يدخله المصمم للنشر).
UPDATE_SIGNAL_FILE_PATH = "update_signals.json"


def fetch_update_signals():
    """يرجع dict {hardware_id: {requested_at}}. يرجع {} بهدوء لو الملف
    غير موجود بعد (لا يوجد أي أمر تحديث فوري صادر لحد الآن)."""
    if not is_configured():
        raise RuntimeError("لم يتم إعداد بيانات GitHub بعد (auto_updater.py) — راجع المصمم")
    try:
        with _api_request(_contents_url(UPDATE_SIGNAL_FILE_PATH)) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return {}
        raise
    content_b64 = data.get("content", "")
    raw = base64.b64decode(content_b64.replace("\n", "")).decode("utf-8")
    parsed = json.loads(raw) if raw.strip() else {}
    return parsed if isinstance(parsed, dict) else {}


def push_update_signal(write_token, hardware_id):
    """يسجّل طلب تحديث فوري لجهاز عميل واحد بالذات. write_token يُمرَّر من
    المتصل (لوحة المصمم)، نفس توكن الكتابة المستخدَم لإلغاء التراخيص عن
    بُعد. لا يحتاج "سحب" لاحقاً — كل جهاز يتحقق من الطابع الزمني
    (requested_at) الخاص به محلياً (راجع check_update_signal) فما يعيد
    تطبيق نفس أمر التحديث مرتين."""
    if not is_configured():
        raise RuntimeError("لم يتم إعداد بيانات GitHub بعد (auto_updater.py) — راجع المصمم")
    if not write_token:
        raise RuntimeError("أدخل توكن GitHub بصلاحية كتابة أولاً (قسم الإعدادات بلوحة المصمم)")

    hardware_id = hardware_id.strip().upper()
    sha = None
    current = {}
    try:
        with _api_request(_contents_url(UPDATE_SIGNAL_FILE_PATH)) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        sha = data.get("sha")
        raw = base64.b64decode(data.get("content", "").replace("\n", "")).decode("utf-8")
        current = json.loads(raw) if raw.strip() else {}
        if not isinstance(current, dict):
            current = {}
    except urllib.error.HTTPError as e:
        if e.code != 404:
            raise
        # الملف غير موجود بعد — أول أمر تحديث فوري ينشئه

    current[hardware_id] = {"requested_at": datetime.now().isoformat(timespec="seconds")}
    commit_msg = f"Push update signal: {hardware_id}"

    new_content_b64 = base64.b64encode(json.dumps(current, ensure_ascii=False, indent=2).encode("utf-8")).decode("ascii")
    body = {"message": commit_msg, "content": new_content_b64}
    if sha:
        body["sha"] = sha

    req = urllib.request.Request(
        f"{API_BASE}{_contents_url(UPDATE_SIGNAL_FILE_PATH)}",
        data=json.dumps(body).encode("utf-8"), method="PUT",
    )
    req.add_header("Authorization", f"Bearer {write_token}")
    req.add_header("Accept", "application/vnd.github+json")
    req.add_header("X-GitHub-Api-Version", "2022-11-28")
    req.add_header("User-Agent", "LIS-Auto-Updater")
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=20):
        pass


def check_update_signal(db):
    """يُستدعى بنفس دورة فحص التحديثات (خلفية دورية أو يدوياً بزر 'تحقق من
    تحديث الآن'). لو صدر أمر تحديث فوري لهذا الجهاز بالذات ولم يُطبَّق
    سابقاً (يقارن الطابع الزمني المحفوظ محلياً)، يفرض check_and_apply
    فوراً بغض النظر عن دورة الـ CHECK_INTERVAL_HOURS العادية. لا يحتاج
    توكن كتابة (فحص فقط بتوكن القراءة)، ولا يحذف نفسه من القائمة البعيدة —
    الحماية من التكرار محلية بالكامل عبر settings.last_applied_update_signal."""
    from database import get_setting, set_setting
    import license_manager
    try:
        signals = fetch_update_signals()
    except Exception:
        return  # فشل الاتصال لا يوقف بقية الفحص أبداً
    hw = license_manager.get_hardware_id()
    entry = signals.get(hw)
    if not entry:
        return
    requested_at = entry.get("requested_at", "")
    if not requested_at:
        return
    last_applied = get_setting(db, "last_applied_update_signal", "")
    if requested_at == last_applied:
        return  # نفس أمر التحديث هذا اتطبّق سابقاً على هذا الجهاز
    set_setting(db, "last_applied_update_signal", requested_at)
    db.commit()
    check_and_apply(db, force_apply=True)

# ======================================== إرسال إعدادات (تصاميم/أطباء/صور) لعميل محدد (v65) ==
# الإعدادات تُوقَّع بنفس مفتاح التحديثات (Ed25519) وتُرفع لمستودعك الخاص كملف client_configs/<HARDWARE_ID>.json.
# جهاز العميل يفحصها بنفس دورة الفحص (أو بزر "تحقق من تحديث الآن")، يتحقق من التوقيع بالمفتاح العام الموجود
# أصلًا ببرنامجه (lab_updater.PUBLIC_KEY_B64)، ثم يطبّقها. لا تُطبَّق نفس الحزمة مرتين (نقارن created المحفوظ).
CONFIG_PACK_DIR = "client_configs"
_config_applier = None


def set_config_applier(fn):
    """app.py يسجّل دالة fn(db, payload) -> رسالة. نفصلها هنا حتى ما يصير import دائري."""
    global _config_applier
    _config_applier = fn


def _config_path(hardware_id):
    return f"{CONFIG_PACK_DIR}/{hardware_id.strip().upper()}.json"


def push_config_pack(write_token, hardware_id, envelope):
    """يكتب/يحدّث client_configs/<HW>.json بالمستودع الخاص. envelope = {created, sig, payload}."""
    if not is_configured():
        raise RuntimeError("لم يتم إعداد بيانات GitHub بعد (auto_updater.py) — راجع المصمم")
    if not write_token:
        raise RuntimeError("أدخل توكن GitHub بصلاحية كتابة أولاً (قسم الإعدادات بلوحة المصمم)")
    path = _config_path(hardware_id)
    sha = None
    try:
        with _api_request(_contents_url(path)) as resp:
            sha = json.loads(resp.read().decode("utf-8")).get("sha")
    except urllib.error.HTTPError as e:
        if e.code != 404:
            raise
    raw = json.dumps(envelope, ensure_ascii=False).encode("utf-8")
    if len(raw) > 20 * 1024 * 1024:
        raise RuntimeError("حجم الإعدادات كبير (أكثر من 20MB) — قلّل الصور")
    body = {"message": f"Push config pack: {hardware_id.strip().upper()}",
            "content": base64.b64encode(raw).decode("ascii")}
    if sha:
        body["sha"] = sha
    req = urllib.request.Request(f"{API_BASE}{_contents_url(path)}", data=json.dumps(body).encode("utf-8"), method="PUT")
    req.add_header("Authorization", f"Bearer {write_token}")
    req.add_header("Accept", "application/vnd.github+json")
    req.add_header("X-GitHub-Api-Version", "2022-11-28")
    req.add_header("User-Agent", "LIS-Auto-Updater")
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=60):
        pass


def fetch_config_pack(hardware_id):
    """يرجّع dict الحزمة أو None لو ما فيه حزمة لهذا الجهاز (404)."""
    try:
        with _api_request(_contents_url(_config_path(hardware_id)), accept="application/vnd.github.raw") as resp:
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise
    return json.loads(raw) if raw.strip() else None


def check_config_pack(db):
    """يرجّع رسالة نصية لو طُبّقت حزمة جديدة، وإلا None. لا يرفع استثناء للاتصال (لا يوقف بقية الفحص)."""
    import hashlib
    from database import get_setting, set_setting
    import license_manager
    try:
        hw = license_manager.get_hardware_id()
        env = fetch_config_pack(hw)
    except Exception:
        return None
    if not env or not isinstance(env, dict):
        return None
    created, sig, payload = env.get("created", ""), env.get("sig", ""), env.get("payload")
    if not created or not sig or not isinstance(payload, dict):
        return None
    if created == get_setting(db, "last_applied_config_pack", ""):
        return None
    now = datetime.now().isoformat(timespec="seconds")
    try:
        import lab_updater
        digest = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False,
                                           separators=(",", ":")).encode("utf-8")).hexdigest()
        ok, why = lab_updater.verify_signature(created, digest, sig)
        if not ok:
            raise RuntimeError(why or "توقيع الإعدادات غير صحيح")
        if _config_applier is None:
            raise RuntimeError("مطبّق الإعدادات غير مسجّل")
        msg = _config_applier(db, payload)
        set_setting(db, "last_applied_config_pack", created)
        set_setting(db, "config_pack_last_status", f"✅ {now} — {msg}")
        db.commit()
        return msg
    except Exception as e:
        try:
            set_setting(db, "config_pack_last_status", f"⚠️ {now} — تعذر تطبيق الإعدادات: {e}")
            db.commit()
        except Exception:
            pass
        return None
